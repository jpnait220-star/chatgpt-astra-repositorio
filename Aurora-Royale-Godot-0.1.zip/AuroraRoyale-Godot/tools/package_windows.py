"""Export a PCK with a locally installed Godot, then bundle an official same-version Windows runtime.
Usage: python tools/package_windows.py --runtime /path/Godot_v4.6.3-stable_win64.exe --out /path/output
For a small standard executable, instead install the official export templates and export in Godot.
"""
import argparse, pathlib, shutil, subprocess, zipfile
p=argparse.ArgumentParser();p.add_argument('--runtime',type=pathlib.Path,required=True);p.add_argument('--godot',default='godot');p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
r=pathlib.Path(__file__).resolve().parents[1];dest=a.out.resolve();dest.mkdir(parents=True,exist_ok=True)
subprocess.run([a.godot,'--headless','--path',str(r),'--editor','--import'],check=True)
subprocess.run([a.godot,'--headless','--path',str(r),'--export-pack','Windows Desktop',str(dest/'AuroraRoyale.pck')],check=True)
shutil.copy2(a.runtime,dest/'AuroraRoyale.exe')
shutil.copy2(r/'README.md',dest/'README.md');shutil.copy2(r/'LICENSE.txt',dest/'LICENSE.txt');shutil.copytree(r/'docs',dest/'docs',dirs_exist_ok=True)
with zipfile.ZipFile(dest.parent/'Aurora-Royale-Windows.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(dest.rglob('*')):
  if f.is_file():z.write(f,pathlib.Path('AuroraRoyale')/f.relative_to(dest))
