#!/usr/bin/env bash
set -eu
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
"${GODOT_BIN:-godot}" --headless --path "$project_root" -- --smoke
