class_name Cover
extends StaticBody3D

var hp := 300.0
var max_hp := 300.0
var expires := 0.0
var kind := 0
var game
var occupied_cells: Array[Vector2i]=[]

func create(owner_game, type: int, at: Vector3, angle: float) -> void:
	game=owner_game
	kind=type
	position=at
	rotation.y=angle
	var size = [Vector3(6.6,2.8,0.8),Vector3(5.5,3.2,0.3),Vector3(5.5,0.3,6.2),Vector3(5.5,0.28,5.5)][kind]
	var shape=BoxShape3D.new()
	shape.size=size
	var cs=CollisionShape3D.new()
	cs.shape=shape
	if kind==2:
		cs.rotation.x=deg_to_rad(32)
		cs.position.y=1.5
	elif kind!=3:cs.position.y=size.y/2
	add_child(cs)
	var frame=Node3D.new()
	frame.transform=cs.transform
	add_child(frame)
	if kind==0:
		hp=600
		max_hp=600
		expires=game.elapsed+55
		var ice_mat=Forge.mat(Color("95dce2"),0.26,0.15)
		for j in range(7):
			var height=2.55+sin(j*1.9)*0.2
			var shard=Forge.box(frame,Vector3((j-3)*0.92,(height-2.8)/2,abs(j-3)*0.13),Vector3(1.03,height,0.8),ice_mat)
			shard.rotation.z=sin(j*2.1)*0.04
			Forge.box(shard,Vector3(0.12,0.1,-0.411),Vector3(0.045,height*0.7,0.02),Forge.mat(Color("e2ffff"),0.2))
	else:
		max_hp=300 if kind!=1 else 250
		hp=max_hp
		var plank=Forge.mat(Color("95755b"))
		Forge.box(frame,Vector3.ZERO,size,plank)
		for x in [-size.x*0.42,size.x*0.42]:
			Forge.box(frame,Vector3(x,0,-0.06),Vector3(0.16,size.y+0.14,size.z+0.18),Forge.mat(Color("56483d")))
		if kind==1:
			for y in [-1.1,-0.3,0.5,1.3]:Forge.box(frame,Vector3(0,y,-0.18),Vector3(5.4,0.04,0.04),Forge.mat(Color("514d43")))

func damage(amount: float,_attacker = null,_head = false) -> void:
	hp-=amount
	if hp<=0:destroy()

func destroy() -> void:
	if not is_queued_for_deletion():
		collision_layer=0
		game.sound_at("break",global_position,-13)
		queue_free()

func _physics_process(_dt: float) -> void:
	if expires>0 and game.elapsed>=expires:destroy()

func _exit_tree() -> void:
	if is_instance_valid(game) and is_instance_valid(game.island):game.island.remove_dynamic(self)
