extends Node3D

var island: Island
var fighters: Array[Fighter]=[]
var supplies: Array[Supply]=[]
var covers: Array[Cover]=[]
var player: Fighter
var ranger_scene: PackedScene=preload("res://assets/ranger.glb")
var running := false
var paused := false
var loading := false
var elapsed := 0.0
var difficulty := 1
var quality := 1
var sensitivity := 0.0022
var zone_center := Vector3.ZERO
var zone_radius := 218.0
var zone_damage := 4.0
var zone_mesh: MeshInstance3D
var preview: MeshInstance3D
var build_mode := false
var build_kind := 1
var build_rotation := 0.0
var placement := Vector3.ZERO
var placement_yaw := 0.0
var place_valid := false
var next_build := 0.0
var hurt_flash := 0.0
var hit_flash := 0.0
var hit_head := false
var shots_fired := 0
var hit_count := 0
var tracers := 0
var audio_count := 0
var message := ""
var message_left := 0.0
var feed: Array[String]=[]
var numbers: Array[Dictionary]=[]
var gui: CanvasLayer
var hud: Control
var menu: Control
var menu_box: VBoxContainer
var flycam: Camera3D
var environment: WorldEnvironment
var sun: DirectionalLight3D
var rng := RandomNumberGenerator.new()
var loot_tick := 0.0
var save := ConfigFile.new()
var map_ready := false
var smoke_mode := false
var screenshot_mode := false
var smoke_clock := 0.0
var match_index := 0
var checks: Array[String]=[]

func _ready() -> void:
	rng.randomize()
	smoke_mode="--smoke" in OS.get_cmdline_user_args()
	screenshot_mode="--capture" in OS.get_cmdline_user_args()
	setup_inputs()
	load_settings()
	Ambience.make_sounds()
	var limiter=AudioEffectLimiter.new()
	limiter.ceiling_db=-1
	limiter.threshold_db=-7
	AudioServer.add_bus_effect(0,limiter)
	create_sky()
	island=Island.new()
	island.game=self
	add_child(island)
	island.generate()
	map_ready=true
	flycam=Camera3D.new()
	flycam.far=1400
	flycam.position=Vector3(105,76,132)
	add_child(flycam)
	flycam.look_at(Vector3(0,0,-12))
	flycam.current=true
	create_zone()
	preview=MeshInstance3D.new()
	var shape=BoxMesh.new()
	shape.size=Vector3(5.5,3.2,0.3)
	preview.mesh=shape
	preview.visible=false
	add_child(preview)
	gui=CanvasLayer.new()
	add_child(gui)
	hud=load("res://scripts/hud.gd").new()
	hud.game=self
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter=Control.MOUSE_FILTER_IGNORE
	gui.add_child(hud)
	apply_quality()
	show_menu()
	if smoke_mode or screenshot_mode:call_deferred("start_match")
	if "--capture-menu" in OS.get_cmdline_user_args():call_deferred("capture_menu")

func setup_inputs() -> void:
	var keys={"forward":KEY_W,"back":KEY_S,"left":KEY_A,"right":KEY_D,"sprint":KEY_SHIFT,"crouch":KEY_CTRL,"jump":KEY_SPACE,"reload":KEY_R,"ice":KEY_G,"build":KEY_B,"interact":KEY_E,"heal":KEY_H,"one":KEY_1,"two":KEY_2,"three":KEY_3,"wall":KEY_Z,"ramp":KEY_X,"floor":KEY_C,"pause":KEY_ESCAPE,"fullscreen":KEY_F11,"help":KEY_F1,"jetpack":KEY_J}
	for action in keys:
		InputMap.add_action(action)
		var event=InputEventKey.new()
		event.physical_keycode=keys[action]
		InputMap.action_add_event(action,event)
	for action in ["fire","aim"]:
		InputMap.add_action(action)
		var event=InputEventMouseButton.new()
		event.button_index=MOUSE_BUTTON_LEFT if action=="fire" else MOUSE_BUTTON_RIGHT
		InputMap.action_add_event(action,event)

func create_sky() -> void:
	environment=WorldEnvironment.new()
	var env=Environment.new()
	env.background_mode=Environment.BG_SKY
	var sky=Sky.new()
	var sky_mat=ProceduralSkyMaterial.new()
	sky_mat.sky_top_color=Color("45677d")
	sky_mat.sky_horizon_color=Color("bdc9c3")
	sky_mat.ground_horizon_color=Color("aab8af")
	sky_mat.ground_bottom_color=Color("4a665d")
	sky.sky_material=sky_mat
	env.sky=sky
	env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color=Color("a5c1c8")
	env.ambient_light_energy=0.3
	env.tonemap_mode=Environment.TONE_MAPPER_FILMIC
	env.fog_enabled=true
	env.fog_light_color=Color("b1c1bc")
	env.fog_density=0.0015
	env.fog_sky_affect=0.35
	environment.environment=env
	add_child(environment)
	sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-34,-38,0)
	sun.light_color=Color("ffe3b0")
	sun.light_energy=0.95
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=105
	add_child(sun)

func create_zone() -> void:
	zone_mesh=MeshInstance3D.new()
	var mesh=CylinderMesh.new()
	mesh.top_radius=1
	mesh.bottom_radius=1
	mesh.height=95
	mesh.radial_segments=128
	mesh.cap_top=false
	mesh.cap_bottom=false
	zone_mesh.mesh=mesh
	var material=StandardMaterial3D.new()
	material.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color=Color(0.32,0.39,0.9,0.14)
	material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode=BaseMaterial3D.CULL_DISABLED
	zone_mesh.material_override=material
	zone_mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	zone_mesh.position.y=42
	zone_mesh.scale=Vector3(zone_radius,1,zone_radius)
	zone_mesh.visible=false
	add_child(zone_mesh)

func start_match() -> void:
	if loading:return
	loading=true
	running=false
	paused=false
	close_menu()
	notice("Preparando a ilha e os 50 adversários…",20)
	for a in fighters:
		if is_instance_valid(a):a.queue_free()
	for item in supplies:
		if is_instance_valid(item):item.queue_free()
	for c in covers:
		if is_instance_valid(c):c.queue_free()
	fighters.clear();supplies.clear();covers.clear();numbers.clear();feed.clear()
	player=null
	await get_tree().process_frame
	elapsed=0;zone_radius=218;zone_center=Vector3.ZERO;zone_damage=4
	shots_fired=0;hit_count=0;build_mode=false;build_rotation=0
	hurt_flash=0;hit_flash=0
	match_index+=1
	player=Fighter.new()
	add_child(player)
	player.setup(self,true,0)
	player.position=Vector3(0,0.25,-35)
	fighters.append(player)
	var used: Array[Vector3]=[player.position]
	for index in range(50):
		var bot=Fighter.new()
		add_child(bot)
		bot.setup(self,false,index)
		var p=island.spawn_points[rng.randi()%island.spawn_points.size()]
		for attempt in range(60):
			var safe=true
			for other in used:
				if p.distance_to(other)<10:safe=false;break
			if safe and p.distance_to(player.position)>22:break
			p=island.spawn_points[rng.randi()%island.spawn_points.size()]
		bot.position=p+Vector3.UP*0.15
		used.append(p)
		fighters.append(bot)
		if index%5==0:await get_tree().process_frame
	for index in range(110):
		var p=island.spawn_points[rng.randi()%island.spawn_points.size()]
		spawn_supply(index%5,p)
	# Supplies within walking distance make the first minutes approachable.
	for i in range(5):spawn_supply(i,Vector3(-5+i*2.5,0.1,-39))
	for i in range(18):spawn_supply(5,island.spawn_points[rng.randi()%island.spawn_points.size()])
	for i in range(15):spawn_supply(6,island.spawn_points[rng.randi()%island.spawn_points.size()])
	# Exactly two jetpacks per match, placed away from the starter supplies.
	var rare_points=island.spawn_points.filter(func(p):return p.distance_to(player.position)>65)
	for i in range(2):
		var rare_index=(rng.randi()%maxi(1,rare_points.size()/2))+(i*rare_points.size()/2)
		spawn_supply(7,rare_points[rare_index])
	flycam.current=false
	player.camera.current=true
	zone_mesh.visible=true
	loading=false
	running=true
	Input.mouse_mode=Input.MOUSE_MODE_CAPTURED if not smoke_mode and not screenshot_mode else Input.MOUSE_MODE_VISIBLE
	notice("OPERAÇÃO INICIADA · 50 bots · sobreviva até o fim",5)
	if smoke_mode:await run_checks()

func _process(dt: float) -> void:
	if not running and not loading and not player:
		var t=Time.get_ticks_msec()*0.000018
		flycam.position=Vector3(125*cos(t),77,125*sin(t))
		flycam.look_at(Vector3(0,0,0))
	if running and not paused:
		elapsed+=dt
		update_zone()
		hurt_flash=maxf(0,hurt_flash-dt)
		hit_flash=maxf(0,hit_flash-dt)
		next_build=maxf(0,next_build-dt)
		message_left=maxf(0,message_left-dt)
		loot_tick-=dt
		if loot_tick<=0:
			loot_tick=0.25
			if player and player.alive:auto_loot(player)
		if build_mode:update_preview()
		for n in numbers:n.time-=dt;n.position.y+=dt*0.6
		numbers=numbers.filter(func(n):return n.time>0)
	if screenshot_mode and running:
		smoke_clock+=dt
		if smoke_clock>0.6:
			screenshot_mode=false
			paused=true
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png("user://captura-jogo.png")
			print("CAPTURE ",ProjectSettings.globalize_path("user://captura-jogo.png"))
			get_tree().quit()
	if hud:hud.queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("fullscreen"):
		var mode=DisplayServer.window_get_mode()
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if mode==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
	if event.is_action_pressed("pause") and running:
		if paused:close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
		else:paused=true;show_menu(true)
		return
	if not running or paused or not player or not player.alive:return
	if event is InputEventMouseMotion and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:
		player.yaw-=event.relative.x*sensitivity
		player.pitch=clampf(player.pitch-event.relative.y*sensitivity,-1.2,0.95)
	if event.is_action_pressed("help"):paused=true;show_help();return
	if event.is_action_pressed("reload"):
		if build_mode:build_rotation+=PI/2
		else:player.reload_weapon()
	if event.is_action_pressed("jetpack") and player.has_jetpack:
		player.jet_enabled=not player.jet_enabled
		notice("Jetpack ligado · Espaço para voar" if player.jet_enabled else "Jetpack desligado",2)
	if event.is_action_pressed("one"):player.switch_weapon(0);build_mode=false
	if event.is_action_pressed("two"):player.switch_weapon(1);build_mode=false
	if event.is_action_pressed("three"):player.switch_weapon(2);build_mode=false
	if event.is_action_pressed("build"):build_mode=not build_mode
	if event.is_action_pressed("wall"):build_kind=1;build_mode=true
	if event.is_action_pressed("ramp"):build_kind=2;build_mode=true
	if event.is_action_pressed("floor"):build_kind=3;build_mode=true
	if event.is_action_pressed("ice"):place_cover(0)
	if event.is_action_pressed("heal") and player.kits>0 and player.hp<100 and player.heal_left<=0:
		player.heal_left=2.8
		player.reload_left=0
		sound_at("heal",player.global_position,-12)
	if event.is_action_pressed("interact"):auto_loot(player,4)
	if event.is_action_pressed("fire") and build_mode:place_cover(build_kind)
	if not build_mode:preview.visible=false

func update_zone() -> void:
	# 75 seconds to loot, then five progressive contractions.
	var old=zone_radius
	if elapsed<75:zone_radius=218
	elif elapsed<210:zone_radius=lerpf(218,150,(elapsed-75)/135)
	elif elapsed<345:zone_radius=lerpf(150,92,(elapsed-210)/135)
	elif elapsed<465:zone_radius=lerpf(92,45,(elapsed-345)/120)
	elif elapsed<570:zone_radius=lerpf(45,16,(elapsed-465)/105)
	else:zone_radius=maxf(2,16-(elapsed-570)*0.25)
	zone_damage=4+floorf(elapsed/120)*2
	zone_mesh.scale=Vector3(zone_radius,1,zone_radius)
	if old>=150 and zone_radius<150:notice("A zona está fechando · procure a área segura",4)

func alive_count() -> int:
	var count=0
	for f in fighters:
		if is_instance_valid(f) and f.alive:count+=1
	return count

func has_sight(a: Fighter,b: Fighter) -> bool:
	var from=a.global_position+Vector3(0,1.5,0)
	var to=b.global_position+Vector3(0,1.2,0)
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(from,to,3,[a.get_rid()]))
	return hit.is_empty() or hit.collider==b

func fire_ray(actor: Fighter,from: Vector3,to: Vector3,damage: float) -> Dictionary:
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(from,to,3,[actor.get_rid()]))
	var end=hit.position if not hit.is_empty() else to
	if tracers<55:
		tracers+=1
		var line=Forge.line(self,from,end,Color("ffdf9d"),0.018 if actor.human else 0.012)
		get_tree().create_timer(0.055).timeout.connect(func():if is_instance_valid(line):line.queue_free();tracers-=1)
	if not hit.is_empty():
		var body=hit.collider
		if body is Fighter or body is Cover:
			var head=body is Fighter and hit.position.y-body.global_position.y>1.48
			var falloff=damage_multiplier(actor.slot,from.distance_to(hit.position))
			var health_before=body.hp
			body.damage(damage*falloff,actor,head)
			if actor.human:
				if hit_flash<=0:sound_at("hit",actor.global_position,-11)
				hit_flash=0.16
				hit_head=head
				hit_count+=1
				var merged=false
				for n in numbers:
					if n.get("body",-1)==body.get_instance_id() and n.time>0.68:
						n.amount+=maxi(1,roundi(health_before-body.hp));n.head=n.head or head;merged=true;break
				if not merged:numbers.append({"body":body.get_instance_id(),"position":hit.position+Vector3.UP*0.25,"amount":maxi(1,roundi(health_before-body.hp)),"time":0.8,"head":head})
	return hit

func get_placement(kind: int) -> Dictionary:
	var direction=Vector3(-sin(player.yaw),0,-cos(player.yaw))
	var at=player.global_position+direction*(5.0 if kind==2 else 4.6)
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(at+Vector3.UP*8,at-Vector3.UP*12,1))
	if hit.is_empty():return {"valid":false,"position":at,"yaw":player.yaw+build_rotation}
	if kind==0 and hit.collider is Cover:return {"valid":false,"position":at,"yaw":player.yaw+build_rotation}
	at.y=hit.position.y+0.06
	var angle=snappedf(player.yaw+build_rotation,PI/12)
	var height=2.8 if kind==0 else 3.2 if kind!=3 else 0.28
	var size=Vector3(6.7 if kind==0 else 5.5,height,0.9 if kind==0 else 0.4 if kind==1 else 6.2)
	var shape=BoxShape3D.new()
	shape.size=size*0.94
	var q=PhysicsShapeQueryParameters3D.new()
	q.shape=shape
	q.transform=Transform3D(Basis(Vector3.UP,angle),at+Vector3.UP*(height/2+0.05))
	q.collision_mask=3
	q.exclude=[player.get_rid()]
	var result=get_world_3d().direct_space_state.intersect_shape(q,6)
	var valid=result.is_empty() and at.distance_to(player.global_position)<10 and at.y-player.global_position.y<5
	if kind==0:valid=valid and player.ice>0
	else:valid=valid and player.materials>=30
	return {"valid":valid,"position":at,"yaw":angle}

func update_preview() -> void:
	var place=get_placement(build_kind)
	place_valid=place.valid
	placement=place.position
	placement_yaw=place.yaw
	preview.visible=true
	var size=[Vector3(6.6,2.8,0.8),Vector3(5.5,3.2,0.3),Vector3(5.5,0.3,6.2),Vector3(5.5,0.28,5.5)][build_kind]
	(preview.mesh as BoxMesh).size=size
	preview.rotation=Vector3(deg_to_rad(32) if build_kind==2 else 0,placement_yaw,0)
	preview.position=placement+Vector3.UP*(1.5 if build_kind==2 else size.y/2)
	var mat=StandardMaterial3D.new()
	mat.albedo_color=Color(0.3,0.95,0.8,0.42) if place_valid else Color(1,0.25,0.2,0.4)
	mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	preview.material_override=mat

func place_cover(kind: int) -> bool:
	if next_build>0:return false
	var place=get_placement(kind)
	if not place.valid:
		notice("Sem espaço ou recursos · mire numa área livre",2)
		return false
	covers=covers.filter(func(c):return is_instance_valid(c))
	if covers.size()>=90:
		notice("Limite de 90 construções na ilha",2)
		return false
	var c=Cover.new()
	add_child(c)
	c.create(self,kind,place.position,place.yaw)
	covers.append(c)
	var visuals=c.get_child(1) as Node3D
	visuals.scale=Vector3.ONE*0.15
	c.create_tween().tween_property(visuals,"scale",Vector3.ONE,0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	island.add_dynamic(c)
	if kind==0:player.ice-=1
	else:player.materials-=30
	next_build=0.35
	sound_at("ice" if kind==0 else "build",place.position,-9)
	return true

func spawn_supply(kind: int,at: Vector3) -> Supply:
	var item=Supply.new()
	add_child(item)
	item.create(self,kind,at)
	supplies.append(item)
	return item

func auto_loot(actor: Fighter,distance: float = 1.8) -> void:
	for item in supplies:
		if not is_instance_valid(item) or item.taken:continue
		if actor.global_position.distance_squared_to(item.global_position)<distance*distance:
			var text=item.take(actor)
			if actor.human and not text.is_empty():notice(text,2.5);sound_at("pickup",actor.global_position,-12)

func on_eliminated(victim: Fighter,killer: Fighter) -> void:
	feed.push_front((killer.nickname if killer else "ZONA")+"  ›  "+victim.nickname)
	if feed.size()>4:feed.pop_back()
	spawn_supply(1,victim.global_position)
	spawn_supply(0,victim.global_position+Vector3(1.5,0,0))
	if victim.has_jetpack:spawn_supply(7,victim.global_position+Vector3(-1.5,0,0))
	if victim.armor_level>0 and victim.armor>0:
		var item=spawn_supply(5,victim.global_position+Vector3(0,0,1.5))
		item.tier=victim.armor_level
	if victim.helmet_level>0 and victim.helmet_durability>0:
		var item=spawn_supply(6,victim.global_position+Vector3(0,0,-1.5))
		item.tier=victim.helmet_level
	if smoke_mode:return
	if victim.human:
		finish_match(false)
	elif alive_count()==1 and player.alive:finish_match(true)

func finish_match(won: bool) -> void:
	running=false
	preview.visible=false
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	show_menu(false,("VITÓRIA ROYALE" if won else "FIM DA OPERAÇÃO"))

func notice(text: String,seconds: float = 3) -> void:
	message=text
	message_left=seconds

func sound_at(name: String,at: Vector3,db: float) -> void:
	if audio_count>=28 or not Ambience.sounds.has(name) or smoke_mode:return
	if player and at.distance_squared_to(player.global_position)>90*90:return
	audio_count+=1
	var sound=AudioStreamPlayer3D.new()
	sound.stream=Ambience.sounds[name]
	sound.volume_db=db
	sound.pitch_scale=randf_range(0.88,1.12) if name in ["step","shot","smg","shotgun","land"] else 1.0
	sound.max_distance=90
	sound.unit_size=6
	add_child(sound)
	sound.global_position=at+Vector3.UP
	sound.finished.connect(func():sound.queue_free();audio_count-=1)
	sound.play()

func load_settings() -> void:
	if save.load("user://settings.cfg")==OK:
		sensitivity=float(save.get_value("settings","sensitivity",0.0022))
		quality=int(save.get_value("settings","quality",1))
		difficulty=int(save.get_value("settings","difficulty",1))
		AudioServer.set_bus_volume_db(0,float(save.get_value("settings","volume",-5)))

func save_settings() -> void:
	for key in ["sensitivity","quality","difficulty"]:save.set_value("settings",key,get(key))
	save.set_value("settings","volume",AudioServer.get_bus_volume_db(0))
	save.save("user://settings.cfg")

func apply_quality() -> void:
	sun.shadow_enabled=quality>0
	get_viewport().msaa_3d=[Viewport.MSAA_DISABLED,Viewport.MSAA_2X,Viewport.MSAA_4X][quality]
	get_viewport().scaling_3d_scale=[0.8,1.0,1.0][quality]

func show_menu(in_match: bool = false,title: String = "") -> void:
	close_menu()
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	menu=Control.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gui.add_child(menu)
	var backdrop=ColorRect.new()
	backdrop.color=Color(0.035,0.07,0.09,0.55)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(backdrop)
	var left=VBoxContainer.new()
	left.position=Vector2(64,78)
	left.add_theme_constant_override("separation",12)
	menu.add_child(left)
	label(left,"A U R O R A",56,Color("ecf5ec"))
	label(left,"R O Y A L E",26,Color("8ce1d0"))
	label(left,"ILHA VÉSPER  /  OPERAÇÃO 01",16,Color("efd6ac"))
	label(left,"Uma ilha. Cinquenta adversários.\nA última escolha é sobreviver.",18,Color("d1dedc"))
	var line=ColorRect.new()
	line.color=Color("8ce1d0")
	line.custom_minimum_size=Vector2(62,3)
	left.add_child(line)
	label(left,"TIRO EM TERCEIRA PESSOA\nGELO DEFENSIVO · CONSTRUÇÃO RÁPIDA\nPARTIDA OFFLINE · ZONA DINÂMICA",13,Color("ced8d2"))
	var panel=PanelContainer.new()
	panel.position=Vector2(804,58)
	panel.size=Vector2(412,602)
	var style=StyleBoxFlat.new()
	style.bg_color=Color(0.045,0.09,0.11,0.96)
	style.corner_radius_top_left=18;style.corner_radius_top_right=18;style.corner_radius_bottom_left=18;style.corner_radius_bottom_right=18
	style.content_margin_left=28;style.content_margin_right=28;style.content_margin_top=26;style.content_margin_bottom=22
	style.border_width_top=1;style.border_color=Color("44625e")
	panel.add_theme_stylebox_override("panel",style)
	menu.add_child(panel)
	var scroll=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(350,536)
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	menu_box=VBoxContainer.new()
	menu_box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	menu_box.add_theme_constant_override("separation",10)
	scroll.add_child(menu_box)
	label(menu_box,title if title!="" else "PAUSADO" if in_match else "PRONTO PARA A ILHA?",23,Color("f3eedf"))
	if player and not running and not loading:
		label(menu_box,"%d eliminações   •   %02d:%02d de partida" % [player.kills,int(elapsed)/60,int(elapsed)%60],14,Color("8ce1d0"))
	else:label(menu_box,"SOLO   /   50 BOTS   /   SEM INTERNET",12,Color("8ce1d0"))
	if in_match:button(menu_box,"CONTINUAR",func():close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED,true)
	else:button(menu_box,"JOGAR AGORA   →",start_match,true)
	label(menu_box,"DIFICULDADE DOS BOTS",12,Color("aabdbb"))
	var difficulty_option=OptionButton.new()
	for text in ["Recruta · mais tempo para reagir","Operador · combate equilibrado","Veterano · bots mais precisos"]:difficulty_option.add_item(text)
	difficulty_option.selected=difficulty
	difficulty_option.item_selected.connect(func(i):difficulty=i;save_settings())
	menu_box.add_child(difficulty_option)
	label(menu_box,"QUALIDADE VISUAL",12,Color("aabdbb"))
	var graphics=OptionButton.new()
	for text in ["Leve · sem sombras","Equilibrado · sombras + 2× AA","Alto · sombras + 4× AA"]:graphics.add_item(text)
	graphics.selected=quality
	graphics.item_selected.connect(func(i):quality=i;apply_quality();save_settings())
	menu_box.add_child(graphics)
	label(menu_box,"SENSIBILIDADE DO MOUSE",12,Color("aabdbb"))
	var slider=HSlider.new()
	slider.min_value=0.0006;slider.max_value=0.005;slider.step=0.0001;slider.value=sensitivity
	slider.value_changed.connect(func(v):sensitivity=v;save_settings())
	menu_box.add_child(slider)
	label(menu_box,"VOLUME",12,Color("aabdbb"))
	var volume=HSlider.new()
	volume.min_value=-40;volume.max_value=0;volume.value=AudioServer.get_bus_volume_db(0)
	volume.value_changed.connect(func(v):AudioServer.set_bus_volume_db(0,v);save_settings())
	menu_box.add_child(volume)
	button(menu_box,"COMO JOGAR  /  CONTROLES",show_help)
	if in_match:button(menu_box,"RECOMEÇAR PARTIDA",start_match)
	button(menu_box,"CRÉDITOS",show_credits)
	button(menu_box,"SAIR",func():get_tree().quit())
	var footer=Label.new()
	footer.text="ALPHA 0.1   •   GODOT 4   •   IDENTIDADE ORIGINAL"
	footer.position=Vector2(64,662)
	footer.add_theme_color_override("font_color",Color("d1dedc"))
	footer.add_theme_font_size_override("font_size",12)
	menu.add_child(footer)

func show_help() -> void:
	close_menu()
	menu=Control.new()
	gui.add_child(menu)
	var panel=PanelContainer.new()
	panel.position=Vector2(240,55)
	panel.size=Vector2(800,610)
	var style=StyleBoxFlat.new()
	style.bg_color=Color("12272e")
	style.content_margin_left=35;style.content_margin_top=28;style.content_margin_right=35;style.content_margin_bottom=28
	panel.add_theme_stylebox_override("panel",style)
	menu.add_child(panel)
	var scroll=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(720,530)
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var box=VBoxContainer.new()
	box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation",15)
	scroll.add_child(box)
	label(box,"SEU GUIA DE SOBREVIVÊNCIA",26,Color("8ce1d0"))
	label(box,"W A S D  mover    •    Mouse  olhar    •    Shift  correr\nEspaço  pular / atravessar janela    •    Ctrl  andar devagar\n\nClique esquerdo  atirar    •    Direito  mirar\nR  recarregar    •    1 / 2 / 3  trocar arma\nH  usar kit (2,8 segundos; dano interrompe)\nJ  liga/desliga jetpack raro; segure Espaço para voar\n\nG  colocar gelo (600 de vida; dura 55 segundos)\nB  entrar/sair da construção\nZ  parede    •    X  rampa    •    C  piso\nClique esquerdo  construir    •    R  girar construção\n\nE  coletar perto (também há coleta automática)\nEsc  pausar    •    F1  ajuda    •    F11  tela cheia",17,Color("e2ece5"))
	label(box,"Gelo e madeira bloqueiam tiros e podem ser destruídos.\nAs rampas são escaláveis. Fique dentro da zona azul.\nDesbloqueie armas nas caixas. Seja o último sobrevivente.",15,Color("e1c693"))
	button(box,"ENTENDI  →",func():
		if running:close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
		else:show_menu(),true)
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE

func close_menu() -> void:
	if is_instance_valid(menu):menu.queue_free()
	menu=null

func label(parent: Node,text: String,size: int,color: Color) -> Label:
	var l=Label.new()
	l.text=text
	l.add_theme_font_override("font",load("res://assets/interface.ttf"))
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	parent.add_child(l)
	return l

func button(parent: Node,text: String,action: Callable,primary: bool = false) -> Button:
	var b=Button.new()
	b.text=text
	b.custom_minimum_size.y=43
	b.add_theme_font_size_override("font_size",15)
	for state in ["normal","hover","pressed","focus"]:
		var style=StyleBoxFlat.new()
		style.bg_color=(Color("92dfce") if state=="normal" else Color("b9efdf")) if primary else (Color("203c43") if state=="normal" else Color("31535a"))
		style.corner_radius_top_left=8;style.corner_radius_top_right=8;style.corner_radius_bottom_left=8;style.corner_radius_bottom_right=8
		b.add_theme_stylebox_override(state,style)
	b.add_theme_color_override("font_color",Color("11272a") if primary else Color("edf1e8"))
	b.add_theme_color_override("font_hover_color",Color("11272a") if primary else Color.WHITE)
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func run_checks() -> void:
	await get_tree().physics_frame
	for f in fighters:
		if not f.human:f.set_physics_process(false)
	check(fighters.size()==51,"50 bots + 1 player")
	check(alive_count()==51,"51 vivos no início")
	check(supplies.size()==150,"150 suprimentos reais")
	check(island.grid.region.get_area()>10000,"malha de rotas preenchida")
	var path=island.path(Vector3(0,0,-35),Vector3(50,0,48))
	check(path.size()>3,"rotas entre obstáculos")
	check(player.camera!=null and player.anim!=null,"câmera e modelo animado")
	var old_pos=player.position
	player.position=Vector3(0,0.2,-180)
	player.yaw=0
	await get_tree().physics_frame
	check(place_cover(0),"gelo construído com colisão")
	check(player.ice==7,"gelo consome recurso")
	await get_tree().physics_frame
	next_build=0
	check(not place_cover(0),"sobreposição de gelo bloqueada")
	if not covers.is_empty():
		var c=covers[0]
		var hp_before=c.hp
		fire_ray(player,c.position+Vector3(0,1.4,4),c.position+Vector3(0,1.4,-4),30)
		check(c.hp<hp_before,"tiro acerta e danifica gelo")
		c.damage(9999)
	await get_tree().physics_frame
	next_build=0
	check(place_cover(1),"parede construída")
	check(player.materials==420,"madeira consome 30 materiais")
	player.position=old_pos
	var bot=fighters[1]
	bot.position=Vector3(0,0.3,-45)
	await get_tree().physics_frame
	var before=bot.hp+bot.armor
	fire_ray(player,Vector3(0,1.2,-40),Vector3(0,1.2,-48),24)
	check(bot.hp+bot.armor<before,"tiro atinge adversário")
	var item=Supply.new()
	add_child(item)
	item.create(self,3,player.position)
	item.take(player)
	check(player.unlocked[1],"saque desbloqueia arma")
	player.switch_weapon(1)
	check(player.slot==1,"troca de arma desbloqueada")
	player.mags[1]=0
	player.reserve[1]=64
	player.reload_weapon()
	player.finish_reload()
	player.reload_left=0
	check(player.mags[1]==32 and player.reserve[1]==32,"recarga conserva munição")
	var original=elapsed
	elapsed=500;update_zone()
	check(zone_radius<45 and zone_damage>=12,"contração e dano da zona")
	elapsed=original;update_zone()
	var b=fighters[2]
	var old_kills=player.kills
	b.damage(9999,player)
	check(not b.alive and player.kills==old_kills+1,"eliminação e contagem")
	check(supplies.filter(func(item):return is_instance_valid(item) and item.kind==7).size()==2,"exatamente dois jetpacks raros na ilha")
	check(damage_multiplier(2,5)>damage_multiplier(2,40)*5,"escopeta forte perto e fraca longe")
	check(damage_multiplier(1,10)>damage_multiplier(1,65)*3,"submetralhadora perde força de longe")
	check(island.windows.size()>=70,"janelas são aberturas reais no mapa")
	var gear=fighters[4]
	gear.hp=100;gear.armor=0;gear.helmet_level=0;gear.helmet_durability=0
	gear.damage(20,null,true)
	var unprotected=100-gear.hp
	gear.hp=100;gear.equip_armor(3,true)
	gear.damage(20,null,true)
	check(100-gear.hp<unprotected*0.5,"capacete nível 3 reduz dano na cabeça")
	check(gear.helmet_durability<90,"capacete perde durabilidade")
	gear.equip_armor(3)
	gear.hp=100
	gear.damage(20,null,false)
	check(gear.hp>90 and gear.armor<140,"colete absorve dano no corpo")
	check(Ambience.sounds.size()>=15,"15 tipos de som e efeitos distintos")
	player.position=Vector3(0,0.2,-170)
	player.equip_jetpack()
	player.hp=100
	var fuel=player.jet_fuel
	var altitude=player.global_position.y
	Input.action_press("jump")
	await get_tree().create_timer(0.55).timeout
	Input.action_release("jump")
	check(player.jet_fuel<fuel,"jetpack consome combustível ao usar")
	check(player.global_position.y>altitude+0.4,"jetpack eleva o jogador com física")
	player.jet_enabled=false
	var window=island.windows[0]
	player.position=Vector3(window.position.x,0.15,window.position.z)+window.normal*1.65
	player.yaw=atan2(window.normal.x,window.normal.z)
	await get_tree().physics_frame
	check(try_vault(player),"salto de janela detecta abertura e destino livre")
	var destination=player.vault_end
	await get_tree().create_timer(0.7).timeout
	check(player.global_position.distance_to(destination)<0.6 and player.collision_mask==3,"salto de janela termina e restaura colisão")
	player.position=old_pos
	player.position=Vector3(25,0.2,-180)
	player.yaw=0
	player.velocity=Vector3.ZERO
	await get_tree().physics_frame
	next_build=0
	var ramp_built=place_cover(2)
	check(ramp_built,"rampa construída em área livre")
	if ramp_built:
		Input.action_press("forward")
		await get_tree().create_timer(1.05).timeout
		Input.action_release("forward")
		check(player.global_position.y>0.6,"rampa pode ser subida com movimento real")
	player.velocity=Vector3.ZERO
	player.position=Vector3(-25,0.2,-180)
	await get_tree().physics_frame
	next_build=0
	check(place_cover(3),"piso construído com colisão")
	player.position=old_pos
	fighters[3].set_physics_process(true)
	var initial=fighters[3].global_position
	await get_tree().create_timer(8).timeout
	check(initial.distance_to(fighters[3].global_position)>0.5,"bot se desloca na ilha")
	check(fighters[3].global_position.y>-2,"bot não atravessa o terreno")
	print("CPU PROCESS ",Performance.get_monitor(Performance.TIME_PROCESS)," PHYSICS ",Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS))
	print("SMOKE COMPLETE ",checks.size()," checks, ",alive_count()," alive, ",Engine.get_frames_per_second()," FPS headless (not GPU benchmark)")
	var file=FileAccess.open("user://smoke-result.txt",FileAccess.WRITE)
	file.store_string("\n".join(checks))
	get_tree().quit(0 if not checks.any(func(s):return s.begins_with("FAIL")) else 1)

func check(ok: bool,text: String) -> void:
	checks.append(("PASS " if ok else "FAIL ")+text)
	print(checks.back())

func damage_multiplier(weapon: int,distance: float) -> float:
	var near_range=[30.0,12.0,8.0][weapon]
	var far_range=[140.0,65.0,45.0][weapon]
	var minimum=[0.45,0.28,0.07][weapon]
	return lerpf(1.0,minimum,clampf((distance-near_range)/(far_range-near_range),0.0,1.0))

func try_vault(actor: Fighter) -> bool:
	for window in island.windows:
		var point: Vector3=window.position
		var flat=Vector3(point.x,actor.global_position.y,point.z)
		if flat.distance_to(actor.global_position)>2.3:continue
		var normal: Vector3=window.normal
		var side=1 if (actor.global_position-flat).dot(normal)>0 else -1
		var forward=Vector3(-sin(actor.yaw),0,-cos(actor.yaw))
		if forward.dot(-normal*side)<0.3:continue
		var landing=Vector3(point.x,0.15,point.z)-normal*side*1.75
		var shape=CapsuleShape3D.new()
		shape.radius=0.38;shape.height=1.85
		var query=PhysicsShapeQueryParameters3D.new()
		query.shape=shape
		query.transform=Transform3D(Basis.IDENTITY,landing+Vector3.UP*0.95)
		query.exclude=[actor.get_rid()]
		query.collision_mask=3
		if not get_world_3d().direct_space_state.intersect_shape(query,1).is_empty():continue
		actor.vault_start=actor.global_position
		actor.vault_end=landing
		actor.vault_time=0.6
		actor.collision_mask=0
		actor.velocity=Vector3.ZERO
		sound_at("vault",actor.global_position,-10)
		return true
	return false

func capture_menu() -> void:
	for i in range(3):await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("user://captura-menu.png")
	print("MENU CAPTURE saved")
	get_tree().quit()

func show_credits() -> void:
	var dialog=AcceptDialog.new()
	dialog.title="Créditos do Aurora Royale"
	dialog.dialog_text="Personagem, texturas do personagem e passos/salto/aterrissagem:\nJuan Linietsky e Fernando Miguel Calabró · 2018\nGodot TPS demo · CC-BY 3.0\nhttps://github.com/godotengine/tps-demo\n\nChão e concreto: Poly Haven · CC0\nFontes: Rajdhani (SIL OFL) e DejaVu Sans\nEngine: Godot 4.6.3 · MIT\n\nModelos/animações foram adaptados para este jogo.\nDetalhes, fontes e licenças completas estão no README."
	dialog.min_size=Vector2i(620,370)
	menu.add_child(dialog)
	dialog.popup_centered()
