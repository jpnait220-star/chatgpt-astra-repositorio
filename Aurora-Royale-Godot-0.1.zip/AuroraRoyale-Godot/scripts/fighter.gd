class_name Fighter
extends CharacterBody3D

var game
var human := false
var alive := true
var hp := 100.0
var armor := 70.0
var armor_level := 1
var helmet_level := 0
var helmet_durability := 0.0
var has_jetpack := false
var jet_enabled := false
var jet_fuel := 0.0
var jet_visual: Node3D
var jet_flames: Node3D
var jet_audio: AudioStreamPlayer3D
var thrusting := false
var vault_time := 0.0
var vault_start := Vector3.ZERO
var vault_end := Vector3.ZERO
var air_last := false
var kills := 0
var nickname := "Ranger"
var cooldown := 0.0
var reload_left := 0.0
var heal_left := 0.0
var stamina := 100.0
var ice := 8
var materials := 450
var kits := 3
var slot := 0
var mags := [30, 32, 2]
var reserve := [210, 160, 42]
var unlocked := [true, false, false]
var yaw := 0.0
var pitch := -0.12
var camera: Camera3D
var pivot: Node3D
var arm: SpringArm3D
var skin: Node3D
var anim: AnimationPlayer
var gun: Node3D
var muzzle: Node3D
var decision := 0.0
var target: Fighter
var route := PackedVector3Array()
var route_step := 0
var goal := Vector3.ZERO
var path_timer := 0.0
var wander_timer := 0.0
var strafe := 1.0
var anim_now := ""
var bob := 0.0
var travel := 0.0
var received_at := -10.0
var last_hurt_audio := -10.0
var rng := RandomNumberGenerator.new()

func setup(owner_game, is_player: bool, index: int) -> void:
	game = owner_game
	human = is_player
	nickname = "VOCÊ" if human else "Ranger %02d" % (index+1)
	rng.seed = index*18373+82715
	decision = rng.randf_range(0.1,1.1)
	path_timer = rng.randf_range(0.1,1.0)
	hp = 100
	armor = 70 if human else 35
	collision_layer = 2
	collision_mask = 1|2
	floor_max_angle = deg_to_rad(48)
	floor_snap_length = 0.4
	var col := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.37
	capsule.height = 1.85
	col.shape = capsule
	col.position.y = 0.94
	add_child(col)
	skin = Node3D.new()
	add_child(skin)
	var model: Node3D = game.ranger_scene.instantiate()
	skin.add_child(model)
	model.scale = Vector3.ONE*0.9
	# Imported glTF faces +Z; our controller faces -Z.
	model.rotation.y = PI
	anim = find_animation(model)
	if anim:
		for name in anim.get_animation_list():
			if "cycle" in name or "running" in name:anim.get_animation(name).loop_mode = Animation.LOOP_LINEAR
	for mi in model.find_children("*","MeshInstance3D",true,false):
		for surface in range(mi.mesh.get_surface_count()):
			var original = mi.mesh.surface_get_material(surface)
			if original:
				mi.set_surface_override_material(surface,load("res://assets/robotemitter.tres") if original.resource_name=="robotemitter" else load("res://assets/playerobot.tres"))
		mi.visibility_range_end = 145.0 if not human else 0.0
		mi.visibility_range_end_margin = 12
	create_jet_visual()
	if not human:
		var mark := Forge.cylinder(skin, Vector3(0,2.02,0),0.1,0.12,Forge.mat(Color("e18c59")),0.03,6)
		mark.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	gun = Node3D.new()
	skin.add_child(gun)
	gun.position = Vector3(0.38,1.28,-0.35)
	var steel = Forge.mat(Color("23333a"),0.35,0.65)
	Forge.box(gun,Vector3(0,0,-0.12),Vector3(0.12,0.17,0.52),steel)
	Forge.box(gun,Vector3(0,-0.14,0.0),Vector3(0.09,0.22,0.13),steel)
	Forge.box(gun,Vector3(0,0.11,-0.13),Vector3(0.07,0.07,0.13),Forge.mat(Color("122025")))
	Forge.box(gun,Vector3(0,0,-0.46),Vector3(0.055,0.055,0.35),steel)
	muzzle = Node3D.new()
	muzzle.position = Vector3(0,0,-0.65)
	gun.add_child(muzzle)
	if human:
		pivot = Node3D.new()
		pivot.position = Vector3(0,1.5,0)
		add_child(pivot)
		arm = SpringArm3D.new()
		arm.position.x = 0.65
		arm.spring_length = 4.1
		arm.margin = 0.2
		arm.collision_mask = 1
		arm.add_excluded_object(get_rid())
		pivot.add_child(arm)
		camera = Camera3D.new()
		camera.fov = 78
		camera.near = 0.12
		camera.far = 1200
		arm.add_child(camera)
		camera.current = true

func find_animation(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:return n
	for child in n.get_children():
		var result = find_animation(child)
		if result:return result
	return null

func _physics_process(dt: float) -> void:
	if not alive or not game.running or game.paused:
		if jet_audio and jet_audio.playing:jet_audio.stop()
		return
	cooldown = maxf(0,cooldown-dt)
	var was_reloading = reload_left > 0
	reload_left = maxf(0,reload_left-dt)
	if was_reloading and reload_left <= 0:finish_reload()
	if heal_left > 0:
		heal_left = maxf(0,heal_left-dt)
		if heal_left <= 0:
			hp = minf(100,hp+65)
			kits -= 1
			if human:game.notice("Kit aplicado · +65 de vida");game.sound_at("heal_done",global_position,-10)
	if global_position.y < -10:damage(999,null,false,true)
	if global_position.distance_to(game.zone_center) > game.zone_radius:
		damage(dt*game.zone_damage,null,false,true)
	if not alive:return
	if human:player_step(dt)
	else:bot_step(dt)
	animate_skin(dt)

func player_step(dt: float) -> void:
	if vault_time>0:
		vault_time=maxf(0,vault_time-dt)
		var progress=1-vault_time/0.6
		global_position=vault_start.lerp(vault_end,progress)+Vector3.UP*sin(progress*PI)*1.16
		if vault_time<=0:collision_mask=3
		pivot.rotation=Vector3(pitch,yaw,0)
		return
	var axis = Input.get_vector("left","right","forward","back")
	var direction = Vector3(axis.x,0,axis.y).rotated(Vector3.UP,yaw)
	var sprint = Input.is_action_pressed("sprint") and axis.y < -0.2 and stamina>1 and not Input.is_action_pressed("aim")
	var speed = 8.4 if sprint else 5.2
	if Input.is_action_pressed("crouch"):speed = 2.7
	if heal_left>0:speed *= 0.55
	stamina = clampf(stamina+dt*(-20 if sprint else 15),0,100)
	velocity.x = move_toward(velocity.x,direction.x*speed,dt*35)
	velocity.z = move_toward(velocity.z,direction.z*speed,dt*35)
	if not is_on_floor():velocity.y -= 24*dt
	elif Input.is_action_just_pressed("jump"):
		if not jet_enabled and game.try_vault(self):return
		velocity.y = 9.0
		game.sound_at("jump",global_position,-12)
	else:velocity.y = -0.1
	thrusting=has_jetpack and jet_enabled and jet_fuel>0 and Input.is_action_pressed("jump")
	if thrusting:
		velocity.y=move_toward(velocity.y,7.5,dt*34)
		jet_fuel=maxf(0,jet_fuel-dt*13)
		if not jet_audio.playing:jet_audio.play()
	else:
		if jet_audio.playing:jet_audio.stop()
	jet_flames.visible=thrusting
	var airborne=not is_on_floor()
	move_and_slide()
	if airborne and is_on_floor():game.sound_at("land",global_position,-13)
	pivot.rotation = Vector3(pitch,yaw,0)
	var aim = Input.is_action_pressed("aim") and not game.build_mode
	camera.fov = lerpf(camera.fov,57.0 if aim else 78.0,1-exp(-dt*14))
	arm.spring_length = lerpf(arm.spring_length,2.3 if aim else 4.1,1-exp(-dt*12))
	arm.position.x = lerpf(arm.position.x,0.68 if aim else 0.65,1-exp(-dt*12))
	if aim or Input.is_action_pressed("fire") or game.build_mode:
		skin.rotation.y = lerp_angle(skin.rotation.y,yaw,1-exp(-dt*18))
	elif direction.length_squared()>0.01:
		skin.rotation.y = lerp_angle(skin.rotation.y,atan2(-direction.x,-direction.z),1-exp(-dt*14))
	if Input.is_action_pressed("fire") and not game.build_mode and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:shoot()
	travel += Vector2(velocity.x,velocity.z).length()*dt
	if travel>3.2 and is_on_floor():
		travel=0
		game.sound_at("step",global_position,-19)

func bot_step(dt: float) -> void:
	decision -= dt
	path_timer -= dt
	wander_timer -= dt
	if decision <= 0:
		decision = rng.randf_range(0.45,0.95)
		target = null
		var closest = 95.0*95.0
		for other in game.fighters:
			if other == self or not is_instance_valid(other) or not other.alive:continue
			var d = global_position.distance_squared_to(other.global_position)
			if d<closest and game.has_sight(self,other):target=other;closest=d
		if rng.randf()<0.22:strafe=-strafe
		if hp<50 and kits>0 and (not target or closest>900) and heal_left<=0:heal_left=2.8
		if target and reload_left<=0:
			var distance=global_position.distance_to(target.global_position)
			var desired=2 if distance<12 and unlocked[2] and mags[2]+reserve[2]>0 else 1 if distance<30 and unlocked[1] and mags[1]+reserve[1]>0 else 0
			switch_weapon(desired)
		if mags[slot]<=0 and reload_left<=0:reload_weapon()
		game.auto_loot(self)
	var direction := Vector3.ZERO
	var threatened = global_position.distance_to(game.zone_center)>game.zone_radius-16
	if target and (not is_instance_valid(target) or not target.alive):target=null
	if target and not threatened:
		var delta = target.global_position-global_position
		var dist = delta.length()
		skin.rotation.y = lerp_angle(skin.rotation.y,atan2(-delta.x,-delta.z),1-exp(-dt*10))
		if dist>27:goal=target.global_position
		elif dist<12:goal=global_position-delta.normalized()*8
		else:goal=global_position+delta.normalized().cross(Vector3.UP)*strafe*6
		if cooldown<=0 and reload_left<=0 and heal_left<=0 and game.has_sight(self,target):
			var spread = [0.095,0.064,0.038][game.difficulty]
			var aim = target.global_position+Vector3(rng.randf_range(-spread,spread)*dist,1.15+rng.randf_range(-0.25,0.25),rng.randf_range(-spread,spread)*dist)
			shoot_at(aim)
	else:
		if threatened:goal=game.zone_center+Vector3(sin(get_instance_id()),0,cos(get_instance_id()))*game.zone_radius*0.25
		elif wander_timer<=0 or global_position.distance_to(goal)<4:
			wander_timer=rng.randf_range(7,14)
			goal=game.island.spawn_points[rng.randi()%game.island.spawn_points.size()]
	if path_timer<=0:
		path_timer=rng.randf_range(1.0,1.8)
		route=game.island.path(global_position,goal)
		route_step=1 if route.size()>1 else 0
	if route_step<route.size():
		var dest = route[route_step]-global_position
		dest.y=0
		if dest.length()<1.2:route_step+=1
		else:direction=dest.normalized()
	elif target:direction=(goal-global_position).normalized();direction.y=0
	var speed = 5.7 if threatened else 4.1
	if target and not threatened:speed=3.4
	if heal_left>0:speed=2
	velocity.x=direction.x*speed
	velocity.z=direction.z*speed
	if not is_on_floor():velocity.y-=24*dt
	else:velocity.y=-0.1
	if is_on_wall() and is_on_floor() and rng.randf()<dt*2:velocity.y=7
	move_and_slide()
	travel+=Vector2(velocity.x,velocity.z).length()*dt
	if travel>2.6 and is_on_floor():
		travel=0
		game.sound_at("step",global_position,-19)
	if not target and direction.length_squared()>0.01:skin.rotation.y=lerp_angle(skin.rotation.y,atan2(-direction.x,-direction.z),1-exp(-dt*8))

func animate_skin(dt: float) -> void:
	if not anim:return
	if not human and game.player and global_position.distance_squared_to(game.player.global_position)>55*55:
		anim.active=false
		return
	anim.active=true
	var moving = Vector2(velocity.x,velocity.z).length()>0.5
	var name = "running_gun-cycle" if moving else "Idlecombat-cycle"
	if not is_on_floor() or vault_time>0:name="jump_3_midair-cycle"
	if name!=anim_now and anim.has_animation(name):
		anim_now=name
		anim.play(name,0.18)
	bob+=dt*9
	gun.position.y=1.28+sin(bob)*0.014 if moving else 1.28

func shoot() -> void:
	if cooldown>0 or reload_left>0 or heal_left>0:return
	if mags[slot]<=0:reload_weapon();return
	var center = get_viewport().get_visible_rect().size*0.5
	var from = camera.project_ray_origin(center)
	var far = from+camera.project_ray_normal(center)*350
	var q = PhysicsRayQueryParameters3D.create(from,far,3,[get_rid()])
	var result = get_world_3d().direct_space_state.intersect_ray(q)
	shoot_at(result.position if not result.is_empty() else far)
	pitch=clampf(pitch+([0.011,0.006,0.034][slot])*(0.6 if Input.is_action_pressed("aim") else 1),-1.2,0.95)

func shoot_at(point: Vector3) -> void:
	if cooldown>0 or reload_left>0 or heal_left>0 or mags[slot]<=0:return
	mags[slot]-=1
	cooldown=[0.115,0.073,0.78][slot] if human else rng.randf_range(0.38,0.8)*[1.4,1.0,0.78][game.difficulty]
	var from = muzzle.global_position
	var dir = (point-from).normalized()
	var pellets = 8 if slot==2 else 1
	for i in range(pellets):
		var spread = [0.006,0.016,0.05][slot] if human else 0.008
		if human and not Input.is_action_pressed("aim"):spread*=2.2
		var shot = (dir+Vector3(rng.randf_range(-spread,spread),rng.randf_range(-spread,spread),rng.randf_range(-spread,spread))).normalized()
		game.fire_ray(self,from,from+shot*350,[25.0,23.0,19.0][slot])
	game.sound_at(["shot","smg","shotgun"][slot],global_position,-13 if human else -16)
	if human:game.shots_fired+=1

func reload_weapon() -> void:
	if reload_left>0 or mags[slot]>=[30,32,2][slot] or reserve[slot]<=0:return
	reload_left=[1.9,1.6,2.5][slot]
	heal_left=0
	if human:game.sound_at("reload",global_position,-10)

func finish_reload() -> void:
	var amount = mini([30,32,2][slot]-mags[slot],reserve[slot])
	mags[slot]+=amount
	reserve[slot]-=amount

func switch_weapon(index: int) -> void:
	if index==slot or not unlocked[index]:return
	reload_left=0
	slot=index
	cooldown=0.25

func damage(amount: float, attacker: Fighter, headshot: bool = false, storm: bool = false) -> void:
	if not alive:return
	if headshot:amount*=1.75
	if not storm:
		if headshot:
			var absorb=minf(helmet_durability,amount*[0.0,0.35,0.5,0.65][helmet_level])
			helmet_durability-=absorb
			amount-=absorb
		else:
			var absorb=minf(armor,amount*[0.0,0.35,0.5,0.65][armor_level])
			armor-=absorb
			amount-=absorb
	hp=maxf(0,hp-amount)
	received_at=game.elapsed
	heal_left=0
	if human:
		game.hurt_flash=0.32
		if not storm and game.elapsed-last_hurt_audio>0.13:
			game.sound_at("hurt",global_position,-16)
			last_hurt_audio=game.elapsed
	if hp<=0:
		alive=false
		collision_layer=0
		collision_mask=0
		if attacker:attacker.kills+=1
		game.on_eliminated(self,attacker)
		if not human:
			skin.rotation.z=PI*0.48
			var tw=create_tween()
			tw.tween_property(skin,"position:y",-0.5,0.5)
			get_tree().create_timer(6).timeout.connect(func():skin.visible=false)

func equip_armor(level: int,helmet: bool=false) -> void:
	if helmet:
		if level>=helmet_level or helmet_durability<=0:
			helmet_level=level
			helmet_durability=[0,40,65,90][level]
	else:
		if level>=armor_level or armor<=0:
			armor_level=level
			armor=[0,70,100,140][level]

func create_jet_visual() -> void:
	jet_visual=Node3D.new()
	skin.add_child(jet_visual)
	var metal=Forge.mat(Color("354851"),0.35,0.65)
	for side in [-1,1]:
		Forge.cylinder(jet_visual,Vector3(side*0.19,1.35,0.36),0.14,0.65,metal,-1,10)
		Forge.box(jet_visual,Vector3(side*0.19,1.55,0.5),Vector3(0.14,0.05,0.03),Forge.mat(Color("80e7de")))
	jet_flames=Node3D.new()
	jet_visual.add_child(jet_flames)
	for side in [-1,1]:Forge.cylinder(jet_flames,Vector3(side*0.19,0.84,0.36),0.015,0.4,Forge.mat(Color("6cddff"),0.2),0.1,7)
	jet_flames.visible=false
	jet_visual.visible=false
	jet_audio=AudioStreamPlayer3D.new()
	jet_audio.stream=Ambience.sounds.get("jet")
	jet_audio.volume_db=-15
	jet_audio.unit_size=5
	jet_audio.max_distance=70
	add_child(jet_audio)

func equip_jetpack() -> void:
	has_jetpack=true
	jet_enabled=true
	jet_fuel=100
	jet_visual.visible=true
