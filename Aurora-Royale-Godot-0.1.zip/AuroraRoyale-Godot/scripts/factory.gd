class_name Forge
extends RefCounted

static var materials: Dictionary = {}
static func mat(color: Color, rough: float = 0.85, metal: float = 0.0) -> StandardMaterial3D:
	var key := str(color) + str(rough) + str(metal)
	if materials.has(key): return materials[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	materials[key] = m
	return m

static func box(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	parent.add_child(mi)
	return mi

static func sphere(parent: Node3D, pos: Vector3, radius: float, material: Material, height: float = -1.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0 if height < 0 else height
	mesh.radial_segments = 10
	mesh.rings = 6
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = material
	parent.add_child(mi)
	return mi

static func cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, top: float = -1.0, sides: int = 10) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.bottom_radius = radius
	mesh.top_radius = radius if top < 0.0 else top
	mesh.height = height
	mesh.radial_segments = sides
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = material
	parent.add_child(mi)
	return mi

static func collider(parent: Node3D, pos: Vector3, size: Vector3) -> StaticBody3D:
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.position = pos
	body.add_child(cs)
	parent.add_child(body)
	return body

static func solid(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> StaticBody3D:
	var body := collider(parent, pos, size)
	box(body, Vector3.ZERO, size, material)
	return body

static func line(parent: Node3D, a: Vector3, b: Vector3, color: Color, radius: float = 0.02) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = a.distance_to(b)
	cm.radial_segments = 4
	mi.mesh = cm
	var m := mat(color, 1.0)
	mi.material_override = m
	parent.add_child(mi)
	mi.global_position = (a + b) / 2.0
	if a.distance_squared_to(b) > 0.01:
		mi.quaternion = Quaternion(Vector3.UP, (b - a).normalized())
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi

static func noise_material(color: Color, scale_uv: float = 1.0) -> StandardMaterial3D:
	var m := mat(color).duplicate() as StandardMaterial3D
	var noise := FastNoiseLite.new()
	noise.frequency = 0.045
	noise.fractal_octaves = 4
	var tex := NoiseTexture2D.new()
	tex.width = 256
	tex.height = 256
	tex.noise = noise
	m.albedo_texture = tex
	m.uv1_triplanar = true
	m.uv1_scale = Vector3.ONE * scale_uv
	return m

static func photo_material(path: String, tint: Color, tiling: float) -> StandardMaterial3D:
	var m=StandardMaterial3D.new()
	m.albedo_texture=load(path)
	m.albedo_color=tint
	m.roughness=0.92
	m.uv1_triplanar=true
	m.uv1_world_triplanar=true
	m.uv1_scale=Vector3.ONE*tiling
	m.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	return m
