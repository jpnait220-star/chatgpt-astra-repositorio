class_name Island
extends Node3D

var game: Node3D
var grid := AStarGrid2D.new()
var static_blocks: Array[Rect2] = []
var spawn_points: Array[Vector3] = []
var windows: Array[Dictionary] = []
var rng := RandomNumberGenerator.new()
var ground: Material
var concrete: Material
var wood: Material
var dark: Material
var leaves: Material
const CELL := 3.5
const HALF := 63

func _init() -> void:
	rng.seed = 502817

func generate() -> void:
	ground = Forge.photo_material("res://assets/ground.jpg",Color(0.85,0.95,0.83),0.075)
	concrete = Forge.photo_material("res://assets/concrete.jpg",Color(1.2,1.25,1.22),0.22)
	wood = Forge.mat(Color("6b5140"))
	dark = Forge.mat(Color("303d42"), 0.6, 0.25)
	leaves = Forge.mat(Color("3d6347"))
	Forge.solid(self, Vector3(0, -2, 0), Vector3(490, 4, 490), ground)
	water()
	coast()
	# Roads connect the four neighborhoods. Their intersections stay traversable.
	for offset in [-57.0, 57.0]:
		Forge.box(self, Vector3(offset, 0.035, 0), Vector3(11, 0.07, 296), Forge.mat(Color("515b5d")))
		Forge.box(self, Vector3(0, 0.04, offset), Vector3(296, 0.08, 11), Forge.mat(Color("515b5d")))
		for mark in range(-132, 133, 9):
			Forge.box(self, Vector3(offset, 0.09, mark), Vector3(0.15, 0.02, 3), Forge.mat(Color("d9cba4")))
			Forge.box(self, Vector3(mark, 0.095, offset), Vector3(3, 0.02, 0.15), Forge.mat(Color("d9cba4")))
	for cx in [-91.0, 11.0, 91.0]:
		for cz in [-91.0, 6.0, 91.0]:
			building(Vector3(cx, 0, cz), Vector2(14, 18), rng.randf_range(4.5, 7.0), Color.from_hsv(rng.randf_range(0.04, 0.14), 0.18, 0.7))
			building(Vector3(cx + 24, 0, cz + 9), Vector2(11, 13), 4.8, Color("708a89"))
			for k in range(3):
				crate(Vector3(cx + 15 + k * 2.6, 0, cz - 12), Vector3(2, 2, 2))
	# Harbor / container yard.
	for j in range(12):
		var p := Vector3(-151 + (j % 4) * 9.5, 0, -20 + (j / 4) * 15.0)
		container(p, Color("536b72") if j % 2 == 0 else Color("966950"))
	building(Vector3(151, 0, -90), Vector2(23, 30), 8, Color("92948c"))
	for k in range(120):
		var p := Vector3(rng.randf_range(-218, 218), 0, rng.randf_range(-218, 218))
		if p.length() > 220 or blocked(p, 4.0) or abs(abs(p.x)-57) < 10 or abs(abs(p.z)-57) < 10: continue
		if p.length() < 125 and k % 3 != 0: continue
		tree(p, rng.randf_range(0.8, 1.55))
	for k in range(52):
		var p := Vector3(rng.randf_range(-205,205),0,rng.randf_range(-205,205))
		if p.length() > 215 or blocked(p, 5) or abs(abs(p.x)-57)<9 or abs(abs(p.z)-57)<9:continue
		var size := Vector3(rng.randf_range(2,5),rng.randf_range(1.5,3),rng.randf_range(2,5))
		var stone := Forge.collider(self,p+Vector3(0,size.y*0.35,0),size*Vector3(0.8,0.65,0.8))
		var rock := Forge.sphere(stone,Vector3.ZERO,1.0,Forge.mat(Color("737e79")))
		rock.scale = size * 0.65
		register_block(p,Vector2(size.x,size.z)*0.9)
	batch_scenery()
	create_grid()
	for k in range(180):
		var p := Vector3(rng.randf_range(-196,196),0.2,rng.randf_range(-196,196))
		if p.length()<198 and not blocked(p,1.3):spawn_points.append(p)

func building(p: Vector3, size: Vector2, height: float, color: Color) -> void:
	var wall_mat := Forge.photo_material("res://assets/concrete.jpg",color*1.65,0.24)
	var x := size.x
	var z := size.y
	window_side(p,-1,x,z,height,wall_mat)
	window_side(p,1,x,z,height,wall_mat)
	wall(p+Vector3(0,height/2,z/2),Vector3(x,height,0.45),wall_mat)
	# A genuine opening, not a door painted on a solid wall.
	for side in [-1,1]:
		wall(p+Vector3(side*(x/4+0.8),height/2,-z/2),Vector3(x/2-1.6,height,0.45),wall_mat)
	wall(p+Vector3(0,(height+3.1)/2,-z/2),Vector3(3.2,height-3.1,0.45),wall_mat)
	Forge.solid(self,p+Vector3(0,height+0.15,0),Vector3(x+0.8,0.35,z+0.8),dark)
	Forge.box(self,p+Vector3(0,0.05,0),Vector3(x,0.1,z),concrete)
	for j in range(2):
		crate(p+Vector3(-x*0.23+j*3.4,0,z*0.26),Vector3(2,1.4,1.8))
	# Roof equipment and trim add readable silhouettes.
	Forge.box(self,p+Vector3(-x*0.25,height+0.65,z*0.2),Vector3(2.1,1,2.2),concrete)
	Forge.box(self,p+Vector3(0,height-0.3,-z/2-0.25),Vector3(x+0.5,0.18,0.5),dark)

func wall(p: Vector3,size: Vector3,material: Material) -> void:
	Forge.solid(self,p,size,material)
	register_block(p,Vector2(size.x,size.z))

func crate(p: Vector3,size: Vector3) -> void:
	wall(p+Vector3(0,size.y/2,0),size,wood)
	for y in [0.15,size.y-0.15]:
		Forge.box(self,p+Vector3(0,y,0),Vector3(size.x+0.06,0.09,size.z+0.06),dark)

func container(p: Vector3,color: Color) -> void:
	wall(p+Vector3(0,1.5,0),Vector3(6.5,3,11),Forge.mat(color,0.65,0.2))
	for j in range(10):
		for side in [-1,1]:
			Forge.box(self,p+Vector3(side*3.28,1.5,-5+j*1.1),Vector3(0.1,2.8,0.08),dark)

func tree(p: Vector3,s: float) -> void:
	var body := Forge.collider(self,p+Vector3(0,2.5*s,0),Vector3(0.65,5,0.65)*s)
	Forge.cylinder(body,Vector3.ZERO,0.4*s,5*s,wood,0.2*s)
	for j in range(3):
		Forge.cylinder(self,p+Vector3(0,(4.5+j*1.5)*s,0),(3.1-j*0.65)*s,4.7*s,leaves,0.06,9)
	register_block(p,Vector2.ONE*1.0*s)

func register_block(p: Vector3,size: Vector2) -> void:
	static_blocks.append(Rect2(Vector2(p.x,p.z)-size/2.0,size))

func blocked(p: Vector3, margin: float) -> bool:
	for r in static_blocks:
		if r.grow(margin).has_point(Vector2(p.x,p.z)):return true
	return false

func create_grid() -> void:
	grid.region = Rect2i(-HALF,-HALF,HALF*2+1,HALF*2+1)
	grid.cell_size = Vector2.ONE*CELL
	grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.update()
	for x in range(-HALF,HALF+1):
		for y in range(-HALF,HALF+1):
			var p := Vector3(x*CELL,0,y*CELL)
			if p.length()>214 or blocked(p,0.65):grid.set_point_solid(Vector2i(x,y))

func cell(p: Vector3) -> Vector2i:
	return Vector2i(clampi(roundi(p.x/CELL),-HALF,HALF),clampi(roundi(p.z/CELL),-HALF,HALF))

func nearest_free(c: Vector2i) -> Vector2i:
	if not grid.is_point_solid(c):return c
	for radius in range(1,9):
		for x in range(-radius,radius+1):
			for y in range(-radius,radius+1):
				var test := c+Vector2i(x,y)
				if grid.region.has_point(test) and not grid.is_point_solid(test):return test
	return c

func path(a: Vector3,b: Vector3) -> PackedVector3Array:
	var start := nearest_free(cell(a))
	var finish := nearest_free(cell(b))
	var result := PackedVector3Array()
	if grid.is_point_solid(start) or grid.is_point_solid(finish):return result
	for c in grid.get_id_path(start,finish):result.append(Vector3(c.x*CELL,0,c.y*CELL))
	return result

func water() -> void:
	var plane := PlaneMesh.new()
	plane.size = Vector2(1900,1900)
	plane.subdivide_width = 60
	plane.subdivide_depth = 60
	var sh := Shader.new()
	sh.code = "shader_type spatial; render_mode cull_disabled; void vertex(){VERTEX.y+=sin(VERTEX.x*0.06+TIME*0.6)*0.25+cos(VERTEX.z*0.05+TIME*0.4)*0.3;} void fragment(){float f=pow(1.0-max(dot(NORMAL,VIEW),0.0),3.0); ALBEDO=mix(vec3(0.035,0.19,0.24),vec3(0.26,0.49,0.52),f); METALLIC=0.35; ROUGHNESS=0.24;}"
	var m := ShaderMaterial.new()
	m.shader=sh
	var mi := MeshInstance3D.new()
	mi.mesh=plane
	mi.material_override=m
	mi.position.y=-2.8
	add_child(mi)

func coast() -> void:
	for j in range(56):
		var angle := j*TAU/56.0
		var p := Vector3(cos(angle),0,sin(angle))*rng.randf_range(236,251)
		var rock := Forge.sphere(self,p-Vector3(0,5,0),10,Forge.mat(Color("6e8076")))
		rock.scale=Vector3(1.8,0.65,1.8)
	for j in range(25):
		var angle := j*TAU/25.0
		var p := Vector3(cos(angle),0,sin(angle))*rng.randf_range(550,740)
		Forge.cylinder(self,p+Vector3(0,25,0),rng.randf_range(60,110),rng.randf_range(65,130),Forge.mat(Color("556f75")),0.4,7)

var dynamic_counts: Dictionary={}
func add_dynamic(c: Cover) -> void:
	var cs=c.get_child(0) as CollisionShape3D
	var bounds=cs.global_transform*AABB(-(cs.shape as BoxShape3D).size/2,(cs.shape as BoxShape3D).size)
	var low=cell(bounds.position-Vector3.ONE*0.7)
	var high=cell(bounds.end+Vector3.ONE*0.7)
	for x in range(low.x,high.x+1):
		for y in range(low.y,high.y+1):
			var key=Vector2i(x,y)
			c.occupied_cells.append(key)
			dynamic_counts[key]=dynamic_counts.get(key,0)+1
			grid.set_point_solid(key,true)

func remove_dynamic(c: Cover) -> void:
	for key in c.occupied_cells:
		var count=int(dynamic_counts.get(key,0))-1
		if count>0:dynamic_counts[key]=count
		else:
			dynamic_counts.erase(key)
			var p=Vector3(key.x*CELL,0,key.y*CELL)
			grid.set_point_solid(key,p.length()>214 or blocked(p,0.65))
	c.occupied_cells.clear()

func batch_scenery() -> void:
	# Merge static triangles per material and 64m chunk. Physics stays separate.
	var groups: Dictionary={}
	var chunks: Dictionary={}
	for mesh in find_children("*","MeshInstance3D",true,false):
		if not mesh.material_override is StandardMaterial3D:continue
		var pos=mesh.global_position
		var key=str(mesh.material_override.get_instance_id())+":"+str(floori(pos.x/64))+":"+str(floori(pos.z/64))
		if not groups.has(key):groups[key]=[]
		groups[key].append(mesh)
	for key in groups:
		var items=groups[key]
		if items.size()<3:continue
		var tool=SurfaceTool.new()
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		tool.set_material(items[0].material_override)
		for mi in items:
			tool.append_from(mi.mesh,0,mi.global_transform)
		var combined=MeshInstance3D.new()
		combined.mesh=tool.commit()
		combined.material_override=items[0].material_override
		add_child(combined)
		for mi in items:mi.queue_free()

func window_side(p: Vector3,side: int,x: float,z: float,height: float,material: Material) -> void:
	var plane_x=p.x+side*x/2
	wall(Vector3(plane_x,0.55,p.z),Vector3(0.45,1.1,z),material)
	wall(Vector3(plane_x,(height+3.2)/2,p.z),Vector3(0.45,height-3.2,z),material)
	var ends=[-z/2,-z*0.28-1.45,-z*0.28+1.45,z*0.22-1.45,z*0.22+1.45,z/2]
	for index in [0,2,4]:
		var length=ends[index+1]-ends[index]
		if length>0:wall(Vector3(plane_x,2.15,p.z+(ends[index+1]+ends[index])/2),Vector3(0.45,2.1,length),material)
	for dz in [-z*0.28,z*0.22]:
		windows.append({"position":Vector3(plane_x,1.1,p.z+dz),"normal":Vector3(side,0,0)})
		for edge in [-1,1]:Forge.box(self,Vector3(plane_x,2.15,p.z+dz+edge*1.47),Vector3(0.55,2.2,0.09),dark)
		for y in [1.08,3.23]:Forge.box(self,Vector3(plane_x,y,p.z+dz),Vector3(0.6,0.09,3.05),dark)
