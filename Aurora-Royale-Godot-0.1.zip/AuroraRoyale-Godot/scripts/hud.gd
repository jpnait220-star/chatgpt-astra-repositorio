extends Control
var game
var font: Font=preload("res://assets/interface.ttf")
var heading: Font=preload("res://assets/heading.ttf")
var shown_hp := 100.0
var shown_armor := 70.0
var styles: Dictionary={}
const WHITE=Color("f2f5f1")
const MINT=Color("8ae7cf")
const GOLD=Color("efc58a")
const MUTED=Color("b0c3c3")
const DARK=Color(0.035,0.067,0.085,0.86)

func text(at: Vector2,content: String,size: int=16,color: Color=WHITE,bold: bool=false) -> void:
	var f=heading if bold else font
	draw_string(f,at+Vector2(0,1),content,HORIZONTAL_ALIGNMENT_LEFT,-1,size,Color(0,0,0,0.3))
	draw_string(f,at,content,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func panel(rect: Rect2,color: Color=DARK,radius: int=12) -> void:
	var key=str(color)+str(radius)
	if not styles.has(key):
		var style=StyleBoxFlat.new()
		style.bg_color=color
		style.corner_radius_top_left=radius;style.corner_radius_top_right=radius;style.corner_radius_bottom_left=radius;style.corner_radius_bottom_right=radius
		style.border_width_top=1
		style.border_color=Color(0.8,0.95,0.95,0.12)
		styles[key]=style
	draw_style_box(styles[key],rect)

func cross(at: Vector2,color: Color) -> void:
	draw_line(at-Vector2(5,0),at+Vector2(5,0),color,3,true)
	draw_line(at-Vector2(0,5),at+Vector2(0,5),color,3,true)

func shield(at: Vector2,color: Color) -> void:
	var points=PackedVector2Array([at+Vector2(-5,-6),at+Vector2(5,-6),at+Vector2(4,2),at+Vector2(0,6),at+Vector2(-4,2),at+Vector2(-5,-6)])
	draw_polyline(points,color,1.6,true)

func _draw() -> void:
	if not game:return
	var size=get_viewport_rect().size
	var w=size.x
	var h=size.y
	var center=size*0.5
	if game.loading:
		panel(Rect2(center-Vector2(235,40),Vector2(470,80)))
		text(center+Vector2(-202,-4),"PREPARANDO SUA PARTIDA",27,MINT,true)
		text(center+Vector2(-202,23),"Carregando a ilha e os 50 adversários…",15,MUTED)
		return
	if not game.running or not game.player:return
	var player=game.player
	if game.hurt_flash>0:draw_rect(Rect2(Vector2.ZERO,size),Color(0.65,0.05,0.025,game.hurt_flash*0.42))
	var unsafe=player.global_position.distance_to(game.zone_center)>game.zone_radius
	if unsafe:
		draw_rect(Rect2(Vector2.ZERO,size),Color(0.24,0.23,0.75,0.13))
		panel(Rect2(center.x-162,35,324,41),Color(0.25,0.23,0.48,0.95))
		text(Vector2(center.x-139,62),"FORA DA ZONA · VOLTE PARA A ÁREA SEGURA",13,WHITE)
	# No coordinates, numerical compass or debug counters in gameplay.
	panel(Rect2(26,24,215,73))
	text(Vector2(44,52),"ILHA VÉSPER",26,WHITE,true)
	draw_circle(Vector2(46,77),3.5,MINT)
	var zone_text="Fecha em %d:%02d" % [maxi(0,int(75-game.elapsed))/60,maxi(0,int(75-game.elapsed))%60] if game.elapsed<75 else "A zona está fechando"
	text(Vector2(58,82),zone_text,13,MUTED)
	minimap(Vector2(w-183,24),154)
	panel(Rect2(w-183,185,154,36),DARK,8)
	text(Vector2(w-169,209),"%d vivos" % game.alive_count(),14,WHITE)
	text(Vector2(w-101,209),"%d abates" % player.kills,14,GOLD)
	# Thin health/armor bars with explicit values and consistent alignment.
	panel(Rect2(26,h-122,266,92))
	text(Vector2(44,h-98),"VOCÊ",15,WHITE,true)
	text(Vector2(217,h-98),"%d" % ceili(player.hp),21,MINT,true)
	shown_hp=lerpf(shown_hp,player.hp,0.18)
	shown_armor=lerpf(shown_armor,player.armor,0.18)
	cross(Vector2(48,h-78),MINT)
	panel(Rect2(65,h-83,208,10),Color("30484a"),4)
	if shown_hp>0:panel(Rect2(65,h-83,maxf(4,208*shown_hp/100),10),MINT,4)
	shield(Vector2(48,h-55),Color("98bceb"))
	panel(Rect2(65,h-59,169,6),Color("30424c"),3)
	if shown_armor>0:panel(Rect2(65,h-59,maxf(3,169*shown_armor/100),6),Color("98bceb"),3)
	text(Vector2(243,h-50),str(ceili(player.armor)),13,MUTED)
	if player.stamina<95:draw_line(Vector2(66,h-39),Vector2(66+167*player.stamina/100,h-39),GOLD,2,true)
	text(Vector2(29,h-135),"Colete %d   ·   Capacete %d" % [player.armor_level,player.helmet_level],12,MUTED)
	if player.has_jetpack:
		panel(Rect2(26,h-202,266,44))
		text(Vector2(42,h-182),"JETPACK  %d%%   [J]" % ceili(player.jet_fuel),16,MINT,true)
		panel(Rect2(42,h-174,230,4),Color("32464e"),2)
		if player.jet_fuel>0:panel(Rect2(42,h-174,maxf(3,230*player.jet_fuel/100),4),MINT,2)
	# Current weapon and ammo. No long technical weapon labels.
	panel(Rect2(w-245,h-127,216,97))
	text(Vector2(w-224,h-101),["AUR-4","VECTOR","RUPTURA"][player.slot],22,MINT,true)
	var outline=Color("b4c9ca")
	draw_rect(Rect2(w-128,h-113,69,6),outline)
	draw_line(Vector2(w-72,h-110),Vector2(w-42,h-110),outline,3,true)
	draw_line(Vector2(w-110,h-109),Vector2(w-114,h-98),outline,4,true)
	text(Vector2(w-224,h-53),"%02d" % player.mags[player.slot],48,WHITE,true)
	text(Vector2(w-169,h-55),"/ %d" % player.reserve[player.slot],17,MUTED)
	text(Vector2(w-88,h-51),"R",14,GOLD)
	# Three understandable action cards; building choices only show in build mode.
	var start=center.x-168
	for i in range(3):
		var x=start+i*115
		panel(Rect2(x,h-95,105,65),DARK,10)
		panel(Rect2(x+10,h-83,21,21),Color("345059"),5)
		text(Vector2(x+16,h-67),["G","H","B"][i],12,WHITE)
		text(Vector2(x+39,h-65),str([player.ice,player.kits,player.materials][i]),24,MINT if i==0 else GOLD if i==2 else WHITE,true)
		text(Vector2(x+11,h-43),["Gelo","Kit de cura","Construir"][i],12,MUTED)
	if game.build_mode:
		panel(Rect2(center.x-184,h-146,368,41))
		for j in range(3):
			var x=center.x-171+j*118
			var active=game.build_kind==j+1
			if active:panel(Rect2(x-3,h-141,111,30),Color("315c58"),7)
			text(Vector2(x+8,h-120),["Z  Parede","X  Rampa","C  Piso"][j],14,MINT if active else MUTED)
		text(Vector2(center.x-127,center.y+55),"Clique para construir · R para girar",13,MINT)
	elif player.reload_left>0:
		panel(Rect2(center.x-94,center.y+43,188,30))
		text(Vector2(center.x-76,center.y+64),"Recarregando  %.1f" % player.reload_left,14,GOLD)
	elif player.heal_left>0:
		panel(Rect2(center.x-78,center.y+43,156,30))
		text(Vector2(center.x-59,center.y+64),"Curando  %.1f" % player.heal_left,14,MINT)
	# Fine reticle with a contrasting outline, no screen-filling decoration.
	var gap=5 if Input.is_action_pressed("aim") else 8
	for direction in [Vector2.LEFT,Vector2.RIGHT,Vector2.UP,Vector2.DOWN]:
		draw_line(center+direction*gap,center+direction*(gap+5),Color(0,0,0,0.75),3,true)
		draw_line(center+direction*gap,center+direction*(gap+5),WHITE,1.2,true)
	draw_circle(center,1.2,WHITE)
	if game.hit_flash>0:
		for x in [-1,1]:
			for y in [-1,1]:draw_line(center+Vector2(x,y)*7,center+Vector2(x,y)*12,GOLD if game.hit_head else WHITE,2,true)
	for n in game.numbers:
		if not player.camera.is_position_behind(n.position):text(player.camera.unproject_position(n.position),str(n.amount),25,GOLD if n.head else WHITE,true)
	if game.message_left>0:
		var width=minf(650,font.get_string_size(game.message,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x+40)
		panel(Rect2(center.x-width/2,97,width,35))
		text(Vector2(center.x-width/2+20,120),game.message,14,MINT)
	for index in range(game.feed.size()):
		panel(Rect2(w-286,236+index*29,257,24),Color(0.04,0.09,0.12,0.68),7)
		text(Vector2(w-272,253+index*29),game.feed[index],12,MUTED)
	text(Vector2(28,h-12),"F1  Ajuda     Esc  Pausa",11,Color("cad5ce"))

func minimap(top: Vector2,edge: float) -> void:
	panel(Rect2(top,Vector2.ONE*edge),Color("263f3c"),14)
	var center=top+Vector2.ONE*edge/2
	var scale=(edge-14)/490
	for road in [-57,57]:
		var offset=road*scale
		draw_line(center+Vector2(offset,-edge*0.44),center+Vector2(offset,edge*0.44),Color("647371"),3,true)
		draw_line(center+Vector2(-edge*0.44,offset),center+Vector2(edge*0.44,offset),Color("647371"),3,true)
	for x in [-91,11,91]:
		for z in [-91,6,91]:
			draw_rect(Rect2(center+Vector2(x-7,z-9)*scale,Vector2(14,18)*scale),Color("a2aaa0"))
			draw_rect(Rect2(center+Vector2(x+18,z+2)*scale,Vector2(11,13)*scale),Color("7e8f86"))
	draw_circle(center,game.zone_radius*scale,Color("a2a8ef"),false,1.3,true)
	var offset=Vector2(game.player.global_position.x,game.player.global_position.z)*scale
	offset=offset.clamp(Vector2.ONE*(-edge/2+7),Vector2.ONE*(edge/2-7))
	var tip=Vector2(0,-7).rotated(game.player.yaw)
	draw_colored_polygon(PackedVector2Array([center+offset+tip,center+offset+tip.rotated(2.45)*0.7,center+offset+tip.rotated(-2.45)*0.7]),WHITE)
	panel(Rect2(top+Vector2(edge/2-9,4),Vector2(18,18)),Color("163032"),4)
	text(top+Vector2(edge/2-4,17),"N",12,MINT,true)
