class_name Supply
extends Node3D
var kind := 0
var taken := false
var tier := 1
var mesh: Node3D
var wave := 0.0
var game

func create(owner_game, type: int, at: Vector3) -> void:
	game=owner_game
	kind=type
	position=at
	if kind in [5,6]:tier=game.rng.randi_range(1,3)
	mesh=Node3D.new()
	add_child(mesh)
	var color = [Color("84dfe1"),Color("eac888"),Color("9be8a6"),Color("8baaff"),Color("e98dce"),Color("85b8ec"),Color("bed0e4"),Color("ffbc68")][kind]
	Forge.box(mesh,Vector3.ZERO,Vector3(0.65,0.4,0.6),Forge.mat(Color("243e43"),0.55,0.3))
	Forge.box(mesh,Vector3(0,0.22,0),Vector3(0.58,0.04,0.52),Forge.mat(color,0.35,0.4))
	if kind==2:
		Forge.box(mesh,Vector3(0,0.26,0),Vector3(0.32,0.02,0.1),Forge.mat(Color.WHITE))
		Forge.box(mesh,Vector3(0,0.27,0),Vector3(0.1,0.02,0.32),Forge.mat(Color.WHITE))
	if kind==5:
		Forge.box(mesh,Vector3(0,0.48,0),Vector3(0.38,0.42,0.2),Forge.mat(Color("4f6570")))
	if kind==6:
		Forge.sphere(mesh,Vector3(0,0.43,0),0.25,Forge.mat(Color("77878b")),0.3)
	if kind==7:
		for side in [-1,1]:Forge.cylinder(mesh,Vector3(side*0.15,0.52,0),0.11,0.5,Forge.mat(Color("d5ad66"),0.3,0.6))
	var ring=Forge.cylinder(self,Vector3(0,0.025,0),0.65,0.02,Forge.mat(color*0.65),-1,16)
	ring.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	wave=randf()*TAU

func _process(dt: float) -> void:
	if taken:return
	wave+=dt*1.7
	mesh.position.y=0.6+sin(wave)*0.08
	mesh.rotation.y+=dt*0.35

func take(actor: Fighter) -> String:
	if taken or not actor.alive:return ""
	if kind==5 and tier<actor.armor_level and actor.armor>0:return ""
	if kind==6 and tier<actor.helmet_level and actor.helmet_durability>0:return ""
	if kind==7 and actor.has_jetpack and actor.jet_fuel>=99.9:return ""
	taken=true
	match kind:
		0:
			actor.ice+=3
			actor.materials+=90
		1:
			actor.reserve[0]+=60
			actor.reserve[1]+=64
			actor.reserve[2]+=12
		2:
			actor.kits+=1
			actor.armor=minf([0,70,100,140][actor.armor_level],actor.armor+35)
		3:actor.unlocked[1]=true;actor.reserve[1]+=64;actor.materials+=60
		4:actor.unlocked[2]=true;actor.reserve[2]+=12;actor.materials+=60
		5:actor.equip_armor(tier)
		6:actor.equip_armor(tier,true)
		7:actor.equip_jetpack()
	queue_free()
	return ["+3 gelos · +90 materiais","Munição coletada","+1 kit · +35 escudo","Vector desbloqueada · tecla 2","Escopeta desbloqueada · tecla 3","Colete nível %d" % tier,"Capacete nível %d" % tier,"JETPACK RARO · segure Espaço para voar · J liga/desliga"][kind]
