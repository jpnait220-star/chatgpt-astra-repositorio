shader_type spatial;
render_mode cull_back;
uniform sampler2D frost_map:repeat_enable,filter_linear_mipmap;
uniform sampler2D crack_map:repeat_enable,filter_linear_mipmap;
uniform float integrity:hint_range(0.0,1.0)=1.0;
void fragment(){
 float frost=texture(frost_map,UV*2.4).r;
 float veins=texture(crack_map,UV*2.0).r;
 float cracks=1.0-smoothstep(0.025,0.09+(1.0-integrity)*0.09,veins);
 float rim=pow(1.0-max(dot(normalize(NORMAL),normalize(VIEW)),0.0),2.7);
 vec3 deep=vec3(0.15,0.49,0.64);
 vec3 milky=vec3(0.78,0.93,0.95);
 ALBEDO=mix(deep,milky,clamp(frost*0.85+rim*0.38,0.0,1.0));
 ALBEDO=mix(ALBEDO,vec3(0.85,0.98,1.0),cracks*(0.15+(1.0-integrity)*0.75));
 ROUGHNESS=0.2+frost*0.45;
 SPECULAR=0.58;
 METALLIC=0.02;
 EMISSION=vec3(0.02,0.06,0.075)*rim;
}
