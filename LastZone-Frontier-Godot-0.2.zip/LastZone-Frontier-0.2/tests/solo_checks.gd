extends RefCounted

static func wait(game,seconds: float) -> void:
 await game.get_tree().create_timer(seconds).timeout

static func run(game) -> void:
 await game.get_tree().physics_frame
 var p=game.player
 game.auto_collect=false
 for f in game.fighters:f.set_physics_process(false)
 game.check(game.fighters.size()==51 and game.alive_count()==51,"50 bots físicos e um jogador")
 game.check(LastRules.data.houses.size()==51 and LastRules.data.roads.size()==18,"51 casas e 18 estradas do HTML")
 game.check(p.max_hp==200 and p.hp==200,"vida inicial 200 do HTML")
 game.check(LastRules.IDS.size()==7,"sete armas do HTML")
 game.check(game.supplies.filter(func(s):return s.kind in [2,12]).size()>=48,"ao menos 48 medicamentos na ilha")
 game.check(game.supplies.filter(func(s):return s.kind==7).size()==2,"dois jetpacks raros iniciais")
 game.check(game.vehicles.size()==10,"dez veículos, carros e motos")
 game.check(game.island.windows.size()>=100,"janelas abertas nos andares das casas")
 game.check(game.island.grid.region.get_area()>30000,"navegação preenchida na ilha de 800m")
 var terrain=game.island.get_node("Terrain");var surface=terrain.mesh.surface_get_arrays(0);var indices=surface[Mesh.ARRAY_INDEX];var points=surface[Mesh.ARRAY_VERTEX]
 var cross=(points[indices[1]]-points[indices[0]]).cross(points[indices[2]]-points[indices[0]])
 game.check(cross.y<0,"faces do terreno apontam para o lado visível da Godot")
 var house=LastRules.data.houses[0];var at=Vector3(house.x,house.H,house.z-house.d/4)
 var floor_hit=game.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(at+Vector3.UP*.6,at-Vector3.UP*.6,1))
 game.check(not floor_hit.is_empty() and absf(floor_hit.position.y-house.H)<.2,"piso superior da casa tem colisão na altura correta")
 var safe=Vector3(0,0.2,-270)
 # Search an unobstructed patch rather than assuming the old island layout.
 for z in range(-310,-180,15):
  var query=PhysicsShapeQueryParameters3D.new();var box=BoxShape3D.new();box.size=Vector3(12,4,18);query.shape=box;query.transform.origin=Vector3(0,2.3,z);query.collision_mask=7;query.exclude=[p.get_rid()]
  if game.get_world_3d().direct_space_state.intersect_shape(query,1).is_empty():safe=Vector3(0,0.2,z);break
 p.position=safe;p.velocity=Vector3.ZERO;p.yaw=0
 var ground=game.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(safe+Vector3.UP*5,safe-Vector3.UP*5,1))
 game.check(not ground.is_empty() and absf(ground.position.y-game.island.height_at(safe.x,safe.z))<0.15,"altura visual e colisão do terreno coincidem")
 var rig=p.rig
 var required=["Idle","Walk_Carry","Run_Carry","Run","Crouch_Idle","Crouch_Fwd","Jump","Shoot_OneHanded","Reload","Consume","Throw","Death","Drive","Climb"]
 var clips_ok=true
 for key in required:clips_ok=clips_ok and rig.animation_player.has_animation(rig.resolve(key))
 game.check(clips_ok,"animações autorais resolvidas para todas as ações")
 rig.set_process(false);rig.tree.active=false
 var bone=rig.skeleton.find_bone("calf_r")
 rig.animation_player.play(rig.resolve("Run"));rig.animation_player.seek(0.05,true);rig.skeleton.force_update_all_bone_transforms()
 var pose=rig.skeleton.get_bone_pose(bone)
 rig.animation_player.seek(0.3,true);rig.skeleton.force_update_all_bone_transforms()
 game.check(not pose.is_equal_approx(rig.skeleton.get_bone_pose(bone)),"ossos das pernas mudam de pose na corrida")
 rig.animation_player.play(rig.resolve("Idle"));rig.animation_player.seek(0.3,true);rig.skeleton.force_update_all_bone_transforms()
 var head=rig.skeleton.get_bone_global_pose(rig.skeleton.find_bone("Head")).origin.y
 rig.animation_player.play(rig.resolve("Crouch_Idle"));rig.animation_player.seek(0.3,true);rig.skeleton.force_update_all_bone_transforms()
 game.check(rig.skeleton.get_bone_global_pose(rig.skeleton.find_bone("Head")).origin.y<head-0.1,"agachamento altera o esqueleto, sem comprimir modelo")
 rig.tree.active=true;rig.set_process(true)
 game.check(p.gun.get_parent() is BoneAttachment3D and p.gun.get_parent().bone_name=="hand_r","arma presa ao osso da mão")
 game.check(rig.head_hair!=null and rig.model.scale==Vector3.ONE*1.04,"novo humano com cabelo, sem robô anterior")
 var clothes=rig.model.find_child("Shirt",true,false) as MeshInstance3D
 game.check(clothes!=null and clothes.get_active_material(0) is StandardMaterial3D and clothes.get_active_material(0).albedo_texture!=null,"camisa tem geometria com pesos e textura de tecido")
 p.collect_weapon(1);p.collect_weapon(2);p.collect_weapon(3)
 game.check(p.carried.size()==3 and p.carried.has(3) and not p.unlocked[2],"inventário limitado a três armas")
 p.collect_weapon(1);p.switch_weapon(1);p.mags[1]=0;p.reserve[1]=64
 p.reload_weapon();p.finish_reload();p.reload_left=0
 game.check(p.mags[1]==25 and p.reserve[1]==39,"UMP recarrega 25 e conserva munição")
 var pitch=p.pitch;p.cooldown=0;p.shoot_at(safe+Vector3(0,1.3,-50))
 game.check(p.pitch==pitch and p.mags[1]==24,"tiro consome bala sem elevar a mira")
 game.check(LastRules.damage_at(5,5)==8 and LastRules.damage_at(5,40)==1.5,"escopeta perde dano por distância como no HTML")
 game.check(LastRules.damage_at(3,55,true)==123.5 and game.damage_multiplier(6,105)>0,"AWM e SCAR usam tabelas próprias sem índice inválido")
 # Ray combat on an isolated frozen bot.
 var bot=game.fighters[1];bot.position=safe+Vector3(0,0,-8);bot.hp=200;bot.armor=0
 await game.get_tree().physics_frame
 var hp=bot.hp;p.slot=1
 game.fire_ray(p,safe+Vector3(0,1.2,-3),safe+Vector3(0,1.2,-12),13)
 game.check(bot.hp<hp,"raio de tiro atinge adversário real")
 bot.position=Vector3(370,1,0)
 p.position=safe;p.yaw=0;p.ice=8;game.next_build=0
 await game.get_tree().physics_frame
 var built=game.place_cover(0)
 game.check(built and p.ice==7,"gelo colocado e recurso consumido")
 if built:
  var c=game.covers.back()
  game.check(c.get_child(0).shape is ConcavePolygonShape3D and c.ice_surface!=null,"gelo curvo usa malha física e material de gelo")
  await wait(game,0.2)
  var ice_hp=c.hp
  game.fire_ray(p,c.position+Vector3(0,1.4,4),c.position+Vector3(0,1.4,-4),13)
  game.check(c.hp<ice_hp and float(c.ice_surface.get_shader_parameter("integrity"))<1,"tiro no gelo reduz resistência e revela rachaduras")
  game.next_build=0;game.check(not game.place_cover(0),"gelo não sobrepõe outra barreira")
  c.damage(9999)
  await game.get_tree().physics_frame
 p.set_physics_process(true);p.position=safe;p.velocity=Vector3.ZERO
 await wait(game,0.25)
 Input.action_press("forward");await wait(game,0.5)
 game.check(absf(Vector2(p.velocity.x,p.velocity.z).length()-5.2)<0.1,"movimento normal 5,2 m/s")
 Input.action_press("sprint");await wait(game,0.4)
 game.check(absf(Vector2(p.velocity.x,p.velocity.z).length()-8.5)<0.1,"corrida 8,5 m/s")
 Input.action_release("sprint");Input.action_press("crouch");await wait(game,0.35)
 game.check(p.crouched and absf(Vector2(p.velocity.x,p.velocity.z).length()-2.6)<0.1 and is_equal_approx(p.get_child(0).shape.height,1.15),"agachar 2,6 m/s e cápsula ajustada")
 Input.action_release("crouch");Input.action_release("forward");p.velocity=Vector3.ZERO;p.position=safe
 await wait(game,0.25)
 p.start_slide();game.check(p.slide_left>0 and p.slide_cooldown>0,"deslize tem duração e intervalo")
 await wait(game,0.65)
 p.position=safe;p.velocity=Vector3.ZERO;p.hp=100;p.small_kits=2
 p.begin_heal("small");game.check(p.small_kits==1 and p.heal_left==2,"kitzinho consumido ao iniciar, duração 2s")
 await wait(game,2.1)
 game.check(p.hp==125,"cura pequena recupera 25 de vida")
 p.begin_heal("large");p.damage(1,null,false,true)
 game.check(p.heal_left==0,"dano interrompe cura")
 p.equip_jetpack();p.jet_enabled=true;p.position=safe+Vector3.UP*2;p.velocity=Vector3.ZERO
 var fuel=p.jet_fuel
 Input.action_press("jump");await wait(game,0.5);Input.action_release("jump")
 game.check(p.jet_fuel<fuel-10 and p.velocity.y>0,"jetpack aplica impulso e consome 28/s no ar")
 p.jet_enabled=false;p.position=safe;p.velocity=Vector3.ZERO
 await wait(game,0.5);p.jet_fuel=40;await wait(game,0.5)
 game.check(p.jet_fuel>46,"jetpack recarrega 15/s no chão")
 p.set_physics_process(false);p.position=safe;p.velocity=Vector3.ZERO
 # A local fixture vehicle tests actual steering and collisions on the road.
 var vehicle=game.vehicles[0];vehicle.position=safe+Vector3(0,0,-15);vehicle.speed=0;vehicle.heading=0
 await game.get_tree().physics_frame
 game.check(vehicle.enter(p) and p.collision_layer==0,"entrar no carro muda estado e colisão do ocupante")
 var start=vehicle.position
 Input.action_press("forward")
 for i in range(45):vehicle.drive(1.0/60,p);await game.get_tree().physics_frame
 Input.action_release("forward")
 game.check(vehicle.global_position.distance_to(start)>1 and vehicle.speed>5,"carro acelera e se desloca com física")
 game.check(vehicle.leave() and p.vehicle==null and p.collision_mask==7,"saída livre restaura jogador e colisões")
 # Find a real window with an unoccupied destination.
 var vaulted=false
 for window in game.island.windows:
  if window.position.y>2:continue
  p.position=window.position+window.normal*1.65-Vector3.UP*0.95
  p.yaw=atan2(window.normal.x,window.normal.z)
  if game.try_vault(p):vaulted=true;break
 game.check(vaulted and p.vault_time==0.5,"janela real inicia transposição de 0,5s")
 if vaulted:
  p.set_physics_process(true);var end=p.vault_end;await wait(game,0.6)
  game.check(p.global_position.distance_to(end)<0.6 and p.collision_mask==7,"transposição termina e restaura colisões")
 p.set_physics_process(false);p.position=safe
 p.grenades=1;game.throw_grenade()
 game.check(p.grenades==0 and game.get_children().any(func(n):return n is RigidBody3D),"granada física lançada e contagem consumida")
 var old=game.elapsed;game.elapsed=52.5;game.update_zone()
 game.check(game.zone_state=="shrink" and absf(game.zone_radius-332.5)<0.1,"zona espera 35s e contrai no tempo do HTML")
 game.elapsed=10000;game.update_zone();game.check(game.zone_radius<=20 and game.zone_damage>4,"zona chega ao círculo final")
 game.elapsed=old;game.update_zone()
 var dead=game.fighters[2];dead.collect_weapon(6);dead.kits=2;dead.small_kits=4
 var kills=p.kills;var loot=game.supplies.size();dead.damage(9999,p)
 game.check(not dead.alive and p.kills==kills+1 and game.supplies.size()>=loot+5,"eliminação contabiliza e deixa armas, kits e recursos")
 p.collect_weapon(6);p.mags[6]=7;p.reserve[6]=11;game.drop_weapon(6)
 var dropped=game.supplies.back();var receiver=game.fighters[5];receiver.carried.assign([0]);receiver.unlocked=[true,false,false,false,false,false,false];receiver.mags[6]=0;receiver.reserve[6]=0;dropped.take(receiver)
 game.check(receiver.mags[6]==7 and receiver.reserve[6]==11,"arma largada conserva carregador e reserva")
 game.check(Ambience.sounds.size()>=18 and Ambience.sounds.engine.loop_mode!=0,"efeitos de som e motor em loop")
 # Open each native interface to catch runtime errors that parsing cannot detect.
 FrontierUI.inventory(game);await game.get_tree().process_frame;game.check(game.ui_mode=="inventory","inventário nativo abre")
 FrontierUI.big_map(game);await game.get_tree().process_frame;game.check(game.ui_mode=="map","mapa completo abre")
 FrontierUI.wardrobe(game);await game.get_tree().process_frame;game.check(game.ui_mode=="wardrobe" and game.menu.find_children("*","SubViewport",true,false).size()==1 and game.menu.find_children("*","SubViewport",true,false)[0].is_inside_tree(),"cofre e personagem 3D estão na árvore de cena")
 FrontierUI.settings(game);await game.get_tree().process_frame;game.check(game.ui_mode=="settings","remapeamento de teclado e mouse abre")
 game.player.rig.set_outfit({"hair_id":"guard"});await game.get_tree().process_frame
 game.player.rig.set_outfit({"hair_id":"natural"});await game.get_tree().process_frame
 game.close_menu();game.paused=false
 var saved=game.outfit.duplicate();game.outfit.shirt="#123456";game.save_settings();game.outfit.shirt="#ffffff";game.load_settings()
 game.check(game.outfit.shirt=="#123456","visual persiste entre sessões")
 game.outfit=saved;game.save_settings()
 var original=InputMap.action_get_events("fire")[0]
 var binding=InputEventMouseButton.new();binding.button_index=MOUSE_BUTTON_MIDDLE;binding.pressed=true;game.rebinding_action="fire";game._input(binding)
 game.load_settings()
 game.check(InputMap.action_get_events("fire")[0] is InputEventMouseButton and InputMap.action_get_events("fire")[0].button_index==MOUSE_BUTTON_MIDDLE,"botão do mouse remapeado persiste nas configurações")
 InputMap.action_erase_events("fire");InputMap.action_add_event("fire",original);game.rebinding_action="";game.close_menu();game.paused=false;game.save_settings()
 var moving=game.fighters[3];moving.set_physics_process(true);var first=moving.global_position
 await wait(game,4)
 game.check(first.distance_to(moving.global_position)>0.5 and moving.global_position.y>-3,"bot se move pela ilha sem atravessar terreno")
 print("SOLO CHECKS COMPLETE ",game.checks.size(),"; failures ",game.checks.filter(func(s):return s.begins_with("FAIL")).size())
 var file=FileAccess.open("user://smoke-result.txt",FileAccess.WRITE);file.store_string("\n".join(game.checks));file.close()
 game.get_tree().quit(1 if game.checks.any(func(s):return s.begins_with("FAIL")) else 0)
