extends Node3D

var island: Island
var fighters: Array[Fighter]=[]
var supplies: Array[Supply]=[]
var covers: Array[Cover]=[]
var player: Fighter
var ui_mode := ""
var outfit: Dictionary={"model":0,"shirt":"#496477","pants":"#34414b","hair":"#29231f","mask_id":"none","boots_id":"pad","boots":"#2a2018"}
var rebinding_action := ""
var vehicles: Array=[]
var auto_collect := true
var zone_phase := 0
var zone_phase_time := 0.0
var zone_state := "wait"
var zone_target_center := Vector3.ZERO
var zone_schedule: Array[Dictionary]=[]
var allow_airdrop := true
var running := false
var paused := false
var loading := false
var elapsed := 0.0
var difficulty := 1
var quality := 1
var sensitivity := 0.0022
var zone_center := Vector3.ZERO
var zone_radius := 395.0
var zone_damage := 4.0
var zone_mesh: MeshInstance3D
var preview: MeshInstance3D
var build_mode := false
var build_kind := 1
var build_rotation := 0.0
var placement := Vector3.ZERO
var placement_yaw := 0.0
var place_valid := false
var next_build := 0.0
var hurt_flash := 0.0
var hit_flash := 0.0
var hit_head := false
var shots_fired := 0
var hit_count := 0
var tracers := 0
var audio_count := 0
var message := ""
var message_left := 0.0
var feed: Array[String]=[]
var numbers: Array[Dictionary]=[]
var gui: CanvasLayer
var hud: Control
var menu: Control
var menu_box: VBoxContainer
var flycam: Camera3D
var environment: WorldEnvironment
var sun: DirectionalLight3D
var rng := RandomNumberGenerator.new()
var loot_tick := 0.0
var save := ConfigFile.new()
var map_ready := false
var smoke_mode := false
var screenshot_mode := false
var smoke_clock := 0.0
var match_index := 0
var checks: Array[String]=[]
var music: AudioStreamPlayer
var music_enabled := true
var music_volume := -22.0

func _ready() -> void:
	rng.randomize()
	smoke_mode="--smoke" in OS.get_cmdline_user_args()
	screenshot_mode="--capture" in OS.get_cmdline_user_args()
	setup_inputs()
	load_settings()
	Ambience.make_sounds()
	create_music()
	var limiter=AudioEffectLimiter.new()
	limiter.ceiling_db=-1
	limiter.threshold_db=-7
	AudioServer.add_bus_effect(0,limiter)
	create_sky()
	island=Island.new()
	island.game=self
	add_child(island)
	island.generate()
	map_ready=true
	flycam=Camera3D.new()
	flycam.far=1400
	flycam.position=Vector3(105,76,132)
	add_child(flycam)
	flycam.look_at(Vector3(0,0,-12))
	flycam.current=true
	create_zone()
	preview=MeshInstance3D.new()
	var shape=BoxMesh.new()
	shape.size=Vector3(5.5,3.2,0.3)
	preview.mesh=shape
	preview.visible=false
	add_child(preview)
	gui=CanvasLayer.new()
	add_child(gui)
	hud=load("res://scripts/hud.gd").new()
	hud.game=self
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter=Control.MOUSE_FILTER_IGNORE
	gui.add_child(hud)
	apply_quality()
	show_menu()
	if smoke_mode or screenshot_mode:call_deferred("start_match")
	if "--capture-menu" in OS.get_cmdline_user_args():call_deferred("capture_menu")

func setup_inputs() -> void:
	var keys={"forward":KEY_W,"back":KEY_S,"left":KEY_A,"right":KEY_D,"sprint":KEY_SHIFT,"crouch":KEY_C,"crouch_toggle":KEY_CTRL,"jump":KEY_SPACE,"reload":KEY_R,"ice":KEY_T,"build":KEY_N,"interact":KEY_E,"heal":KEY_H,"one":KEY_1,"two":KEY_2,"three":KEY_3,"wall":KEY_Z,"ramp":KEY_X,"floor":KEY_C,"pause":KEY_ESCAPE,"fullscreen":KEY_F11,"help":KEY_F1,"jetpack":KEY_K,"inventory":KEY_TAB,"map":KEY_M,"vehicle":KEY_B,"grenade":KEY_G,"large_heal":KEY_J,"slide":KEY_Q,"camera_view":KEY_F5,"freelook":KEY_ALT,"vault":KEY_V,"collect_mode":KEY_L}
	for action in keys:
		InputMap.add_action(action)
		var event=InputEventKey.new()
		event.physical_keycode=keys[action]
		InputMap.action_add_event(action,event)
	for action in ["fire","aim"]:
		InputMap.add_action(action)
		var event=InputEventMouseButton.new()
		event.button_index=MOUSE_BUTTON_LEFT if action=="fire" else MOUSE_BUTTON_RIGHT
		InputMap.action_add_event(action,event)

func create_sky() -> void:
	environment=WorldEnvironment.new()
	var env=Environment.new()
	env.background_mode=Environment.BG_SKY
	var sky=Sky.new()
	var sky_mat=ProceduralSkyMaterial.new()
	sky_mat.sky_top_color=Color("45677d")
	sky_mat.sky_horizon_color=Color("bdc9c3")
	sky_mat.ground_horizon_color=Color("aab8af")
	sky_mat.ground_bottom_color=Color("4a665d")
	sky.sky_material=sky_mat
	env.sky=sky
	env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color=Color("a5c1c8")
	env.ambient_light_energy=0.3
	env.tonemap_mode=Environment.TONE_MAPPER_FILMIC
	env.fog_enabled=true
	env.fog_light_color=Color("b1c1bc")
	env.fog_density=0.0015
	env.fog_sky_affect=0.35
	environment.environment=env
	add_child(environment)
	sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-34,-38,0)
	sun.light_color=Color("ffe3b0")
	sun.light_energy=0.95
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=105
	add_child(sun)

func create_zone() -> void:
	zone_mesh=MeshInstance3D.new()
	var mesh=CylinderMesh.new()
	mesh.top_radius=1
	mesh.bottom_radius=1
	mesh.height=95
	mesh.radial_segments=128
	mesh.cap_top=false
	mesh.cap_bottom=false
	zone_mesh.mesh=mesh
	var material=StandardMaterial3D.new()
	material.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color=Color(0.32,0.39,0.9,0.14)
	material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode=BaseMaterial3D.CULL_DISABLED
	zone_mesh.material_override=material
	zone_mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	zone_mesh.position.y=42
	zone_mesh.scale=Vector3(zone_radius,1,zone_radius)
	zone_mesh.visible=false
	add_child(zone_mesh)

func start_match() -> void:
	if loading:return
	loading=true
	running=false
	paused=false
	close_menu()
	notice("Preparando a ilha e os 50 adversários…",20)
	for a in fighters:
		if is_instance_valid(a):a.queue_free()
	for item in supplies:
		if is_instance_valid(item):item.queue_free()
	for c in covers:
		if is_instance_valid(c):c.queue_free()
	for v in vehicles:
		if is_instance_valid(v):v.queue_free()
	vehicles.clear()
	fighters.clear();supplies.clear();covers.clear();numbers.clear();feed.clear()
	player=null
	await get_tree().process_frame
	elapsed=0;zone_radius=395;zone_center=Vector3.ZERO;zone_damage=4
	shots_fired=0;hit_count=0;build_mode=false;build_rotation=0
	hurt_flash=0;hit_flash=0
	match_index+=1
	player=Fighter.new()
	add_child(player)
	player.setup(self,true,0)
	player.position=Vector3(0,0.25,-35)
	fighters.append(player)
	var used: Array[Vector3]=[player.position]
	for index in range(50):
		var bot=Fighter.new()
		add_child(bot)
		bot.setup(self,false,index)
		var p=island.spawn_points[rng.randi()%island.spawn_points.size()]
		for attempt in range(60):
			var safe=true
			for other in used:
				if p.distance_to(other)<10:safe=false;break
			if safe and p.distance_to(player.position)>22:break
			p=island.spawn_points[rng.randi()%island.spawn_points.size()]
		bot.position=p+Vector3.UP*0.15
		used.append(p)
		fighters.append(bot)
		if index%5==0:await get_tree().process_frame
	var loot_records: Array[Dictionary]=[]
	for house in LastRules.data.houses:
		for floor_index in range(int(house.floors)):
			for k in range(2):
				var at=Vector3(house.x+rng.randf_range(-house.w*0.22,house.w*0.22),floor_index*house.H+0.13,house.z-house.d*0.25 if floor_index else house.z+rng.randf_range(-1.5,1.5))
				loot_records.append({"kind":random_loot(),"at":at})
	for i in range(45):loot_records.append({"kind":random_loot(),"at":island.spawn_points[rng.randi()%island.spawn_points.size()]})
	var medicine=loot_records.filter(func(item):return item.kind in [2,12]).size()
	for item in loot_records:
		if medicine>=48:break
		if item.kind in [0,1,13]:item.kind=2 if medicine%3==0 else 12;medicine+=1
	for item in loot_records:spawn_supply(item.kind,item.at)
	for i in range(18):spawn_supply(5,island.spawn_points[rng.randi()%island.spawn_points.size()])
	for i in range(15):spawn_supply(6,island.spawn_points[rng.randi()%island.spawn_points.size()])
	var rare_points=island.spawn_points.filter(func(at):return at.distance_to(player.position)>65)
	for i in range(2):spawn_supply(7,rare_points[(rng.randi()%maxi(1,rare_points.size()/2))+(i*rare_points.size()/2)])
	spawn_vehicles()
	prepare_zones()
	player.rig.set_outfit(outfit)
	if allow_airdrop and not smoke_mode and not screenshot_mode:
		player.position.y=130+rng.randf_range(0,20);player.deployment_state="fall"
		for bot in fighters:
			if not bot.human:bot.position.y=130+rng.randf_range(0,20);bot.deployment_state="fall"
	flycam.current=false
	player.camera.current=true
	zone_mesh.visible=true
	loading=false
	running=true
	Input.mouse_mode=Input.MOUSE_MODE_CAPTURED if not smoke_mode and not screenshot_mode else Input.MOUSE_MODE_VISIBLE
	notice("OPERAÇÃO INICIADA · 50 bots · sobreviva até o fim",5)
	if smoke_mode:await run_checks()

func _process(dt: float) -> void:
	if not running and not loading and not player:
		var t=Time.get_ticks_msec()*0.000018
		flycam.position=Vector3(125*cos(t),77,125*sin(t))
		flycam.look_at(Vector3(0,0,0))
	if running and not paused:
		elapsed+=dt
		update_zone()
		hurt_flash=maxf(0,hurt_flash-dt)
		hit_flash=maxf(0,hit_flash-dt)
		next_build=maxf(0,next_build-dt)
		message_left=maxf(0,message_left-dt)
		loot_tick-=dt
		if loot_tick<=0:
			loot_tick=0.25
			if player and player.alive and auto_collect and player.deployment_state=="ground":auto_loot(player)
		if build_mode:update_preview()
		for n in numbers:n.time-=dt;n.position.y+=dt*0.6
		numbers=numbers.filter(func(n):return n.time>0)
	if screenshot_mode and running:
		smoke_clock+=dt
		if smoke_clock>0.6:
			screenshot_mode=false
			paused=true
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png("user://captura-jogo.png")
			print("CAPTURE ",ProjectSettings.globalize_path("user://captura-jogo.png"))
			get_tree().quit()
	if hud:hud.queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("fullscreen"):
		var mode=DisplayServer.window_get_mode()
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if mode==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)
	if event.is_action_pressed("pause") and running:
		if paused:close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
		else:paused=true;show_menu(true)
		return
	if running and player and player.alive:
		if event.is_action_pressed("inventory"):
			if ui_mode=="inventory":FrontierUI.resume(self)
			else:FrontierUI.inventory(self)
			return
		if event.is_action_pressed("map"):
			if ui_mode=="map":FrontierUI.resume(self)
			else:FrontierUI.big_map(self)
			return
	if not running or paused or not player or not player.alive:return
	if event is InputEventMouseMotion and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:
		if Input.is_action_pressed("freelook"):
			player.free_yaw=clampf(player.free_yaw-event.relative.x*sensitivity,-PI,PI)
			player.free_pitch=clampf(player.free_pitch-event.relative.y*sensitivity,-0.8,0.8)
		else:
			player.yaw-=event.relative.x*sensitivity
			player.pitch=clampf(player.pitch-event.relative.y*sensitivity,-1.2,0.95)
	if event.is_action_pressed("help"):paused=true;show_help();return
	if event.is_action_pressed("reload"):
		if build_mode:build_rotation+=PI/2
		else:player.reload_weapon()
	if event.is_action_pressed("jetpack") and player.has_jetpack:
		player.jet_enabled=not player.jet_enabled
		notice("Jetpack ligado · Espaço para voar" if player.jet_enabled else "Jetpack desligado",2)
	if event.is_action_pressed("one") and player.carried.size()>0:player.switch_weapon(player.carried[0]);build_mode=false
	if event.is_action_pressed("two") and player.carried.size()>1:player.switch_weapon(player.carried[1]);build_mode=false
	if event.is_action_pressed("three") and player.carried.size()>2:player.switch_weapon(player.carried[2]);build_mode=false
	if event.is_action_pressed("build"):build_mode=not build_mode
	if event.is_action_pressed("wall"):build_kind=1;build_mode=true
	if event.is_action_pressed("ramp"):build_kind=2;build_mode=true
	if event.is_action_pressed("floor") and build_mode:build_kind=3
	if event.is_action_pressed("ice"):place_cover(0)
	if event.is_action_pressed("heal"):player.begin_heal("small")
	if event.is_action_pressed("large_heal"):player.begin_heal("large")
	if event.is_action_pressed("crouch_toggle"):player.crouch_latched=not player.crouch_latched
	if event.is_action_pressed("slide"):player.start_slide()
	if event.is_action_pressed("camera_view"):player.camera_mode=(player.camera_mode+1)%3
	if event.is_action_pressed("vault"):try_vault(player)
	if event.is_action_pressed("vehicle"):use_vehicle()
	if event.is_action_pressed("grenade"):throw_grenade()
	if event.is_action_pressed("collect_mode"):auto_collect=not auto_collect;notice("Coleta automática" if auto_collect else "Coleta manual · E",2)
	if event.is_action_pressed("interact"):auto_loot(player,4)
	if event.is_action_pressed("fire") and build_mode:place_cover(build_kind)
	if not build_mode:preview.visible=false

func prepare_zones() -> void:
	zone_schedule.clear()
	var center=Vector3.ZERO
	var radius=395.0
	var time=0.0
	for phase in LastRules.data.zones:
		var angle=rng.randf()*TAU
		var distance=maxf(0,radius-phase.r)*rng.randf()*0.8
		var target=center+Vector3(cos(angle),0,sin(angle))*distance
		zone_schedule.append({"start":time,"wait":float(phase.w),"shrink":float(phase.s),"from":center,"to":target,"r0":radius,"r1":float(phase.r)})
		time+=phase.w+phase.s;center=target;radius=phase.r

func update_zone() -> void:
	if zone_schedule.is_empty():prepare_zones()
	var phase=zone_schedule.back()
	zone_phase=zone_schedule.size()-1
	for i in range(zone_schedule.size()):
		var step=zone_schedule[i]
		if elapsed<step.start+step.wait+step.shrink:phase=step;zone_phase=i;break
	zone_phase_time=elapsed-phase.start
	zone_state="wait" if zone_phase_time<phase.wait else "shrink"
	var t=clampf((zone_phase_time-phase.wait)/phase.shrink,0,1)
	zone_center=phase.from.lerp(phase.to,t)
	zone_target_center=phase.to
	zone_radius=lerpf(phase.r0,phase.r1,t)
	zone_damage=4+zone_phase*2
	zone_mesh.position=zone_center+Vector3.UP*42
	zone_mesh.scale=Vector3(zone_radius,1,zone_radius)

func alive_count() -> int:
	var count=0
	for f in fighters:
		if is_instance_valid(f) and f.alive:count+=1
	return count

func has_sight(a: Fighter,b: Fighter) -> bool:
	var from=a.global_position+Vector3(0,1.5,0)
	var to=b.global_position+Vector3(0,1.2,0)
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(from,to,7,[a.get_rid()]))
	return hit.is_empty() or hit.collider==b

func fire_ray(actor: Fighter,from: Vector3,to: Vector3,damage: float) -> Dictionary:
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(from,to,7,[actor.get_rid()]))
	var end=hit.position if not hit.is_empty() else to
	if tracers<55:
		tracers+=1
		var line=Forge.line(self,from,end,Color("ffdf9d"),0.018 if actor.human else 0.012)
		get_tree().create_timer(0.055).timeout.connect(func():if is_instance_valid(line):line.queue_free();tracers-=1)
	if not hit.is_empty():
		var body=hit.collider
		if body is Fighter or body is Cover or body is RoadVehicle:
			var head=body is Fighter and hit.position.y-body.global_position.y>1.48
			var falloff=damage_multiplier(actor.slot,from.distance_to(hit.position))
			var health_before=body.hp
			body.damage(damage*falloff,actor,head)
			if actor.human:
				if hit_flash<=0:sound_at("hit",actor.global_position,-11)
				hit_flash=0.16
				hit_head=head
				hit_count+=1
				var merged=false
				for n in numbers:
					if n.get("body",-1)==body.get_instance_id() and n.time>0.68:
						n.amount+=maxi(1,roundi(health_before-body.hp));n.head=n.head or head;merged=true;break
				if not merged:numbers.append({"body":body.get_instance_id(),"position":hit.position+Vector3.UP*0.25,"amount":maxi(1,roundi(health_before-body.hp)),"time":0.8,"head":head})
	return hit

func get_placement(kind: int) -> Dictionary:
	var direction=Vector3(-sin(player.yaw),0,-cos(player.yaw))
	var at=player.global_position+direction*(5.0 if kind==2 else 4.6)
	var hit=get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(at+Vector3.UP*8,at-Vector3.UP*12,1))
	if hit.is_empty():return {"valid":false,"position":at,"yaw":player.yaw+build_rotation}
	if kind==0 and hit.collider is Cover:return {"valid":false,"position":at,"yaw":player.yaw+build_rotation}
	at.y=hit.position.y+0.06
	var angle=snappedf(player.yaw+build_rotation,PI/12)
	var height=2.8 if kind==0 else 3.2 if kind!=3 else 0.28
	var size=Vector3(6.7 if kind==0 else 5.5,height,1.65 if kind==0 else 0.4 if kind==1 else 6.2)
	var shape=BoxShape3D.new()
	shape.size=size*0.94
	var q=PhysicsShapeQueryParameters3D.new()
	q.shape=shape
	q.transform=Transform3D(Basis(Vector3.UP,angle),at+Vector3.UP*(height/2+0.05))
	q.collision_mask=3
	q.exclude=[player.get_rid()]
	var result=get_world_3d().direct_space_state.intersect_shape(q,6)
	var valid=result.is_empty() and at.distance_to(player.global_position)<10 and at.y-player.global_position.y<5
	if kind==0:valid=valid and player.ice>0
	else:valid=valid and player.materials>=30
	return {"valid":valid,"position":at,"yaw":angle}

func update_preview() -> void:
	var place=get_placement(build_kind)
	place_valid=place.valid
	placement=place.position
	placement_yaw=place.yaw
	preview.visible=true
	var size=[Vector3(6.6,2.8,0.8),Vector3(5.5,3.2,0.3),Vector3(5.5,0.3,6.2),Vector3(5.5,0.28,5.5)][build_kind]
	(preview.mesh as BoxMesh).size=size
	preview.rotation=Vector3(deg_to_rad(32) if build_kind==2 else 0,placement_yaw,0)
	preview.position=placement+Vector3.UP*(1.5 if build_kind==2 else size.y/2)
	var mat=StandardMaterial3D.new()
	mat.albedo_color=Color(0.3,0.95,0.8,0.42) if place_valid else Color(1,0.25,0.2,0.4)
	mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	preview.material_override=mat

func place_cover(kind: int) -> bool:
	if next_build>0:return false
	var place=get_placement(kind)
	if not place.valid:
		notice("Sem espaço ou recursos · mire numa área livre",2)
		return false
	covers=covers.filter(func(c):return is_instance_valid(c))
	if covers.size()>=90:
		notice("Limite de 90 construções na ilha",2)
		return false
	var c=Cover.new()
	add_child(c)
	c.create(self,kind,place.position,place.yaw)
	covers.append(c)
	var visuals=c.get_child(1) as Node3D
	visuals.scale=Vector3.ONE*0.15
	c.create_tween().tween_property(visuals,"scale",Vector3.ONE,0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	island.add_dynamic(c)
	if kind==0:player.ice-=1
	else:player.materials-=30
	next_build=0.35
	sound_at("ice" if kind==0 else "build",place.position,-9)
	return true

func spawn_supply(kind: int,at: Vector3) -> Supply:
	var item=Supply.new()
	add_child(item)
	item.create(self,kind,at)
	supplies.append(item)
	return item

func auto_loot(actor: Fighter,distance: float = 1.8) -> void:
	for item in supplies:
		if not is_instance_valid(item) or item.taken:continue
		if actor.global_position.distance_squared_to(item.global_position)<distance*distance:
			var text=item.take(actor)
			if actor.human and not text.is_empty():notice(text,2.5);sound_at("pickup",actor.global_position,-12)

func on_eliminated(victim: Fighter,killer: Fighter) -> void:
	feed.push_front((killer.nickname if killer else "ZONA")+"  ›  "+victim.nickname)
	if feed.size()>4:feed.pop_back()
	var weapon_types={1:3,2:4,3:8,4:9,5:10,6:11}
	for index in victim.carried:
		if index==0:continue
		var offset=Vector3(cos(index*2.4),0,sin(index*2.4))*2.2
		var item=spawn_supply(weapon_types[index],victim.global_position+offset)
		item.payload={"mag":victim.mags[index],"reserve":victim.reserve[index]}
	if victim.kits>0:
		var item=spawn_supply(2,victim.global_position+Vector3(1.4,0,1.4));item.payload={"quantity":victim.kits}
	if victim.small_kits>0:
		var item=spawn_supply(12,victim.global_position+Vector3(-1.4,0,1.4));item.payload={"quantity":victim.small_kits}
	spawn_supply(1,victim.global_position)
	spawn_supply(0,victim.global_position+Vector3(1.5,0,0))
	if victim.has_jetpack:spawn_supply(7,victim.global_position+Vector3(-1.5,0,0))
	if victim.armor_level>0 and victim.armor>0:
		var item=spawn_supply(5,victim.global_position+Vector3(0,0,1.5))
		item.tier=victim.armor_level
	if victim.helmet_level>0 and victim.helmet_durability>0:
		var item=spawn_supply(6,victim.global_position+Vector3(0,0,-1.5))
		item.tier=victim.helmet_level
	if smoke_mode:return
	if victim.human:
		finish_match(false)
	elif alive_count()==1 and player.alive:finish_match(true)

func finish_match(won: bool) -> void:
	running=false
	preview.visible=false
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	show_menu(false,("VITÓRIA ROYALE" if won else "FIM DA OPERAÇÃO"))

func notice(text: String,seconds: float = 3) -> void:
	message=text
	message_left=seconds

func sound_at(name: String,at: Vector3,db: float) -> void:
	if audio_count>=28 or not Ambience.sounds.has(name) or smoke_mode:return
	if player and at.distance_squared_to(player.global_position)>90*90:return
	audio_count+=1
	var sound=AudioStreamPlayer3D.new()
	sound.stream=Ambience.sounds[name]
	sound.volume_db=db
	sound.pitch_scale=randf_range(0.88,1.12) if name in ["step","shot","smg","shotgun","land"] else 1.0
	sound.max_distance=90
	sound.unit_size=6
	add_child(sound)
	sound.global_position=at+Vector3.UP
	sound.finished.connect(func():sound.queue_free();audio_count-=1)
	sound.play()

func load_settings() -> void:
	if save.load("user://settings.cfg")==OK:
		music_enabled=save.get_value("settings","music_enabled",true)
		music_volume=save.get_value("settings","music_volume",-22.0)
		outfit.merge(save.get_value("settings","outfit",{}),true)
		for action in save.get_section_keys("bindings") if save.has_section("bindings") else []:
			if not InputMap.has_action(action):continue
			var binding=save.get_value("bindings",action)
			var event=InputEventKey.new() if binding.type=="key" else InputEventMouseButton.new()
			if event is InputEventKey:event.physical_keycode=int(binding.code)
			else:event.button_index=int(binding.code)
			InputMap.action_erase_events(action);InputMap.action_add_event(action,event)
		sensitivity=float(save.get_value("settings","sensitivity",0.0022))
		quality=int(save.get_value("settings","quality",1))
		difficulty=int(save.get_value("settings","difficulty",1))
		AudioServer.set_bus_volume_db(0,float(save.get_value("settings","volume",-5)))

func save_settings() -> void:
	save.set_value("settings","music_enabled",music_enabled)
	save.set_value("settings","music_volume",music_volume)
	save.set_value("settings","outfit",outfit)
	for action in InputMap.get_actions():
		if action.begins_with("ui_"):continue
		var events=InputMap.action_get_events(action)
		if not events.is_empty():
			var event=events[0]
			if event is InputEventKey:save.set_value("bindings",action,{"type":"key","code":event.physical_keycode})
			elif event is InputEventMouseButton:save.set_value("bindings",action,{"type":"mouse","code":event.button_index})
	for key in ["sensitivity","quality","difficulty"]:save.set_value("settings",key,get(key))
	save.set_value("settings","volume",AudioServer.get_bus_volume_db(0))
	save.save("user://settings.cfg")

func apply_quality() -> void:
	sun.shadow_enabled=quality>0
	get_viewport().msaa_3d=[Viewport.MSAA_DISABLED,Viewport.MSAA_2X,Viewport.MSAA_4X][quality]
	get_viewport().scaling_3d_scale=[0.8,1.0,1.0][quality]

func show_menu(in_match: bool = false,title: String = "") -> void:
	close_menu()
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	menu=Control.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gui.add_child(menu)
	var backdrop=ColorRect.new()
	backdrop.color=Color(0.035,0.07,0.09,0.55)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(backdrop)
	var left=VBoxContainer.new()
	left.position=Vector2(64,78)
	left.add_theme_constant_override("separation",12)
	menu.add_child(left)
	label(left,"LAST ZONE",56,Color("ecf5ec"))
	label(left,"F R O N T I E R",26,Color("8ce1d0"))
	label(left,"SEU LASTZONE · AGORA NA GODOT",16,Color("efd6ac"))
	label(left,"Uma ilha. Cinquenta adversários.\nA última escolha é sobreviver.",18,Color("d1dedc"))
	var line=ColorRect.new()
	line.color=Color("8ce1d0")
	line.custom_minimum_size=Vector2(62,3)
	left.add_child(line)
	label(left,"TIRO EM TERCEIRA PESSOA\nGELO DEFENSIVO · CONSTRUÇÃO RÁPIDA\nPARTIDA OFFLINE · ZONA DINÂMICA",13,Color("ced8d2"))
	var panel=PanelContainer.new()
	panel.position=Vector2(804,58)
	panel.size=Vector2(412,602)
	var style=StyleBoxFlat.new()
	style.bg_color=Color(0.045,0.09,0.11,0.96)
	style.corner_radius_top_left=18;style.corner_radius_top_right=18;style.corner_radius_bottom_left=18;style.corner_radius_bottom_right=18
	style.content_margin_left=28;style.content_margin_right=28;style.content_margin_top=26;style.content_margin_bottom=22
	style.border_width_top=1;style.border_color=Color("44625e")
	panel.add_theme_stylebox_override("panel",style)
	menu.add_child(panel)
	var scroll=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(350,536)
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	menu_box=VBoxContainer.new()
	menu_box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	menu_box.add_theme_constant_override("separation",10)
	scroll.add_child(menu_box)
	label(menu_box,title if title!="" else "PAUSADO" if in_match else "PRONTO PARA A ILHA?",23,Color("f3eedf"))
	if player and not running and not loading:
		label(menu_box,"%d eliminações   •   %02d:%02d de partida" % [player.kills,int(elapsed)/60,int(elapsed)%60],14,Color("8ce1d0"))
	else:label(menu_box,"SOLO   /   50 BOTS   /   SEM INTERNET",12,Color("8ce1d0"))
	if in_match:button(menu_box,"CONTINUAR",func():close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED,true)
	else:button(menu_box,"INICIAR BATALHA   →",start_match,true)
	label(menu_box,"DIFICULDADE DOS BOTS",12,Color("aabdbb"))
	var difficulty_option=OptionButton.new()
	for text in ["Recruta · mais tempo para reagir","Operador · combate equilibrado","Veterano · bots mais precisos"]:difficulty_option.add_item(text)
	difficulty_option.selected=difficulty
	difficulty_option.item_selected.connect(func(i):difficulty=i;save_settings())
	menu_box.add_child(difficulty_option)
	label(menu_box,"QUALIDADE VISUAL",12,Color("aabdbb"))
	var graphics=OptionButton.new()
	for text in ["Leve · sem sombras","Equilibrado · sombras + 2× AA","Alto · sombras + 4× AA"]:graphics.add_item(text)
	graphics.selected=quality
	graphics.item_selected.connect(func(i):quality=i;apply_quality();save_settings())
	menu_box.add_child(graphics)
	label(menu_box,"SENSIBILIDADE DO MOUSE",12,Color("aabdbb"))
	var slider=HSlider.new()
	slider.min_value=0.0006;slider.max_value=0.005;slider.step=0.0001;slider.value=sensitivity
	slider.value_changed.connect(func(v):sensitivity=v;save_settings())
	menu_box.add_child(slider)
	label(menu_box,"VOLUME",12,Color("aabdbb"))
	var volume=HSlider.new()
	volume.min_value=-40;volume.max_value=0;volume.value=AudioServer.get_bus_volume_db(0)
	volume.value_changed.connect(func(v):AudioServer.set_bus_volume_db(0,v);save_settings())
	menu_box.add_child(volume)
	var music_toggle=CheckButton.new();music_toggle.text="Música ambiente";music_toggle.button_pressed=music_enabled;menu_box.add_child(music_toggle)
	music_toggle.toggled.connect(func(value):music_enabled=value;apply_music();save_settings())
	button(menu_box,"INVENTÁRIO",func():FrontierUI.inventory(self)) if in_match else button(menu_box,"COFRE · PERSONAGEM",func():FrontierUI.wardrobe(self))
	button(menu_box,"CONFIGURAÇÕES · TECLAS",func():FrontierUI.settings(self))
	button(menu_box,"COMO JOGAR",show_help)
	if in_match:button(menu_box,"RECOMEÇAR PARTIDA",start_match)
	button(menu_box,"CRÉDITOS",show_credits)
	button(menu_box,"SAIR",func():get_tree().quit())
	var footer=Label.new()
	footer.text="ALPHA 0.2   •   GODOT 4   •   PARTIDA SOLO"
	footer.position=Vector2(64,662)
	footer.add_theme_color_override("font_color",Color("d1dedc"))
	footer.add_theme_font_size_override("font_size",12)
	menu.add_child(footer)

func show_help() -> void:
	close_menu()
	menu=Control.new()
	gui.add_child(menu)
	var panel=PanelContainer.new()
	panel.position=Vector2(240,55)
	panel.size=Vector2(800,610)
	var style=StyleBoxFlat.new()
	style.bg_color=Color("12272e")
	style.content_margin_left=35;style.content_margin_top=28;style.content_margin_right=35;style.content_margin_bottom=28
	panel.add_theme_stylebox_override("panel",style)
	menu.add_child(panel)
	var scroll=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(720,530)
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var box=VBoxContainer.new()
	box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation",15)
	scroll.add_child(box)
	label(box,"SEU GUIA DE SOBREVIVÊNCIA",26,Color("8ce1d0"))
	label(box,"W A S D mover • Mouse olhar • Shift correr\nEspaço pular / paraquedas • V atravessar janela\nCtrl alternar agachado • C segurar agachado • Q deslizar\n\nEsquerdo atirar • Direito mirar • R recarregar\n1 / 2 / 3 escolher os três espaços de armas\nH kitzinho (+25, 2s) • J kitão (+100, 4s)\n\nT gelo • G granada • B entrar/sair do veículo\nJetpack raro: K liga/desliga; Espaço no ar impulsiona\nTab inventário • M mapa • E coletar • L coleta automática\nF5 câmera • Alt olhar livre • F11 tela cheia\n\nN construção extra • Z parede • X rampa • C piso\nNo modo construção: esquerdo coloca, R gira\nEsc pausar • F1 ajuda\n\nVocê pode trocar as teclas e botões nas configurações.",16,Color("e2ece5"))
	label(box,"Gelo e madeira bloqueiam tiros e podem ser destruídos.\nAs rampas são escaláveis. Fique dentro da zona azul.\nDesbloqueie armas nas caixas. Seja o último sobrevivente.",15,Color("e1c693"))
	button(box,"ENTENDI  →",func():
		if running:close_menu();paused=false;Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
		else:show_menu(),true)
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE

func close_menu() -> void:
	if is_instance_valid(menu):menu.queue_free()
	menu=null
	ui_mode=""

func label(parent: Node,text: String,size: int,color: Color) -> Label:
	var l=Label.new()
	l.text=text
	l.add_theme_font_override("font",load("res://assets/interface.ttf"))
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	parent.add_child(l)
	return l

func button(parent: Node,text: String,action: Callable,primary: bool = false) -> Button:
	var b=Button.new()
	b.text=text
	b.custom_minimum_size.y=43
	b.add_theme_font_size_override("font_size",15)
	for state in ["normal","hover","pressed","focus"]:
		var style=StyleBoxFlat.new()
		style.bg_color=(Color("92dfce") if state=="normal" else Color("b9efdf")) if primary else (Color("203c43") if state=="normal" else Color("31535a"))
		style.corner_radius_top_left=8;style.corner_radius_top_right=8;style.corner_radius_bottom_left=8;style.corner_radius_bottom_right=8
		b.add_theme_stylebox_override(state,style)
	b.add_theme_color_override("font_color",Color("11272a") if primary else Color("edf1e8"))
	b.add_theme_color_override("font_hover_color",Color("11272a") if primary else Color.WHITE)
	b.pressed.connect(action)
	parent.add_child(b)
	return b

func run_checks() -> void:
	await load("res://tests/solo_checks.gd").run(self)

func check(ok: bool,text: String) -> void:
	checks.append(("PASS " if ok else "FAIL ")+text)
	print(checks.back())

func damage_multiplier(weapon: int,distance: float) -> float:
	return LastRules.damage_at(weapon,distance)/float(LastRules.data.damage[LastRules.IDS[weapon]].max)

func try_vault(actor: Fighter) -> bool:
	for window in island.windows:
		var point: Vector3=window.position
		var flat=Vector3(point.x,actor.global_position.y,point.z)
		if flat.distance_to(actor.global_position)>2.3:continue
		var normal: Vector3=window.normal
		var side=1 if (actor.global_position-flat).dot(normal)>0 else -1
		var forward=Vector3(-sin(actor.yaw),0,-cos(actor.yaw))
		if forward.dot(-normal*side)<0.3:continue
		var landing=Vector3(point.x,point.y-1.1+0.15,point.z)-normal*side*1.75
		var shape=CapsuleShape3D.new()
		shape.radius=0.38;shape.height=1.85
		var query=PhysicsShapeQueryParameters3D.new()
		query.shape=shape
		query.transform=Transform3D(Basis.IDENTITY,landing+Vector3.UP*0.95)
		query.exclude=[actor.get_rid()]
		query.collision_mask=7
		if not get_world_3d().direct_space_state.intersect_shape(query,1).is_empty():continue
		actor.vault_start=actor.global_position
		actor.vault_end=landing
		actor.vault_time=0.5
		actor.collision_mask=0
		actor.velocity=Vector3.ZERO
		sound_at("vault",actor.global_position,-10)
		return true
	return false

func capture_menu() -> void:
	for i in range(3):await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("user://captura-menu.png")
	print("MENU CAPTURE saved")
	get_tree().quit()

func show_credits() -> void:
	var dialog=AcceptDialog.new()
	dialog.title="Créditos do Aurora Royale"
	dialog.dialog_text="Humano, cabelo e animações: Quaternius · CC0\nPassos/salto/aterrissagem:\nJuan Linietsky e Fernando Miguel Calabró · 2018\nGodot TPS demo · CC-BY 3.0\nhttps://github.com/godotengine/tps-demo\n\nChão e concreto: Poly Haven · CC0\nFontes: Rajdhani (SIL OFL) e DejaVu Sans\nEngine: Godot 4.6.3 · MIT\n\nModelos/animações foram adaptados para este jogo.\nDetalhes, fontes e licenças completas estão no README."
	dialog.min_size=Vector2i(620,370)
	menu.add_child(dialog)
	dialog.popup_centered()

func random_loot() -> int:
	var roll=rng.randf()
	if roll<0.26:return 1
	if roll<0.44:return 12
	if roll<0.49:return 2
	if roll<0.60:return 3
	if roll<0.70:return 4
	if roll<0.75:return 8
	if roll<0.82:return 13
	return [0,5,9,10,11][rng.randi()%5]

func spawn_vehicles() -> void:
	for i in range(10):
		var along_x=rng.randf()<0.5
		var distance=rng.randf_range(55,140)*(1 if rng.randf()<0.5 else -1)
		var offset=rng.randf_range(-3,3)
		var at=Vector3(distance,0,offset) if along_x else Vector3(offset,0,distance)
		at.y=island.height_at(at.x,at.z)
		var v=RoadVehicle.new();add_child(v);v.create(self,i%2,at,PI/2 if along_x else 0);vehicles.append(v)

func use_vehicle() -> void:
	if is_instance_valid(player.vehicle):
		if not player.vehicle.leave():notice("Sem espaço livre para sair",2)
		return
	var best: RoadVehicle
	var closest=4.0
	for v in vehicles:
		if not is_instance_valid(v) or is_instance_valid(v.driver):continue
		var distance=player.global_position.distance_to(v.global_position)
		if distance<closest:closest=distance;best=v
	if best:best.enter(player)
	else:notice("Aproxime-se de um carro ou moto e pressione B",2)

func throw_grenade() -> void:
	if player.grenades<=0 or player.deployment_state!="ground" or is_instance_valid(player.vehicle):return
	var grenade=load("res://scripts/grenade.gd").new();add_child(grenade);grenade.create(self,player)
	grenade.global_position=player.global_position+Vector3.UP*1.5
	var direction=-player.camera.global_basis.z
	grenade.linear_velocity=(direction+Vector3.UP*0.2).normalized()*17
	player.grenades-=1
	player.rig.play_action("Throw")

func _input(event: InputEvent) -> void:
	if rebinding_action.is_empty():return
	if event is InputEventKey and event.pressed and not event.echo or event is InputEventMouseButton and event.pressed:
		if event is InputEventKey and event.physical_keycode==KEY_ESCAPE:
			rebinding_action="";get_viewport().set_input_as_handled();return
		var action=rebinding_action
		InputMap.action_erase_events(action);InputMap.action_add_event(action,event)
		rebinding_action="";Input.action_release(action)
		save_settings();get_viewport().set_input_as_handled();FrontierUI.settings(self)

func drop_weapon(index: int) -> void:
	if index==0 or not player.carried.has(index):return
	var types={1:3,2:4,3:8,4:9,5:10,6:11}
	var item=spawn_supply(types[index],player.global_position+Vector3(2.7,0,0))
	item.payload={"mag":player.mags[index],"reserve":player.reserve[index]}
	player.mags[index]=0;player.reserve[index]=0
	player.carried.erase(index);player.unlocked[index]=false
	player.switch_weapon(player.carried[0])

func create_music() -> void:
	music=AudioStreamPlayer.new()
	music.stream=load("res://assets/audio/frontier_music.wav").duplicate()
	if music.stream is AudioStreamWAV:
		music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD
		music.stream.loop_end=music.stream.data.size()/2
	add_child(music)
	apply_music()

func apply_music() -> void:
	if not music:return
	music.volume_db=music_volume
	if music_enabled and not smoke_mode:music.play() if not music.playing else null
	else:music.stop()
