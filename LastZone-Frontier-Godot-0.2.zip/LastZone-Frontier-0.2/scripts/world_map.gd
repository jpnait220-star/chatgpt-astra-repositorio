extends Control
var game
var font: Font=preload("res://assets/interface.ttf")
func _draw() -> void:
 var edge=minf(size.x,size.y)
 var top=(size-Vector2.ONE*edge)/2
 var center=top+Vector2.ONE*edge/2
 var scale=edge/830
 draw_circle(center,400*scale,Color("3b6550"))
 for road in LastRules.data.get("roads",[]):
  var p=road.p;var s=road.s;var rotation=road.r if road.get("r")!=null else [0,0,0]
  var points=PackedVector2Array()
  for corner in [Vector2(-s[0]/2,-s[2]/2),Vector2(s[0]/2,-s[2]/2),Vector2(s[0]/2,s[2]/2),Vector2(-s[0]/2,s[2]/2)]:points.append(center+(Vector2(p[0],p[2])+corner.rotated(-rotation[1]))*scale)
  draw_colored_polygon(points,Color("73817a"))
 for h in LastRules.data.houses:draw_rect(Rect2(center+Vector2(h.x-h.w/2,h.z-h.d/2)*scale,Vector2(h.w,h.d)*scale),Color("c0c0ab"))
 draw_circle(center+Vector2(game.zone_center.x,game.zone_center.z)*scale,game.zone_radius*scale,Color("b1f4ed"),false,2,true)
 if game.zone_state=="shrink":
  var r=LastRules.data.zones[mini(game.zone_phase,LastRules.data.zones.size()-1)].r
  draw_circle(center+Vector2(game.zone_target_center.x,game.zone_target_center.z)*scale,r*scale,Color("7eb5ec"),false,1.5,true)
 for area in LastRules.data.areas:draw_string(font,center+Vector2(area[1],area[2])*scale-Vector2(20,6),str(area[0]),HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("f0ead5"))
 if game.player:
  var at=center+Vector2(game.player.global_position.x,game.player.global_position.z)*scale
  var forward=Vector2(0,-9).rotated(game.player.yaw)
  draw_colored_polygon(PackedVector2Array([at+forward,at+forward.rotated(2.4)*0.7,at+forward.rotated(-2.4)*0.7]),Color("fff3c6"))
