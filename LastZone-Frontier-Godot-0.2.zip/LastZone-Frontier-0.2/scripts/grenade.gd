extends RigidBody3D
var game
var thrower: Fighter
var fuse := 3.0
var exploding := false
func create(owner_game,actor: Fighter) -> void:
 game=owner_game;thrower=actor;mass=0.45;collision_layer=8;collision_mask=1|4
 var col=CollisionShape3D.new();var sphere=SphereShape3D.new();sphere.radius=0.12;col.shape=sphere;add_child(col)
 Forge.sphere(self,Vector3.ZERO,0.12,Forge.mat(Color("4d6149"),0.7,0.3))
 var material=PhysicsMaterial.new();material.bounce=0.45;material.friction=0.65;physics_material_override=material
func _physics_process(dt: float) -> void:
 if not game.running or game.paused:freeze=true;return
 freeze=false;fuse-=dt
 if fuse<=0:explode()
func explode() -> void:
 if exploding:return
 exploding=true
 for actor in game.fighters:
  if not actor.alive:continue
  var at=actor.global_position+Vector3.UP
  var distance=at.distance_to(global_position)
  if distance>12:continue
  var ray=PhysicsRayQueryParameters3D.create(global_position,at,1)
  if get_world_3d().direct_space_state.intersect_ray(ray).is_empty():actor.damage(120*(1-distance/12),thrower)
 for cover in game.covers:
  if is_instance_valid(cover) and cover.global_position.distance_to(global_position)<9:cover.damage(180,thrower)
 game.sound_at("shotgun",global_position,-8)
 var flash=Forge.sphere(game,global_position,0.3,Forge.mat(Color("ecb16f")),0.6)
 var tween=flash.create_tween();tween.tween_property(flash,"scale",Vector3.ONE*15,0.18);tween.tween_callback(flash.queue_free)
 queue_free()
