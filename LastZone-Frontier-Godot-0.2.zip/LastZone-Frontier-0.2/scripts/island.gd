class_name Island
extends Node3D

var game: Node3D
var grid := AStarGrid2D.new()
var static_blocks: Array[Rect2] = []
var spawn_points: Array[Vector3] = []
var windows: Array[Dictionary] = []
var rng := RandomNumberGenerator.new()
var ground: Material
var concrete: Material
var wood: Material
var dark: Material
var leaves: Material
const CELL := 4.0
const HALF := 100

func _init() -> void:
	rng.seed = 502817

func generate() -> void:
	rng.seed=120518
	ground=Forge.photo_material("res://assets/ground.jpg",Color(0.85,0.95,0.83),0.075)
	concrete=Forge.photo_material("res://assets/concrete.jpg",Color(1.2,1.25,1.22),0.22)
	wood=Forge.mat(Color("6b5140"))
	dark=Forge.mat(Color("303d42"),0.6,0.25)
	leaves=Forge.mat(Color("3d6347"))
	create_terrain()
	water()
	coast()
	for house in LastRules.data.houses:source_house(house)
	var roads=LastRules.data.get("roads",[])
	if roads.is_empty():
		Forge.box(self,Vector3(0,0.045,0),Vector3(10,0.07,788),Forge.mat(Color("515b5d")))
		Forge.box(self,Vector3(0,0.05,0),Vector3(788,0.08,10),Forge.mat(Color("515b5d")))
	else:
		for road in roads:
			var item=Forge.box(self,Vector3(road.p[0],maxf(0.043,road.p[1]),road.p[2]),Vector3(road.s[0],maxf(0.025,road.s[1]),road.s[2]),Forge.mat(Color("515b5d")))
			if road.get("r")!=null:item.rotation=Vector3(road.r[0],road.r[1],road.r[2])
	for prop in LastRules.data.get("props",[]):
		if prop is Dictionary and prop.has("x") and prop.has("w"):
			var at=Vector3(prop.x,height_at(prop.x,prop.z),prop.z)
			crate(at,Vector3(prop.w,prop.get("h",1.5),prop.get("d",prop.w)))
	var trees=LastRules.data.get("trees",[])
	if not trees.is_empty():
		for t in trees:tree(Vector3(t.x,height_at(t.x,t.z),t.z),rng.randf_range(0.8,1.4))
	else:
		for i in range(650):
			var at=Vector3(rng.randf_range(-382,382),0,rng.randf_range(-382,382))
			if at.length()>382 or blocked(at,5) or absf(at.x)<9 or absf(at.z)<9:continue
			for area in LastRules.data.areas:
				if Vector2(at.x-area[1],at.z-area[2]).length()<28:at.y=-999;break
			if at.y<-100:continue
			at.y=height_at(at.x,at.z)
			tree(at,rng.randf_range(0.8,1.4))
	batch_scenery()
	create_grid()
	for i in range(600):
		var at=Vector3(rng.randf_range(-382,382),0,rng.randf_range(-382,382))
		if at.length()<382 and not blocked(at,1.3):
			at.y=height_at(at.x,at.z)+0.2
			spawn_points.append(at)

func building(p: Vector3, size: Vector2, height: float, color: Color) -> void:
	var wall_mat := Forge.photo_material("res://assets/concrete.jpg",color*1.65,0.24)
	var x := size.x
	var z := size.y
	window_side(p,-1,x,z,height,wall_mat)
	window_side(p,1,x,z,height,wall_mat)
	wall(p+Vector3(0,height/2,z/2),Vector3(x,height,0.45),wall_mat)
	# A genuine opening, not a door painted on a solid wall.
	for side in [-1,1]:
		wall(p+Vector3(side*(x/4+0.8),height/2,-z/2),Vector3(x/2-1.6,height,0.45),wall_mat)
	wall(p+Vector3(0,(height+3.1)/2,-z/2),Vector3(3.2,height-3.1,0.45),wall_mat)
	Forge.solid(self,p+Vector3(0,height+0.15,0),Vector3(x+0.8,0.35,z+0.8),dark)
	Forge.box(self,p+Vector3(0,0.05,0),Vector3(x,0.1,z),concrete)
	for j in range(2):
		crate(p+Vector3(-x*0.23+j*3.4,0,z*0.26),Vector3(2,1.4,1.8))
	# Roof equipment and trim add readable silhouettes.
	Forge.box(self,p+Vector3(-x*0.25,height+0.65,z*0.2),Vector3(2.1,1,2.2),concrete)
	Forge.box(self,p+Vector3(0,height-0.3,-z/2-0.25),Vector3(x+0.5,0.18,0.5),dark)

func wall(p: Vector3,size: Vector3,material: Material) -> void:
	Forge.solid(self,p,size,material)
	if p.y-size.y/2<1.7:register_block(p,Vector2(size.x,size.z))

func crate(p: Vector3,size: Vector3) -> void:
	wall(p+Vector3(0,size.y/2,0),size,wood)
	for y in [0.15,size.y-0.15]:
		Forge.box(self,p+Vector3(0,y,0),Vector3(size.x+0.06,0.09,size.z+0.06),dark)

func container(p: Vector3,color: Color) -> void:
	wall(p+Vector3(0,1.5,0),Vector3(6.5,3,11),Forge.mat(color,0.65,0.2))
	for j in range(10):
		for side in [-1,1]:
			Forge.box(self,p+Vector3(side*3.28,1.5,-5+j*1.1),Vector3(0.1,2.8,0.08),dark)

func tree(p: Vector3,s: float) -> void:
	var body := Forge.collider(self,p+Vector3(0,2.5*s,0),Vector3(0.65,5,0.65)*s)
	Forge.cylinder(body,Vector3.ZERO,0.4*s,5*s,wood,0.2*s)
	for j in range(3):
		Forge.cylinder(self,p+Vector3(0,(4.5+j*1.5)*s,0),(3.1-j*0.65)*s,4.7*s,leaves,0.06,9)
	register_block(p,Vector2.ONE*1.0*s)

func register_block(p: Vector3,size: Vector2) -> void:
	static_blocks.append(Rect2(Vector2(p.x,p.z)-size/2.0,size))

func blocked(p: Vector3, margin: float) -> bool:
	for r in static_blocks:
		if r.grow(margin).has_point(Vector2(p.x,p.z)):return true
	return false

func create_grid() -> void:
	grid.region=Rect2i(-HALF,-HALF,HALF*2+1,HALF*2+1)
	grid.cell_size=Vector2.ONE*CELL
	grid.diagonal_mode=AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.update()
	for x in range(-HALF,HALF+1):
		for y in range(-HALF,HALF+1):
			if Vector2(x*CELL,y*CELL).length()>392:grid.set_point_solid(Vector2i(x,y))
	for rect in static_blocks:
		var low=cell(Vector3(rect.position.x-0.65,0,rect.position.y-0.65))
		var high=cell(Vector3(rect.end.x+0.65,0,rect.end.y+0.65))
		for x in range(low.x,high.x+1):
			for y in range(low.y,high.y+1):
				if rect.grow(0.65).has_point(Vector2(x,y)*CELL):grid.set_point_solid(Vector2i(x,y))

func cell(p: Vector3) -> Vector2i:
	return Vector2i(clampi(roundi(p.x/CELL),-HALF,HALF),clampi(roundi(p.z/CELL),-HALF,HALF))

func nearest_free(c: Vector2i) -> Vector2i:
	if not grid.is_point_solid(c):return c
	for radius in range(1,9):
		for x in range(-radius,radius+1):
			for y in range(-radius,radius+1):
				var test := c+Vector2i(x,y)
				if grid.region.has_point(test) and not grid.is_point_solid(test):return test
	return c

func path(a: Vector3,b: Vector3) -> PackedVector3Array:
	var start := nearest_free(cell(a))
	var finish := nearest_free(cell(b))
	var result := PackedVector3Array()
	if grid.is_point_solid(start) or grid.is_point_solid(finish):return result
	for c in grid.get_id_path(start,finish):result.append(Vector3(c.x*CELL,0,c.y*CELL))
	return result

func water() -> void:
	var plane := PlaneMesh.new()
	plane.size = Vector2(1900,1900)
	plane.subdivide_width = 60
	plane.subdivide_depth = 60
	var sh := Shader.new()
	sh.code = "shader_type spatial; render_mode cull_disabled; void vertex(){VERTEX.y+=sin(VERTEX.x*0.06+TIME*0.6)*0.25+cos(VERTEX.z*0.05+TIME*0.4)*0.3;} void fragment(){float f=pow(1.0-max(dot(NORMAL,VIEW),0.0),3.0); ALBEDO=mix(vec3(0.035,0.19,0.24),vec3(0.26,0.49,0.52),f); METALLIC=0.35; ROUGHNESS=0.24;}"
	var m := ShaderMaterial.new()
	m.shader=sh
	var mi := MeshInstance3D.new()
	mi.mesh=plane
	mi.material_override=m
	mi.position.y=-2.8
	add_child(mi)

func coast() -> void:
	for j in range(56):
		var angle := j*TAU/56.0
		var p := Vector3(cos(angle),0,sin(angle))*rng.randf_range(394,411)
		var rock := Forge.sphere(self,p-Vector3(0,5,0),10,Forge.mat(Color("6e8076")))
		rock.scale=Vector3(1.8,0.65,1.8)
	for j in range(25):
		var angle := j*TAU/25.0
		var p := Vector3(cos(angle),0,sin(angle))*rng.randf_range(850,1050)
		Forge.cylinder(self,p+Vector3(0,25,0),rng.randf_range(60,110),rng.randf_range(65,130),Forge.mat(Color("556f75")),0.4,7)

var dynamic_counts: Dictionary={}
func add_dynamic(c: Cover) -> void:
	var cs=c.get_child(0) as CollisionShape3D
	var dimensions=Vector3(6.6,2.8,1.65) if c.kind==0 else (cs.shape as BoxShape3D).size
	var bounds=cs.global_transform*AABB(-dimensions/2,dimensions)
	var low=cell(bounds.position-Vector3.ONE*0.7)
	var high=cell(bounds.end+Vector3.ONE*0.7)
	for x in range(low.x,high.x+1):
		for y in range(low.y,high.y+1):
			var key=Vector2i(x,y)
			c.occupied_cells.append(key)
			dynamic_counts[key]=dynamic_counts.get(key,0)+1
			grid.set_point_solid(key,true)

func remove_dynamic(c: Cover) -> void:
	for key in c.occupied_cells:
		var count=int(dynamic_counts.get(key,0))-1
		if count>0:dynamic_counts[key]=count
		else:
			dynamic_counts.erase(key)
			var p=Vector3(key.x*CELL,0,key.y*CELL)
			grid.set_point_solid(key,p.length()>392 or blocked(p,0.65))
	c.occupied_cells.clear()

func batch_scenery() -> void:
	# Merge static triangles per material and 64m chunk. Physics stays separate.
	var groups: Dictionary={}
	var chunks: Dictionary={}
	for mesh in find_children("*","MeshInstance3D",true,false):
		if not mesh.material_override is StandardMaterial3D:continue
		var pos=mesh.global_position
		var key=str(mesh.material_override.get_instance_id())+":"+str(floori(pos.x/64))+":"+str(floori(pos.z/64))
		if not groups.has(key):groups[key]=[]
		groups[key].append(mesh)
	for key in groups:
		var items=groups[key]
		if items.size()<3:continue
		var tool=SurfaceTool.new()
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		tool.set_material(items[0].material_override)
		for mi in items:
			tool.append_from(mi.mesh,0,mi.global_transform)
		var combined=MeshInstance3D.new()
		combined.mesh=tool.commit()
		combined.material_override=items[0].material_override
		add_child(combined)
		for mi in items:mi.queue_free()

func window_side(p: Vector3,side: int,x: float,z: float,height: float,material: Material) -> void:
	var plane_x=p.x+side*x/2
	wall(Vector3(plane_x,p.y+0.55,p.z),Vector3(0.45,1.1,z),material)
	wall(Vector3(plane_x,p.y+(height+3.2)/2,p.z),Vector3(0.45,height-3.2,z),material)
	var ends=[-z/2,-z*0.28-1.45,-z*0.28+1.45,z*0.22-1.45,z*0.22+1.45,z/2]
	for index in [0,2,4]:
		var length=ends[index+1]-ends[index]
		if length>0:wall(Vector3(plane_x,p.y+2.15,p.z+(ends[index+1]+ends[index])/2),Vector3(0.45,2.1,length),material)
	for dz in [-z*0.28,z*0.22]:
		windows.append({"position":Vector3(plane_x,p.y+1.1,p.z+dz),"normal":Vector3(side,0,0)})
		for edge in [-1,1]:Forge.box(self,Vector3(plane_x,p.y+2.15,p.z+dz+edge*1.47),Vector3(0.55,2.2,0.09),dark)
		for y in [1.08,3.23]:Forge.box(self,Vector3(plane_x,p.y+y,p.z+dz),Vector3(0.6,0.09,3.05),dark)

func source_house(info: Dictionary) -> void:
	var p=Vector3(info.x,0,info.z)
	var x=float(info.w)
	var z=float(info.d)
	var height=float(info.H)
	var count=int(info.floors)
	var material=Forge.photo_material("res://assets/concrete.jpg",LastRules.color(info.c)*1.65,0.24)
	for floor_index in range(count):
		var base=p+Vector3.UP*height*floor_index
		window_side(base,-1,x,z,height,material)
		window_side(base,1,x,z,height,material)
		wall(base+Vector3(0,height/2,-z/2),Vector3(x,height,0.45),material)
		if floor_index>0:wall(base+Vector3(0,height/2,z/2),Vector3(x,height,0.45),material)
		else:
			for side in [-1,1]:wall(base+Vector3(side*(x/4+0.75),height/2,z/2),Vector3(x/2-1.5,height,0.45),material)
			wall(base+Vector3(0,(height+2.5)/2,z/2),Vector3(3,height-2.5,0.45),material)
	Forge.solid(self,p+Vector3.UP*(count*height+0.08),Vector3(x+0.7,0.18,z+0.7),dark)
	Forge.solid(self,p+Vector3(0,0.0,0),Vector3(x,0.08,z),concrete)
	if count>1:
		Forge.solid(self,p+Vector3(0,height,-z/4),Vector3(x,0.18,z/2),wood)
		var length=z/2-0.7
		var ramp=Forge.solid(self,p+Vector3(-x/2+1.4,height/2-0.08,length/2),Vector3(1.8,0.16,sqrt(length*length+height*height)),wood)
		ramp.rotation.x=atan2(height,length)

func height_at(x: float,z: float) -> float:
	if absf(x)<5 or absf(z)<5:return 0.012
	for road in LastRules.data.roads:
		if absf(x-road.p[0])<=road.s[0]/2 and absf(z-road.p[2])<=road.s[2]/2:return 0.012
	for house in LastRules.data.houses:
		if absf(x-house.x)<house.w/2+0.3 and absf(z-house.z)<house.d/2+0.3:return 0.012
	var gx=clampf((x+400)/5,0,159.999)
	var gz=clampf((z+400)/5,0,159.999)
	var ix=int(gx);var iz=int(gz)
	var rows=LastRules.data.terrain
	return lerpf(lerpf(rows[iz][ix],rows[iz][ix+1],gx-ix),lerpf(rows[iz+1][ix],rows[iz+1][ix+1],gx-ix),gz-iz)

func create_terrain() -> void:
	var vertices=PackedVector3Array()
	var normals=PackedVector3Array()
	var uv=PackedVector2Array()
	var heights=PackedFloat32Array()
	for z in range(161):
		for x in range(161):
			var px=(x-80)*5.0;var pz=(z-80)*5.0
			var y=height_at(px,pz)
			vertices.append(Vector3(px,y,pz));heights.append(y)
			normals.append(Vector3(height_at(px-1,pz)-height_at(px+1,pz),2,height_at(px,pz-1)-height_at(px,pz+1)).normalized())
			uv.append(Vector2(px,pz)*0.1)
	var indices=PackedInt32Array()
	for z in range(160):
		for x in range(160):
			if Vector2((x-79.5)*5,(z-79.5)*5).length()>400:continue
			var a=z*161+x;var b=a+161;var c=b+1;var d=a+1
			indices.append_array(PackedInt32Array([a,c,b,a,d,c]))
	var arrays=[];arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX]=vertices;arrays[Mesh.ARRAY_NORMAL]=normals;arrays[Mesh.ARRAY_TEX_UV]=uv;arrays[Mesh.ARRAY_INDEX]=indices
	var terrain=MeshInstance3D.new();terrain.name="Terrain"
	var mesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	terrain.mesh=mesh;terrain.material_override=ground
	add_child(terrain)
	var body=StaticBody3D.new();var col=CollisionShape3D.new();var shape=HeightMapShape3D.new()
	shape.map_width=161;shape.map_depth=161;shape.map_data=heights
	col.shape=shape;col.scale=Vector3(5,1,5)
	body.add_child(col);add_child(body)
