class_name LastRules
extends RefCounted

static var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/lastzone_rules.json"))
const IDS = ["pistol","ump","ak","awm","mp40","m1014","scar"]
const LOOT_WEAPONS = {3:1,4:2,8:3,9:4,10:5,11:6}

static func weapon(slot: int) -> Dictionary:
 return data.weapons[IDS[clampi(slot,0,6)]]
static func damage_at(slot: int,distance: float,head: bool=false) -> float:
 var profile=data.damage[IDS[clampi(slot,0,6)]]
 var ratio=clampf((distance-float(profile.near))/float(profile.far-profile.near),0,1)
 return lerpf(float(profile.max),float(profile.min),ratio)*(float(profile.head) if head else 1.0)
static func max_hp() -> float:return float(data.world.maxHealth)
static func sound(slot: int) -> String:return ["shot","smg","shot","shotgun","smg","shotgun","shot"][clampi(slot,0,6)]
static func color(number: float) -> Color:return Color.hex((int(number)<<8)|255)
