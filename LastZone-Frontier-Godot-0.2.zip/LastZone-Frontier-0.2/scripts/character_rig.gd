class_name CharacterRig
extends Node3D

var actor
var model: Node3D
var skeleton: Skeleton3D
var animation_player: AnimationPlayer
var tree: AnimationTree
var blend_tree: AnimationNodeBlendTree
var hand: BoneAttachment3D
var support: SkeletonIK3D
var action_clip: AnimationNodeAnimation
var action_node: AnimationNodeOneShot
var dying := false
var preview_pose := ""
var death_clock := 0.0
var native_clips: Dictionary={}
var outfit: Dictionary={}
var head_hair: Node3D
var hair_id := "natural"
var hair_models: Dictionary={}
var head_socket: BoneAttachment3D
var face_cover: Node3D
var beard: Node3D
var helmet: Node3D
var vest: Node3D
var headband: MeshInstance3D

func build(owner_actor,variant: int=0) -> void:
 actor=owner_actor
 var path="res://assets/characters/human_male.glb"
 model=load(path).instantiate()
 add_child(model)
 model.scale=Vector3.ONE*1.04
 model.rotation.y=PI
 skeleton=model.find_children("*","Skeleton3D",true,false)[0]
 animation_player=model.find_children("*","AnimationPlayer",true,false)[0]
 for clip in animation_player.get_animation_list():
  native_clips[clip.to_lower().replace("_","").replace("-","")]=clip
  if "Idle" in clip or "Walk" in clip or "Run" in clip or "Sprint" in clip or "Jog" in clip or "Driving" in clip:animation_player.get_animation(clip).loop_mode=Animation.LOOP_LINEAR
 build_tree()
 for mesh in model.find_children("*","MeshInstance3D",true,false):
  mesh.visibility_range_end=150.0 if not actor.human else 0.0
  mesh.visibility_range_end_margin=10
  for surface in range(mesh.mesh.get_surface_count()):
   var original=mesh.mesh.surface_get_material(surface) as StandardMaterial3D
   if original and "Hair" in original.resource_name:
    var brow=original.duplicate() as StandardMaterial3D;brow.albedo_color=Color("29231f");mesh.set_surface_override_material(surface,brow)
   if original and original.resource_name in ["Shirt","Pants"]:
    var fabric=original.duplicate() as StandardMaterial3D
    fabric.albedo_texture=load("res://assets/clothes_"+("shirt" if original.resource_name=="Shirt" else "pants")+".jpg")
    fabric.roughness=0.95;fabric.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    mesh.set_surface_override_material(surface,fabric)
 set_outfit({"shirt":"#496477","pants":"#34414b","hair":"#29231f"} if actor.human else {"shirt":["#675542","#495f58","#4f5571"][variant%3],"pants":"#303638"})
 animation_player.play(resolve("Idle"))
 animation_player.advance(0)
 skeleton.force_update_all_bone_transforms()
 hand=BoneAttachment3D.new()
 hand.bone_name="hand_r"
 skeleton.add_child(hand)
 hand.name="WeaponHand"
 add_accessories()

func animation(clip: String) -> AnimationNodeAnimation:
 var node=AnimationNodeAnimation.new()
 node.animation=StringName(resolve(clip))
 return node

func build_tree() -> void:
 tree=AnimationTree.new()
 model.add_child(tree)
 tree.anim_player=tree.get_path_to(animation_player)
 blend_tree=AnimationNodeBlendTree.new()
 tree.tree_root=blend_tree
 var movement=AnimationNodeBlendSpace1D.new()
 movement.min_space=0
 movement.max_space=8.5
 movement.add_blend_point(animation("Idle"),0)
 movement.add_blend_point(animation("Walk_Carry"),2.6)
 movement.add_blend_point(animation("Run_Carry"),5.2)
 movement.add_blend_point(animation("Run"),8.5)
 blend_tree.add_node("movement",movement)
 var crouch_move=AnimationNodeBlendSpace1D.new();crouch_move.min_space=0;crouch_move.max_space=2.6
 crouch_move.add_blend_point(animation("Crouch_Idle"),0);crouch_move.add_blend_point(animation("Crouch_Fwd"),2.6)
 blend_tree.add_node("crouch_move",crouch_move)
 blend_tree.add_node("crouched",AnimationNodeBlend2.new())
 blend_tree.connect_node("crouched",0,"movement");blend_tree.connect_node("crouched",1,"crouch_move")
 blend_tree.add_node("jump",animation("Jump"))
 var jump_time=AnimationNodeTimeSeek.new()
 blend_tree.add_node("jump_time",jump_time)
 blend_tree.connect_node("jump_time",0,"jump")
 var air=AnimationNodeBlend2.new()
 blend_tree.add_node("air",air)
 blend_tree.connect_node("air",0,"crouched")
 blend_tree.connect_node("air",1,"jump_time")
 blend_tree.add_node("aim_pose",animation("Shoot_OneHanded"))
 blend_tree.add_node("aim_time",AnimationNodeTimeSeek.new())
 blend_tree.connect_node("aim_time",0,"aim_pose")
 var aim=AnimationNodeBlend2.new()
 aim.filter_enabled=true
 filter_upper(aim,false)
 blend_tree.add_node("aim",aim)
 blend_tree.connect_node("aim",0,"air")
 blend_tree.connect_node("aim",1,"aim_time")
 action_clip=animation("PickUp")
 blend_tree.add_node("action_clip",action_clip)
 blend_tree.add_node("action_speed",AnimationNodeTimeScale.new())
 blend_tree.connect_node("action_speed",0,"action_clip")
 action_node=AnimationNodeOneShot.new()
 action_node.fadein_time=0.10
 action_node.fadeout_time=0.16
 action_node.filter_enabled=true
 filter_upper(action_node)
 blend_tree.add_node("action",action_node)
 blend_tree.connect_node("action",0,"aim")
 blend_tree.connect_node("action",1,"action_speed")
 blend_tree.connect_node("output",0,"action")
 tree.active=true

func filter_upper(node: AnimationNode,torso: bool=true) -> void:
 var root=animation_player.get_node(animation_player.root_node)
 var path=str(root.get_path_to(skeleton))
 for name in ["spine_02","spine_03","neck_01","Head","clavicle_l","upperarm_l","lowerarm_l","hand_l","clavicle_r","upperarm_r","lowerarm_r","hand_r"]:
  if torso or name not in ["spine_02","spine_03"]:node.set_filter_path(NodePath(path+":"+name),true)

func attach_weapon(weapon: Node3D) -> void:
 if weapon.get_parent():weapon.reparent(hand,false)
 else:hand.add_child(weapon)
 # Calibrate the grip in an authored shooting pose, instead of placing the weapon in space.
 tree.active=false
 animation_player.play(resolve("Shoot_OneHanded"))
 animation_player.seek(0.12,true)
 skeleton.force_update_all_bone_transforms()
 var index=skeleton.find_bone("hand_r")
 var global_hand=skeleton.global_transform*skeleton.get_bone_global_pose(index)
 weapon.basis=global_hand.basis.inverse()*actor.skin.global_basis
 weapon.position=Vector3.ZERO
 tree.active=true
 tree.set("parameters/aim_time/seek_request",0.12)
 var grip=Marker3D.new()
 grip.name="SupportGrip"
 grip.position=Vector3(-0.025,-0.03,-0.24)
 weapon.add_child(grip)
 support=SkeletonIK3D.new()
 support.root_bone="upperarm_l"
 support.tip_bone="hand_l"
 support.override_tip_basis=false
 support.use_magnet=true
 support.magnet=Vector3(0.5,1.2,0.2)
 skeleton.add_child(support)
 support.target_node=support.get_path_to(grip)
 support.max_iterations=8
 support.min_distance=0.015
 support.interpolation=0.75
 support.start()

func play_action(clip: String,duration: float=0,whole_body: bool=false) -> void:
 clip=resolve(clip)
 if clip==resolve("Shoot_OneHanded") and tree.get("parameters/action/active"):return
 if not animation_player.has_animation(clip):push_error("Missing action clip: "+clip);return
 action_clip.animation=resolve(clip)
 action_node.filter_enabled=not whole_body
 var scale=animation_player.get_animation(clip).length/duration if duration>0 else 1.0
 tree.set("parameters/action_speed/scale",scale)
 tree.set("parameters/action/request",AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)

func _process(dt: float) -> void:
 if not is_instance_valid(actor) or not tree:return
 if not preview_pose.is_empty():
  tree.active=false
  if animation_player.current_animation!=resolve(preview_pose):animation_player.play(resolve(preview_pose))
  return
 if dying and not actor.alive:
  death_clock+=dt
  if death_clock>animation_player.get_animation(resolve("Death")).length-0.18:tree.active=false;return
 if is_instance_valid(actor.vehicle):
  tree.active=false
  if animation_player.current_animation!=resolve("Drive"):animation_player.play(resolve("Drive"))
  return
 var visible_actor=actor.human or not actor.game.player or global_position.distance_squared_to(actor.game.player.global_position)<70*70
 tree.active=not actor.game.paused and visible_actor
 if not tree.active:return
 var speed=Vector2(actor.velocity.x,actor.velocity.z).length()
 tree.set("parameters/movement/blend_position",speed)
 tree.set("parameters/crouch_move/blend_position",speed)
 tree.set("parameters/crouched/blend_amount",1.0 if actor.crouched else 0.0)
 var airborne=not actor.is_on_floor() or actor.vault_time>0
 tree.set("parameters/air/blend_amount",1.0 if airborne else 0.0)
 if airborne:tree.set("parameters/jump_time/seek_request",0.4)
 tree.set("parameters/aim_time/seek_request",0.12)
 var combat=Input.is_action_pressed("aim") or actor.cooldown>0 if actor.human else is_instance_valid(actor.target)
 tree.set("parameters/aim/blend_amount",1.0 if combat else 0.32 if speed>0.5 else 0.0)
 if support:
  support.interpolation=move_toward(support.interpolation,0.0 if actor.reload_left>0 or actor.heal_left>0 or actor.slot in [0,4] else 0.8,dt*8)
 if helmet:
  helmet.visible=actor.helmet_durability>0 or str(outfit.get("hair_id",""))=="cap"
  head_hair.visible=not helmet.visible
  headband.visible=str(outfit.get("hair_id","")).begins_with("f") and not helmet.visible
 if vest:vest.visible=actor.armor>0
 if not actor.alive and not dying:
  dying=true
  play_action("Death",0,true)

func set_outfit(settings: Dictionary) -> void:
 outfit.merge(settings,true)
 if is_instance_valid(head_socket):update_accessories()
 var mapping={"Shirt":"shirt","Pants":"pants","Hair":"hair","Belt":"boots","Boot fabric":"boots","MI_Hair_1":"hair","MI_Hair_2":"hair"}
 for mesh in model.find_children("*","MeshInstance3D",true,false):
  for surface in range(mesh.mesh.get_surface_count()):
   var material=mesh.get_surface_override_material(surface) as StandardMaterial3D

   if material and mapping.has(material.resource_name) and outfit.has(mapping[material.resource_name]):
    material.albedo_color=Color(outfit[mapping[material.resource_name]])

func resolve(action: String) -> String:
 var choices={"Idle":["Idle"],"Walk_Carry":["Walk_Carry","Walk"],"Run_Carry":["Jog_Fwd","Walk_Carry"],"Run":["Sprint","Jog_Fwd"],"Jump":["Jump"],"Shoot_OneHanded":["Pistol_Shoot"],"PickUp":["Pistol_Reload"],"Reload":["Pistol_Reload"],"Consume":["Consume"],"Throw":["OverhandThrow"],"Death":["Death01"],"Roll":["Roll"],"Drive":["Driving"],"Climb":["ClimbUp_1m"]}
 for name in choices.get(action,[action]):
  if animation_player.has_animation(name):return name
 push_error("Unresolved authored animation: "+action)
 return "Idle"

func add_accessories() -> void:
 head_socket=BoneAttachment3D.new();head_socket.bone_name="Head";skeleton.add_child(head_socket)
 var index=skeleton.find_bone("Head")
 var matrix=skeleton.global_transform*skeleton.get_bone_global_rest(index)
 head_hair=load("res://assets/characters/hair/Hair_SimpleParted.gltf").instantiate()
 head_socket.add_child(head_hair)
 hair_models["Hair_SimpleParted"]=head_hair
 head_hair.transform=matrix.affine_inverse()*model.global_transform
 for bone in ["foot_l","foot_r"]:
  var socket=BoneAttachment3D.new();socket.bone_name=bone;skeleton.add_child(socket)
  var rest=skeleton.global_transform*skeleton.get_bone_global_rest(skeleton.find_bone(bone))
  var shoe=load("res://assets/equipment/boot.glb").instantiate();socket.add_child(shoe)
  shoe.basis=rest.basis.inverse()*model.global_basis
  shoe.position=rest.basis.inverse()*(model.global_basis*Vector3(0,-0.12,0))
  for mesh in shoe.find_children("*","MeshInstance3D",true,false):
   for surface in range(mesh.mesh.get_surface_count()):
    var material=mesh.mesh.surface_get_material(surface)
    if material:mesh.set_surface_override_material(surface,material.duplicate())
 for mesh in head_hair.find_children("*","MeshInstance3D",true,false):
  for surface in range(mesh.mesh.get_surface_count()):
   var material=mesh.mesh.surface_get_material(surface)
   if material:mesh.set_surface_override_material(surface,material.duplicate())
 face_cover=attach_body_asset("res://assets/equipment/mask.glb","Head")
 beard=attach_body_asset("res://assets/characters/hair/Hair_Beard.gltf","Head")
 helmet=attach_body_asset("res://assets/equipment/helmet.glb","Head")
 vest=attach_body_asset("res://assets/equipment/vest.glb","spine_03")
 var band_parent=Node3D.new();head_socket.add_child(band_parent)
 band_parent.transform=matrix.affine_inverse()*model.global_transform
 headband=MeshInstance3D.new();var ring=TorusMesh.new();ring.inner_radius=0.093;ring.outer_radius=0.104;ring.rings=24;ring.ring_segments=8;headband.mesh=ring;headband.material_override=Forge.mat(Color("86d5ea"));headband.position=Vector3(0,1.74,-0.01)
 band_parent.add_child(headband)
 set_outfit(outfit)

func attach_body_asset(path: String,bone: String) -> Node3D:
 var socket=BoneAttachment3D.new();socket.bone_name=bone;skeleton.add_child(socket)
 var rest=skeleton.global_transform*skeleton.get_bone_global_rest(skeleton.find_bone(bone))
 var asset=load(path).instantiate();socket.add_child(asset);asset.transform=rest.affine_inverse()*model.global_transform
 for mesh in asset.find_children("*","MeshInstance3D",true,false):
  for surface in range(mesh.mesh.get_surface_count()):
   var material=mesh.mesh.surface_get_material(surface)
   if material:mesh.set_surface_override_material(surface,material.duplicate())
 return asset

func update_accessories() -> void:
 if not is_instance_valid(face_cover):return
 var selected=str(outfit.get("hair_id","natural"))
 if hair_id!=selected:
  hair_id=selected
  head_hair.hide()
  var file="Hair_Long" if selected.begins_with("f") or selected=="guard" else "Hair_Buzzed" if selected=="cap" else "Hair_SimpleParted"
  if hair_models.has(file):head_hair=hair_models[file]
  else:
   head_hair=load("res://assets/characters/hair/"+file+".gltf").instantiate();head_socket.add_child(head_hair)
   hair_models[file]=head_hair
   var matrix=skeleton.global_transform*skeleton.get_bone_global_rest(skeleton.find_bone("Head"))
   head_hair.transform=matrix.affine_inverse()*model.global_transform
   for mesh in head_hair.find_children("*","MeshInstance3D",true,false):
    for surface in range(mesh.mesh.get_surface_count()):
     var material=mesh.mesh.surface_get_material(surface)
     if material:mesh.set_surface_override_material(surface,material.duplicate())
 var has_helmet=actor.helmet_durability>0 or selected=="cap"
 helmet.visible=has_helmet;head_hair.visible=not has_helmet
 vest.visible=actor.armor>0
 headband.visible=selected.begins_with("f") and not has_helmet
 if headband.visible:
  var option=LastRules.data.hair.get(selected,[])
  var color=LastRules.color(option[3]) if option.size()>3 else Color("86d5ea")
  headband.material_override=Forge.mat(color)
 var mask=str(outfit.get("mask_id","none"))
 face_cover.visible=mask in ["azul","sem"]
 beard.visible=mask=="barba"
 for mesh in face_cover.find_children("*","MeshInstance3D",true,false):
  mesh.material_override=Forge.mat(Color("5099b4") if mask=="azul" else Color("dce4df"))

func raise_weapon() -> void:
 if tree.active:
  tree.set("parameters/aim/blend_amount",1.0)
  tree.set("parameters/aim_time/seek_request",0.12)
  tree.advance(0)
  skeleton.force_update_all_bone_transforms()
