class_name Fighter
extends CharacterBody3D

var game
var human := false
var alive := true
var hp := 200.0
var max_hp := 200.0
var rig: CharacterRig
var vehicle
var deployment_state := "ground"
var parachute: Node3D
var small_kits := 3
var heal_kind := "small"
var grenades := 0
var slide_left := 0.0
var slide_cooldown := 0.0
var slide_direction := Vector3.ZERO
var camera_mode := 0
var free_yaw := 0.0
var free_pitch := 0.0
var camera_ready := false
var camera_anchor := Vector3.ZERO
var camera_arm := 3.8
var crouched := false
var crouch_latched := false
var armor := 0.0
var armor_level := 0
var helmet_level := 0
var helmet_durability := 0.0
var has_jetpack := false
var jet_enabled := false
var jet_fuel := 0.0
var jet_visual: Node3D
var jet_flames: Node3D
var jet_audio: AudioStreamPlayer3D
var thrusting := false
var vault_time := 0.0
var vault_start := Vector3.ZERO
var vault_end := Vector3.ZERO
var air_last := false
var kills := 0
var nickname := "Ranger"
var cooldown := 0.0
var reload_left := 0.0
var heal_left := 0.0
var stamina := 100.0
var ice := 8
var materials := 450
var kits := 3
var slot := 0
var mags := [5,0,0,0,0,0,0]
var reserve := [15,0,0,0,0,0,0]
var unlocked := [true,false,false,false,false,false,false]
var carried: Array[int]=[0]
var yaw := 0.0
var pitch := -0.12
var camera: Camera3D
var pivot: Node3D
var arm: SpringArm3D
var skin: Node3D
var anim: AnimationPlayer
var gun: Node3D
var gun_model: Node3D
var muzzle: Node3D
var decision := 0.0
var target: Fighter
var route := PackedVector3Array()
var route_step := 0
var goal := Vector3.ZERO
var path_timer := 0.0
var wander_timer := 0.0
var strafe := 1.0
var anim_now := ""
var bob := 0.0
var travel := 0.0
var received_at := -10.0
var last_hurt_audio := -10.0
var rng := RandomNumberGenerator.new()

func setup(owner_game, is_player: bool, index: int) -> void:
	game = owner_game
	human = is_player
	nickname = "VOCÊ" if human else "Ranger %02d" % (index+1)
	rng.seed = index*18373+82715
	decision = rng.randf_range(0.1,1.1)
	path_timer = rng.randf_range(0.1,1.0)
	hp = max_hp
	armor = 0
	collision_layer = 2
	collision_mask = 1|2|4
	floor_max_angle = deg_to_rad(48)
	floor_snap_length = 0.4
	var col := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.37
	capsule.height = 1.85
	col.shape = capsule
	col.position.y = 0.94
	add_child(col)
	skin = Node3D.new()
	add_child(skin)
	rig=CharacterRig.new()
	skin.add_child(rig)
	rig.build(self,index)
	anim=rig.animation_player
	create_jet_visual()
	if not human:
		var mark := Forge.cylinder(skin, Vector3(0,2.02,0),0.1,0.12,Forge.mat(Color("e18c59")),0.03,6)
		mark.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	gun = Node3D.new()
	skin.add_child(gun)
	gun.position = Vector3(0.38,1.28,-0.35)
	update_weapon_model()
	muzzle = Node3D.new()
	muzzle.position = Vector3(0,0.075,-0.205)
	gun.add_child(muzzle)
	rig.attach_weapon(gun)
	create_parachute()
	if human:
		pivot = Node3D.new()
		pivot.position = Vector3(0,1.5,0)
		add_child(pivot)
		arm = SpringArm3D.new()
		arm.position.x = 0.65
		arm.spring_length = 4.1
		arm.margin = 0.2
		arm.collision_mask = 1
		arm.add_excluded_object(get_rid())
		pivot.add_child(arm)
		camera = Camera3D.new()
		camera.fov = 78
		camera.near = 0.12
		camera.far = 1200
		pivot.add_child(camera)
		arm.collision_mask=0
		camera.set_as_top_level(true)
		camera.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
		camera.current = true

func find_animation(n: Node) -> AnimationPlayer:
	if n is AnimationPlayer:return n
	for child in n.get_children():
		var result = find_animation(child)
		if result:return result
	return null

func _physics_process(dt: float) -> void:
	if not alive or not game.running or game.paused:
		if jet_audio and jet_audio.playing:jet_audio.stop()
		return
	cooldown = maxf(0,cooldown-dt)
	var was_reloading = reload_left > 0
	reload_left = maxf(0,reload_left-dt)
	if was_reloading and reload_left <= 0:finish_reload()
	if heal_left > 0:
		heal_left = maxf(0,heal_left-dt)
		if heal_left <= 0:
			hp = minf(max_hp,hp+(25 if heal_kind=="small" else 100))
			pass # The HTML consumes a kit when starting its use.
			if human:game.notice("Cura concluída");game.sound_at("heal_done",global_position,-10)
	if global_position.y < -10:damage(999,null,false,true)
	if global_position.distance_to(game.zone_center) > game.zone_radius:
		damage(dt*game.zone_damage,null,false,true)
	if not alive:return
	if human:player_step(dt)
	else:bot_step(dt)
	animate_skin(dt)

func player_step(dt: float) -> void:
	stamina=100
	slide_cooldown=maxf(0,slide_cooldown-dt)
	if is_instance_valid(vehicle):
		vehicle.drive(dt,self)
		return
	if vault_time>0:
		vault_time=maxf(0,vault_time-dt)
		var progress=1-vault_time/0.5
		var eased=progress*progress*(3-2*progress)
		global_position=vault_start.lerp(vault_end,eased)+Vector3.UP*sin(progress*PI)*1.25
		skin.rotation.x=-sin(progress*PI)*0.3
		if vault_time<=0:collision_mask=7;skin.rotation.x=0
		return
	var axis=Input.get_vector("left","right","forward","back")
	var direction=Vector3(axis.x,0,axis.y).rotated(Vector3.UP,yaw)
	crouched=crouch_latched or Input.is_action_pressed("crouch") and not game.build_mode or slide_left>0
	if not crouched:
		var check=PhysicsShapeQueryParameters3D.new();var standing=CapsuleShape3D.new();standing.radius=0.37;standing.height=1.85
		check.shape=standing;check.transform=Transform3D(Basis.IDENTITY,global_position+Vector3.UP*0.945);check.collision_mask=1|4;check.exclude=[get_rid()]
		if not get_world_3d().direct_space_state.intersect_shape(check,1).is_empty():crouched=true
	var collider=get_child(0) as CollisionShape3D
	var capsule=collider.shape as CapsuleShape3D
	capsule.height=1.15 if crouched else 1.85
	collider.position.y=capsule.height/2+0.02
	var sprint=Input.is_action_pressed("sprint") and not crouched
	var speed=2.6 if crouched else 8.5 if sprint else 5.2
	if deployment_state!="ground":
		speed=13.0 if deployment_state=="fall" else 8.0
		if Input.is_action_just_pressed("jump") or global_position.y-game.island.height_at(global_position.x,global_position.z)<35:deployment_state="chute"
		velocity.y=-35 if deployment_state=="fall" else -6
		parachute.visible=deployment_state=="chute"
	else:
		if not is_on_floor():velocity.y-=22*dt
		else:velocity.y=-0.1
		if Input.is_action_just_pressed("jump") and is_on_floor():
			if game.try_vault(self):return
			velocity.y=7.5
			game.sound_at("jump",global_position,-12)
	var desired=direction*speed
	var horizontal=Vector2(velocity.x,velocity.z)
	horizontal=horizontal.move_toward(Vector2(desired.x,desired.z),(30 if is_on_floor() else 12)*dt)
	velocity.x=horizontal.x;velocity.z=horizontal.y
	if slide_left>0:
		slide_left=maxf(0,slide_left-dt)
		velocity.x=slide_direction.x*17*(slide_left/0.6)
		velocity.z=slide_direction.z*17*(slide_left/0.6)
	thrusting=has_jetpack and jet_enabled and jet_fuel>0 and not is_on_floor() and deployment_state=="ground" and Input.is_action_pressed("jump")
	if thrusting:
		velocity.y=minf(9,velocity.y+45*dt)
		jet_fuel=maxf(0,jet_fuel-dt*28)
		if not jet_audio.playing:jet_audio.play()
	else:
		if jet_audio.playing:jet_audio.stop()
		if has_jetpack and is_on_floor():jet_fuel=minf(100,jet_fuel+15*dt)
	jet_flames.visible=thrusting
	var airborne=not is_on_floor()
	move_and_slide()
	if is_on_floor() and deployment_state!="ground":
		deployment_state="ground";parachute.visible=false
		game.sound_at("land",global_position,-13)
	elif airborne and is_on_floor():game.sound_at("land",global_position,-13)
	var flat=Vector2(global_position.x,global_position.z)
	if flat.length()>398:
		flat=flat.normalized()*398;global_position.x=flat.x;global_position.z=flat.y
	skin.scale.y=1.0
	skin.rotation.y=lerp_angle(skin.rotation.y,yaw,1-exp(-dt*18))
	if Input.is_action_pressed("fire") and not game.build_mode and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:shoot()
	travel+=Vector2(velocity.x,velocity.z).length()*dt
	if travel>2.6 and is_on_floor():travel=0;game.sound_at("step",global_position,-19)

func _process(dt: float) -> void:
	if human and camera and game.running and not game.paused:update_camera(minf(dt,0.12))

func update_camera(dt: float) -> void:
	var tuning=LastRules.data.camera
	if not Input.is_action_pressed("freelook"):
		free_yaw=lerpf(free_yaw,0.0,1-exp(-dt*12));free_pitch=lerpf(free_pitch,0.0,1-exp(-dt*12))
	var head=global_position+Vector3.UP*(1.25 if crouched else 1.65)
	if not camera_ready or camera_anchor.distance_to(head)>8:
		camera_anchor=head;camera_arm=float(tuning.distance);camera_ready=true
	else:
		var a=1-exp(-float(tuning.follow)*dt)
		camera_anchor.x=lerpf(camera_anchor.x,head.x,a);camera_anchor.z=lerpf(camera_anchor.z,head.z,a)
		camera_anchor.y=lerpf(camera_anchor.y,head.y,1-exp(-float(tuning.heightFollow)*dt))
	var view_yaw=yaw+free_yaw
	var view_pitch=pitch+free_pitch
	var direction=Vector3(-sin(view_yaw)*cos(view_pitch),sin(view_pitch),-cos(view_yaw)*cos(view_pitch)).normalized()
	var right=Vector3(cos(view_yaw),0,-sin(view_yaw))
	var aiming=Input.is_action_pressed("aim") and not game.build_mode
	camera.fov=lerpf(camera.fov,float(LastRules.weapon(slot).zm) if aiming else 70.0,1-exp(-dt*12))
	if camera_mode==1:
		camera.global_position=camera_anchor;camera.look_at(camera_anchor+direction)
	else:
		var distance=float(tuning.adsDistance if aiming else tuning.distance)
		var offset=direction*distance*(1 if camera_mode==2 else -1)
		if camera_mode!=2:offset+=right*float(tuning.shoulder)*(0.5 if aiming else 1.0)
		var desired=camera_anchor+offset
		var delta=desired-head
		var length=delta.length()
		if length>0.001:
			var unit=delta/length
			var allowed=length
			var excluded: Array[RID]=[get_rid()]
			if is_instance_valid(vehicle):excluded.append(vehicle.get_rid())
			for shift in [Vector3.ZERO,right*0.13,-right*0.13,Vector3.UP*0.13,Vector3.DOWN*0.13]:
				var query=PhysicsRayQueryParameters3D.create(head+shift,head+shift+unit*(length+0.15),1|4,excluded)
				var hit=get_world_3d().direct_space_state.intersect_ray(query)
				if not hit.is_empty():allowed=minf(allowed,maxf(0.28,(head+shift).distance_to(hit.position)-0.2))
			if allowed<camera_arm:camera_arm=allowed
			else:camera_arm=lerpf(camera_arm,allowed,1-exp(-float(tuning.release)*dt))
			camera.global_position=head+unit*minf(allowed,camera_arm)
		else:camera.global_position=desired
		camera.global_position.y=maxf(camera.global_position.y,game.island.height_at(camera.global_position.x,camera.global_position.z)+0.23)
		camera.look_at(head if camera_mode==2 else camera.global_position+direction)
	skin.visible=camera_mode!=1 and (not is_instance_valid(vehicle) or vehicle.kind==1)

func start_slide() -> void:
	if not is_on_floor() or slide_cooldown>0 or deployment_state!="ground" or is_instance_valid(vehicle):return
	var axis=Input.get_vector("left","right","forward","back")
	if axis.length()<0.1:axis=Vector2(0,-1)
	slide_direction=Vector3(axis.x,0,axis.y).rotated(Vector3.UP,yaw).normalized()
	slide_left=0.6;slide_cooldown=1.3
	rig.play_action("Roll",0.6,true)

func begin_heal(kind: String="small") -> void:
	if hp>=max_hp or heal_left>0 or deployment_state!="ground" or is_instance_valid(vehicle):return
	if kind=="small" and small_kits<=0 or kind=="large" and kits<=0:return
	heal_kind=kind
	if kind=="small":small_kits-=1
	else:kits-=1
	heal_left=2.0 if kind=="small" else 4.0
	reload_left=0
	rig.play_action("Consume",heal_left)
	game.sound_at("heal",global_position,-12)

func create_parachute() -> void:
	parachute=Node3D.new();add_child(parachute)
	var canopy=Forge.sphere(parachute,Vector3(0,3.9,0),2.5,Forge.mat(Color("596f79")),1.1)
	for side in [-1,1]:
		for front in [-1,1]:Forge.line(parachute,Vector3(side*0.4,1.5,front*0.1),Vector3(side*1.6,3.7,front*1.1),Color("b5bdba"),0.014)
	parachute.visible=false

func bot_step(dt: float) -> void:
	if deployment_state!="ground":
		if global_position.y-game.island.height_at(global_position.x,global_position.z)<55:deployment_state="chute"
		parachute.visible=deployment_state=="chute"
		velocity.y=-35 if deployment_state=="fall" else -6
		move_and_slide()
		if is_on_floor():deployment_state="ground";parachute.visible=false
		return
	decision -= dt
	path_timer -= dt
	wander_timer -= dt
	if decision <= 0:
		decision = rng.randf_range(0.45,0.95)
		target = null
		var closest = 95.0*95.0
		for other in game.fighters:
			if other == self or not is_instance_valid(other) or not other.alive:continue
			var d = global_position.distance_squared_to(other.global_position)
			if d<closest and game.has_sight(self,other):target=other;closest=d
		if rng.randf()<0.22:strafe=-strafe
		if hp<max_hp*0.35 and kits>0 and (not target or closest>900) and heal_left<=0:heal_left=2.8
		if target and reload_left<=0:
			var distance=global_position.distance_to(target.global_position)
			var preference=[5,4,1,2,6,0] if distance<14 else [3,2,6,1,4,0]
			var desired=slot
			for option in preference:
				if carried.has(option) and mags[option]+reserve[option]>0:desired=option;break
			switch_weapon(desired)
		if mags[slot]<=0 and reload_left<=0:reload_weapon()
		game.auto_loot(self)
	var direction := Vector3.ZERO
	var threatened = global_position.distance_to(game.zone_center)>game.zone_radius-16
	if target and (not is_instance_valid(target) or not target.alive):target=null
	if target and not threatened:
		var delta = target.global_position-global_position
		var dist = delta.length()
		skin.rotation.y = lerp_angle(skin.rotation.y,atan2(-delta.x,-delta.z),1-exp(-dt*10))
		if dist>27:goal=target.global_position
		elif dist<12:goal=global_position-delta.normalized()*8
		else:goal=global_position+delta.normalized().cross(Vector3.UP)*strafe*6
		if cooldown<=0 and reload_left<=0 and heal_left<=0 and game.has_sight(self,target):
			var spread = [0.095,0.064,0.038][game.difficulty]
			var aim = target.global_position+Vector3(rng.randf_range(-spread,spread)*dist,1.15+rng.randf_range(-0.25,0.25),rng.randf_range(-spread,spread)*dist)
			shoot_at(aim)
	else:
		if threatened:goal=game.zone_center+Vector3(sin(get_instance_id()),0,cos(get_instance_id()))*game.zone_radius*0.25
		elif wander_timer<=0 or global_position.distance_to(goal)<4:
			wander_timer=rng.randf_range(7,14)
			goal=game.island.spawn_points[rng.randi()%game.island.spawn_points.size()]
	if path_timer<=0:
		path_timer=rng.randf_range(1.0,1.8)
		route=game.island.path(global_position,goal)
		route_step=1 if route.size()>1 else 0
	if route_step<route.size():
		var dest = route[route_step]-global_position
		dest.y=0
		if dest.length()<1.2:route_step+=1
		else:direction=dest.normalized()
	elif target:direction=(goal-global_position).normalized();direction.y=0
	var speed = 5.7 if threatened else 4.1
	if target and not threatened:speed=3.4
	if heal_left>0:speed=2
	velocity.x=direction.x*speed
	velocity.z=direction.z*speed
	if not is_on_floor():velocity.y-=24*dt
	else:velocity.y=-0.1
	if is_on_wall() and is_on_floor() and rng.randf()<dt*2:velocity.y=7
	move_and_slide()
	travel+=Vector2(velocity.x,velocity.z).length()*dt
	if travel>2.6 and is_on_floor():
		travel=0
		game.sound_at("step",global_position,-19)
	if not target and direction.length_squared()>0.01:skin.rotation.y=lerp_angle(skin.rotation.y,atan2(-direction.x,-direction.z),1-exp(-dt*8))

func animate_skin(_dt: float) -> void:
	# CharacterRig owns the blended, authored animation clips.
	pass

func shoot() -> void:
	if cooldown>0 or reload_left>0 or heal_left>0 or deployment_state!="ground" or is_instance_valid(vehicle) or Input.is_action_pressed("freelook"):return
	if not LastRules.weapon(slot).auto and not Input.is_action_just_pressed("fire"):return
	if mags[slot]<=0:reload_weapon();return
	var center = get_viewport().get_visible_rect().size*0.5
	var from = camera.project_ray_origin(center)
	var far = from+camera.project_ray_normal(center)*350
	var q = PhysicsRayQueryParameters3D.create(from,far,3,[get_rid()])
	var result = get_world_3d().direct_space_state.intersect_ray(q)
	shoot_at(result.position if not result.is_empty() else far)
	# Camera aim remains exactly where the player points it; recoil is visual only.

func shoot_at(point: Vector3) -> void:
	if cooldown>0 or reload_left>0 or heal_left>0 or mags[slot]<=0 or deployment_state!="ground":return
	var weapon=LastRules.weapon(slot)
	mags[slot]-=1
	cooldown=float(weapon.rate) if human else maxf(float(weapon.rate),rng.randf_range(0.38,0.8)*[1.4,1.0,0.78][game.difficulty])
	rig.raise_weapon()
	var from=muzzle.global_position
	var dir=(point-from).normalized()
	for i in range(int(weapon.get("pellets",1))):
		game.fire_ray(self,from,from+dir*350,float(LastRules.data.damage[LastRules.IDS[slot]].max))
	game.sound_at(LastRules.sound(slot),global_position,-13 if human else -16)
	rig.play_action("Shoot_OneHanded",minf(0.35,float(weapon.rate)))
	if human:game.shots_fired+=1

func reload_weapon() -> void:
	if reload_left>0 or mags[slot]>=LastRules.weapon(slot).mag or reserve[slot]<=0:return
	reload_left=float(LastRules.weapon(slot).rl)
	rig.play_action("Reload",reload_left)
	heal_left=0
	if human:game.sound_at("reload",global_position,-10)

func finish_reload() -> void:
	var amount = mini(int(LastRules.weapon(slot).mag)-mags[slot],reserve[slot])
	mags[slot]+=amount
	reserve[slot]-=amount

func switch_weapon(index: int) -> void:
	if index==slot or not unlocked[index]:return
	reload_left=0
	slot=index
	update_weapon_model()

func damage(amount: float, attacker: Fighter, headshot: bool = false, storm: bool = false) -> void:
	if not alive:return
	if headshot:amount*=float(LastRules.data.damage[LastRules.IDS[attacker.slot]].head) if attacker else 1.75
	if not storm:
		if headshot:
			var absorb=minf(helmet_durability,amount*[0.0,0.35,0.5,0.65][helmet_level])
			helmet_durability-=absorb
			amount-=absorb
		else:
			var absorb=minf(armor,amount*[0.0,0.35,0.5,0.65][armor_level])
			armor-=absorb
			amount-=absorb
	hp=maxf(0,hp-amount)
	received_at=game.elapsed
	heal_left=0
	if human:
		game.hurt_flash=0.32
		if not storm and game.elapsed-last_hurt_audio>0.13:
			game.sound_at("hurt",global_position,-16)
			last_hurt_audio=game.elapsed
	if hp<=0:
		alive=false
		collision_layer=0
		collision_mask=0
		if attacker:attacker.kills+=1
		game.on_eliminated(self,attacker)
		if not human:
			rig.play_action("Death",0,true)
			get_tree().create_timer(6).timeout.connect(func():skin.visible=false)

func equip_armor(level: int,helmet: bool=false) -> void:
	if helmet:
		if level>=helmet_level or helmet_durability<=0:
			helmet_level=level
			helmet_durability=[0,40,65,90][level]
	else:
		if level>=armor_level or armor<=0:
			armor_level=level
			armor=[0,70,100,140][level]

func create_jet_visual() -> void:
	jet_visual=Node3D.new()
	skin.add_child(jet_visual)
	var metal=Forge.mat(Color("354851"),0.35,0.65)
	for side in [-1,1]:
		Forge.cylinder(jet_visual,Vector3(side*0.19,1.35,0.36),0.14,0.65,metal,-1,10)
		Forge.box(jet_visual,Vector3(side*0.19,1.55,0.5),Vector3(0.14,0.05,0.03),Forge.mat(Color("80e7de")))
	jet_flames=Node3D.new()
	jet_visual.add_child(jet_flames)
	for side in [-1,1]:Forge.cylinder(jet_flames,Vector3(side*0.19,0.84,0.36),0.015,0.4,Forge.mat(Color("6cddff"),0.2),0.1,7)
	jet_flames.visible=false
	jet_visual.visible=false
	jet_audio=AudioStreamPlayer3D.new()
	jet_audio.stream=Ambience.sounds.get("jet")
	jet_audio.volume_db=-15
	jet_audio.unit_size=5
	jet_audio.max_distance=70
	add_child(jet_audio)

func equip_jetpack() -> void:
	has_jetpack=true
	jet_enabled=true
	jet_fuel=100
	jet_visual.visible=true

func collect_weapon(index: int) -> void:
	if not carried.has(index):
		if carried.size()>=3:
			var removed=carried.pop_back()
			unlocked[removed]=false
		carried.append(index)
		unlocked[index]=true
		mags[index]=int(LastRules.weapon(index).mag)
	reserve[index]+=int(LastRules.weapon(index).mag)*3
	switch_weapon(index)

func update_weapon_model() -> void:
	if is_instance_valid(gun_model):gun_model.queue_free()
	gun_model=load("res://assets/equipment/"+LastRules.IDS[slot]+".glb").instantiate()
	gun.add_child(gun_model)
	if muzzle:muzzle.position=Vector3(0,0.075,-[0.205,0.38,0.58,0.85,0.38,0.70,0.58][slot])
	for mesh in gun_model.find_children("*","MeshInstance3D",true,false):
		mesh.visibility_range_end=90.0 if not human else 0.0
