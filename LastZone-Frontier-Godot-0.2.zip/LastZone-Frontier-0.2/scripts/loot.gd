class_name Supply
extends Node3D
var kind := 0
var taken := false
var tier := 1
var mesh: Node3D
var wave := 0.0
var payload: Dictionary={}
var game

func create(owner_game, type: int, at: Vector3) -> void:
	game=owner_game
	kind=type
	position=at
	if kind in [5,6]:tier=game.rng.randi_range(1,3)
	mesh=Node3D.new()
	add_child(mesh)
	var color = [Color("84dfe1"),Color("eac888"),Color("9be8a6"),Color("8baaff"),Color("e98dce"),Color("85b8ec"),Color("bed0e4"),Color("ffbc68"),Color("91b097"),Color("aaaac7"),Color("c4aa8e"),Color("d1bf7c"),Color("a7e1b9"),Color("798e68")][kind]
	Forge.box(mesh,Vector3.ZERO,Vector3(0.65,0.4,0.6),Forge.mat(Color("243e43"),0.55,0.3))
	Forge.box(mesh,Vector3(0,0.22,0),Vector3(0.58,0.04,0.52),Forge.mat(color,0.35,0.4))
	if kind in [2,12]:
		Forge.box(mesh,Vector3(0,0.26,0),Vector3(0.32,0.02,0.1),Forge.mat(Color.WHITE))
		Forge.box(mesh,Vector3(0,0.27,0),Vector3(0.1,0.02,0.32),Forge.mat(Color.WHITE))
	if kind==5:
		Forge.box(mesh,Vector3(0,0.48,0),Vector3(0.38,0.42,0.2),Forge.mat(Color("4f6570")))
	if kind==6:
		Forge.sphere(mesh,Vector3(0,0.43,0),0.25,Forge.mat(Color("77878b")),0.3)
	if kind==7:
		for side in [-1,1]:Forge.cylinder(mesh,Vector3(side*0.15,0.52,0),0.11,0.5,Forge.mat(Color("d5ad66"),0.3,0.6))
	var ring=Forge.cylinder(self,Vector3(0,0.025,0),0.65,0.02,Forge.mat(color*0.65),-1,16)
	ring.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	wave=randf()*TAU

func _process(dt: float) -> void:
	if taken:return
	wave+=dt*1.7
	mesh.position.y=0.6+sin(wave)*0.08
	mesh.rotation.y+=dt*0.35

func take(actor: Fighter) -> String:
	if taken or not actor.alive:return ""
	if kind==5 and tier<actor.armor_level and actor.armor>0:return ""
	if kind==6 and tier<actor.helmet_level and actor.helmet_durability>0:return ""
	if kind==7 and actor.has_jetpack and actor.jet_fuel>=99.9:return ""
	taken=true
	match kind:
		0:actor.ice=mini(8,actor.ice+2);actor.materials+=90
		1:
			for index in range(7):actor.reserve[index]+=5 if index==3 else 12 if index==5 else int(LastRules.weapon(index).mag)*2
		2:actor.kits+=int(payload.get("quantity",1))
		5:actor.equip_armor(tier)
		6:actor.equip_armor(tier,true)
		7:actor.equip_jetpack()
		12:actor.small_kits+=int(payload.get("quantity",1))
		13:actor.grenades+=2
		_:
			if LastRules.LOOT_WEAPONS.has(kind):
				var index=int(LastRules.LOOT_WEAPONS[kind])
				if payload.is_empty():actor.collect_weapon(index)
				else:
					var existing=actor.carried.has(index)
					var previous=actor.reserve[index]
					actor.collect_weapon(index)
					actor.reserve[index]=previous+int(payload.reserve)+(int(payload.mag) if existing else 0)
					if not existing:actor.mags[index]=int(payload.mag)

	queue_free()
	return title()

func title() -> String:
	if LastRules.LOOT_WEAPONS.has(kind):return str(LastRules.weapon(LastRules.LOOT_WEAPONS[kind]).n)
	return {0:"+2 gelos",1:"Munição",2:"KITÃO +100 HP",5:"Colete nível %d"%tier,6:"Capacete nível %d"%tier,7:"Jetpack",12:"Kitzinho +25 HP",13:"+2 granadas"}.get(kind,"Suprimento")
