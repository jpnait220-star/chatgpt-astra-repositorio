class_name RoadVehicle
extends CharacterBody3D

var game
var kind := 0
var driver: Fighter
var speed := 0.0
var heading := 0.0
var hp := 500.0
var visual: Node3D
var wheels: Array[Node3D]=[]
var engine_audio: AudioStreamPlayer3D

func create(owner_game,type: int,at: Vector3,angle: float) -> void:
 game=owner_game;kind=type;heading=angle;position=at
 collision_layer=4;collision_mask=1|2|4
 floor_max_angle=deg_to_rad(46)
 var col=CollisionShape3D.new();var shape=BoxShape3D.new();shape.size=Vector3(0.85,1.5,2.3) if kind else Vector3(2.0,1.7,4.1);col.shape=shape;col.position.y=0.95;add_child(col)
 visual=Node3D.new();add_child(visual)
 if kind==0:build_van()
 else:
  var scene=load("res://assets/vehicles/motorcycle.glb") as PackedScene
  if scene:visual.add_child(scene.instantiate())
 engine_audio=AudioStreamPlayer3D.new();engine_audio.stream=Ambience.sounds.get("engine",Ambience.sounds.jet);engine_audio.volume_db=-21;engine_audio.unit_size=9;engine_audio.max_distance=100;add_child(engine_audio)

func build_van() -> void:
 var source=load("res://assets/vehicles/vehicles.glb").instantiate()
 var van=source.find_child("Minivan",true,false) as MeshInstance3D
 var wheel=source.find_child("Wheel",true,false) as MeshInstance3D
 if van:
  var body=MeshInstance3D.new();body.mesh=van.mesh;body.position.y=0.2;body.rotation.y=PI;visual.add_child(body)
  for surface in range(body.mesh.get_surface_count()):
   var m=body.mesh.surface_get_material(surface)
   if m and m.resource_name=="truck_trailer":
    var textured=m.duplicate() as StandardMaterial3D;textured.albedo_texture=load("res://assets/vehicles/vehicles.png");body.set_surface_override_material(surface,textured)
 if wheel:
  for side in [-1,1]:
   for z in [-1.25,1.3]:
    var w=MeshInstance3D.new();w.mesh=wheel.mesh;w.position=Vector3(side*0.98,0.43,z);w.rotation.y=PI if side<0 else 0;visual.add_child(w);wheels.append(w)
 source.free()

func _physics_process(dt: float) -> void:
 if not game.running or game.paused:
  if engine_audio.playing:engine_audio.stop()
  return
 if is_instance_valid(driver):return
 speed=move_toward(speed,0,dt*7)
 move_vehicle(dt)

func drive(dt: float,actor: Fighter) -> void:
 var axis=Input.get_vector("left","right","forward","back")
 var throttle=-axis.y
 speed+=throttle*(22 if kind else 16)*dt
 if absf(throttle)<0.1:speed*=maxf(0,1-1.2*dt)
 if Input.is_action_pressed("jump"):speed=move_toward(speed,0,dt*35)
 speed=clampf(speed,-8,32 if kind else 26)
 heading-=axis.x*minf(1,absf(speed)/8)*1.8*dt*(1 if speed>=0 else -1)
 move_vehicle(dt)
 actor.global_position=global_position+Vector3(0,0.1 if kind else 0.35,0)
 actor.yaw=heading
 actor.velocity=Vector3.ZERO
 actor.skin.rotation.y=heading
 actor.gun.visible=false
 if not engine_audio.playing:engine_audio.play()
 engine_audio.pitch_scale=0.65+absf(speed)/32

func move_vehicle(dt: float) -> void:
 rotation.y=heading
 velocity=Vector3(-sin(heading),0,-cos(heading))*speed
 velocity.y=-5
 move_and_slide()
 global_position.y=lerpf(global_position.y,game.island.height_at(global_position.x,global_position.z),1-exp(-dt*16))
 if get_slide_collision_count()>0:
  for i in range(get_slide_collision_count()):
   var collision=get_slide_collision(i)
   if absf(collision.get_normal().y)<0.65:speed*=-0.3;break
 var p=Vector2(global_position.x,global_position.z)
 if p.length()>396:p=p.normalized()*396;global_position.x=p.x;global_position.z=p.y;speed=0
 for wheel in wheels:wheel.rotate_x(-speed*dt/0.43)

func enter(actor: Fighter) -> bool:
 if is_instance_valid(driver) or actor.deployment_state!="ground":return false
 driver=actor;actor.vehicle=self;actor.collision_layer=0;actor.collision_mask=0
 actor.arm.add_excluded_object(get_rid())
 game.notice("B para sair · Espaço para frear",3)
 return true

func leave() -> bool:
 if not is_instance_valid(driver):return false
 for side in [Vector3(2.2,0,0),Vector3(-2.2,0,0),Vector3(0,0,3.1)]:
  var at=global_position+side.rotated(Vector3.UP,heading);at.y=game.island.height_at(at.x,at.z)+0.15
  var query=PhysicsShapeQueryParameters3D.new();var shape=CapsuleShape3D.new();shape.radius=0.38;shape.height=1.85;query.shape=shape;query.transform=Transform3D(Basis.IDENTITY,at+Vector3.UP*0.95);query.collision_mask=7;query.exclude=[get_rid(),driver.get_rid()]
  if not get_world_3d().direct_space_state.intersect_shape(query,1).is_empty():continue
  var actor=driver;actor.vehicle=null;driver=null;actor.global_position=at;actor.velocity=Vector3.ZERO;actor.collision_layer=2;actor.collision_mask=7;actor.skin.visible=true;actor.gun.visible=true;actor.arm.remove_excluded_object(get_rid());engine_audio.stop();return true
 return false

func damage(amount: float,_attacker=null,_head=false) -> void:
 hp-=amount
 if hp<=0:
  leave()
  game.sound_at("break",global_position,-9)
  queue_free()
