class_name Ambience
extends RefCounted

static var sounds: Dictionary={}
static func make_sounds() -> void:
	var durations={"shot":0.28,"smg":0.18,"shotgun":0.48,"reload":0.7,"step":0.16,"hit":0.1,"build":0.5,"ice":0.55,"break":0.42,"pickup":0.26,"jump":0.2,"land":0.28,"vault":0.58,"heal":0.8,"heal_done":0.35,"jet":0.5,"hurt":0.16,"engine":1.0}
	for name in durations:
		var count=int(22050*durations[name])
		var bytes=PackedByteArray()
		bytes.resize(count*2)
		var random=RandomNumberGenerator.new()
		random.seed=name.hash()
		var prev=0.0
		for i in range(count):
			var t=float(i)/22050.0
			var p=float(i)/count
			var noise=random.randf_range(-1,1)
			prev=lerpf(prev,noise,0.21)
			var sample=0.0
			match name:
				"shot":sample=(noise*0.5+sin(t*TAU*(130-100*p))*0.42)*exp(-p*12)+prev*0.16*exp(-absf(p-0.17)*35)
				"smg":sample=(noise*0.48+sin(t*TAU*(170-100*p))*0.35)*exp(-p*15)
				"shotgun":sample=(noise*0.42+sin(t*TAU*(85-50*p))*0.45)*exp(-p*9)+prev*0.18*exp(-p*3)
				"step":sample=(prev*0.7+sin(t*TAU*85)*0.17)*exp(-p*16)
				"jump":sample=prev*0.35*sin(p*PI)*exp(-p*4)
				"land":sample=(prev*0.65+sin(t*TAU*(65-25*p))*0.23)*exp(-p*12)
				"break":sample=noise*0.32*exp(-p*10)+prev*0.35*exp(-p*4)
				"vault":sample=prev*0.4*(exp(-absf(p-0.15)*18)+0.7*exp(-absf(p-0.75)*25))
				"reload":sample=(noise*0.4+sin(t*TAU*900)*0.09)*(exp(-absf(p-0.08)*70)+exp(-absf(p-0.58)*80)+0.65*exp(-absf(p-0.85)*90))
				"hit":sample=sin(t*TAU*1050)*exp(-p*15)*0.3
				"build","ice":sample=(prev*0.45+sin(t*TAU*(250+1100*p))*0.12)*sin(p*PI)*exp(-p*3)
				"pickup","heal_done":sample=sin(t*TAU*(660 if p<0.5 else 990))*sin(p*PI)*0.18
				"heal":sample=prev*0.28*sin(p*PI)+sin(t*TAU*(440+220*p))*0.05*sin(p*PI)
				"hurt":sample=prev*0.45*exp(-p*13)
				"engine":sample=(sin(t*TAU*40)*0.19+sin(t*TAU*80)*0.08+sin(t*TAU*120)*0.04)*(0.75+0.25*sin(t*TAU*20))
				"jet":sample=sin(t*TAU*64)*0.16+sin(t*TAU*128)*0.08+prev*0.19
			bytes.encode_s16(i*2,int(clampf(sample,-0.95,0.95)*32700))
		var wav=AudioStreamWAV.new()
		wav.format=AudioStreamWAV.FORMAT_16_BITS
		wav.mix_rate=22050
		wav.data=bytes
		if name in ["jet","engine"]:
			wav.loop_mode=AudioStreamWAV.LOOP_FORWARD
			wav.loop_end=count
		sounds[name]=wav

	# Footsteps, jumps and landings from the credited Godot TPS audio assets.
	for name in ["step","jump","land"]:
		var path="res://assets/audio/"+name+".wav"
		if ResourceLoader.exists(path):sounds[name]=load(path)
