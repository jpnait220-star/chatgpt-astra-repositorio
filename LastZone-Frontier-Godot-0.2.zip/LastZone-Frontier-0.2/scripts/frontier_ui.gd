class_name FrontierUI
extends RefCounted

static func modal(game,title: String,size: Vector2=Vector2(820,610)) -> VBoxContainer:
 game.close_menu()
 game.paused=game.running
 Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
 game.menu=Control.new()
 game.menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 game.gui.add_child(game.menu)
 var shade=ColorRect.new();shade.color=Color(0.025,0.04,0.05,0.72);shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);game.menu.add_child(shade)
 var panel=PanelContainer.new();panel.position=(Vector2(1280,720)-size)/2;panel.size=size
 var style=StyleBoxFlat.new();style.bg_color=Color("14282d");style.set_corner_radius_all(14);style.content_margin_left=28;style.content_margin_right=28;style.content_margin_top=22;style.content_margin_bottom=22
 panel.add_theme_stylebox_override("panel",style);game.menu.add_child(panel)
 var scroll=ScrollContainer.new();scroll.custom_minimum_size=size-Vector2(56,44);scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;panel.add_child(scroll)
 var box=VBoxContainer.new();box.size_flags_horizontal=Control.SIZE_EXPAND_FILL;box.add_theme_constant_override("separation",12);scroll.add_child(box)
 game.label(box,title,27,Color("e9d5aa"))
 return box

static func inventory(game) -> void:
 var box=modal(game,"INVENTÁRIO")
 game.ui_mode="inventory"
 var p=game.player
 game.label(box,"VIDA  %d / %d    ·    COLETE %d    ·    CAPACETE %d" % [p.hp,p.max_hp,p.armor,p.helmet_durability],15,Color("a6d6ce"))
 for index in p.carried:
  var row=HBoxContainer.new();box.add_child(row)
  var label=game.label(row,"%s   %d / %d" % [LastRules.weapon(index).n,p.mags[index],p.reserve[index]],18,Color.WHITE);label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
  game.button(row,"EQUIPADA" if index==p.slot else "EQUIPAR",func():p.switch_weapon(index);inventory(game))
  if index!=0:game.button(row,"LARGAR",func():game.drop_weapon(index);inventory(game))
 game.label(box,"MEDICAMENTOS",17,Color("e9d5aa"))
 var small=HBoxContainer.new();box.add_child(small)
 game.label(small,"Kitzinho  +25 HP · 2s  (%d)" % p.small_kits,17,Color.WHITE).size_flags_horizontal=Control.SIZE_EXPAND_FILL
 game.button(small,"USAR [H]",func():resume(game);p.begin_heal("small"))
 var large=HBoxContainer.new();box.add_child(large)
 game.label(large,"KITÃO  +100 HP · 4s  (%d)" % p.kits,17,Color.WHITE).size_flags_horizontal=Control.SIZE_EXPAND_FILL
 game.button(large,"USAR [J]",func():resume(game);p.begin_heal("large"))
 game.label(box,"Gelo %d   ·   Granadas %d   ·   Jetpack %s" % [p.ice,p.grenades,"%d%%" % p.jet_fuel if p.has_jetpack else "Não equipado"],16,Color("a6d6ce"))
 game.button(box,"FECHAR  [TAB]",func():resume(game),true)

static func resume(game) -> void:
 game.close_menu();game.paused=false;game.ui_mode=""
 Input.mouse_mode=Input.MOUSE_MODE_CAPTURED

static func big_map(game) -> void:
 var box=modal(game,"MAPA DA ILHA",Vector2(1120,660))
 game.ui_mode="map"
 var map=load("res://scripts/world_map.gd").new();map.game=game;map.custom_minimum_size=Vector2(1000,490);box.add_child(map)
 game.button(box,"VOLTAR À PARTIDA  [M]",func():resume(game),true)

static func wardrobe(game) -> void:
 var box=modal(game,"COFRE · SEU PERSONAGEM",Vector2(1100,650))
 game.ui_mode="wardrobe"
 var row=HBoxContainer.new();row.add_theme_constant_override("separation",24);box.add_child(row)
 var view=SubViewportContainer.new();view.custom_minimum_size=Vector2(430,460);view.stretch=true;row.add_child(view)
 var viewport=SubViewport.new();viewport.size=Vector2i(430,460);viewport.transparent_bg=true;viewport.own_world_3d=true;view.add_child(viewport)
 var stage=Node3D.new();viewport.add_child(stage)
 var dummy=Fighter.new();dummy.game=game;dummy.human=true;dummy.skin=Node3D.new();stage.add_child(dummy);dummy.add_child(dummy.skin);dummy.set_physics_process(false)
 var rig=CharacterRig.new();dummy.skin.add_child(rig);rig.build(dummy,int(game.outfit.get("model",0)));rig.preview_pose="Idle";rig.set_outfit(game.outfit)
 var camera=Camera3D.new();stage.add_child(camera);camera.position=Vector3(0,1.3,-3.5);camera.look_at(Vector3(0,0.95,0));camera.fov=38;camera.current=true
 var light=DirectionalLight3D.new();light.rotation_degrees=Vector3(-35,-35,0);light.light_energy=0.75;stage.add_child(light)
 var env=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_COLOR;e.background_color=Color("14282d");e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color("c4d1d9");e.ambient_light_energy=0.65;env.environment=e;stage.add_child(env)
 var choices=VBoxContainer.new();choices.size_flags_horizontal=Control.SIZE_EXPAND_FILL;choices.add_theme_constant_override("separation",9);row.add_child(choices)
 game.label(choices,"PERFIL DE ROUPA",14,Color("a6d6ce"))
 var variants=OptionButton.new()
 for name in ["Urbano","Operador","Sobrevivente"]:variants.add_item(name)
 variants.selected=int(game.outfit.get("model",0));variants.item_selected.connect(func(i):game.outfit.model=i;game.outfit.shirt=["#496477","#3a4842","#594a3a"][i];game.outfit.pants=["#34414b","#252b27","#333235"][i];game.save_settings();wardrobe(game));choices.add_child(variants)
 for category in [["shirts","shirt","CAMISA"],["pants","pants","CALÇA"],["hair","hair","CABELO"],["masks","mask","MÁSCARA"],["boots","boots","CALÇADOS"]]:
  game.label(choices,category[2],13,Color("a6d6ce"))
  var select=OptionButton.new();var entries=LastRules.data[category[0]].duplicate()
  if category[0]=="hair":
   var ordered={"natural":["Cabelo natural",0x29231f]};ordered.merge(entries);entries=ordered
  var ids=entries.keys()
  for id in ids:select.add_item(str(entries[id][0]))
  var chosen=str(game.outfit.get(category[1]+"_id","none" if category[0]=="masks" else "pad" if category[0]=="boots" else ""))
  var matched=false
  if ids.has(chosen):select.selected=ids.find(chosen);matched=true
  else:
   for i in range(ids.size()):
    var option=entries[ids[i]]
    if option.size()>1 and game.outfit.get(category[1],"")=="#"+LastRules.color(option[1]).to_html(false):select.selected=i;matched=true;break
  if not matched:
   select.add_item("Cor personalizada");select.selected=select.item_count-1
  select.item_selected.connect(func(i):
   if i>=ids.size():return
   var option=entries[ids[i]]
   var color=LastRules.color(option[1]) if option.size()>1 else Color("273e4a")
   game.outfit[category[1]+"_id"]=ids[i]
   game.outfit[category[1]]="#"+color.to_html(false)
   if category[0]=="hair":game.outfit.hair_id=ids[i]
   if category[0]=="masks":game.outfit.mask_id=ids[i]
   rig.set_outfit(game.outfit);game.save_settings()
   if is_instance_valid(game.player):game.player.rig.set_outfit(game.outfit))
  choices.add_child(select)
 game.label(choices,"Seu visual fica salvo neste computador.\nAs cores e acessórios acompanham o personagem.",13,Color("b4c5c5"))
 game.button(box,"VOLTAR",func():game.show_menu(game.running),true)

static func settings(game) -> void:
 var box=modal(game,"CONFIGURAÇÕES · CONTROLES")
 game.ui_mode="settings"
 game.label(box,"Clique numa ação e pressione uma tecla ou botão do mouse. Esc cancela.",14,Color("a6d6ce"))
 for pair in [["forward","Frente"],["back","Trás"],["left","Esquerda"],["right","Direita"],["fire","Atirar"],["aim","Mirar"],["crouch_toggle","Agachar (alternar)"],["crouch","Agachar (segurar)"],["jump","Pular / paraquedas / jetpack"],["reload","Recarregar"],["ice","Gelo"],["grenade","Granada"],["vehicle","Entrar/sair de veículo"],["slide","Deslizar"],["heal","Kitzinho"],["large_heal","KITÃO"],["interact","Coletar"],["inventory","Inventário"],["map","Mapa"],["camera_view","Câmera"]]:
  var row=HBoxContainer.new();box.add_child(row)
  game.label(row,pair[1],16,Color.WHITE).size_flags_horizontal=Control.SIZE_EXPAND_FILL
  var events=InputMap.action_get_events(pair[0]);var label=events[0].as_text() if not events.is_empty() else "Sem tecla"
  var action=pair[0];var button=game.button(row,label,func():game.rebinding_action=action;game.notice("Pressione uma tecla ou botão para "+action,8))
 game.button(box,"VOLTAR",func():game.show_menu(game.running),true)
