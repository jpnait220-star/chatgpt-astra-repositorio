extends SceneTree
var game
var busy=false
func _initialize():call_deferred("run")
func shot(name: String):
 await create_timer(0.4).timeout
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png("/workspace/aurora-02-research/"+name+".png")
 print("GALLERY ",name)
func run():
 game=load("res://scenes/main.tscn").instantiate();root.add_child(game)
 await process_frame
 await shot("lastzone-menu")
 game.allow_airdrop=false
 await game.start_match()
 game.auto_collect=false
 for actor in game.fighters:
  if not actor.human:actor.set_physics_process(false)
 var p=game.player
 p.position=Vector3(0,0.2,-50);p.yaw=PI;p.pitch=-0.08;p.velocity=Vector3.ZERO
 p.collect_weapon(2);p.equip_armor(2);p.equip_armor(1,true)
 var v=game.vehicles[0];v.position=Vector3(7,0,-32);v.heading=-0.4
 var bot=game.fighters[1];bot.position=Vector3(-8,0.15,-10);bot.yaw=PI;bot.skin.rotation.y=PI
 await create_timer(0.6).timeout
 p.set_physics_process(false)
 p.update_camera(0.12)
 game.notice("LastZone Frontier · prévia da partida solo",5)
 await shot("lastzone-partida")
 # Real rounded ice meshes and native wardrobe, captured from the running game.
 var ice=Cover.new();game.add_child(ice);ice.create(game,0,Vector3(-7,0.06,-35),0.25);game.covers.append(ice)
 game.flycam.position=Vector3(-14,4,-44);game.flycam.look_at(Vector3(-4,1.2,-34));game.flycam.current=true
 await shot("lastzone-gelo")
 ice.damage(380)
 await shot("lastzone-gelo-danificado")
 FrontierUI.wardrobe(game)
 await shot("lastzone-cofre")
 game.close_menu();game.paused=false
 game.flycam.current=true;game.flycam.position=Vector3(10,3,-37);game.flycam.look_at(v.position+Vector3.UP)
 await shot("lastzone-veiculos")
 # Two actual authored running poses provide visual animation evidence.
 game.flycam.position=p.position+Vector3(2.4,1.4,3.7);game.flycam.look_at(p.position+Vector3(0,1,0))
 p.rig.preview_pose="Run";p.gun.visible=false
 await shot("lastzone-animacao-a")
 await create_timer(0.18).timeout
 await shot("lastzone-animacao-b")
 game.free()
 await process_frame
 quit()
