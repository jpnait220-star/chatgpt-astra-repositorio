extends SceneTree
var timer:=0.0
var actor: Fighter
class PreviewGame:
 extends RefCounted
 var paused=false
 var running=false
 var player
 var elapsed=0.0

func _initialize():call_deferred("build_stage")
func build_stage():
 var stage=Node3D.new();root.add_child(stage)
 var game=PreviewGame.new()
 actor=Fighter.new();stage.add_child(actor);actor.setup(game,true,0);actor.set_physics_process(false)
 actor.rig.preview_pose="Idle"
 var plane=Forge.box(stage,Vector3(0,-0.06,0),Vector3(18,0.1,18),Forge.mat(Color("303b43")))
 var env=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_COLOR;e.background_color=Color("1a252e");e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color("b9c9d8");e.ambient_light_energy=0.6;env.environment=e;stage.add_child(env)
 var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-45,-35,0);sun.light_energy=0.9;stage.add_child(sun)
 var cam=Camera3D.new();stage.add_child(cam);cam.position=Vector3(2.4,1.55,-3.7);cam.look_at(Vector3(0,0.95,0));cam.current=true;cam.fov=40
func _process(dt):
 timer+=dt
 if timer>0.8:
  await RenderingServer.frame_post_draw
  root.get_texture().get_image().save_png("/workspace/aurora-02-research/personagem-humano.png")
  actor.free()
  await process_frame
  quit()
