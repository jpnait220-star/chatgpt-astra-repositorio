"""Additional requested adjustments, always relative to the frozen pre-request build."""
from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io,copy,hashlib,re,shutil
from render_cosmetic_icons223 import render,rotation
import numpy as np
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics'
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
base=ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.24.jar')
def model(k):return json.loads(base.read(f'assets/duckswords/cosmetics/{k.lower()}/model.json'))
def move(m,delta):
 for b in m['minecraft:geometry'][0]['bones']:
  if not b['name'].startswith('anchor_') and 'pivot' in b:b['pivot']=[v+d for v,d in zip(b['pivot'],delta)]
  for c in b.get('cubes',[]):
   for field in ['origin','pivot']:
    if field in c:c[field]=[v+d for v,d in zip(c[field],delta)]
changed=[]
for k,d in [('customMask',[0,-1,0]),('summer2024JapaneseFoxMask',[0,0,1]),('fall2025OwlMask',[0,1,0]),('demon2024CrowMask',[0,0,-1])]:
 m=model(k);move(m,d);save(R/k.lower()/'model.json',m);changed.append(k)
# Resize about each hand, so a larger glove does not drift away from the wrist.
for k in ['spring2025BoxingGloves','springClaws']:
 m=model(k);g=m['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']}
 def anchor(b):return anchor(bones[b['parent']]) if b.get('parent') in bones else b
 for b in g['bones']:
  a=anchor(b);pivot=[6 if 'left' in a['name'].lower() else -6,14,0]
  def point(v):return [round(p+(x-p)*1.2,6) for x,p in zip(v,pivot)]
  if b!=a and 'pivot' in b:b['pivot']=point(b['pivot'])
  for c in b.get('cubes',[]):
   c['origin']=point(c['origin']);c['size']=[round(v*1.2,6) for v in c['size']]
   if 'pivot' in c:c['pivot']=point(c['pivot'])
 save(R/k.lower()/'model.json',m);changed.append(k)
# Explicit visible end-caps instead of zero-area UVs sampling a transparent corner.
m=model('spaceMask');c=m['minecraft:geometry'][0]['bones'][1]['cubes'];c[1]['uv']['west']=copy.deepcopy(c[1]['uv']['east']);c[3]['uv']['east']=copy.deepcopy(c[3]['uv']['west']);save(R/'spacemask/model.json',m);changed.append('spaceMask')
m=model('summer2024PropellerHat');g=m['minecraft:geometry'][0]
# Two-sided original propeller planes: underside used a transparent net strip.
for b in g['bones']:
 for c in b.get('cubes',[]):
  if c['size'][1]==0 and c['size'][0]>0 and c['size'][2]>0:c['uv']['down']=copy.deepcopy(c['uv']['up'])
save(R/'summer2024propellerhat/model.json',m);changed.append('summer2024PropellerHat')
m=model('angelGloves')
for b in m['minecraft:geometry'][0]['bones']:
 for c in b.get('cubes',[]):
  if all(v>0 for v in c['size']):c['uv']['up']={'uv':[4,0] if c['origin'][0]<0 else [0,0],'uv_size':[-4,2] if c['origin'][0]<0 else [4,2]}
save(R/'angelgloves/model.json',m);changed.append('angelGloves')
m=model('dragonFestivalGloves')
for b in m['minecraft:geometry'][0]['bones']:
 for c in b.get('cubes',[]):
  if c['size'][2]==0:
   c.pop('inflate',None)
   c['uv']['south']=copy.deepcopy(c['uv']['north'])
   c['uv']['south']['uv'][0]+=c['uv']['south']['uv_size'][0];c['uv']['south']['uv_size'][0]*=-1
  else:
   c['origin'][0]+=.25 if c['origin'][0]<0 else -.25
save(R/'dragonfestivalgloves/model.json',m);changed.append('dragonFestivalGloves')
# Original gem atlas, rather than metal/transparent UVs on the small faceted stones.
for k in ['dontTouchMyLifeBlackCrown','dontTouchMyLifeWhiteCrown']:
 m=model(k);im=np.array(Image.open(io.BytesIO(base.read(f'assets/duckswords/cosmetics/{k.lower()}/texture.png'))).convert('RGBA'));rgb=im[:,:,:3].astype(float);sat=rgb.max(2)-rgb.min(2);ys,xs=np.where((sat>80)&(im[:,:,3]>220));assert len(xs)>100
 # A compact opaque, saturated patch from the original red/purple jewel region.
 best=None
 for y in range(int(ys.min()),int(ys.max())-15,4):
  for x in range(int(xs.min()),int(xs.max())-15,4):
   block=sat[y:y+16,x:x+16];score=block.mean() if im[y:y+16,x:x+16,3].min()>220 else -1
   if best is None or score>best[0]:best=(score,x,y)
 tw=m['minecraft:geometry'][0]['description']['texture_width'];scale=im.shape[1]/tw
 for b in m['minecraft:geometry'][0]['bones']:
  for c in b.get('cubes',[]):
   if max(c['size'])<3 and c['origin'][1]>31 and c.get('rotation'):
    c['uv']={f:{'uv':[best[1]/scale,best[2]/scale],'uv_size':[16/scale,16/scale]} for f in ['north','south','east','west','up','down']}
 save(R/k.lower()/'model.json',m);changed.append(k)
manifest=json.loads((B/'cosmetics225-manifest.json').read_text());manifest['items']=[r for r in manifest['items'] if r['id']!='cyberNinjaGloves'];manifest['removed']=sorted(set(manifest['removed'])|{'cyberNinjaGloves'});shutil.rmtree(R/'cyberninjagloves',ignore_errors=True)
animated=json.loads((R/'animated-textures.json').read_text())
with ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip') as pack:
 for k,label in [('springSparklesAura','Aura de brilho'),('winter2024ShardsAura','Aura de gelo')]:
  source='game/cosmetics/auras/'+k;m=json.loads(pack.read(source+'.geo.json'));g=m['minecraft:geometry'][0];root=R/k.lower();root.mkdir(exist_ok=True)
  lo=min(c['origin'][1] for b in g['bones'] for c in b.get('cubes',[]));hi=max(c['origin'][1]+c['size'][1] for b in g['bones'] for c in b.get('cubes',[]));factor=min(1,34/max(1,hi-lo));mid=(lo+hi)/2
  for b in g['bones']:
   if b['name'].startswith('anchor_'):continue
   def point(v):return [round(v[0]*factor,6),round((v[1]-mid)*factor+28,6),round(v[2]*factor,6)]
   if 'pivot' in b:b['pivot']=point(b['pivot'])
   for c in b.get('cubes',[]):
    c['origin']=point(c['origin']);c['size']=[round(v*factor,6) for v in c['size']]
    if 'pivot' in c:c['pivot']=point(c['pivot'])
  save(root/'model.json',m);image=Image.open(io.BytesIO(pack.read(source+'.webp')));frames=[]
  for i in range(getattr(image,'n_frames',1)):
   image.seek(i);name='texture.png' if i==0 else f'texture_{i}.png';image.convert('RGBA').save(root/name);frames.append({'file':name,'duration':max(20,int(image.info.get('duration',100)))})
  if len(frames)>1:animated[k]=frames
  anim=json.loads(pack.read(source+'.animation.json'))
  # Position channels are relative translations and must use the same geometry scale.
  def scale_pos(value):
   if isinstance(value,list):return [round(v*factor,6) if isinstance(v,(int,float)) else v for v in value]
   if isinstance(value,dict):return {a:scale_pos(v) for a,v in value.items()}
   return value
  for a in anim.get('animations',{}).values():
   for b in a.get('bones',{}).values():
    if 'position' in b:b['position']=scale_pos(b['position'])
  save(root/'animation.json',anim);manifest['items']=[r for r in manifest['items'] if r['id']!=k];manifest['items'].append({'id':k,'name':label,'category':'auras','cubes':sum(len(b.get('cubes',[])) for b in g['bones']),'bones':len(g['bones']),'animation':True,'source_sha256':hashlib.sha256(pack.read(source+'.geo.json')).hexdigest(),'root_renames':{}});changed.append(k)
save(R/'animated-textures.json',animated);save(B/'cosmetics225-manifest.json',manifest)
p=B/'modules-src/com/duckswords/cosmetic/CosmeticCatalog222.java';s=p.read_text();s=re.sub(r'Map.entry\("cyberNinjaGloves","[^"]*"\),?\s*','',s)
start=s.index('public static final List<String> IDS=');end=s.index(';',start);ids=[r['id'] for r in manifest['items']];s=s[:start]+'public static final List<String> IDS=List.of('+','.join(json.dumps(v) for v in ids)+')'+s[end:]
start=s.index('private static final Set<String> REMOVED=');end=s.index(';',start);s=s[:start]+'private static final Set<String> REMOVED=Set.of('+','.join(json.dumps(v) for v in manifest['removed'])+')'+s[end:]
for k,label in [('springSparklesAura','Aura de brilho'),('winter2024ShardsAura','Aura de gelo')]:
 if 'Map.entry("'+k+'"' not in s:s=s.replace('LABELS=Map.ofEntries(','LABELS=Map.ofEntries(Map.entry('+json.dumps(k)+','+json.dumps(label,ensure_ascii=False)+'),')
p.write_text(s)
for k in changed:
 root=R/k.lower()
 if not (root/'texture.png').exists():(root/'texture.png').write_bytes(base.read('assets/duckswords/cosmetics/'+k.lower()+'/texture.png'))
 render(k,'auras' if k.endswith('Aura') else 'face')
print('Prepared',len(changed),'requested cosmetic adjustments; original aura assets imported; cyber fists removed')

import runpy
runpy.run_path(str(B/'prepare_texture226.py'),run_name='__main__')
