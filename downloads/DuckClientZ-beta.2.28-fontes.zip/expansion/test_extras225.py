from pathlib import Path
from zipfile import ZipFile
import json,subprocess,os,numpy as np
B=Path(__file__).parent;out=B/'extras225-runtime';out.mkdir(exist_ok=True)
test=r'''import com.duckswords.visuals.LegacyProjection225;public class Projection225Tests {static int n;static void check(boolean value){if(!value)throw new AssertionError("projection "+n);n++;}public static void main(String[] a){float[] p=new float[3];for(int[] size:new int[][]{{1920,1080},{854,480},{320,180},{2560,1440}})for(int yaw=-180;yaw<=180;yaw+=15)for(int pitch=-75;pitch<=75;pitch+=15)for(int fov=30;fov<=120;fov+=15){double y=Math.toRadians(yaw),t=Math.toRadians(pitch),x=-Math.sin(y)*Math.cos(t)*8,dy=-Math.sin(t)*8,z=Math.cos(y)*Math.cos(t)*8;check(LegacyProjection225.project(x,dy,z,yaw,pitch,fov,size[0],size[1],0,.42,p));check(Math.abs(p[0]-size[0]*.5)<.001&&Math.abs(p[1]-size[1]*.5)<.001);check(!LegacyProjection225.project(-x,-dy,-z,yaw,pitch,fov,size[0],size[1],0,.42,p));}check(LegacyProjection225.project(-1,0,8,0,0,90,1920,1080,0,.42,p));float regular=p[0];check(LegacyProjection225.project(-1,0,8,0,0,90,1920,1080,4./3,.42,p));check(p[0]>regular);check(!LegacyProjection225.project(Double.NaN,0,0,0,0,90,1920,1080,0,.42,p));System.out.println("PASS "+n+" Legacy overlay projections: camera center across yaw/pitch/FOV, four sizes/F11, behind-camera rejection, stretched world aspect");}}'''
(out/'Projection225Tests.java').write_text(test)
import shutil
shutil.rmtree(out/'com',ignore_errors=True)
for v,e in json.loads((B/'build-report.json').read_text()).items():
 cp=os.pathsep.join([str(out),e['jar']]);subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(out/'Projection225Tests.java')],check=True);subprocess.run(['java','-Xverify:all','-cp',cp,'Projection225Tests'],check=True)

expected={'custommask':(0,-1,0),'summer2024japanesefoxmask':(0,0,1),'fall2025owlmask':(0,1,0),'demon2024crowmask':(0,0,-1)}
for v,e in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(e['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{v}-1.5.28-beta.2.24.jar') as old:
  for key,delta in expected.items():
   path=f'assets/duckswords/cosmetics/{key}/model.json';a=json.loads(z.read(path))['minecraft:geometry'][0]['bones'];b=json.loads(old.read(path))['minecraft:geometry'][0]['bones']
   for first,previous in zip(a,b):
    for cube,prior in zip(first.get('cubes',[]),previous.get('cubes',[])):assert np.allclose(np.array(cube['origin'])-prior['origin'],delta),(key,cube)
  for key in ['spring2025boxinggloves','springclaws']:
   path=f'assets/duckswords/cosmetics/{key}/model.json';a=json.loads(z.read(path))['minecraft:geometry'][0]['bones'];b=json.loads(old.read(path))['minecraft:geometry'][0]['bones']
   for first,previous in zip(a,b):
    for cube,prior in zip(first.get('cubes',[]),previous.get('cubes',[])):assert np.allclose(cube['size'],np.array(prior['size'])*1.2)
  g=json.loads(z.read('assets/duckswords/cosmetics/spacemask/model.json'))['minecraft:geometry'][0]['bones'][1]['cubes'];assert all(abs(x)>0 for x in g[1]['uv']['west']['uv_size']) and all(abs(x)>0 for x in g[3]['uv']['east']['uv_size'])
  for key in ['springSparklesAura','winter2024ShardsAura']:
   g=json.loads(z.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json'))['minecraft:geometry'][0];assert g['bones'][0]['name']=='anchor_body';assert sum(len(b.get('cubes',[])) for b in g['bones'])>3;assert 'assets/duckswords/cosmetics/'+key.lower()+'/animation.json' in z.namelist()
 print('PASS extra225 assets',v,'exact pixel offsets; +20% fist size; ear faces nonzero; two original animated auras')
