from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,urllib.request,subprocess
B=Path(__file__).parent;commit=subprocess.check_output(['git','-C','/workspace/duck-publish218','rev-parse','HEAD'],text=True).strip();manifest=json.loads((B/'release-manifest.json').read_text())
def verify(item):
 name,expected=item;url=f'https://raw.githubusercontent.com/jpnait220-star/chatgpt-astra-repositorio/{commit}/downloads/{name}';request=urllib.request.Request(url,headers={'User-Agent':'DuckClientZ-artifact-verification'});digest=hashlib.sha256();count=0
 with urllib.request.urlopen(request,timeout=60) as stream:
  assert stream.status==200
  while True:
   chunk=stream.read(1024*1024)
   if not chunk:break
   count+=len(chunk);digest.update(chunk)
 assert digest.hexdigest()==expected,name
 return {'file':name,'bytes':count,'sha256':digest.hexdigest(),'url':url}
with ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(verify,manifest.items()))
for result in results:print('PASS HTTP/SHA256:',result['file'],result['bytes'])
with urllib.request.urlopen(urllib.request.Request('https://raw.githubusercontent.com/jpnait220-star/chatgpt-astra-repositorio/asasa/downloads/DuckClientZ-beta.2.27-4-versoes.zip',method='HEAD'),timeout=30) as response:
 assert response.status==200
 print('PASS current branch direct download URL returns HTTP200')
(B/'download-verification.json').write_text(json.dumps({'commit':commit,'verified':results},indent=2)+'\n')
