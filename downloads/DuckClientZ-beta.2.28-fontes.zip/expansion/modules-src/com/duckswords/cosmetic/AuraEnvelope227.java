package com.duckswords.cosmetic;
import net.minecraft.class_4587;
/** Match Money's animated envelope while keeping the original motion, UVs and mesh count. */
public final class AuraEnvelope227 {
 public static void apply(class_4587 matrices,String id){
  float sx,sy,sz,pivotY,centerX,centerZ;
  if(id.equals("springSparklesAura")){sx=2.6f;sy=2.6f;sz=3.25f;pivotY=5.29f;centerX=-.216406f;centerZ=.008924f;}
  else if(id.equals("winter2024ShardsAura")){sx=2.85f;sy=2.6f;sz=3.75f;pivotY=5.96f;centerX=.396808f;centerZ=.095234f;}
  else return;
  matrices.method_46416(0,pivotY/16,0);
  matrices.method_22905(sx,sy,sz);
  matrices.method_46416(-centerX/16,-pivotY/16,-centerZ/16);
 }
}
