package com.duckswords.cosmetic;
import com.duckswords.client.ClientData;import java.util.*;import net.minecraft.class_310;
/** Scoped first-person pass uses the very same baked models and original animated frames. */
public final class Fists225 {
 private static final Set<String> IDS=Set.of("spring2025BoxingGloves","springClaws","springFireFists","springIceFists","bloodFists","beenTakenCorruptedFists","angelGloves","dragonFestivalGloves","knightGloves","voidGloves","gamerRGBFists");
 private static final ThreadLocal<Boolean> SIDE=new ThreadLocal<>();private record ArmMaps(Map<?,?> left,Map<?,?> right){}private static final IdentityHashMap<Map<?,?>,ArmMaps> ARMS=new IdentityHashMap<>();private static List<Cosmetic> previous,filtered=List.of();
 public static boolean mainLeft(){throw new IllegalStateException("native dominant arm");}
 public static boolean begin(boolean left){if(SIDE.get()!=null||class_310.method_1551().field_1724==null||!ClientData.firstPerson()||ClientData.count(ClientData.held(left!=mainLeft()))>0)return false;SIDE.set(left);return true;}
 public static void end(){SIDE.remove();}public static boolean hide(boolean original,int id){return SIDE.get()==null&&com.duckswords.social.CosmeticSharing.localHide(original,id);}
 public static List<Cosmetic> filter(List<Cosmetic> original){if(SIDE.get()==null)return original;if(original!=previous){previous=original;filtered=original.stream().filter(c->IDS.contains(c.id)||c.id.toLowerCase(Locale.ROOT).contains("fists")).toList();}return filtered;}
 public static Map<?,?> parts(Map<?,?> original){Boolean side=SIDE.get();if(side==null)return original;ArmMaps cached=ARMS.get(original);if(cached==null){if(ARMS.size()>128)ARMS.clear();Map<?,?> left=Map.of(),right=Map.of();for(var e:original.entrySet()){String name=((Enum<?>)e.getKey()).name();if(name.equals("LEFT_ARM"))left=Collections.singletonMap(e.getKey(),e.getValue());if(name.equals("RIGHT_ARM"))right=Collections.singletonMap(e.getKey(),e.getValue());}cached=new ArmMaps(left,right);ARMS.put(original,cached);}return side?cached.left:cached.right;}
}
