package com.duckswords.cosmetic;
import java.util.*;
/** Current selectable catalog. Deprecated IDs remain importable only as inert profile data. */
public final class CosmeticCatalog222 {
 private static final Map<String,String> LABELS=Map.ofEntries(Map.entry("winter2024ShardsAura","Aura de gelo"),Map.entry("springSparklesAura","Aura de brilho"),Map.entry("cyberpunkLEDMask","Máscara LED"),
Map.entry("fall2025OwlMask","Máscara de coruja"),
Map.entry("cloudMask","Máscara de nuvem"),
Map.entry("spaceMask","Máscara espacial"),
Map.entry("gamerGamerGlasses","Óculos gamer"),
Map.entry("hellLordMask","Máscara de demônio"),
Map.entry("angelGloves","Punhos angelicais"),
Map.entry("dragonFestivalGloves","Punhos do dragão"),
Map.entry("knightGloves","Punhos de cavaleiro"),
Map.entry("voidGloves","Punhos do vazio"),
Map.entry("gamerRGBFists","Punhos RGB"),
Map.entry("jan2025BlackHoleAura","Aura de buraco negro"),
Map.entry("jan2025SolarSystemAura","Aura do sistema solar"),
Map.entry("flameFragsFireRing","Aura de fogo"),
Map.entry("spring2025RainbowAura","Aura de arco-íris"),
Map.entry("gamerControllerAura","Aura de controles gamer"),
Map.entry("gamerJoystickAura","Aura de joysticks gamer"),
Map.entry("springKatana","Katana nas costas"),
Map.entry("gamerGamerTower","PC gamer"),
Map.entry("donutDragonWings","Asas de dragão"),
Map.entry("gamerGameOverSign","Placa Game Over"),
Map.entry("gamerRGBBoots","Botas RGB gamer"),
Map.entry("gamerGamerHeadsetV2","Headset gamer"),
Map.entry("spring2025FrogHat","Chapéu de sapo"),
Map.entry("winter2024IceCrown","Coroa de gelo"),
Map.entry("summer2024PropellerHat","Chapéu de hélice"),
Map.entry("duckBeePet","Pet abelha"),Map.entry("duckFoxPet","Pet raposa"),Map.entry("duckAxolotlPet","Pet axolote"));
 public static final List<String> IDS=List.of("cyberpunkLEDMask","fall2025OwlMask","cloudMask","spaceMask","gamerGamerGlasses","hellLordMask","angelGloves","dragonFestivalGloves","knightGloves","voidGloves","gamerRGBFists","jan2025BlackHoleAura","jan2025SolarSystemAura","flameFragsFireRing","spring2025RainbowAura","gamerControllerAura","gamerJoystickAura","springKatana","gamerGamerTower","donutDragonWings","gamerGameOverSign","gamerRGBBoots","gamerGamerHeadsetV2","spring2025FrogHat","winter2024IceCrown","summer2024PropellerHat","duckBeePet","duckFoxPet","duckAxolotlPet","springSparklesAura","winter2024ShardsAura");
 private static final Set<String> REMOVED=Set.of("cloudAura","cyberNinjaGloves","cyberpunkOniMask","demon2024DemonKnightHelmet","demon2024DemonScythe","halloween2024FrankensteinMask","hellLordAura","natureGloves","spaceAura","springCowboyHat","springLeatherBackpack","springShield","springTurtleShell","summer2024FishingRod","summer2024GasMask","summer2024Surfboard");
 public static List<String> extend(List<String> original){Set<String> all=new LinkedHashSet<>(original);all.removeAll(REMOVED);all.addAll(IDS);return List.copyOf(all);}
 public static String label(String id){return LABELS.get(id);}
 public static String description(String id){return id.equals("duckBeePet")||id.equals("duckFoxPet")||id.equals("duckAxolotlPet")?"Miniatura com texturas originais do Minecraft":LABELS.containsKey(id)?"Modelo original do pacote enviado; texturas e animações preservadas":null;}
}
