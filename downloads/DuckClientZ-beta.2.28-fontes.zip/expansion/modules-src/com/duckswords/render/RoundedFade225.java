package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.gui.GuiTransforms;
/** Horizontal opacity falloff with cached rounded column limits; no scissor/global state changes. */
public final class RoundedFade225 {
 private static final java.util.Map<Integer,int[]> EDGES=new java.util.HashMap<>();
 private static int[] edges(int r){int[] a=new int[r*2];for(int i=0;i<a.length;i++){double dx=r*2-i-.5;a[i]=(int)Math.round(r*2-Math.sqrt(Math.max(0,r*r*4-dx*dx)));}return a;}
 public static void draw(class_332 c,int x,int y,int w,int h,int r,int color,float strength,float alpha){if(w<=0||h<=0)return;r=Math.max(0,Math.min(r,Math.min(w,h)/2));int[] edge=EDGES.computeIfAbsent(r,RoundedFade225::edges);int width=w*2,height=h*2;float opacity=Math.max(0,Math.min(1,strength*alpha));GuiTransforms.push(c,x,y,.5f);try{for(int col=0;col<width;){int distance=Math.min(col,width-col-1),inset=distance<edge.length?edge[distance]:0,step=distance<edge.length?1:Math.min(8,width-edge.length-col);if(step<1)step=1;float fall=1-(col+step*.5f)/width;int a=Math.round(opacity*fall*fall*255);if(a>0)c.method_25294(col,inset,col+step,height-inset,(color&0xffffff)|(a<<24));col+=step;}}finally{GuiTransforms.pop(c);}}
}
