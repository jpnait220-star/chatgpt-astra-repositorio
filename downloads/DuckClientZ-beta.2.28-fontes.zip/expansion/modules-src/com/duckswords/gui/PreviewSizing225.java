package com.duckswords.gui;
import com.duckswords.cosmetic.*;import com.google.gson.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
/** Precomputed model bounds; recalculate only when the equipped list changes. */
public final class PreviewSizing225 {
 private static final Map<String,Float> HEIGHTS=load();private static List<Cosmetic> previous;private static float top=32;
 private static Map<String,Float> load(){try(InputStream in=PreviewSizing225.class.getResourceAsStream("/assets/duckswords/cosmetics/preview-headroom225.json")){if(in==null)return Map.of();Map<String,Float> out=new HashMap<>();for(var e:JsonParser.parseReader(new InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject().entrySet())out.put(e.getKey(),e.getValue().getAsFloat());return Map.copyOf(out);}catch(IOException|RuntimeException e){return Map.of();}}
 public static int fit(int preferred,int viewHeight){List<Cosmetic> current=ModelCosmetics.equipped();if(current!=previous){float highest=32;for(Cosmetic c:current)highest=Math.max(highest,HEIGHTS.getOrDefault(c.id.toLowerCase(Locale.ROOT),32f));top=highest;previous=current;}float above=Math.max(1,top/16-1);return Math.min(preferred,Math.max(8,(int)Math.floor(viewHeight/(2*above))));}
}
