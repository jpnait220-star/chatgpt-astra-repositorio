package com.duckswords.visuals;
/** Matches the camera basis and FOV; output storage belongs to the caller/main render thread. */
public final class LegacyProjection225 {
 public static boolean project(double dx,double dy,double dz,double yawDegrees,double pitchDegrees,double fov,int width,int height,double ratio,double radius,float[] out){
  double yaw=Math.toRadians(yawDegrees),pitch=Math.toRadians(pitchDegrees),syaw=Math.sin(yaw),cyaw=Math.cos(yaw),spitch=Math.sin(pitch),cpitch=Math.cos(pitch);
  double right=-cyaw*dx-syaw*dz,up=-syaw*spitch*dx+cpitch*dy+cyaw*spitch*dz,depth=-syaw*cpitch*dx-spitch*dy+cyaw*cpitch*dz;
  if(!Double.isFinite(depth)||depth<=.05||width<=0||height<=0)return false;
  double factor=height/(2*Math.tan(Math.toRadians(Math.max(1,Math.min(179,fov)))*.5)),x=width*.5+right*factor/depth,y=height*.5-up*factor/depth;
  if(Double.isFinite(ratio)&&ratio>0)x=width*.5+(x-width*.5)*(width/(double)height)/ratio;
  double size=Math.max(6,Math.min(height,radius*2*factor/depth));if(!Double.isFinite(x)||!Double.isFinite(y)||x+size<0||x-size>width||y+size<0||y-size>height)return false;
  out[0]=(float)x;out[1]=(float)y;out[2]=(float)size;return true;
 }
}
