package com.duckswords.social;
import java.util.*;import java.util.function.Supplier;import java.util.concurrent.*;import net.minecraft.class_310;
/** Bounded skin lookups use Minecraft's own asynchronous downloader/cache. */
public final class CommunityFaces225 {
 private static final ThreadPoolExecutor LOOKUP=new ThreadPoolExecutor(0,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),r->{Thread t=new Thread(r,"Duck-Avatar-Lookup");t.setDaemon(true);return t;},new ThreadPoolExecutor.DiscardPolicy());
 private static final Map<String,Object> SKINS=new LinkedHashMap<>();
 public static Object get(String id,String name){Object value=SKINS.get(id);if(value==null){if(SKINS.size()>=64)SKINS.remove(SKINS.keySet().iterator().next());value=fallback(id);SKINS.put(id,value);if(Community225.enabled())LOOKUP.execute(()->{try{Object profile=resolve(id,name);if(profile!=null)((Executor)(Object)class_310.method_1551()).execute(()->{if(!Community225.enabled()||!SKINS.containsKey(id))return;Object loaded=load(profile,id);if(loaded!=null)SKINS.put(id,loaded);});}catch(RuntimeException ignored){}});}return value instanceof Supplier<?> s?s.get():value;}
 public static Object resolve(String id,String name){throw new IllegalStateException("native complete skin profile");}

 public static void put(String id,Object skin){if(SKINS.containsKey(id))SKINS.put(id,skin);}
 public static Object load(Object profile,String id){throw new IllegalStateException("native asynchronous skin lookup");}
 public static Object fallback(String id){throw new IllegalStateException("native default skin");}
}
