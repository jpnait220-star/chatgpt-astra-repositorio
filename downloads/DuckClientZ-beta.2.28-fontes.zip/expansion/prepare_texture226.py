"""Freeze original vanilla box-net UVs independently from the +20% fist geometry."""
from pathlib import Path
from zipfile import ZipFile
import json,copy
from render_cosmetic_icons223 import render
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics'
def net(u,v,w,h,d):
 # Exact min/max UV rectangles emitted by the native Minecraft Cube constructor.
 # Model-space DOWN is the physical top after the player-model Y inversion.
 return {name:{'uv':xy,'uv_size':size} for name,xy,size in [
  ('north',[u+d,v+d],[w,h]),('south',[u+2*d+w,v+d],[w,h]),
  ('east',[u+d+w,v+d],[d,h]),('west',[u,v+d],[d,h]),
  ('down',[u+d,v],[w,d]),('up',[u+d+w,v],[w,d])]}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.24.jar') as base:
 for key in ['spring2025BoxingGloves','springClaws']:
  root=R/key.lower();p=root/'model.json';current=json.loads(p.read_text());original=json.loads(base.read(f'assets/duckswords/cosmetics/{key.lower()}/model.json'))
  for bone,old in zip(current['minecraft:geometry'][0]['bones'],original['minecraft:geometry'][0]['bones']):
   assert bone['name']==old['name']
   for cube,prior in zip(bone.get('cubes',[]),old.get('cubes',[])):
    if isinstance(prior.get('uv'),list):cube['uv']=net(*prior['uv'],*prior['size'])
  p.write_text(json.dumps(current,separators=(',',':'))+'\n');render(key,'arm')
root=R/'summer2024propellerhat';p=root/'model.json';current=json.loads(p.read_text());cap=current['minecraft:geometry'][0]['bones'][0]['cubes'][0]
cap['uv']['down']=copy.deepcopy(cap['uv']['up'])
p.write_text(json.dumps(current,separators=(',',':'))+'\n');render('summer2024PropellerHat','hats')
print('Prepared226: boxing/claw UV nets retain original texture pixels at unchanged enlarged size; physical cap top now uses its opaque original top region')
