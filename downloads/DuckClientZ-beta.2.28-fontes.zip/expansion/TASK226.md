# beta.2.26

User reports: the new sparkles/ice auras sit at the feet; make the chat icon button smaller; remove small gaps joining the two top accent strokes on Features. User also reauthorized deployment of Duck Connect, then confirmed Vercel login.

Cause of aura placement: fitting only the static mesh ignored the source idle animation's downward translation (~18/19 model pixels). Its visible centroid was around6px above the feet despite static0..32 bounds. Raise both models12pixels while retaining every animation/texture byte. Test animated visible bounds using the actual version-specific baker and idle sampler over the complete cycle.

Chat button:28x26->20x18; bubble artwork and click rectangle resized together. Count moved closer and kept readable.

Top accent: the real DuckTheme.gradient insets its straight section by1pixel on each side and leaves its end rectangles empty at height2. Compensate those insets for the arc-to-straight joins. Tests must use the actual extracted gradient method; the prior full-rectangle mock hid the gap.

All four builds and targeted technical checks passed. Packaging/download publication follows. No Minecraft/GPU/FPS execution.

Further user reports: boxing gloves/claws have detached texture pixels but their enlarged size is correct; colored cap top still has missing pixels. Cause: vanilla box-net UV layouts use mesh dimensions, so scaling those mesh dimensions also moved UV coordinates into transparent atlas regions. Freeze original224 native UV rectangles per face while preserving every225 enlarged coordinate, pivot, size, rotation and inflate. For the cap, model-space DOWN is its physical top after Y inversion; its old atlas rectangle was fully transparent. Point that one face at the original opaque cap-top region and preserve legitimate transparent propeller tips. Compare every native Cube/Polygon/Vertex UV to224, and verify actual cap-top opacity.

Deployment completed: https://duck-connect.vercel.app, deployment dpl_47LvkmwnAmHPyWz3p2QF9oy1iLsi. Public unauthenticated health, legacy profile lookup, presence/session reuse, chat validation and missing-session rejection passed. No public chat message was posted by tests. Site npm test:7passed. Vercel credentials and .env.local are excluded from every deliverable.

Final validation: native MC/Fabric/API references and Mixin APPLY; all42cosmetic models bake/UV/animation;1920 actual baker/idle samples across the two new auras and four versions; native Cube/Polygon/Vertex comparisons for every original boxing/claw UV vertex and opaque physical cap top; UI uses the actual native gradient and asserts continuous joins,20x18chat drawing and click region. Exact file comparison with225 confines changes to five cosmetic model/icon resources, two menu helpers and metadata; fist size/geometry, profiles, textures and animations remain unchanged. No Minecraft/GPU/Pojav/FPS execution.

Published artifact/service-source commit 6c412193b8ca10191c7efbe7f07be9a33754520c. Ten public downloads HTTP200 and SHA256 matched; combined ZIP branch URL and direct GitHub alias verified. Git checkout clean. Production service already ready and publicly checked.
