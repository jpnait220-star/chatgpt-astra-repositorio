from pathlib import Path
from zipfile import ZipFile
import json

B = Path(__file__).parent
report = json.loads((B / 'build-report.json').read_text())
for game, entry in report.items():
    before = B / 'dist' / f'DuckClientZ-{game}-1.5.28-beta.2.27.jar'
    with ZipFile(before) as old, ZipFile(entry['jar']) as new:
        assert set(old.namelist()) == set(new.namelist()), game
        changed = {name for name in old.namelist() if old.read(name) != new.read(name)}
        expected = {'fabric.mod.json'}
        if game == '1.21.11':
            expected.add('com/duckswords/mixin/MixinGuiBlit220.class')
        assert changed == expected, (game, changed)
        metadata = json.loads(new.read('fabric.mod.json'))
        assert metadata['version'] == '1.5.28-beta.2.28', metadata['version']
        assert new.testzip() is None
    print('PASS exact scope:', game, sorted(changed), '; all other classes/resources byte-identical to2.27')
