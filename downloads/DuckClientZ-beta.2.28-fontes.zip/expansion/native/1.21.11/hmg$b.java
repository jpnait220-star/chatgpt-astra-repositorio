/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  amo
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  hpa
 *  ilo
 */
import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;

public static final class hmg.b
extends Record {
    private final boolean e;
    private final amo f;
    private final RenderPipeline g;
    public static final hmg.b a = new hmg.b(true, ilo.d, hpa.ai);
    public static final hmg.b b = new hmg.b(true, ilo.e, hpa.ai);
    public static final hmg.b c = new hmg.b(false, ilo.f, hpa.ah);
    public static final hmg.b d = new hmg.b(true, ilo.f, hpa.ai);

    public hmg.b(boolean $$0, amo $$1, RenderPipeline $$2) {
        this.e = $$0;
        this.f = $$1;
        this.g = $$2;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{hmg.b.class, "translucent;textureAtlasLocation;pipeline", "e", "f", "g"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{hmg.b.class, "translucent;textureAtlasLocation;pipeline", "e", "f", "g"}, this);
    }

    @Override
    public final boolean equals(Object $$0) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{hmg.b.class, "translucent;textureAtlasLocation;pipeline", "e", "f", "g"}, this, $$0);
    }

    public boolean a() {
        return this.e;
    }

    public amo b() {
        return this.f;
    }

    public RenderPipeline c() {
        return this.g;
    }
}
