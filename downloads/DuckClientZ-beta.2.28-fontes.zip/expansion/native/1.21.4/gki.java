/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  gga
 *  gjv
 *  het
 */
public abstract class gki
extends gjv {
    protected het E;

    protected gki(gga $$0, double $$1, double $$2, double $$3) {
        super($$0, $$1, $$2, $$3);
    }

    protected gki(gga $$0, double $$1, double $$2, double $$3, double $$4, double $$5, double $$6) {
        super($$0, $$1, $$2, $$3, $$4, $$5, $$6);
    }

    protected void a(het $$0) {
        this.E = $$0;
    }

    protected float c() {
        return this.E.c();
    }

    protected float d() {
        return this.E.d();
    }

    protected float e() {
        return this.E.g();
    }

    protected float f() {
        return this.E.h();
    }

    public void a(gkd $$0) {
        this.a($$0.a(this.r));
    }

    public void b(gkd $$0) {
        if (!this.o) {
            this.a($$0.a(this.s, this.t));
        }
    }
}
