/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  akv
 *  gmj
 *  hes
 *  javax.annotation.Nullable
 */
import java.lang.invoke.MethodHandle;
import java.lang.runtime.ObjectMethods;
import javax.annotation.Nullable;

public final class gjm
extends Record {
    private final String f;
    @Nullable
    private final gmj g;
    public static final gjm a = new gjm("TERRAIN_SHEET", gmj.B((akv)hes.d));
    public static final gjm b = new gjm("PARTICLE_SHEET_OPAQUE", gmj.A((akv)hes.e));
    public static final gjm c = new gjm("PARTICLE_SHEET_TRANSLUCENT", gmj.B((akv)hes.e));
    public static final gjm d = new gjm("CUSTOM", null);
    public static final gjm e = new gjm("NO_RENDER", null);

    public gjm(String $$0, @Nullable gmj $$1) {
        this.f = $$0;
        this.g = $$1;
    }

    @Override
    public final String toString() {
        return ObjectMethods.bootstrap("toString", new MethodHandle[]{gjm.class, "name;renderType", "f", "g"}, this);
    }

    @Override
    public final int hashCode() {
        return (int)ObjectMethods.bootstrap("hashCode", new MethodHandle[]{gjm.class, "name;renderType", "f", "g"}, this);
    }

    @Override
    public final boolean equals(Object $$0) {
        return (boolean)ObjectMethods.bootstrap("equals", new MethodHandle[]{gjm.class, "name;renderType", "f", "g"}, this, $$0);
    }

    public String a() {
        return this.f;
    }

    @Nullable
    public gmj b() {
        return this.g;
    }
}
