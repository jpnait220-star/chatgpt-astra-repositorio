# beta.2.24

Requested: rounded configuration button, main menu, header tabs/search, settings controls/panel, cosmetic menu/cards and wardrobe. Activation/deactivation buttons unchanged. Move the scrollbars right within the gutter. Remove Oni/Frankenstein masks, space/cloud/infernal auras, scythe, surfboard and cowboy hat. Repair reaper pet and disconnected rainbow/fire rings. Colorful propeller hat +1 model Y pixel; owl mask -3 Y pixels; Game Over +1 Z pixel; back katana blade downward on the same diagonal; repair intersecting knight face plate.

Implementation: shared DuckScreen.card/button native draw calls redirected to cached rounded panels; toggle methods unchanged. Top accents inset inside curved corners. Settings scrollbar x is logical content-right+2, preserving scaled width/clamp/drag. Feature list track/thumb +1 logical pixel. Wardrobe frame/floor rounded. Baseline profile code schemas a-z/0/1 and dictionaries frozen; removed cosmetic IDs remain inert if imported from existing profiles. No profile reset/migration.

Geometry corrections are deterministic against the published beta.2.23. Atlas texture pixels preserved. Katana flipped about its assembled center. One horizontal animated rainbow ring; fire halves share a single pivot, with detached second ring removed. Reaper inflated face overlay removed; complete original hood atlas used. Knight diagonal solid face box replaced by thin centered plate in front of the shell.

Additional requests: round ProfileScreen and copy dialog; clown/Japanese fox masks forward one model pixel. AutoClicker is rerouted to exact native single-click actions. The old held-mining HEAD cancellation suppressed vanilla release cleanup; replace with ModifyVariable forcing only the held argument false. Drain physical attack key state/queue, preserve start/progress/instant-break guards. Replace serial+poll double-edge handling with one press latch and virtual key event state. Test actual adapter bodies and real Mixin application.

Latest additions: fox/axolotl on opposite shoulders (X-6/+6, transformed geometry base Y24.1, original atlas, no root vertical bounce); China Hat stars disabled in flag accessor even for old/remote profiles and their three settings removed after registration.

Final scope additions: Ghost top/bottom cap UV and lantern grip placement; fire/blood/ice/corrupted original WebP frames 3/3/3/8 and durations from game.zip, no invented animation. Boxing/claws slim-model fit through exact native PlayerModel field accessor. Animal shoes original model icon. Aura attachment ignores ModelPart attack/use rotation while following its pivot.

Build and validation complete for all four versions. Fifteen final report groups passed: native API/Mixin targets, real Mixin APPLY (including action invokers, held argument and slim accessor), all assets/frozen profiles, 42 model load/bake/frame loops, 1794 runtime checks/version, 9678 UI checks/version plus actual call-route/toggle bytecode assertions, 30 AutoClicker adapter/state checks/version, 2563 aura/slim pose checks/version, artifact CRC/hash/fixture exclusions, Cleaner/HUD/default migration/profile codecs/HTTP worker/particle regressions. No test errors remain. Publication pending; package below includes this reviewable implementation and reports. No in-game, GPU, Pojav or FPS test available.

## Publication complete

Commit `0cf2c9eb2fe6cc5844fb1650489fc249d219ca6e` on `jpnait220-star/chatgpt-astra-repositorio:asasa`. Nine new 2.24 files published; all HTTP200 and SHA256 verified. Branch download URL also HTTP200. Older release files preserved.

Download: https://github.com/jpnait220-star/chatgpt-astra-repositorio/raw/refs/heads/asasa/downloads/DuckClientZ-beta.2.24-4-versoes.zip

Packaged TASK224 records the pre-publication checkpoint; the shipped implementation, release notes and fifteen report groups are final. No in-game/GPU/Pojav/FPS validation.
