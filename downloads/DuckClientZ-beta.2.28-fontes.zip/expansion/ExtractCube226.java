import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Run the actual game Cube/Polygon/Vertex UV construction; GPU drawing and normals are irrelevant here. */
public class ExtractCube226 extends CosmeticCompatPatch {
 static void getter(ClassNode c,String name,String field,String desc,String ret){MethodNode m=new MethodNode(ACC_PUBLIC,name,"()"+desc,null,null);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new FieldInsnNode(GETFIELD,c.name,field,desc));m.instructions.add(new InsnNode(ret.equals("float")?FRETURN:ARETURN));c.methods.add(m);}
 public static void main(String[] a)throws Exception{out=Path.of(a[1]);String owner="";for(String line:Files.readAllLines(Path.of(a[3]))){String[] p=line.split("\t");if(p[0].equals("c")){owner=p[1];classes.put(p[1],p[2]);}else if(p.length==5&&(p[1].equals("m")||p[1].equals("f")))(p[1].equals("m")?methods:fields).put(owner+" "+p[3]+p[2],p[4]);}var uv=com.google.gson.JsonParser.parseString(Files.readString(Path.of(a[4]))).getAsJsonObject();
 try(ZipFile game=new ZipFile(a[2])){for(String type:List.of("class_628","class_593","class_618")){ClassNode c=mapped(game,"net/minecraft/class_630$"+type);
 if(type.equals("class_628")){c.methods.removeIf(m->!m.name.equals("<init>"));c.interfaces.add("com/duckswords/mixin/ModelPartCuboidAccessor1211");String desc="[Lnet/minecraft/class_630$class_593;";getter(c,"duckswords$getSides",c.fields.stream().filter(f->f.desc.equals(desc)).findFirst().orElseThrow().name,desc,"array");}
 if(type.equals("class_593")){c.interfaces.add("com/duckswords/mixin/ModelPartQuadAccessor1211");String desc="[Lnet/minecraft/class_630$class_618;";getter(c,"duckswords$getVertices",c.fields.stream().filter(f->f.desc.equals(desc)).findFirst().orElseThrow().name,desc,"array");
  for(MethodNode m:c.methods){if(m.desc.equals("(Lnet/minecraft/class_2350;)Lnet/minecraft/class_2350;")){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new InsnNode(ARETURN));}
   for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals("net/minecraft/class_2350")&&(call.desc.equals("()Lorg/joml/Vector3f;")||call.desc.equals("()Lorg/joml/Vector3fc;"))){call.setOpcode(INVOKESTATIC);call.owner="Uv226Tests";call.name=call.desc.contains("Vector3fc")?"normalC":"normalF";call.desc="(Lnet/minecraft/class_2350;"+call.desc.substring(1);call.itf=false;}}
 }
 if(type.equals("class_618")){c.interfaces.add("com/duckswords/mixin/ModelPartVertexAccessor1211");getter(c,"duckswords$getU",uv.getAsJsonArray("u").get(1).getAsString(),"F","float");getter(c,"duckswords$getV",uv.getAsJsonArray("v").get(1).getAsString(),"F","float");}
 ClassNode accessible=new ClassNode();c.accept(new net.fabricmc.loader.impl.transformer.PackageAccessFixer(ASM9,accessible));save(accessible);
 }}}
}
