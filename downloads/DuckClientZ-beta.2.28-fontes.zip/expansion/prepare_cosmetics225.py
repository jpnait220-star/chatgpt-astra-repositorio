"""225: one catalog removal and a consistent reaper atlas/neutral pose/grip."""
from pathlib import Path
from zipfile import ZipFile
import json,re,shutil
import numpy as np
from render_cosmetic_icons223 import rotation,render
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
def boxuv(u,v,w,h,d):return {f:{'uv':a,'uv_size':s} for f,a,s in [('north',[u+d,v+d],[w,h]),('south',[u+2*d+w,v+d],[w,h]),('east',[u+d+w,v+d],[d,h]),('west',[u,v+d],[d,h]),('up',[u+d,v],[w,d]),('down',[u+d+w,v+d],[w,-d])]}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.24.jar') as old:
 m=json.loads(old.read('assets/duckswords/cosmetics/halloween2024reaperpet/model.json'));g=m['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']}
 head=bones['head']['cubes'][0];head['uv']=boxuv(0,0,16,16,8);head['uv']['down']={'uv':[8,8],'uv_size':[16,-8]}
 bones['body']['cubes'][0]['uv']=boxuv(20,24,8,12,4)
 for name in ['leftArm','rightArm','leftLeg','rightLeg']:
  bones[name]['rotation']=[0,0,0]
  bones[name]['cubes'][0]['uv']=boxuv(20,24,4,12,4)
 weapon=bones['bone'];weapon['rotation']=[90,-45,15];blade,rod=weapon['cubes'];rod.pop('inflate',None)
 rod['uv']={f:{'uv':[20,56],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}
 blade['uv']={f:{'uv':[56,48],'uv_size':[24,16]} for f in ['east','west']}
 arm=bones['leftArm']['cubes'][0];hand=np.array([arm['origin'][0]+arm['size'][0]/2,arm['origin'][1]+arm['size'][0]/2,arm['origin'][2]+arm['size'][2]/2])
 grip=np.array([rod['origin'][0]+rod['size'][0]/2,rod['origin'][1]+rod['size'][1]/2,rod['origin'][2]+rod['size'][2],1]);delta=hand-(rotation(weapon['rotation'],weapon['pivot'])@grip)[:3]
 weapon['pivot']=(np.array(weapon['pivot'])+delta).tolist()
 for c in weapon['cubes']:
  c['origin']=(np.array(c['origin'])+delta).tolist()
  if 'pivot' in c:c['pivot']=(np.array(c['pivot'])+delta).tolist()
 # Bring the miniature beside the shoulder/body rather than above the player's head.
 for b in g['bones']:
  if b['name']=='anchor_body':continue
  if 'pivot' in b:b['pivot']=[b['pivot'][0]+2,b['pivot'][1]-3,b['pivot'][2]]
  for c in b.get('cubes',[]):
   c['origin']=[c['origin'][0]+2,c['origin'][1]-3,c['origin'][2]]
   if 'pivot' in c:c['pivot']=[c['pivot'][0]+2,c['pivot'][1]-3,c['pivot'][2]]
 save(R/'halloween2024reaperpet/model.json',m)
key='demon2024DemonKnightHelmet';shutil.rmtree(R/key.lower(),ignore_errors=True)
p=B/'modules-src/com/duckswords/cosmetic/CosmeticCatalog222.java';s=p.read_text();s=re.sub(r'Map\.entry\("'+key+r'","[^"]*"\),?\s*','',s);start=s.index('public static final List<String> IDS=');end=s.index(';',start);s=s[:start]+s[start:end].replace('"'+key+'",','').replace(',"'+key+'"','')+s[end:];start=s.index('private static final Set<String> REMOVED=Set.of(');end=s.index(');',start);removed=set(re.findall(r'"([^"]+)"',s[start:end]))|{key};s=s[:start]+'private static final Set<String> REMOVED=Set.of('+','.join(json.dumps(k) for k in sorted(removed))+s[end:];p.write_text(s)
m=json.loads((B/'cosmetics224-manifest.json').read_text());m['items']=[r for r in m['items'] if r['id']!=key];m['removed']=sorted(set(m['removed'])|{key});m['revision']=225;m['adjustments'].pop(key,None);m['adjustments']['halloween2024ReaperPet']='full-size original atlas regions for hood/robe/limbs; neutral limbs; scythe grip in hand; 2px inward and 3px down';save(B/'cosmetics225-manifest.json',m)
render('halloween2024ReaperPet','face')
# Headroom uses actual transformed head accessories, not the player's vanilla bounding box.
heights={}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.24.jar') as old:
 for name in old.namelist():
  if not name.startswith('assets/duckswords/cosmetics/') or not name.endswith('/model.json'):continue
  id=name.split('/')[3]
  if id in {k.lower() for k in m['removed']}:continue
  p=B/'resources'/name;g=json.loads(p.read_bytes() if p.exists() else old.read(name))['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']}
  if not any('head' in b['name'].lower() for b in g['bones'] if not b.get('parent')):continue
  cache={}
  def transform(b):
   if b['name'] not in cache:
    local=rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));cache[b['name']]=transform(bones[b['parent']])@local if b.get('parent') in bones else local
   return cache[b['name']]
  maximum=32.
  for b in g['bones']:
   for c in b.get('cubes',[]):
    lo=np.array(c['origin'])-c.get('inflate',0);hi=np.array(c['origin'])+c['size']+c.get('inflate',0);t=transform(b)@rotation(c.get('rotation',[0,0,0]),c.get('pivot',((lo+hi)/2).tolist()))
    maximum=max(maximum,*[(t@np.array([x,y,z,1]))[1] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
  heights[id]=float(maximum+2)
save(R/'preview-headroom225.json',heights)
print('Prepared 225: knight removed; reaper atlas/pose/grip; preview heights for',len(heights),'head accessories')
