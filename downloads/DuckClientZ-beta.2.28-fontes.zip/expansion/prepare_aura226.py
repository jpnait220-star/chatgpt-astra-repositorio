"""Raise the two new auras relative to their published 225 pose, retaining every animation byte."""
from pathlib import Path
from zipfile import ZipFile
import json
from render_cosmetic_icons223 import render
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics'
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.25.jar') as z:
 for key in ['springSparklesAura','winter2024ShardsAura']:
  path=f'assets/duckswords/cosmetics/{key.lower()}/model.json';model=json.loads(z.read(path))
  for bone in model['minecraft:geometry'][0]['bones']:
   if bone['name'].startswith('anchor_'):continue
   if 'pivot' in bone:bone['pivot'][1]+=12
   for cube in bone.get('cubes',[]):
    cube['origin'][1]+=12
    if 'pivot' in cube:cube['pivot'][1]+=12
  (R/key.lower()/'model.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
  assert (R/key.lower()/'animation.json').read_bytes()==z.read(f'assets/duckswords/cosmetics/{key.lower()}/animation.json')
  render(key,'auras')
print('Prepared 226: both new auras raised 12 model pixels; original idle/texture animations unchanged')
