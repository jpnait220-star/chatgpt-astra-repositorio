# beta.2.27

User says sparkle/ice auras are now centered but too small and concentrated at the torso; explicitly requests an aura like Money.

Reference measured with the real baker/idle sampler: Money animated envelope28.38px wide,28.41px deep,50.32px tall. Current sparkle/ice are only~10px wide/~8px deep/~19px tall. New constant matrix envelope expands both to Money-like dimensions around the player, retaining body-centered height. No extra particles, new motion, texture changes or per-frame mesh/JSON work. Original animations and every resource remain byte-identical. Only two exact IDs receive the transform. Other cosmetics, profiles and settings preserved.

All four builds, native API/Mixin checks, full-loop comparison to Money, exact change-scope verification and anti-attack-pose checks passed. Packaging/download publication follows. No Minecraft/GPU/FPS execution.

Measured production attachment + real native idle sampler,240 samples/effect/version: Money28.38x50.32x28.41px; sparkle28.30x49.81x28.36px; ice28.11x50.16x28.20px. Both within5% on every axis, centered around the player. All original resources/animations/configs are byte-identical to226; only the aura attachment, new envelope helper and release metadata changed. No extra geometry or particles; no per-frame file work or mesh rebuilding. Other seven aura attachments, glove/claw slim fit and cosmetics retain their behavior. No Minecraft/GPU/FPS execution.
