from pathlib import Path
from zipfile import ZipFile
import json
B=Path(__file__).parent
added={'com/duckswords/cosmetic/AuraEnvelope227.class'}
allowed=added|{'fabric.mod.json','com/duckswords/cosmetic/AuraAnchor224.class'}
for v,e in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(e['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{v}-1.5.28-beta.2.26.jar') as old:
  assert set(z.namelist())==set(old.namelist())|added
  changed={n for n in old.namelist() if z.read(n)!=old.read(n)};assert changed<=allowed,changed-allowed
  assert json.loads(z.read('fabric.mod.json'))['version']=='1.5.28-beta.2.27'
 print('PASS227 exact scope:',v,'only native aura envelope/attachment and release metadata; all meshes, textures, original animations, profiles, input and other features byte-identical to226')
