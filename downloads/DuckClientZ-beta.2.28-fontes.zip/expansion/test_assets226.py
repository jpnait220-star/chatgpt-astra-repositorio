from pathlib import Path
from zipfile import ZipFile
import json,numpy as np
B=Path(__file__).parent
allowed={'fabric.mod.json','com/duckswords/render/MenuPanels223.class','com/duckswords/gui/CommunityMenu225.class'}
for key in ['springsparklesaura','winter2024shardsaura','spring2025boxinggloves','springclaws','summer2024propellerhat']:
 for name in ['model.json','icon.png']:allowed.add('assets/duckswords/cosmetics/'+key+'/'+name)
for v,e in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(e['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{v}-1.5.28-beta.2.25.jar') as old:
  assert set(z.namelist())==set(old.namelist()),'Unexpected new/removed files'
  changed={name for name in z.namelist() if z.read(name)!=old.read(name)};assert changed<=allowed,changed-allowed
  for key in ['springsparklesaura','winter2024shardsaura']:
   path=f'assets/duckswords/cosmetics/{key}/model.json';now=json.loads(z.read(path))['minecraft:geometry'][0]['bones'];before=json.loads(old.read(path))['minecraft:geometry'][0]['bones']
   for n,b in zip(now,before):
    if n['name'].startswith('anchor_'):assert n==b;continue
    if 'pivot' in n:assert np.allclose(np.array(n['pivot'])-b['pivot'],[0,12,0])
    for cube,previous in zip(n.get('cubes',[]),b.get('cubes',[])):
     assert np.allclose(np.array(cube['origin'])-previous['origin'],[0,12,0]);assert cube['size']==previous['size'];assert cube['uv']==previous['uv']
     if 'pivot' in cube:assert np.allclose(np.array(cube['pivot'])-previous['pivot'],[0,12,0])
  for key in ['spring2025boxinggloves','springclaws']:
   path=f'assets/duckswords/cosmetics/{key}/model.json';now=json.loads(z.read(path))['minecraft:geometry'][0]['bones'];before=json.loads(old.read(path))['minecraft:geometry'][0]['bones']
   for n,b in zip(now,before):
    assert {k:v for k,v in n.items() if k!='cubes'}=={k:v for k,v in b.items() if k!='cubes'}
    for cube,previous in zip(n.get('cubes',[]),b.get('cubes',[])):
     assert {k:v for k,v in cube.items() if k!='uv'}=={k:v for k,v in previous.items() if k!='uv'}
  path='assets/duckswords/cosmetics/summer2024propellerhat/model.json';cap=json.loads(z.read(path))['minecraft:geometry'][0]['bones'][0]['cubes'][0];assert cap['uv']['down']==cap['uv']['up']
  assert json.loads(z.read('fabric.mod.json'))['version']=='1.5.28-beta.2.26'
 print('PASS exact226 scope:',v,'two auras, fist UVs, cap top, two menu helpers and version metadata only; fist geometry/size unchanged; all animations, textures, profiles, input and other features byte-identical to225')
