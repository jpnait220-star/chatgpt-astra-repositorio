from pathlib import Path
from zipfile import ZipFile
import json,numpy as np
from render_cosmetic_icons223 import rotation
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics';manifest=json.loads((B/'cosmetics225-manifest.json').read_text())
def save(p,v):p.write_text(json.dumps(v,separators=(',',':'))+'\n')
# Headroom uses actual transformed head accessories, not the player's vanilla bounding box.
heights={}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.24.jar') as old:
 for name in old.namelist():
  if not name.startswith('assets/duckswords/cosmetics/') or not name.endswith('/model.json'):continue
  id=name.split('/')[3]
  if id in {k.lower() for k in manifest['removed']}:continue
  p=B/'resources'/name;g=json.loads(p.read_bytes() if p.exists() else old.read(name))['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']}
  if not any('head' in b['name'].lower() for b in g['bones'] if not b.get('parent')):continue
  cache={}
  def transform(b):
   if b['name'] not in cache:
    local=rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));cache[b['name']]=transform(bones[b['parent']])@local if b.get('parent') in bones else local
   return cache[b['name']]
  maximum=32.
  for b in g['bones']:
   for c in b.get('cubes',[]):
    lo=np.array(c['origin'])-c.get('inflate',0);hi=np.array(c['origin'])+c['size']+c.get('inflate',0);t=transform(b)@rotation(c.get('rotation',[0,0,0]),c.get('pivot',((lo+hi)/2).tolist()))
    maximum=max(maximum,*[(t@np.array([x,y,z,1]))[1] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
  heights[id]=float(maximum+2)
save(R/'preview-headroom225.json',heights)
