# beta.2.28

User crash report: crash-2026-10-29_23.40.40-client.txt, Minecraft1.21.11, Duck2.27, VerifyError at class_332.duck$marker225(Object;IIIIFFFFI)V: Object is not assignable to Identifier/class_2960. Occurs when DrawContext is verified, even before Legacy is used.

Cause: native11 marker method cloned a native Identifier-argument method and changed its bridge descriptor to Object without CHECKCAST. The older-version bridge already casts. Fix the native11 texture load before invoking its typed native blit. Keep Legacy behavior/tint/coordinates intact.

Regression: reproduce2.27 failure under java-Xverify:all, then instantiate/invoke the exact fixed bridge from every version with typed native call descriptors and record its inputs. Also reject a non-Identifier Object via ClassCastException instead of invalid bytecode. Native pipeline/GPU bodies are replaced only at the boundary; the bridge instructions and Object/Identifier types are preserved. Normal API/Mixin and exact scope checks accompany this. No Minecraft/GPU run.

Final checks: all4 builds pass native API/exact callsite verification, real Mixin APPLY on remapped Minecraft targets, JAR integrity/metadata and exact2.27 scope comparison. The real JVM regression reproduced2.27 VerifyError and passed all4 corrected bridge invocations, argument/UV/tint recording and wrong-type rejection. Shared bridge coordinates are x1,x2,y1,y2, as declared in LegacyMarker225.Blit; native11 already reorders internally before the existing adapter reorders back. Test expectation corrected accordingly; product coordinates were not modified.
