from pathlib import Path
from zipfile import ZipFile
import json,numpy as np
from render_cosmetic_icons223 import rotation
B=Path(__file__).parent;m=json.loads((B/'cosmetics225-manifest.json').read_text());assert len(m['items'])==31 and len(m['removed'])==16
for v,e in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(e['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{v}-1.5.28-beta.2.24.jar') as old:
  for key in m['removed']:assert not any(n.startswith('assets/duckswords/cosmetics/'+key.lower()+'/') for n in z.namelist()),key
  for name in old.namelist():
   if not name.startswith('assets/'):continue
   if any(name.startswith('assets/duckswords/cosmetics/'+k.lower()+'/') for k in m['removed']):continue
   if name in ['assets/duckswords/cosmetics/halloween2024reaperpet/model.json','assets/duckswords/cosmetics/halloween2024reaperpet/icon.png']:continue
   if name.startswith('assets/duckswords/cosmetics/'):
    parts=name.split('/');edited={'custommask','summer2024japanesefoxmask','fall2025owlmask','demon2024crowmask','spring2025boxinggloves','springclaws','spacemask','summer2024propellerhat','angelgloves','dragonfestivalgloves','donttouchmylifeblackcrown','donttouchmylifewhitecrown'}
    if parts[3] in edited and parts[-1] in {'model.json','icon.png'}:continue
    if parts[-1]=='animated-textures.json':
     original=json.loads(old.read(name));current=json.loads(z.read(name));assert all(current[k]==v for k,v in original.items());assert set(current)-set(original)=={'springSparklesAura'};continue
   assert z.read(name)==old.read(name),name
  g=json.loads(z.read('assets/duckswords/cosmetics/halloween2024reaperpet/model.json'))['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']};head=bones['head']['cubes'][0];assert head['uv']['north']=={'uv':[8,8],'uv_size':[16,16]};assert len(bones['head']['cubes'])==1
  for name in ['leftArm','rightArm','leftLeg','rightLeg']:assert bones[name]['rotation']==[0,0,0] and bones[name]['cubes'][0]['uv']['north']['uv']==[24,28]
  weapon=bones['bone'];rod=weapon['cubes'][1];grip=np.array([rod['origin'][0]+rod['size'][0]/2,rod['origin'][1]+rod['size'][1]/2,rod['origin'][2]+rod['size'][2],1]);hand=bones['leftArm']['cubes'][0];target=np.array([hand['origin'][0]+hand['size'][0]/2,hand['origin'][1]+hand['size'][0]/2,hand['origin'][2]+hand['size'][2]/2]);assert np.max(np.abs((rotation(weapon['rotation'],weapon['pivot'])@grip)[:3]-target))<1e-6
  assert abs(bones['body']['pivot'][0]+10)<1e-6 and abs(bones['rightLeg']['cubes'][0]['origin'][1]-20)<1e-6
  heights=json.loads(z.read('assets/duckswords/cosmetics/preview-headroom225.json'));assert len(heights)>=15 and heights['chinahat']>32 and 'demon2024demonknighthelmet' not in heights
 print('PASS 225 assets:',v,'knight absent; reaper full-atlas UV/neutral pose and grip/position; hat height table; requested cosmetic edits; all unrelated assets, original fist frames and frozen profiles unchanged')
