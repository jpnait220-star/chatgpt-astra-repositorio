Fontes incrementais da atualização DuckClientZ beta.2.14.

Este pacote contém os helpers, transformações ASM, recursos e testes escritos
para a atualização. Não é uma recuperação integral do projeto original do client.
Compile-stubs e fixtures existem somente para compilação/testes: nunca devem
entrar no JAR do mod. validate_artifacts.py verifica essa separação.

Base: fixes.9 nas três versões anteriores e opt.2 na 1.21.11, publicadas na
branch asasa de jpnait220-star/chatgpt-astra-repositorio, pasta downloads.
As fontes das correções anteriores estão incluídas em bases-fontes/.
Os JARs originais de referência do Soup e o Minecraft não são redistribuídos
neste pacote de fontes. Os arquivos de crash do usuário também não estão nele.

Ambiente usado: Java 21, Python 3, ASM 9.7.1, Gson 2.10.1, JOML por versão,
Fabric Loader/Mixin e API de partículas Fabric por versão, LWJGL apenas para
compilar o cursor. As bibliotecas do jogo não são embutidas no resultado.

build.py usa os caminhos do workspace da sessão:
/workspace/duckclientz-expansion
/workspace/duckclientz/{tools,repair,dist-fixes9}
/workspace/duckclientz-1.21.11/{tools,repair,dist}
Disponibilize as bases e dependências nesses diretórios ou ajuste os caminhos.
A compilação Java usa java -m jdk.compiler/com.sun.tools.javac.Main -proc:none.
Execute python build.py. DUCK_VERSIONS seleciona versões separadas por vírgula;
DUCK_RELEASE define o identificador de versão. build-report.json registra hashes.

Testes:
python check_native.py           APIs oficiais remapeadas e novos mixins
python test_search.py            campo de busca nativo gerado
python test_safety.py            câmera/zoom/Sharpness/cosméticos/delay
python test_settings.py          modelos/swing/menus/limites/disabled paths
python test_particles.py         fábrica nativa, fade, morte e ancoragem
python test_profile_integration.py   Config/ProfileManager reais
python test_regressions.py       correções anteriores nas três versões
python test_native_regressions.py    correções anteriores na 1.21.11
python validate_artifacts.py     metadados, recursos e ausência de stubs
ProfileCodeTests.java e StorageTests.java cobrem codec e migração isolados.
Os testes usam fixtures do Minecraft; não representam execução dentro do jogo.

IMPORTANTE: os esquemas a-f em assets/duckswords/profiles/v3 são imutáveis.
Nunca substitua uma base existente, pois invalidaria códigos já compartilhados.
Acrescente novos identificadores em futuras versões quando necessário.
