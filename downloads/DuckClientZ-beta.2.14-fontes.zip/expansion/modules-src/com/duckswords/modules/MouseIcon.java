package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;
import net.minecraft.class_310;import org.lwjgl.glfw.*;import org.lwjgl.system.MemoryUtil;
import javax.imageio.ImageIO;import java.awt.image.BufferedImage;import java.io.*;import java.nio.ByteBuffer;
public final class MouseIcon extends Module{
 public final ModeSetting icon=add(new ModeSetting("Icone","Usa texturas originais de itens do Minecraft apenas na janela do jogo","Espada de diamante","Padrao","Espada de diamante","Espada de netherite","Machado de diamante","Tridente","Escova"));
 public final NumberSetting size=add(new NumberSetting("Tamanho","Tamanho do cursor em pixels",32,16,64,8));
 private long cursor,window;private String applied="";
 public MouseIcon(){super("Mouse Icon","Cursores de itens na janela do Minecraft",Category.CLIENT);}
 @Override public void onTick(){
  long handle=class_310.method_1551().method_22683().method_4490();String key=icon.getValue()+":"+size.getInt();if(window==handle&&key.equals(applied))return;
  clear();window=handle;applied=key;if(icon.is("Padrao"))return;
  String item=switch(icon.getValue()){case "Espada de netherite"->"netherite_sword";case "Machado de diamante"->"diamond_axe";case "Tridente"->"trident";case "Escova"->"brush";default->"diamond_sword";};
  try(InputStream stream=MouseIcon.class.getResourceAsStream("/assets/minecraft/textures/item/"+item+".png")){
   if(stream==null)return;BufferedImage image=ImageIO.read(stream);if(image==null)return;int n=size.getInt();ByteBuffer pixels=MemoryUtil.memAlloc(n*n*4);
   try(GLFWImage nativeImage=GLFWImage.malloc()){
    for(int y=0;y<n;y++)for(int x=0;x<n;x++){int argb=image.getRGB(x*image.getWidth()/n,y*image.getHeight()/n);pixels.put((byte)(argb>>16)).put((byte)(argb>>8)).put((byte)argb).put((byte)(argb>>>24));}
    pixels.flip();nativeImage.width(n).height(n).pixels(pixels);cursor=GLFW.glfwCreateCursor(nativeImage,n-1,0);if(cursor!=0)GLFW.glfwSetCursor(window,cursor);
   }finally{MemoryUtil.memFree(pixels);}
  }catch(IOException|RuntimeException ex){System.err.println("[DuckClientZ] Cursor indisponivel: "+ex.getMessage());}
 }
 private void clear(){if(window!=0)GLFW.glfwSetCursor(window,0);if(cursor!=0)GLFW.glfwDestroyCursor(cursor);cursor=0;}
 @Override public void onDisable(){clear();window=0;applied="";}
}
