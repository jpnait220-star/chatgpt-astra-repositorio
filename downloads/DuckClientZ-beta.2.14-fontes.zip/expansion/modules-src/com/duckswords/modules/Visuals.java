package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.particles.VisualParticles;import com.duckswords.perf.ParticleBudget;import net.minecraft.*;import java.util.concurrent.ThreadLocalRandom;
public final class Visuals extends Module{
 private static Visuals instance;private Object previousWorld;
 public final ModeSetting style=add(new ModeSetting("Estilo","ModernDuck ilumina as particulas; Classico usa a luz do mundo","ModernDuck","Classico","ModernDuck"));
 public final BooleanSetting hits=add(new BooleanSetting("Particulas ao acertar","Efeitos extras no alvo ao atacar",true));
 public final ModeSetting hitShape=add(new ModeSetting("Particula do hit","Textura do efeito ao acertar","Estrelas",VisualParticles.SHAPES));
 public final ColorSetting hitColor=add(new ColorSetting("Cor do hit","Cor e opacidade do efeito",0xfff06c85));
 public final NumberSetting hitCount=add(new NumberSetting("Quantidade no hit","Novas particulas por ataque",12,1,48,1));
 public final NumberSetting hitSize=add(new NumberSetting("Tamanho no hit","Raio visual da particula em blocos",.18,.03,.7,.01));
 public final NumberSetting hitLife=add(new NumberSetting("Duracao do hit","Duracao em ticks",24,5,100,1));
 public final NumberSetting speed=add(new NumberSetting("Velocidade no hit","Velocidade da explosao de particulas",.12,.01,.4,.01));
 public final BooleanSetting physics=add(new BooleanSetting("Fisica no hit","Ativa gravidade e colisao; usa mais CPU",false));
 public final BooleanSetting ambient=add(new BooleanSetting("Particulas no ambiente","Particulas flutuantes ao redor do jogador",false));
 public final ModeSetting ambientShape=add(new ModeSetting("Particula do ambiente","Textura das particulas ao redor","Vagalumes",VisualParticles.SHAPES));
 public final ColorSetting ambientColor=add(new ColorSetting("Cor do ambiente","Cor e opacidade das particulas flutuantes",0xc8ffe0a3));
 public final NumberSetting ambientCount=add(new NumberSetting("Limite no ambiente","Limite combinado de particulas extras visuais",48,8,128,8));
 public final NumberSetting ambientRadius=add(new NumberSetting("Raio do ambiente","Raio de criacao em blocos",8,2,24,1));
 public final NumberSetting ambientSize=add(new NumberSetting("Tamanho no ambiente","Raio visual em blocos",.12,.03,.5,.01));
 public final NumberSetting ambientLife=add(new NumberSetting("Duracao no ambiente","Duracao em ticks",60,10,160,5));
 public final BooleanSetting targetRender=add(new BooleanSetting("Target render","Efeito visual no alvo selecionado",false));
 public final ModeSetting targetStyle=add(new ModeSetting("Estilo do alvo","Marcador, anel, orbitas ou cristais","Legacy","Legacy","Circle","Ghosts","Crystals"));
 public final ColorSetting targetColor=add(new ColorSetting("Cor do alvo","Cor do efeito no alvo",0xffff7089));
 public final NumberSetting targetSize=add(new NumberSetting("Tamanho do alvo","Tamanho do marcador ou raio das orbitas",.7,.2,1.5,.05));
 public final NumberSetting targetSpeed=add(new NumberSetting("Velocidade do alvo","Velocidade da animacao visual",1,.1,3,.1));
 public final NumberSetting targetRange=add(new NumberSetting("Alcance do alvo","Alcance de selecao em blocos",8,1,24,.5));
 private class_1309 target;private int targetTicks;
 public class_1309 target(){return targetRender.getValue()?target:null;}
 private void tickTarget(){
  if(!targetRender.getValue()){target=null;targetTicks=0;return;}
  class_1309 found=com.duckswords.util.PlayerUtil.getCrosshairTarget(targetRange.getValue());if(found!=null){target=found;targetTicks=20;}else if(targetTicks>0&&--targetTicks==0)target=null;
  if(target==null||!target.method_5805()){target=null;return;}
  if((targetColor.getDisplayValue()>>>24)==0)return;double phase=System.nanoTime()*1e-9*targetSpeed.getValue();
  if(targetStyle.is("Legacy"))emitTarget("Marcador",target.method_23317(),target.method_23318()+.9,target.method_23321());
  if(targetStyle.is("Ghosts"))for(int i=0;i<3&&VisualParticles.capacity();i++){double angle=phase*2+i*Math.PI*2/3,radius=targetSize.getValue();emitTarget("Brilho",target.method_23317()+Math.cos(angle)*radius,target.method_23318()+.9+Math.sin(angle*1.5)*.5,target.method_23321()+Math.sin(angle)*radius);}
 }
 private void emitTarget(String shape,double x,double y,double z){class_2400 type=VisualParticles.type(shape,2);if(type!=null&&VisualParticles.capacity())ParticleBudget.spawn(mc.field_1687,type,x,y,z,0,0,0);}
 @Override public void onDisable(){target=null;targetTicks=0;}
 public Visuals(){super("Visuals","Particulas de hit e ambiente com texturas e limites de custo",Category.VISUALS);instance=this;}
 public static Visuals current(){return instance;}
 @Override public void onTick(){if(mc.field_1687!=previousWorld){previousWorld=mc.field_1687;target=null;targetTicks=0;VisualParticles.reset(previousWorld);}if(mc.field_1724==null||mc.field_1687==null){target=null;return;}tickTarget();if(!ambient.getValue()||(ambientColor.getDisplayValue()>>>24)==0)return;ThreadLocalRandom r=ThreadLocalRandom.current();for(int i=0;i<3&&VisualParticles.live()<ambientCount.getInt();i++){double radius=ambientRadius.getValue();double x=mc.field_1724.method_23317()+r.nextDouble(-radius,radius),y=mc.field_1724.method_23318()+r.nextDouble(-1,3),z=mc.field_1724.method_23321()+r.nextDouble(-radius,radius);emit(true,x,y,z,r.nextDouble(-.008,.008),r.nextDouble(.002,.012),r.nextDouble(-.008,.008));}}
 @Override public void onAttack(class_1297 target){if(!hits.getValue()||target==null||mc.field_1687==null||(hitColor.getDisplayValue()>>>24)==0)return;ThreadLocalRandom r=ThreadLocalRandom.current();for(int i=0;i<hitCount.getInt()&&VisualParticles.capacity();i++){double v=speed.getValue();emit(false,target.method_23317(),target.method_23318()+.9,target.method_23321(),r.nextDouble(-v,v),r.nextDouble(.02,v+.03),r.nextDouble(-v,v));}}
 private void emit(boolean ambient,double x,double y,double z,double vx,double vy,double vz){class_2400 type=VisualParticles.type((ambient?ambientShape:hitShape).getValue(),ambient);if(type!=null&&VisualParticles.capacity())ParticleBudget.spawn(mc.field_1687,type,x,y,z,vx,vy,vz);}
}
