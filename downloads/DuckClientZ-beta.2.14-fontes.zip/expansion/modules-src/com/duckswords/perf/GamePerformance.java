package com.duckswords.perf;
import com.duckswords.module.Module;import com.duckswords.setting.*;import net.minecraft.*;import java.util.*;
public final class GamePerformance{
 private record Options(BooleanSetting entities,NumberSetting items,NumberSetting mobs,NumberSetting players,BooleanSetting particles,NumberSetting distance,NumberSetting budget){}
 private static final IdentityHashMap<Module,Options> OPTIONS=new IdentityHashMap<>();
 public static volatile boolean entitiesActive,particlesActive;
 private static double itemSquared=1024,mobSquared=4096,playerSquared=16384,particleSquared=576;private static int maximum=512,tick=Integer.MIN_VALUE,used;private static Object world;
 private static <T extends Setting<?>> T add(Module m,T s){m.getSettings().add(s);return s;}
 public static void attach(Module m){OPTIONS.put(m,new Options(
  add(m,new BooleanSetting("Limitar entidades distantes","Reduz desenhos de entidades por categoria; pode ocultar entidades alem do alcance escolhido",false)),
  add(m,new NumberSetting("Alcance de itens no chao","Distancia maxima de desenho dos itens no chao, em blocos",32,8,128,8)),
  add(m,new NumberSetting("Alcance de criaturas","Distancia maxima de desenho de mobs, em blocos",64,16,256,8)),
  add(m,new NumberSetting("Alcance de jogadores","Distancia maxima de desenho de outros jogadores, em blocos",128,16,256,8)),
  add(m,new BooleanSetting("Limitar particulas do jogo","Limita distancia e novas particulas vanilla/mods; reduz detalhes visuais quando atinge o limite",false)),
  add(m,new NumberSetting("Alcance das particulas do jogo","Distancia maxima de novas particulas do jogo, em blocos",24,8,128,4)),
  add(m,new NumberSetting("Particulas do jogo por tick","Quantidade maxima de novas particulas por tick",512,32,4096,32))));}
 public static void update(Module m){Options o=OPTIONS.get(m);if(o==null)return;entitiesActive=m.isEnabled()&&o.entities.getValue();particlesActive=m.isEnabled()&&o.particles.getValue();itemSquared=square(o.items.getValue());mobSquared=square(o.mobs.getValue());playerSquared=square(o.players.getValue());particleSquared=square(o.distance.getValue());maximum=o.budget.getInt();}
 private static double square(double value){return value*value;}
 public static void disable(){entitiesActive=false;particlesActive=false;world=null;used=0;tick=Integer.MIN_VALUE;}
 public static boolean cull(class_1297 entity,double x,double y,double z){
  if(!entitiesActive||entity==null||entity==class_310.method_1551().field_1724)return false;
  double cap;if(entity instanceof class_1542)cap=itemSquared;else if(entity instanceof class_1657)cap=playerSquared;else if(entity instanceof class_1309)cap=mobSquared;else return false;
  double dx=entity.method_23317()-x,dy=entity.method_23318()-y,dz=entity.method_23321()-z;return dx*dx+dy*dy+dz*dz>cap;
 }
 public static boolean dropParticle(double x,double y,double z){
  if(!particlesActive)return false;class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1687==null)return false;
  if(world!=mc.field_1687||tick!=mc.field_1724.field_6012){world=mc.field_1687;tick=mc.field_1724.field_6012;used=0;}
  double dx=x-mc.field_1724.method_23317(),dy=y-mc.field_1724.method_23318(),dz=z-mc.field_1724.method_23321();if(dx*dx+dy*dy+dz*dz>particleSquared||used>=maximum)return true;used++;return false;
 }
}
