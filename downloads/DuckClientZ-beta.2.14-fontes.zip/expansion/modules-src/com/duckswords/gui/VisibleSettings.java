package com.duckswords.gui;
import com.duckswords.module.Module;import com.duckswords.setting.*;import java.util.*;
/** Dynamic UI projection. Serialization always reads Module.getSettings() directly. */
public final class VisibleSettings{
 private static final IdentityHashMap<Module,View> VIEWS=new IdentityHashMap<>();
 public static List<Setting<?>> of(Module module){View v=VIEWS.get(module);if(v==null){if(VIEWS.size()>128)VIEWS.clear();v=new View(module);VIEWS.put(module,v);}return v;}
 private static final class View extends AbstractList<Setting<?>> implements RandomAccess{
  final Module module;final List<Setting<?>> raw;final List<Setting<?>> gates=new ArrayList<>();List<Setting<?>> visible=List.of();long checked;int signature=Integer.MIN_VALUE;
  View(Module m){module=m;raw=m.getSettings();for(Setting<?> s:raw)if(s instanceof ModeSetting||s instanceof BooleanSetting)gates.add(s);}
  private Object value(String name){for(Setting<?> s:gates)if(s.getName().equals(name))return s.getValue();return null;}
  private boolean on(String name){return Boolean.TRUE.equals(value(name));}
  private boolean show(Setting<?> s){String n=s.getName();String owner=module.getName();
   if(owner.equals("ViewModel")){boolean modern="ModernDuck".equals(value("Modelo"));if(n.equals("Modelo")||n.equals("Afetar comidas")||n.startsWith("Velocidade da anima"))return true;return n.startsWith("ModernDuck ")==modern;}
   if(owner.equals("Swing")){boolean modern="ModernDuck".equals(value("Modo"));if(n.equals("Modo")||n.equals("Descer com cooldown"))return true;if(n.startsWith("ModernDuck custom "))return modern&&"Custom".equals(value("Estilo ModernDuck"));if(n.startsWith("ModernDuck ")||n.equals("Estilo ModernDuck"))return modern;return !modern;}
   if(owner.equals("Performance")){
    if(n.equals("Particulas por tick"))return on("Limitar particulas extras");if(n.equals("Distancia das particulas"))return on("Limitar distancia das particulas");
    if(n.equals("Alcance de itens no chao")||n.equals("Alcance de criaturas")||n.equals("Alcance de jogadores"))return on("Limitar entidades distantes");
    if(n.equals("Alcance das particulas do jogo")||n.equals("Particulas do jogo por tick"))return on("Limitar particulas do jogo");
   }
   if(owner.equals("Visuals")){
    if(n.equals("Estilo")||n.equals("Particulas ao acertar")||n.equals("Particulas no ambiente")||n.equals("Target render"))return true;
    if(n.contains("alvo"))return on("Target render");if(n.contains("ambiente"))return on("Particulas no ambiente");return on("Particulas ao acertar");
   }
   return true;
  }
  private void update(){long now=System.nanoTime();if(checked!=0&&now-checked<1_000_000)return;checked=now;int sig=raw.size();for(Setting<?> s:gates)sig=31*sig+Objects.hashCode(s.getValue());if(sig==signature)return;signature=sig;ArrayList<Setting<?>> result=new ArrayList<>();for(Setting<?> s:raw)if(show(s))result.add(s);visible=List.copyOf(result);}
  public int size(){update();return visible.size();}public Setting<?> get(int index){update();return visible.get(index);}
 }
}
