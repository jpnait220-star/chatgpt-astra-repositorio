package com.duckswords.gui;
import com.duckswords.theme.HudText;import net.minecraft.*;
public final class CosmeticsPreview{
 public static int panelWidth(int width){return Math.max(112,Math.min(260,(int)(width*.36f)));}
 public static int scrollMax(int count,int columns,int available){return Math.max(0,((count+columns-1)/columns)*104-8-available);}
 public static int columns(int width){return Math.max(1,Math.min(5,(width-panelWidth(width)-24)/104));}
 public static void draw(class_332 ctx,int x,int y,int w,int h){
  if(w<80||h<100)return;
  ctx.method_25296(x,y,x+w,y+h,0xe8192335,0xe80d1320);
  ctx.method_25294(x,y,x+w,y+1,0x554d6c91);ctx.method_25294(x,y+h-1,x+w,y+h,0x554d6c91);
  ctx.method_25294(x,y,x+1,y+h,0x554d6c91);ctx.method_25294(x+w-1,y,x+w,y+h,0x554d6c91);
  HudText.draw(ctx,"PREVIA",x+12,y+12,0xffe7eef8);
  int base=y+h-34,cx=x+w/2;
  // Cloud silhouette is built with a handful of batched rectangles, no generated artwork.
  ctx.method_25296(x+14,base,x+w-14,base+15,0xc8ffffff,0x305f80a2);
  ctx.method_25296(cx-w/4,base-7,cx+w/4,base+8,0xe8ffffff,0x90bed1e5);
  ctx.method_25296(cx-w/7,base-14,cx+w/7,base+5,0xf2ffffff,0xb0d7e3ef);
  class_1309 player=class_310.method_1551().field_1724;
  if(player==null){HudText.draw(ctx,"Entre em um mundo",x+10,y+h/2,0xffaabbd1);return;}
  int size=Math.max(22,Math.min(w/3,(h-70)/2));
  render(ctx,x+6,y+32,x+w-6,base+2,size,player);
 }
 public static void render(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){com.duckswords.visuals.PreviewViewport.draw(ctx,x1,y1,x2,y2,size,player);}
 public static void renderNative(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){throw new IllegalStateException("Missing version adapter");}
}
