package com.duckswords.particles;
import net.minecraft.*;import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
public final class ParticleBridge{
 public static void register(String id,class_2400 type){throw new IllegalStateException("Missing particle registration adapter");}
 public static class_703 create(FabricSpriteProvider sprites,class_638 world,double x,double y,double z,double vx,double vy,double vz,int channel){throw new IllegalStateException("Missing native particle adapter");}
}
