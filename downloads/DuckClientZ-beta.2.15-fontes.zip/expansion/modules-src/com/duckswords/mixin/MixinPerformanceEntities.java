package com.duckswords.mixin;
import com.duckswords.perf.GamePerformance;import net.minecraft.*;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(class_898.class)
public abstract class MixinPerformanceEntities{
 @Redirect(method="method_3950(Lnet/minecraft/class_1297;Lnet/minecraft/class_4604;DDD)Z",at=@At(value="INVOKE",target="Lnet/minecraft/class_897;method_3933(Lnet/minecraft/class_1297;Lnet/minecraft/class_4604;DDD)Z"),require=1,remap=false)
 private boolean duck$entityDistance(class_897 renderer,class_1297 e,class_4604 frustum,double x,double y,double z){return !(GamePerformance.entitiesActive&&GamePerformance.cull(e,x,y,z))&&renderer.method_3933(e,frustum,x,y,z);}
}
