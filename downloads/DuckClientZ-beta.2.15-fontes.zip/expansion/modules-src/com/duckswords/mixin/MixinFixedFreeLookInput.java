package com.duckswords.mixin;
import com.duckswords.camera.FreeLookControl;import net.minecraft.class_1297;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=class_1297.class,remap=false)
public abstract class MixinFixedFreeLookInput{
 @Inject(method="method_5872(DD)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
 private void duck$keepPlayerHead(double dx,double dy,CallbackInfo callback){if(FreeLookControl.look(this,dx,dy))callback.cancel();}
}
