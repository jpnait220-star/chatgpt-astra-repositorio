package com.duckswords.mixin;
import com.duckswords.camera.FreeLookControl;import net.minecraft.class_312;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=class_312.class,remap=false)
public abstract class MixinFixedFreeLookScroll{
 @Inject(method="method_1598(JDD)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
 private void duck$zoomFreeLook(long window,double horizontal,double vertical,CallbackInfo callback){if(FreeLookControl.scroll(vertical))callback.cancel();}
}
