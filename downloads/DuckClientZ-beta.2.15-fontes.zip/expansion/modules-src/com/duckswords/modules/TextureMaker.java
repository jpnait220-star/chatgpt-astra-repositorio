package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.gui.TextureMakerScreen;import net.minecraft.class_310;
public final class TextureMaker extends Module {public TextureMaker(){super("Texture Maker","Crie resource packs e desenhe texturas dentro do jogo",Category.CLIENT);}@Override public void onEnable(){class_310 mc=class_310.method_1551();mc.method_1507(new TextureMakerScreen(mc.field_1755));setEnabled(false);}}
