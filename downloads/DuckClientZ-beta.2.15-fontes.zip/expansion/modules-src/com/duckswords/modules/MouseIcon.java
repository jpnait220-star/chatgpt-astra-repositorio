package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.cursor.CursorBitmap;
import net.minecraft.class_310;import org.lwjgl.glfw.*;import org.lwjgl.system.MemoryUtil;import javax.imageio.ImageIO;import java.awt.image.BufferedImage;import java.io.*;import java.nio.ByteBuffer;
public final class MouseIcon extends Module {
 public final ModeSetting icon=add(new ModeSetting("Icone","Itens e cursores Bibata existentes; altera apenas a janela do Minecraft","Espada de diamante","Padrao","Espada de diamante","Espada de netherite","Machado de diamante","Tridente","Escova","Bibata Claro","Bibata Escuro","Bibata Mira","Bibata Mao","Bibata Lapis","Bibata Texto"));
 public final NumberSetting size=add(new NumberSetting("Tamanho","Tamanho do cursor em pixels",32,16,64,8));
 private static MouseIcon instance;private long cursor,window;private String applied="";
 public MouseIcon(){super("Mouse Icon","Cursores do Minecraft e Bibata, exclusivos da janela do jogo",Category.CLIENT);instance=this;}
 public static void afterFrame(){MouseIcon m=instance;if(m!=null&&m.isEnabled()&&m.cursor!=0&&m.window!=0)GLFW.glfwSetCursor(m.window,m.cursor);}
 @Override public void onTick(){long handle=class_310.method_1551().method_22683().method_4490();String key=icon.getValue()+":"+size.getInt();if(window==handle&&key.equals(applied))return;clear();window=handle;applied=key;if(icon.is("Padrao"))return;int n=size.getInt();
  try{BufferedImage image;int hotX,hotY;boolean mirror=false;
   if(icon.getValue().startsWith("Bibata")){String name=switch(icon.getValue()){case "Bibata Escuro"->"classic-left_ptr";case "Bibata Mira"->"ice-crosshair";case "Bibata Mao"->"ice-hand2";case "Bibata Lapis"->"ice-pencil";case "Bibata Texto"->"ice-xterm";default->"ice-left_ptr";};try(InputStream in=MouseIcon.class.getResourceAsStream("/assets/duckswords/cursors/bibata-"+name+".cursor")){if(in==null)return;CursorBitmap bitmap=CursorBitmap.read(in.readAllBytes(),n);image=bitmap.image();hotX=bitmap.hotX()*n/image.getWidth();hotY=bitmap.hotY()*n/image.getHeight();}}
   else{String item=switch(icon.getValue()){case "Espada de netherite"->"netherite_sword";case "Machado de diamante"->"diamond_axe";case "Tridente"->"trident";case "Escova"->"brush";default->"diamond_sword";};try(InputStream in=MouseIcon.class.getResourceAsStream("/assets/minecraft/textures/item/"+item+".png")){if(in==null)return;image=ImageIO.read(in);}if(image==null)return;mirror=!item.equals("diamond_axe");hotX=mirror?0:n-1;hotY=0;}
   ByteBuffer pixels=MemoryUtil.memAlloc(n*n*4);try(GLFWImage nativeImage=GLFWImage.malloc()){
    for(int y=0;y<n;y++)for(int x=0;x<n;x++){int src=mirror?n-1-x:x,argb=image.getRGB(src*image.getWidth()/n,y*image.getHeight()/n);pixels.put((byte)(argb>>16)).put((byte)(argb>>8)).put((byte)argb).put((byte)(argb>>>24));}pixels.flip();nativeImage.width(n).height(n).pixels(pixels);cursor=GLFW.glfwCreateCursor(nativeImage,hotX,hotY);if(cursor!=0)GLFW.glfwSetCursor(window,cursor);
   }finally{MemoryUtil.memFree(pixels);}
  }catch(IOException|RuntimeException e){System.err.println("[DuckClientZ] Cursor indisponivel: "+e.getMessage());}
 }
 private void clear(){if(window!=0)GLFW.glfwSetCursor(window,0);if(cursor!=0)GLFW.glfwDestroyCursor(cursor);cursor=0;}
 @Override public void onDisable(){clear();window=0;applied="";}
}
