package com.duckswords.audio;
import com.duckswords.DucksWordsClient;import com.duckswords.modules.HitSound;import com.duckswords.util.UiSound;import net.minecraft.*;import java.util.*;
public final class ModernSounds{
 public static final Map<String,String> IDS=Map.ofEntries(Map.entry("ModernDuck Click","modern_click"),Map.entry("ModernDuck Enable","modern_enable"),Map.entry("ModernDuck Disable","modern_disable"),Map.entry("ModernDuck Bell","modern_bell"),Map.entry("ModernDuck Pop","modern_pop"),Map.entry("ModernDuck Bubble","modern_bubble"),Map.entry("ModernDuck Bonk","modern_bonk"),Map.entry("ModernDuck Blip","modern_blip"),Map.entry("ModernDuck 8bit","modern_8bit"));
 public static String id(String value){return IDS.get(value);}
 public static String[] modes(String[] old){String[] extra=IDS.keySet().stream().sorted().toArray(String[]::new);String[] all=Arrays.copyOf(old,old.length+extra.length);System.arraycopy(extra,0,all,old.length,extra.length);return all;}
 public static boolean hit(class_1309 victim,class_1297 attacker){
  HitSound feature=DucksWordsClient.MODULES.get(HitSound.class);if(feature==null||!IDS.containsKey(feature.sound.getValue()))return false;class_310 mc=class_310.method_1551();
  if(feature.isEnabled()&&mc.field_1724!=null&&mc.field_1687!=null&&attacker==mc.field_1724&&victim!=mc.field_1724)UiSound.play(feature.sound.getValue(),feature.volume.getFloat(),feature.pitch.getFloat());return true;
 }
}
