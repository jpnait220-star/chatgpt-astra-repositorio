package com.duckswords.texturemaker;
import net.minecraft.class_332;import java.util.*;
/** Cached horizontal runs; bounded visible sample count, with no texture/GL allocation per frame. */
public final class PixelRaster {
 private record Run(int x,int y,int w,int color){}
 private PixelCanvas canvas;private int revision=-1,startX,startY,span,cells;private List<Run> runs=List.of();
 public void draw(class_332 ctx,PixelCanvas image,int x,int y,int size,int left,int top,int region){int resolution=Math.min(48,Math.max(1,region));if(canvas!=image||revision!=image.revision()||left!=startX||top!=startY||span!=region||cells!=resolution){canvas=image;revision=image.revision();startX=left;startY=top;span=region;cells=resolution;List<Run> next=new ArrayList<>();for(int row=0;row<cells;row++){int previous=0,begin=0;for(int col=0;col<=cells;col++){int xx=left+col*region/cells,yy=top+row*region/cells,color=col==cells||xx<0||xx>=image.width||yy<0||yy>=image.height?0:image.pixel(xx,yy);if(col==0){previous=color;continue;}if(color!=previous||col==cells){if((previous>>>24)!=0)next.add(new Run(begin,row,col-begin,previous));begin=col;previous=color;}}}runs=List.copyOf(next);}
  for(Run run:runs){int x1=x+run.x*size/cells,y1=y+run.y*size/cells,x2=x+(run.x+run.w)*size/cells,y2=y+(run.y+1)*size/cells;ctx.method_25294(x1,y1,x2,y2,run.color);}
 }
}
