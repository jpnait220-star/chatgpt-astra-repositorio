package com.duckswords.texturemaker;
import net.minecraft.class_310;import org.lwjgl.glfw.GLFW;
public final class EditorKeys {public static int modifiers(){long w=class_310.method_1551().method_22683().method_4490();return (GLFW.glfwGetKey(w,341)==1||GLFW.glfwGetKey(w,345)==1?2:0)|(GLFW.glfwGetKey(w,340)==1||GLFW.glfwGetKey(w,344)==1?1:0);}}
