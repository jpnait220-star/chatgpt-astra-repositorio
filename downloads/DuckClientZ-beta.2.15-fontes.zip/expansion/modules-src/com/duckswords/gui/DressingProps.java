package com.duckswords.gui;
import net.minecraft.*;
/** Menu-only display entities: never added to or ticked in the game world. */
public final class DressingProps {
 private static Object world;private static class_1309[] stands;private static class_1799 lectern;
 public static void clear(){world=null;stands=null;}
 public static class_1309 stand(int index){Object current=class_310.method_1551().field_1687;if(current==null){world=null;stands=null;return null;}if(current!=world){class_1309 a=create(current,false),b=create(current,true);stands=new class_1309[]{a,b};world=current;}return stands[index];}
 public static class_1309 create(Object world,boolean diamond){throw new IllegalStateException("Missing dressing entity adapter");}
 public static class_1799 book(){throw new IllegalStateException("Missing dressing book adapter");}
 public static void item(class_332 ctx,class_1799 stack,int x,int y){throw new IllegalStateException("Missing dressing item adapter");}
 public static void drawBook(class_332 ctx,int x,int y){if(lectern==null)lectern=book();item(ctx,lectern,x,y);}
}
