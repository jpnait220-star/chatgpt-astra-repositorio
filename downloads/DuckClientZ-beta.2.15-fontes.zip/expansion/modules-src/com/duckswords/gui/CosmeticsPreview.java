package com.duckswords.gui;
import com.duckswords.theme.HudText;import net.minecraft.*;
public final class CosmeticsPreview{
 public static int panelWidth(int width){return Math.max(112,Math.min(260,(int)(width*.36f)));}
 public static int scrollMax(int count,int columns,int available){return Math.max(0,((count+columns-1)/columns)*104-8-available);}
 public static int columns(int width){return Math.max(1,Math.min(5,(width-panelWidth(width)-24)/104));}
 public static void draw(class_332 ctx,int x,int y,int w,int h){
  if(w<80||h<100)return;
  ctx.method_25294(x,y,x+w,y+h,0xff171c23);
  ctx.method_25294(x,y,x+w,y+1,0xff384251);ctx.method_25294(x,y+h-1,x+w,y+h,0xff384251);
  HudText.draw(ctx,"VESTIARIO",x+10,y+12,0xffd9dee7);
  int floor=y+h-25;ctx.method_25294(x+1,floor,x+w-1,y+h-1,0xff332c29);
  for(int i=1;i<7;i++){int xx=x+i*w/7;ctx.method_25294(xx,floor,xx+1,y+h-1,0xff423a32);}
  class_1309 player=class_310.method_1551().field_1724;
  if(player==null||class_310.method_1551().field_1687==null){HudText.draw(ctx,"Entre em um mundo",x+8,y+h/2,0xffaabbd1);return;}
  int propSize=Math.max(10,Math.min(w/9,(h-65)/3)),size=Math.max(18,Math.min(w/5,(h-48)/3));
  render(ctx,x+3,Math.max(y+29,floor+1-2*propSize),x+w/3,floor+1,propSize,DressingProps.stand(0));
  render(ctx,x+w*2/3,Math.max(y+29,floor+1-2*propSize),x+w-3,floor+1,propSize,DressingProps.stand(1));
  render(ctx,x+w/4,Math.max(y+29,floor+4-2*size),x+w*3/4,floor+4,size,player);
  DressingProps.drawBook(ctx,x+w-24,floor+2);
 }
 public static void render(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){com.duckswords.visuals.PreviewViewport.draw(ctx,x1,y1,x2,y2,size,player);}
 public static void renderNative(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){throw new IllegalStateException("Missing version adapter");}
}
