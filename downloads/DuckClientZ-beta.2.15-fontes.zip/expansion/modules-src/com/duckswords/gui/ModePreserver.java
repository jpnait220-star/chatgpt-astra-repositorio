package com.duckswords.gui;
import com.duckswords.DucksWordsClient;import com.duckswords.module.Module;import com.duckswords.setting.*;import java.util.*;
public final class ModePreserver {
 private record Choice(ModeSetting setting,String value){}
 public static Object capture(List<Setting<?>> settings){List<Choice> choices=new ArrayList<>();for(Setting<?> setting:settings)if(setting instanceof ModeSetting mode&&(setting.getName().equals("Modelo")||setting.getName().equals("Modo")||setting.getName().equals("Estilo ModernDuck")))choices.add(new Choice(mode,mode.getValue()));return choices;}
 public static Object all(){List<Object> snapshots=new ArrayList<>();for(Module module:DucksWordsClient.MODULES.getModules())if(module.getName().equals("ViewModel")||module.getName().equals("Swing"))snapshots.add(capture(module.getSettings()));return snapshots;}
 public static void restore(Object snapshot){if(snapshot instanceof List<?> list)for(Object value:list){if(value instanceof Choice choice)choice.setting.setValue(choice.value);else restore(value);}}
 public static List<Module> order(List<Module> modules){Module profile=null,theme=null;for(int i=modules.size()-1;i>=0;i--){Module m=modules.get(i);String name=m.getName();if(name.equals("Interface")||name.equals("Theme")||name.equals("Tema")){theme=m;modules.remove(i);}else if(name.equals("Profiles")){profile=m;modules.remove(i);}}if(profile!=null)modules.add(profile);if(theme!=null)modules.add(theme);return modules;}
}
