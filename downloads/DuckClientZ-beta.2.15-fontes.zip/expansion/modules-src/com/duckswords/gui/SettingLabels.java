package com.duckswords.gui;
import com.duckswords.setting.Setting;
/** Display labels only: profile keys remain unchanged. */
public final class SettingLabels {public static String name(Setting<?> setting){String value=setting.getName();if(value.equals("Estilo ModernDuck"))return "Estilo";if(value.startsWith("ModernDuck ")){value=value.substring(11);if(!value.isEmpty())value=Character.toUpperCase(value.charAt(0))+value.substring(1);}return value;}}
