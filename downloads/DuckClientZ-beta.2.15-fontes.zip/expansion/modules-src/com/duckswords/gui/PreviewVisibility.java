package com.duckswords.gui;
import com.duckswords.setting.BooleanSetting;import net.minecraft.class_310;
public final class PreviewVisibility{public static Boolean value(BooleanSetting setting){Object screen=class_310.method_1551().field_1755;return screen!=null?Boolean.FALSE:setting.getValue();}}
