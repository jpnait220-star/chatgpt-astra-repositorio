package com.duckswords.visuals;
import com.duckswords.module.Module;import com.duckswords.setting.*;
import net.minecraft.*;import org.joml.Quaternionf;import java.util.*;
/** Separate model and swing settings; old styles are never overwritten. */
public final class ModernDuck{
 private static Module swingModule;private static final IdentityHashMap<Module,Model> MODELS=new IdentityHashMap<>();private static final IdentityHashMap<Module,Animation> SWINGS=new IdentityHashMap<>();
 private static <T extends Setting<?>> T add(Module m,T s){m.getSettings().add(s);return s;}
 private static NumberSetting number(Module m,String name,double def,double min,double max,double step){return add(m,new NumberSetting(name,"Ajuste independente do modo ModernDuck",def,min,max,step));}
 private static final class Hand{
  final NumberSetting x,y,z,rx,ry,rz,size,sx,sy,sz;
  Hand(Module m,String name){x=number(m,name+" X",0,-1,1,.01);y=number(m,name+" Y",0,-1,1,.01);z=number(m,name+" Z",0,-2.5,2.5,.01);rx=number(m,name+" Pitch",0,-180,180,1);ry=number(m,name+" Yaw",0,-180,180,1);rz=number(m,name+" Roll",0,-180,180,1);size=number(m,name+" Tamanho",1,.1,2,.05);sx=number(m,name+" Esticar X",1,.1,3,.05);sy=number(m,name+" Esticar Y",1,.1,3,.05);sz=number(m,name+" Esticar Z",1,.1,3,.05);}
 }
 private static final class Model{
  final ModeSetting mode;final Hand main,off;
  Model(Module m){mode=add(m,new ModeSetting("Modelo","DuckModels preserva seus ajustes atuais; ModernDuck usa ajustes separados","DuckModels","DuckModels","ModernDuck"));main=new Hand(m,"ModernDuck principal");off=new Hand(m,"ModernDuck secundaria");}
 }
 private static final class Animation{
  final ModeSetting original,type;final NumberSetting intensity,speed;final NumberSetting[] custom=new NumberSetting[9];
  Animation(Module m){original=(ModeSetting)m.getSettings().stream().filter(s->s instanceof ModeSetting&&s.getName().equals("Modo")).findFirst().orElseThrow();type=add(m,new ModeSetting("Estilo ModernDuck","Estilo de animacao no modo ModernDuck","Smooth","Swipe","Down","Smooth","Power","Feast","Custom"));intensity=number(m,"ModernDuck intensidade",1,0,2,.05);speed=number(m,"ModernDuck velocidade",1,.5,2,.05);String[] keys={"Posicao X","Posicao Y","Posicao Z","Rotacao X","Rotacao Y","Rotacao Z","Ataque X","Ataque Y","Ataque Z"};double[] defaults={.56,-.32,-.72,0,0,0,-60,0,0};for(int i=0;i<9;i++)custom[i]=number(m,"ModernDuck custom "+keys[i],defaults[i],i<3?-2:-180,i<3?2:180,i<3?.01:1);}
 }
 public static void attachModel(Module m){Model model=new Model(m);MODELS.put(m,model);m.getSettings().remove(model.mode);m.getSettings().add(0,model.mode);}
 public static void attachSwing(Module m){SWINGS.put(m,new Animation(m));swingModule=m;}
 public static boolean pose(Module owner,class_4587 m,class_1268 hand){Model v=MODELS.get(owner);if(v==null||!v.mode.is("ModernDuck"))return false;Hand h=hand==class_1268.field_5810?v.off:v.main;m.method_46416(h.x.getFloat(),h.y.getFloat(),h.z.getFloat());rotate(m,h.rx.getFloat(),h.ry.getFloat(),h.rz.getFloat());return true;}
 public static boolean scale(Module owner,class_4587 m,class_1268 hand){Model v=MODELS.get(owner);if(v==null||!v.mode.is("ModernDuck"))return false;Hand h=hand==class_1268.field_5810?v.off:v.main;float size=h.size.getFloat();m.method_22905(h.sx.getFloat()*size,h.sy.getFloat()*size,h.sz.getFloat()*size);return true;}
 public static boolean swingDuration(Object entity,org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Integer> result){Module module=swingModule;Animation a=SWINGS.get(module);if(module==null||a==null||!module.isEnabled()||!a.original.is("ModernDuck"))return false;if(entity==class_310.method_1551().field_1724){int vanilla=result.getReturnValueI();if(vanilla>0)result.setReturnValue(Math.max(1,Math.round(vanilla/a.speed.getFloat())));}return true;}
 private static void rotate(class_4587 m,float x,float y,float z){if(x!=0)m.method_22907(new Quaternionf().rotationX((float)Math.toRadians(x)));if(y!=0)m.method_22907(new Quaternionf().rotationY((float)Math.toRadians(y)));if(z!=0)m.method_22907(new Quaternionf().rotationZ((float)Math.toRadians(z)));}
 public static boolean swing(Module owner,class_4587 m,class_1306 arm,float progress,boolean hasEquipBase){
  Animation a=SWINGS.get(owner);if(a==null||!a.original.is("ModernDuck"))return false;if(!Float.isFinite(progress))progress=0;float p=Math.max(0,Math.min(1,progress)),side=arm==class_1306.field_6182?-1:1;
  float first=(float)Math.sin(p*p*Math.PI),second=(float)Math.sin(Math.sqrt(p)*Math.PI)*a.intensity.getFloat(),smooth=(float)Math.sin(p*Math.PI)*.5f;
  if(hasEquipBase)m.method_46416(-side*.56f,.52f,.72f);
  if(a.type.is("Custom")){m.method_46416(side*a.custom[0].getFloat(),a.custom[1].getFloat(),a.custom[2].getFloat());rotate(m,a.custom[3].getFloat(),side*a.custom[4].getFloat(),side*a.custom[5].getFloat());rotate(m,second*a.custom[6].getFloat(),side*second*a.custom[7].getFloat(),side*second*a.custom[8].getFloat());return true;}
  m.method_46416(side*.56f,a.type.is("Smooth")?-.42f:-.32f,-.72f);
  switch(a.type.getValue()){
   case "Swipe":rotate(m,0,60*side,-60*side);rotate(m,-second*first*120,-second*first*5,0);rotate(m,-60,0,0);break;
   case "Down":rotate(m,0,76*side,0);rotate(m,0,-second*5,0);rotate(m,second*100,0,0);rotate(m,-second*155,0,0);rotate(m,-100,0,0);break;
   case "Smooth":rotate(m,0,side*(45-first*20),0);rotate(m,0,0,-side*second*20);rotate(m,-second*80,0,0);rotate(m,0,-side*45,0);m.method_46416(0,-.1f,0);break;
   case "Power":m.method_46416(-smooth*smooth*first*side,0,0);rotate(m,0,61*side,0);rotate(m,0,0,second);rotate(m,0,-second*first*5,0);rotate(m,-second*first*30,0,0);rotate(m,-60,0,0);rotate(m,-smooth*60,0,0);break;
   case "Feast":rotate(m,0,30*side,0);rotate(m,0,second*75*side,0);rotate(m,-second*45,0,0);rotate(m,0,30*side,0);rotate(m,-80,0,0);rotate(m,0,35*side,0);break;
  }return true;
 }
}
