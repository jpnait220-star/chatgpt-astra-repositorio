package com.duckswords.visuals;
import com.duckswords.module.Module;import com.duckswords.setting.ModeSetting;import com.duckswords.DucksWordsClient;import com.duckswords.modules.TargetHud;import net.minecraft.class_332;import java.util.*;
public final class ModernTargetStyle{
 private static final IdentityHashMap<Module,ModeSetting> MODES=new IdentityHashMap<>();
 public static void attach(Module owner){ModeSetting mode=new ModeSetting("Estilo do HUD","Preserva o HUD atual ou usa o painel ModernDuck","DuckHUD","DuckHUD","ModernDuck Default","ModernDuck Round");owner.getSettings().add(0,mode);MODES.put(owner,mode);}
 private static String mode(Module m){ModeSetting s=MODES.get(m);return s==null?"DuckHUD":s.getValue();}
 private static int shade(int c,int delta){int r=Math.max(0,Math.min(255,(c>>16&255)+delta)),g=Math.max(0,Math.min(255,(c>>8&255)+delta)),b=Math.max(0,Math.min(255,(c&255)+delta));return c&0xff000000|r<<16|g<<8|b;}
 public static void background(class_332 ctx,int x1,int y1,int x2,int y2,int color,Module owner){String mode=mode(owner);if(mode.equals("DuckHUD")){ctx.method_25294(x1,y1,x2,y2,color);return;}if(mode.equals("ModernDuck Round")){ctx.method_25296(x1+4,y1,x2-4,y2,shade(color,12),shade(color,-4));ctx.method_25296(x1+1,y1+3,x1+4,y2-3,shade(color,10),shade(color,-4));ctx.method_25296(x2-4,y1+3,x2-1,y2-3,shade(color,10),shade(color,-4));}else ctx.method_25296(x1,y1,x2,y2,shade(color,12),shade(color,-4));int alpha=(color>>>24)/3;ctx.method_25294(x1+4,y1,x2-4,y1+1,alpha<<24|0xffffff);}
 public static boolean bar(class_332 ctx,int x,int y,int w,int h,int radius,int color){String mode=mode(DucksWordsClient.MODULES.get(TargetHud.class));if(mode.equals("DuckHUD"))return false;if(w<=0||h<=0)return true;int inset=mode.equals("ModernDuck Round")&&w>4?1:0;ctx.method_25296(x+inset,y,x+w-inset,y+h,shade(color,10),shade(color,-8));if(inset>0&&h>2){ctx.method_25294(x,y+1,x+1,y+h-1,color);ctx.method_25294(x+w-1,y+1,x+w,y+h-1,color);}return true;}
}
