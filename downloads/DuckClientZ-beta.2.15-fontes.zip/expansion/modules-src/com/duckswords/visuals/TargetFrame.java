package com.duckswords.visuals;public final class TargetFrame{public static float delta(){throw new IllegalStateException("Missing frame adapter");}}
