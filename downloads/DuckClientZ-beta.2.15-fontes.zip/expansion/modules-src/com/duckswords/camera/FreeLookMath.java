package com.duckswords.camera;
public final class FreeLookMath{
 public static float yaw(float current,double delta){if(!Float.isFinite(current))current=0;return Double.isFinite(delta)?(float)Math.IEEEremainder(current+delta*.15,360):current;}
 public static float pitch(float current,double delta){if(!Float.isFinite(current))current=0;return Double.isFinite(delta)?(float)Math.max(-90,Math.min(90,current+delta*.15)):current;}
}
