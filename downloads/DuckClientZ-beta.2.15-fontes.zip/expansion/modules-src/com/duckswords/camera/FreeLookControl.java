package com.duckswords.camera;
import com.duckswords.DucksWordsClient;import com.duckswords.modules.RecordingCamera;import net.minecraft.class_310;
public final class FreeLookControl{
 public static RecordingCamera camera(){class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1755!=null)return null;RecordingCamera camera=DucksWordsClient.MODULES.get(RecordingCamera.class);return camera!=null&&camera.isEnabled()&&camera.isCameraActive()?camera:null;}
 public static boolean look(Object entity,double dx,double dy){if(entity!=class_310.method_1551().field_1724)return false;RecordingCamera camera=camera();if(camera==null||!camera.lockCamera.getValue())return false;if(Double.isFinite(dx)&&Double.isFinite(dy))camera.rotate(dx,dy);return true;}
 public static float distance(RecordingCamera camera){return camera.cameraDistance();}
 public static boolean scroll(double amount){RecordingCamera camera=camera();if(camera==null||!Double.isFinite(amount))return false;camera.zoom(amount);return true;}
}
