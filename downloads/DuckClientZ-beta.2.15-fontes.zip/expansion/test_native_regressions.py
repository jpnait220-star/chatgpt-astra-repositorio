from pathlib import Path
import subprocess,json,os
B=Path(__file__).parent;R=Path('/workspace/duckclientz-1.21.11/repair');T=Path('/workspace/duckclientz/tools');entry=json.loads((B/'build-report.json').read_text())['1.21.11'];out=B/'native-regression-classes';out.mkdir(exist_ok=True)
src=B/'native-regression-src/Tests12111.java';src.write_text((R/'Tests12111.java').read_text().replace('for(String mode:Swing.MODES)','for(String mode:java.util.Arrays.copyOf(Swing.MODES,5))'))
cp=os.pathsep.join(map(str,[out,R/'testclasses',R/'probes',R/'stubclasses',B/'compile-stubclasses-new',entry['jar'],R.parent/'tools/joml.jar',T/'gson.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,(B/'native-regression-src').rglob('*.java')),str(B/'compile-stubs-new/net/minecraft/class_4587.java')],check=True)
for test in ['Tests12111','HudLayoutTests','GeneralPerfTests']:subprocess.run(['java','-Xverify:all','-cp',cp,test],check=True)
