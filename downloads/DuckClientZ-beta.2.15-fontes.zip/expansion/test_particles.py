from pathlib import Path
import subprocess,json,os
B=Path(__file__).parent
common={
'net/minecraft/class_638.java':'public class class_638 {}',
'net/minecraft/class_2394.java':'public interface class_2394 {}',
'net/minecraft/class_2400.java':'public class class_2400 implements class_2394 {}',
'net/minecraft/class_5819.java':'public interface class_5819 {}',
'net/minecraft/class_1058.java':'public class class_1058 {}',
'net/minecraft/class_1297.java':'public class class_1297 {public double x,y,z;public boolean alive=true;public double method_23317(){return x;}public double method_23318(){return y;}public double method_23321(){return z;}public boolean method_5805(){return alive;}}',
'net/minecraft/class_4002.java':'public interface class_4002 {default class_1058 method_74304(){return new class_1058();}}',
'net/minecraft/class_3999.java':'public class class_3999 {public static final class_3999 field_17829=new class_3999();}',
'net/fabricmc/fabric/api/client/particle/v1/FabricSpriteProvider.java':'public interface FabricSpriteProvider extends net.minecraft.class_4002 {}',
'net/minecraft/class_703.java':'''public class class_703 {
 public class_638 field_3851;public double field_3852,field_3869,field_3850,field_3874,field_3854,field_3871,field_3858,field_3838,field_3856;public boolean field_3843,field_3862;public int field_3847,field_3866;public float field_3844,field_17867,field_3861,field_3857,field_62637,field_62638,red,green,blue,alpha;
 public class_703(class_638 w,double x,double y,double z,double vx,double vy,double vz){field_3851=w;method_3063(x,y,z);}
 public void method_3063(double x,double y,double z){field_3874=x;field_3854=y;field_3871=z;}
 public void method_3070(){field_3858=field_3874;field_3838=field_3854;field_3856=field_3871;field_3874+=field_3852;field_3854+=field_3869;field_3871+=field_3850;if(++field_3866>=field_3847)method_3085();}
 public void method_3085(){field_3843=true;}public int method_3068(float d){return 42;}
 public void method_3084(float r,float g,float b){red=r;green=g;blue=b;}public void method_3083(float a){alpha=a;}public void method_74305(float r,float g,float b){method_3084(r,g,b);}public void method_74308(float a){alpha=a;}
}''',
'net/minecraft/class_4003.java':'''public class class_4003 extends class_703 {public class_4002 provider;public class_4003(class_638 w,double x,double y,double z,double vx,double vy,double vz){super(w,x,y,z,vx,vy,vz);}public void method_18140(class_4002 p){provider=p;}public class_3999 method_18122(){return class_3999.field_17829;}}''',
'net/minecraft/class_3940.java':'''public class class_3940 extends class_703 {public class_1058 sprite;public class_3940(class_638 w,double x,double y,double z,double vx,double vy,double vz,class_1058 s){super(w,x,y,z,vx,vy,vz);sprite=s;}public static class class_11941 {public static final class_11941 field_62641=new class_11941();}protected class_11941 method_74255(){return class_11941.field_62641;}}''',
'com/duckswords/particles/VisualParticles.java':'''public class VisualParticles {public static int live;public static Object world;public static boolean bright=true,physics;public static net.minecraft.class_1297 anchor;public static boolean keepMarker(net.minecraft.class_1297 entity){return entity==anchor&&entity!=null&&entity.alive;}public static int color(int c){return 0x80336699;}public static float size(int c){return .25f;}public static int life(int c){return 4;}public static boolean physics(int c){return physics;}public static boolean bright(){return bright;}public static net.minecraft.class_1297 anchor(int c){return anchor;}public static float spin(int c){return c==2?.1f:0;}public static float rotation(){return .5f;}public static void created(Object w){world=w;live++;}public static void died(Object w){if(w==world)live--;}}'''
}
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 modern=v=='1.21.11';root=B/'particle-runtime'/v;src=root/'src';out=root/'classes';out.mkdir(parents=True,exist_ok=True)
 factory='public interface class_707<T extends class_2394> {class_703 method_3090(T effect,class_638 world,double x,double y,double z,double vx,double vy,double vz'+(',class_5819 random' if modern else '')+');}'
 for file,body in (common|{'net/minecraft/class_707.java':factory}).items():
  path=src/file;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('package '+str(Path(file).parent).replace('/','.')+';'+body)
 test='''import com.duckswords.particles.*;import net.minecraft.*;import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
 public class ParticleTests {static int checks;static void check(boolean b){if(!b)throw new AssertionError("particle check "+checks);checks++;}static void near(double a,double b){check(Math.abs(a-b)<.0001);}public static void main(String[] args)throws Exception{
 class_638 world=new class_638();FabricSpriteProvider provider=new FabricSpriteProvider(){};class_707<class_2400> factory=new VisualParticleFactory(provider,0);
 class_703 p=factory.method_3090(new class_2400(),world,1,2,3,.1,.2,.3RNG);check(VisualParticles.live==1);near(p.field_3852,.1);near(p.field_3869,.2);near(p.field_3850,.3);near(p.field_17867,.25);check(p.field_3847==4);near(p.red,0x33/255f);near(p.green,0x66/255f);near(p.blue,0x99/255f);near(p.alpha,128/255f);check(p.method_3068(.5f)==15728880);check(!p.field_3862);
 p.method_3070();near(p.alpha,128/255f*.75);near(p.field_3874,1.1);near(p.field_3858,1);for(int i=0;i<3;i++)p.method_3070();check(p.field_3843&&VisualParticles.live==0);p.method_3085();p.method_3070();check(VisualParticles.live==0);
 VisualParticles.bright=false;VisualParticles.physics=true;p=ParticleBridge.create(provider,world,0,0,0,0,0,0,0);check(p.method_3068(0)==42);check(p.field_3862);near(p.field_3844,.06);p.method_3085();check(VisualParticles.live==0);
 class_1297 target=new class_1297();target.x=5;target.y=10;target.z=15;VisualParticles.anchor=target;p=ParticleBridge.create(provider,world,6,11,16,0,0,0,2);target.x+=2;target.y+=3;target.z+=4;p.method_3070();near(p.field_3874,8);near(p.field_3854,14);near(p.field_3871,20);for(int i=0;i<20;i++)p.method_3070();check(!p.field_3843&&VisualParticles.live==1);near(p.alpha,128/255f);target.alive=false;p.method_3070();check(p.field_3843&&VisualParticles.live==0);p.method_3085();check(VisualParticles.live==0);
 System.out.println("PASS: "+checks+" native particle/factory runtime checks: color, opacity/fade, size, velocity, physics, light, lifetime, external death and target attachment VERSION");}}
 '''.replace('RNG',',null' if modern else '').replace('VERSION',v)
 (src/'ParticleTests.java').write_text(test)
 cp=os.pathsep.join([str(out),entry['jar']])
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,src.rglob('*.java'))],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'ParticleTests'],check=True)
