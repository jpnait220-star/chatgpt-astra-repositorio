package com.duckswords.cursor;
import java.nio.*;import java.io.*;import java.awt.image.BufferedImage;
/** Decoder for the static Xcursor frames distributed by Bibata. No native desktop theme is installed. */
public record CursorBitmap(BufferedImage image,int hotX,int hotY) {
 public static CursorBitmap read(byte[] bytes,int desired)throws IOException{
  if(bytes.length<16||bytes.length>4_000_000)throw new IOException("Invalid cursor size");ByteBuffer b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);if(b.getInt()!=0x72756358)throw new IOException("Invalid Xcursor signature");int header=b.getInt();b.getInt();int count=b.getInt();if(header<16||count<1||count>1024||(long)header+count*12>bytes.length)throw new IOException("Invalid cursor table");int best=-1,distance=Integer.MAX_VALUE;
  for(int i=0;i<count;i++){b.position(header+i*12);int type=b.getInt(),size=b.getInt(),offset=b.getInt();if(type==0xfffd0002&&Math.abs(size-desired)<distance){best=offset;distance=Math.abs(size-desired);}}
  if(best<0||(long)best+36>bytes.length)throw new IOException("No cursor frame");b.position(best);int chunk=b.getInt(),type=b.getInt();b.getInt();b.getInt();int w=b.getInt(),h=b.getInt(),x=b.getInt(),y=b.getInt();b.getInt();if(type!=0xfffd0002||chunk<36||w<1||h<1||w>256||h>256||x<0||x>=w||y<0||y>=h||(long)best+chunk+(long)w*h*4>bytes.length)throw new IOException("Invalid cursor image");b.position(best+chunk);BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);for(int row=0;row<h;row++)for(int col=0;col<w;col++){int pixel=b.getInt(),a=pixel>>>24,r=pixel>>16&255,g=pixel>>8&255,blue=pixel&255;if(a>0&&a<255){r=Math.min(255,r*255/a);g=Math.min(255,g*255/a);blue=Math.min(255,blue*255/a);}image.setRGB(col,row,a<<24|r<<16|g<<8|blue);}return new CursorBitmap(image,x,y);
 }
}
