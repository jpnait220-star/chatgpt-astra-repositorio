package com.duckswords.profiles;
import java.io.*;import java.nio.charset.StandardCharsets;import java.nio.file.*;import java.util.*;
/** Version-scoped storage. Migration copies originals and never overwrites a destination. */
public final class VersionStorage {
 private static final Properties META=new Properties();
 static{try(InputStream in=VersionStorage.class.getResourceAsStream("/assets/duckswords/storage.properties")){if(in==null)throw new IOException("Missing storage version");META.load(in);}catch(IOException ex){throw new ExceptionInInitializerError(ex);}}
 private static final Set<Path> READY=new HashSet<>();
 public static Path configFile(Path legacy){return prepare(legacy.getParent()).resolve("config.json");}
 public static Path profilesDir(Path legacy){return prepare(legacy.getParent().getParent()).resolve("profiles");}
 private static Path shared(){String app=System.getenv("APPDATA");return app!=null&&!app.isBlank()?Path.of(app,"DuckClientZ"):Path.of(System.getProperty("user.home","."),".duckclientz");}
 private static synchronized Path prepare(Path config){
  String version=META.getProperty("minecraft");if(version==null||!version.matches("[0-9]+\\.[0-9]+(?:\\.[0-9]+)?"))throw new IllegalStateException("Invalid storage version");
  Path root=config.toAbsolutePath().normalize().resolve("duckswords").resolve(version);if(READY.contains(root))return root;
  try{migrate(config,root,Boolean.parseBoolean(META.getProperty("sharedLegacy"))?shared():null);READY.add(root);return root;}catch(IOException ex){throw new UncheckedIOException("Falha ao migrar configuracoes para "+root,ex);}
 }
 public static void migrate(Path config,Path root,Path shared)throws IOException{
  Files.createDirectories(root.resolve("profiles"));Path marker=root.resolve("migration-v1.complete");if(Files.isRegularFile(marker,LinkOption.NOFOLLOW_LINKS))return;
  Path sourceConfig=config.resolve("duckswords.json"),sourceProfiles=config.resolve("duckswords/profiles");
  if(shared!=null&&Files.isRegularFile(shared.resolve("duckswords.json"),LinkOption.NOFOLLOW_LINKS))sourceConfig=shared.resolve("duckswords.json");
  if(shared!=null&&Files.isDirectory(shared.resolve("profiles"),LinkOption.NOFOLLOW_LINKS))sourceProfiles=shared.resolve("profiles");
  copy(sourceConfig,root.resolve("config.json"),root.resolve("migration-backup/config.json"));
  if(Files.isDirectory(sourceProfiles,LinkOption.NOFOLLOW_LINKS))try(var files=Files.list(sourceProfiles)){
   for(Path source:files.filter(p->Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS)).toList()){
    String name=source.getFileName().toString();if(!(name.endsWith(".json")||name.endsWith(".txt")||name.endsWith(".applied")||name.endsWith(".bak")))continue;
    copy(source,root.resolve("profiles").resolve(name),root.resolve("migration-backup/profiles").resolve(name));
   }
  }
  Files.writeString(marker,"Config e perfis copiados sem alterar os arquivos originais.\n",StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
 }
 private static void copy(Path from,Path to,Path backup)throws IOException{
  if(!Files.isRegularFile(from,LinkOption.NOFOLLOW_LINKS)||Files.exists(to,LinkOption.NOFOLLOW_LINKS))return;
  Files.createDirectories(backup.getParent());if(!Files.exists(backup,LinkOption.NOFOLLOW_LINKS))Files.copy(from,backup);
  Files.createDirectories(to.getParent());Path temp=Files.createTempFile(to.getParent(),"migration-",".tmp");
  try{Files.copy(from,temp,StandardCopyOption.REPLACE_EXISTING);if(!Files.exists(to,LinkOption.NOFOLLOW_LINKS))Files.move(temp,to);}finally{Files.deleteIfExists(temp);}
 }
}
