package com.duckswords.texturemaker;
import java.awt.image.BufferedImage;import java.util.*;
/** Pixel editing with bounded undo memory, independent from Minecraft's renderer. */
public final class PixelCanvas {
 private static final Map<PixelCanvas,Boolean> TRACKED=new WeakHashMap<>();private static final long HISTORY_LIMIT=16_777_216;private static long clock;private long changed;
 public final int width,height;private int[] pixels,before;private final Deque<int[]> undo=new ArrayDeque<>(),redo=new ArrayDeque<>();private int revision;
 public PixelCanvas(int w,int h){if(w<1||h<1||w>2048||h>2048)throw new IllegalArgumentException("Tamanho maximo: 2048 x 2048");width=w;height=h;pixels=new int[w*h];synchronized(TRACKED){TRACKED.put(this,Boolean.TRUE);}}
 public static PixelCanvas of(BufferedImage image){PixelCanvas c=new PixelCanvas(image.getWidth(),image.getHeight());image.getRGB(0,0,c.width,c.height,c.pixels,0,c.width);return c;}
 private PixelCanvas(int w,int h,int[] backing){width=w;height=h;pixels=backing;synchronized(TRACKED){TRACKED.put(this,Boolean.TRUE);}}
 public PixelCanvas copy(){return new PixelCanvas(width,height,pixels.clone());}
 public int revision(){return revision;}public int pixel(int x,int y){return pixels[y*width+x];}public int[] snapshot(){return pixels.clone();}
 public void begin(){if(before==null)before=pixels.clone();}
 public void end(){if(before==null)return;if(!Arrays.equals(before,pixels)){undo.addLast(before);redo.clear();trim(undo);}before=null;}
 private void trim(Deque<int[]> history){while(history.size()>32)history.removeFirst();synchronized(TRACKED){changed=++clock;long total=0;for(PixelCanvas canvas:TRACKED.keySet())total+=(long)(canvas.undo.size()+canvas.redo.size())*canvas.width*canvas.height*4;while(total>HISTORY_LIMIT){PixelCanvas oldest=null;for(PixelCanvas canvas:TRACKED.keySet())if(!canvas.undo.isEmpty()||!canvas.redo.isEmpty())if(oldest==null||canvas.changed<oldest.changed)oldest=canvas;if(oldest==null)break;if(!oldest.redo.isEmpty())oldest.redo.removeFirst();else oldest.undo.removeFirst();total-=(long)oldest.width*oldest.height*4;}}}
 public void paint(int x,int y,int color,int size,boolean mirror){if(x<0||y<0||x>=width||y>=height)return;begin();for(int dy=0;dy<size;dy++)for(int dx=0;dx<size;dx++){int xx=x+dx,yy=y+dy;if(xx<width&&yy<height){pixels[yy*width+xx]=color;if(mirror)pixels[yy*width+width-1-xx]=color;}}revision++;}
 public void line(int x0,int y0,int x1,int y1,int color,int size,boolean mirror){int dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1,error=dx+dy;for(int guard=0;guard<4096;guard++){paint(x0,y0,color,size,mirror);if(x0==x1&&y0==y1)break;int twice=error*2;if(twice>=dy){error+=dy;x0+=sx;}if(twice<=dx){error+=dx;y0+=sy;}}}
 public void fill(int x,int y,int color){if(x<0||y<0||x>=width||y>=height)return;int old=pixel(x,y);if(old==color)return;begin();int[] queue=new int[pixels.length];int first=0,last=0,start=y*width+x;pixels[start]=color;queue[last++]=start;while(first<last){int p=queue[first++],px=p%width,py=p/width;if(px>0&&pixels[p-1]==old){pixels[p-1]=color;queue[last++]=p-1;}if(px+1<width&&pixels[p+1]==old){pixels[p+1]=color;queue[last++]=p+1;}if(py>0&&pixels[p-width]==old){pixels[p-width]=color;queue[last++]=p-width;}if(py+1<height&&pixels[p+width]==old){pixels[p+width]=color;queue[last++]=p+width;}}revision++;end();}
 public void undo(){end();if(!undo.isEmpty()){redo.addLast(pixels);pixels=undo.removeLast();trim(redo);revision++;}}
 public void redo(){end();if(!redo.isEmpty()){undo.addLast(pixels);pixels=redo.removeLast();trim(undo);revision++;}}
 public void flip(boolean horizontal){begin();for(int y=0;y<height;y++)for(int x=0;x<width;x++){int xx=horizontal?width-1-x:x,yy=horizontal?y:height-1-y;if(y*width+x<yy*width+xx){int v=pixels[y*width+x];pixels[y*width+x]=pixels[yy*width+xx];pixels[yy*width+xx]=v;}}revision++;end();}
 public BufferedImage image(){BufferedImage out=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);out.setRGB(0,0,width,height,pixels,0,width);return out;}
}
