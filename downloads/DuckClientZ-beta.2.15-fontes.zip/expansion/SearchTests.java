import net.minecraft.*;import java.lang.reflect.*;
public class SearchTests{
 static void check(boolean yes){if(!yes)throw new AssertionError();}
 public static void main(String[] a)throws Exception{
 boolean modern=a[0].equals("1.21.11");Class<?> widget=Class.forName("com.duckswords.gui.SmallSearchField");var ctor=widget.getConstructors()[0];
 for(float scale:new float[]{.5f,.68f,.72f,1f,1.5f}){
  class_342 w=(class_342)ctor.newInstance(null,25,30,180,20,null,scale);class_332 ctx=new class_332();w.method_48579(ctx,0,0,0);
  check(Math.abs(ctx.capturedX-(25+8*scale))<.001);check(Math.abs(ctx.capturedY-(30+3*scale))<.001);ctx.capture(0,0);check(ctx.capturedX==0&&ctx.capturedY==0);
  if(modern){Class<?> click=Class.forName("net.minecraft.class_11909");Object input=click.getConstructors()[0].newInstance(25+8.0*scale,35.0,null);widget.getMethod("method_25348",click,boolean.class).invoke(w,input,false);}else widget.getMethod("method_25348",double.class,double.class).invoke(w,25+8.0*scale,35.0);
  check(Math.abs(w.clickedX-33)<.001);w.fail=true;try{w.method_48579(ctx,0,0,0);throw new AssertionError();}catch(IllegalStateException expected){}ctx.capture(0,0);check(ctx.capturedX==0&&ctx.capturedY==0);
 }System.out.println("PASS: search glyph alignment, inverse mouse mapping and matrix cleanup at 5 UI scales; actual generated subclass "+a[0]);
 }
}
