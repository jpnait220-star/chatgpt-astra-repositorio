package net.minecraft; public enum class_1304 {field_6169,field_6174,field_6172,field_6166}
