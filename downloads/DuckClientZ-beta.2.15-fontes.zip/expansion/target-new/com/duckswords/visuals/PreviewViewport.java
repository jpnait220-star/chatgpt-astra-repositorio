package com.duckswords.visuals;
import com.duckswords.gui.CosmeticsPreview;import net.minecraft.*;import org.joml.Matrix3x2fStack;
public final class PreviewViewport{
 public static void draw(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){
  Matrix3x2fStack pose=ctx.method_51448();float sx=pose.m00(),sy=pose.m11(),tx=pose.m20(),ty=pose.m21();
  int left=Math.round(x1*sx+tx),top=Math.round(y1*sy+ty),right=Math.round(x2*sx+tx),bottom=Math.round(y2*sy+ty),actual=Math.max(1,Math.round(size*Math.abs(sx)));
  pose.pushMatrix();try{pose.identity();CosmeticsPreview.renderNative(ctx,left,top,right,bottom,actual,player);}finally{pose.popMatrix();}
 }
}
