package com.duckswords.particles;
import net.minecraft.*;import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
public final class VisualParticleFactory implements class_707<class_2400>{
 private final FabricSpriteProvider sprites;private final int channel;
 public VisualParticleFactory(FabricSpriteProvider sprites,int channel){this.sprites=sprites;this.channel=channel;}
 public class_703 method_3090(class_2400 type,class_638 world,double x,double y,double z,double vx,double vy,double vz,class_5819 random){return ParticleBridge.create(sprites,world,x,y,z,vx,vy,vz,channel);}
}
