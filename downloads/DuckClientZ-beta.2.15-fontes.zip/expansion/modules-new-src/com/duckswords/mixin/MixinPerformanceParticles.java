package com.duckswords.mixin;
import com.duckswords.perf.GamePerformance;import net.minecraft.*;import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;
@Mixin(class_702.class)
public abstract class MixinPerformanceParticles{
 @Redirect(method="method_3055(Lnet/minecraft/class_2394;DDDDDD)Lnet/minecraft/class_703;",at=@At(value="INVOKE",target="Lnet/minecraft/class_707;method_3090(Lnet/minecraft/class_2394;Lnet/minecraft/class_638;DDDDDDLnet/minecraft/class_5819;)Lnet/minecraft/class_703;"),require=1,remap=false)
 private class_703 duck$particleBudget(class_707<class_2394> factory,class_2394 effect,class_638 world,double x,double y,double z,double vx,double vy,double vz,class_5819 random){return GamePerformance.particlesActive&&GamePerformance.dropParticle(x,y,z)?null:factory.method_3090(effect,world,x,y,z,vx,vy,vz,random);}
}
