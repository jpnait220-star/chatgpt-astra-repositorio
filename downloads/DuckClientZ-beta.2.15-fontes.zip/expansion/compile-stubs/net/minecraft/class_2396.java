package net.minecraft;public class class_2396<T extends class_2394>{}
