package net.minecraft;public class class_1059{}
