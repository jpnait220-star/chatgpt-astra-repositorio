package net.minecraft;public class class_2586 {public class_2338 method_11016(){return null;}}
