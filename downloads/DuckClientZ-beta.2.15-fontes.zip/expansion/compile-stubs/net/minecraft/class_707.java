package net.minecraft;public interface class_707<T extends class_2394>{class_703 method_3090(T type,class_638 world,double x,double y,double z,double vx,double vy,double vz);}
