package net.minecraft;public class class_897 {public boolean method_3933(class_1297 e,class_4604 f,double x,double y,double z){return true;}}
