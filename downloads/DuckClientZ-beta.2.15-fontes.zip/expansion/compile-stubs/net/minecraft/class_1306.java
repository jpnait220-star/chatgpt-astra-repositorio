package net.minecraft;public enum class_1306{field_6182,field_6183}
