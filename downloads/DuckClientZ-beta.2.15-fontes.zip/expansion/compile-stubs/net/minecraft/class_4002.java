package net.minecraft;public interface class_4002{}
