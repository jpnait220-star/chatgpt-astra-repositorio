package net.minecraft; public class class_702 {public class_703 method_3056(class_2394 t,double x,double y,double z,double vx,double vy,double vz){return null;}}
