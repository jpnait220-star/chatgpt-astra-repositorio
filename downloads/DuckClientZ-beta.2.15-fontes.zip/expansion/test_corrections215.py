from pathlib import Path
import subprocess,json,os
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');asm=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',str(B/'classes'),str(B/'ExtractResetText.java')],check=True)
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');out=B/'corrections215-runtime'/v;src=out/'src/net/minecraft';classes=out/'classes';src.mkdir(parents=True,exist_ok=True);classes.mkdir(exist_ok=True)
 for name in ['class_1113.java','class_1109.java','class_3414.java']:(src/name).write_text((Path('/workspace/duckclientz-1.21.11/repair/stubs/net/minecraft')/name).read_text())
 (src/'class_1935.java').write_text('package net.minecraft;public interface class_1935 {}')
 (src/'class_2338.java').write_text('package net.minecraft;public class class_2338 {public int x,y,z;public class_2338(int x,int y,int z){this.x=x;this.y=y;this.z=z;}public int method_10263(){return x;}public int method_10264(){return y;}public int method_10260(){return z;}}')
 (src/'class_2586.java').write_text('package net.minecraft;public class class_2586 {private final class_2338 p;public class_2586(class_2338 p){this.p=p;}public class_2338 method_11016(){return p;}}')
 cp=os.pathsep.join(map(str,[classes,r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),entry['jar'],T/'gson.jar',r.parent/'tools/joml.jar',T/'mixin.jar',T/'slf4j-api-2.0.9.jar',T/'slf4j-simple-2.0.9.jar',T/'fabric-loader-0.16.10.jar']))
 subprocess.run(['java','-cp',asm,'ExtractResetText',entry['jar'],str(classes)],check=True)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(classes),*map(str,src.glob('*.java')),str(B/'Corrections215Tests.java'),str(B/'CleanDefaultTests.java'),str(B/'settings-test-src/net/minecraft/class_1304.java'),'/workspace/duckclientz/repair/teststubs/net/fabricmc/loader/api/FabricLoader.java'],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'Corrections215Tests',v],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'CleanDefaultTests',v],check=True)
