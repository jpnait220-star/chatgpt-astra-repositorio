import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class SoundsPatch implements Opcodes{
 public static void main(String[] a)throws Exception{Path out=Path.of(a[1]);String H="com/duckswords/audio/ModernSounds";try(ZipFile z=new ZipFile(a[0])){for(String owner:List.of("com/duckswords/util/UiSound","com/duckswords/modules/HitSound")){
 ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(owner+".class"))).accept(c,0);int arrays=0,hooks=0;
 for(MethodNode m:c.methods){if(m.name.equals("<clinit>"))for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode f&&f.getOpcode()==PUTSTATIC&&f.desc.equals("[Ljava/lang/String;")){m.instructions.insertBefore(n,new MethodInsnNode(INVOKESTATIC,H,"modes","([Ljava/lang/String;)[Ljava/lang/String;",false));arrays++;}
 if(m.name.equals("customIdOf")){InsnList i=new InsnList();LabelNode keep=new LabelNode();i.add(new VarInsnNode(ALOAD,0));i.add(new MethodInsnNode(INVOKESTATIC,H,"id","(Ljava/lang/String;)Ljava/lang/String;",false));i.add(new InsnNode(DUP));i.add(new JumpInsnNode(IFNULL,keep));i.add(new InsnNode(ARETURN));i.add(keep);i.add(new FrameNode(F_SAME1,0,null,1,new Object[]{"java/lang/String"}));i.add(new InsnNode(POP));m.instructions.insert(i);hooks++;}
 if(m.name.equals("onLocalHit")){InsnList i=new InsnList();LabelNode keep=new LabelNode();i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new MethodInsnNode(INVOKESTATIC,H,"hit","(Lnet/minecraft/class_1309;Lnet/minecraft/class_1297;)Z",false));i.add(new JumpInsnNode(IFEQ,keep));i.add(new InsnNode(RETURN));i.add(keep);i.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(i);hooks++;}
 }
 if(arrays<1||hooks!=1)throw new IllegalStateException("Sound hooks "+owner+" "+arrays+"/"+hooks);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path file=out.resolve(owner+".class");Files.createDirectories(file.getParent());Files.write(file,w.toByteArray());
 }}}
}
