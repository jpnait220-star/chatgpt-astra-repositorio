from pathlib import Path
import subprocess,os,json
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');out=B/'settings-runtime'/v;out.mkdir(parents=True,exist_ok=True)
 cp=os.pathsep.join(map(str,[out,r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),entry['jar'],T/'gson.jar',r.parent/'tools/joml.jar',T/'mixin.jar',B/'tools'/f'fabric-particles-{v}.jar',T/'fabric-loader-0.16.10.jar',B/'tools/lwjgl.jar',B/'tools/lwjgl-glfw.jar']))
 sources=[*(B/'settings-test-src').rglob('*.java'),B/'ExpandedSettingsTests.java']
 if new:sources.append(B/'compile-stubs-new/net/minecraft/class_4587.java')
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,sources)],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'ExpandedSettingsTests',v],check=True)
