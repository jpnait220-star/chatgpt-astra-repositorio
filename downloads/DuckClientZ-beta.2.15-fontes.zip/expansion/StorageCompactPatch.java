import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class StorageCompactPatch implements Opcodes{
 static void body(MethodNode m,String owner,String name){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,owner,name,m.desc,false));m.instructions.add(new InsnNode(ARETURN));}
 public static void main(String[] a)throws Exception{Path out=Path.of(a[1]);try(ZipFile z=new ZipFile(a[0])){for(String name:List.of("com/duckswords/Config","com/duckswords/profiles/ProfileManager")){
 ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,0);boolean native11=a[2].equals("1.21.11");
 for(MethodNode m:c.methods){
  if(name.endsWith("/Config")&&m.name.equals("file")){
   if(native11){for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==ARETURN)m.instructions.insertBefore(n,new MethodInsnNode(INVOKESTATIC,"com/duckswords/profiles/VersionStorage","configFile","(Ljava/nio/file/Path;)Ljava/nio/file/Path;",false));
   }else for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals("com/duckswords/DuckSharedPaths")&&call.name.equals("configFile"))call.owner="com/duckswords/profiles/VersionStorage";
  }
  if(name.endsWith("/ProfileManager")&&m.name.equals("<clinit>")){
   if(native11){for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode f&&f.getOpcode()==PUTSTATIC&&f.name.equals("DIRECTORY"))m.instructions.insertBefore(n,new MethodInsnNode(INVOKESTATIC,"com/duckswords/profiles/VersionStorage","profilesDir","(Ljava/nio/file/Path;)Ljava/nio/file/Path;",false));
   }else for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals("com/duckswords/DuckSharedPaths")&&call.name.equals("profilesDir"))call.owner="com/duckswords/profiles/VersionStorage";
  }
  if(name.endsWith("/ProfileManager")&&m.name.equals("encode"))body(m,"com/duckswords/profiles/CompactProfileCode","encode");
  if(name.endsWith("/ProfileManager")&&m.name.equals("decode")){m.name="duck$decodeLegacy";for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals(name)&&call.name.equals("defaultProfileConfig")){call.owner="com/duckswords/profiles/CompactProfileCode";call.name="legacyDefault";}}
 }
 if(name.endsWith("/ProfileManager")){
  MethodNode m=new MethodNode(ACC_PRIVATE|ACC_STATIC,"decode","(Ljava/lang/String;)Ljava/lang/String;",null,new String[]{"java/io/IOException"});LabelNode legacy=new LabelNode();m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/profiles/CompactProfileCode","accepts","(Ljava/lang/String;)Z",false));m.instructions.add(new JumpInsnNode(IFEQ,legacy));m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/profiles/CompactProfileCode","decode",m.desc,false));m.instructions.add(new InsnNode(ARETURN));m.instructions.add(legacy);m.instructions.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,c.name,"duck$decodeLegacy",m.desc,false));m.instructions.add(new InsnNode(ARETURN));c.methods.add(m);
 }
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=out.resolve(name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }} }
}
