from pathlib import Path
import subprocess,json,os
B=Path(__file__).parent
fixtures={
'net/minecraft/class_437.java':'public class class_437 {}',
'net/minecraft/class_310.java':'public class class_310 {static final class_310 INSTANCE=new class_310();public class_437 field_1755;public static class_310 method_1551(){return INSTANCE;}public void method_1507(class_437 s){field_1755=s;}}',
'net/minecraft/class_332.java':'''public class class_332 {public int count;public int[] clip;public void method_25294(int x,int y,int x2,int y2,int color){if(x2<x||y2<y)throw new AssertionError("inverted rect");count++;}public void method_44379(int x,int y,int x2,int y2){if(clip!=null)throw new AssertionError("nested test clip");clip=new int[]{x,y,x2,y2};}public void method_44380(){if(clip==null)throw new AssertionError("clip stack");clip=null;}}''',
'com/duckswords/theme/HudText.java':'public class HudText {public static void draw(net.minecraft.class_332 c,String s,int x,int y,int color){}public static void draw(net.minecraft.class_332 c,String s,float x,float y,int color){}}',
'com/duckswords/gui/DuckScreen.java':'''public class DuckScreen extends net.minecraft.class_437 {public static int width=640,height=360;protected DuckScreen(String title){}protected void method_25426(){}protected int uiWidth(){return width;}protected int uiHeight(){return height;}protected int unX(double x){return (int)x;}protected int unY(double y){return (int)y;}protected int reX(int x){return x;}protected int reY(int y){return y;}protected void pushScale(net.minecraft.class_332 c){}protected void popScale(net.minecraft.class_332 c){}protected static boolean inside(int x,int y,int a,int b,int w,int h){return x>=a&&y>=b&&x<a+w&&y<b+h;}}''',
'com/duckswords/texturemaker/EditorKeys.java':'public class EditorKeys {public static int modifiers(){return 0;}}',
'net/minecraft/class_11909.java':'public record class_11909(double comp_4798,double comp_4799,int button){public int method_74245(){return button;}}',
'net/minecraft/class_11908.java':'public record class_11908(int comp_4795){}',
'net/minecraft/class_11905.java':'public record class_11905(int comp_4793){}'
}
test='''import com.duckswords.gui.*;import com.duckswords.texturemaker.*;import net.minecraft.*;import java.lang.reflect.*;
public class EditorUITests {static int checks;static void check(boolean b){if(!b)throw new AssertionError("UI check "+checks);checks++;}static int number(Object s,String n)throws Exception{Field f=s.getClass().getDeclaredField(n);f.setAccessible(true);return f.getInt(s);}static Object field(Object s,String n)throws Exception{Field f=s.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(s);}public static void main(String[] args)throws Exception{
 for(int[] size:new int[][]{{320,180},{427,240},{640,360},{960,540}}){DuckScreen.width=size[0];DuckScreen.height=size[1];TextureMakerScreen screen=new TextureMakerScreen(null);class_332 ctx=new class_332();screen.method_25394(ctx,0,0,0);check(ctx.clip==null);int x=number(screen,"canvasX"),y=number(screen,"canvasY"),n=number(screen,"canvasSize"),right=number(screen,"right");check(x>=0&&x+n<=right&&y+n<size[1]-20);check(ctx.count<4000);screen.click(x+n/2.,y+n/2.,0);screen.release();PixelCanvas canvas=(PixelCanvas)field(screen,"canvas");check(canvas.pixel(8,8)!=0);canvas.undo();check(canvas.pixel(8,8)==0);canvas.redo();check(canvas.pixel(8,8)!=0);
 screen.scroll(right+2,100,-10000);screen.method_25394(ctx,0,0,0);check(ctx.clip==null);check(number(screen,"toolsScroll")<=number(screen,"toolsMaximum"));screen.scroll(right+2,100,10000);screen.method_25394(ctx,0,0,0);check(number(screen,"toolsScroll")==0);screen.click(number(screen,"left")+8,number(screen,"top")+48,0);check(screen.character('s'));check(screen.character('w'));check(field(screen,"query").equals("sw"));screen.key(259,0);check(field(screen,"query").equals("s"));
 if(args[0].equals("1.21.11")){screen.method_25400(new class_11905('o'));check(field(screen,"query").equals("so"));screen.method_25404(new class_11908(259));check(field(screen,"query").equals("s"));}
 }
 System.out.println("PASS: "+checks+" editor UI checks: four window sizes, bounded rectangles/scissor cleanup, paint/undo, sidebar scrolling, resource search and version input events "+args[0]);}}
'''
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 root=B/'editor-ui-runtime'/v;src=root/'src';out=root/'classes';out.mkdir(parents=True,exist_ok=True)
 for file,body in fixtures.items():
  p=src/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+str(Path(file).parent).replace('/','.')+';'+body)
 body=test
 if v!='1.21.11':body=body[:body.index(' if(args[0].equals("1.21.11"))')]+body[body.index('\n }\n System.out.println'):]
 (src/'EditorUITests.java').write_text(body)
 cp=os.pathsep.join([str(out),entry['jar'],'/workspace/duckclientz/tools/gson.jar'])
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,src.rglob('*.java'))],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'EditorUITests',v],check=True)
