from pathlib import Path
import subprocess,os
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 modern=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11' if modern else '/workspace/duckclientz');t=r/'tools';stubs=r/'repair/stubclasses';test=B/('test-new' if modern else 'test-old');out=B/('testclasses-new' if modern else 'testclasses-old')
 cp=os.pathsep.join(str(p) for p in [out,stubs,r/'repair/teststubclasses',B/'patched'/v,B/('helpers-new' if modern else 'helpers-old'),t/'joml.jar'])
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',cp,'-d',str(out),*[str(p) for p in test.rglob('*.java')],str(B/'SearchTests.java')],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'SearchTests',v],check=True)
