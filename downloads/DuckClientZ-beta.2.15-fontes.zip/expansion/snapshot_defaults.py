from pathlib import Path
import subprocess,os,json
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v in ['1.21.4','1.21.11']:
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');out=B/('settings-tests-new' if new else 'settings-tests');out.mkdir(exist_ok=True)
 cp=os.pathsep.join(map(str,[out,r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),json.loads((B/'build-report.json').read_text())[v]['jar'],T/'gson.jar',r.parent/'tools/joml.jar',T/'mixin.jar',B/'tools'/f'fabric-particles-{v}.jar',T/'fabric-loader-0.16.10.jar',B/'tools/lwjgl.jar',B/'tools/lwjgl-glfw.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,(B/'settings-test-src').rglob('*.java')),str(B/'DefaultsSnapshot.java')],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'DefaultsSnapshot',str(B/f'expanded-settings-{v}.json')],check=True)
