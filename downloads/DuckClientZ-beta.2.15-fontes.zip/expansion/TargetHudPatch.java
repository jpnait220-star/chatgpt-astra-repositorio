import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class TargetHudPatch implements Opcodes{
 public static void main(String[] a)throws Exception{Path out=Path.of(a[1]);String owner="com/duckswords/modules/TargetHud",H="com/duckswords/visuals/ModernTargetStyle";try(ZipFile z=new ZipFile(a[0])){ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(owner+".class"))).accept(c,0);int changes=0;
 for(MethodNode m:c.methods){
  if(m.name.equals("<init>"))for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(new MethodInsnNode(INVOKESTATIC,H,"attach","(Lcom/duckswords/module/Module;)V",false));m.instructions.insertBefore(n,i);changes++;}
  if(m.name.equals("onHudRender")){for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals("net/minecraft/class_332")&&call.name.equals("method_25294")&&call.desc.equals("(IIIII)V")){m.instructions.insertBefore(call,new VarInsnNode(ALOAD,0));call.setOpcode(INVOKESTATIC);call.owner=H;call.name="background";call.desc="(Lnet/minecraft/class_332;IIIIILcom/duckswords/module/Module;)V";call.itf=false;changes++;break;}}
  if(m.name.equals("drawRoundedBar")){InsnList i=new InsnList();LabelNode keep=new LabelNode();i.add(new VarInsnNode(ALOAD,0));for(int j=1;j<=6;j++)i.add(new VarInsnNode(ILOAD,j));i.add(new MethodInsnNode(INVOKESTATIC,H,"bar","(Lnet/minecraft/class_332;IIIIII)Z",false));i.add(new JumpInsnNode(IFEQ,keep));i.add(new InsnNode(RETURN));i.add(keep);i.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(i);changes++;}
 }
 if(changes!=3)throw new IllegalStateException("HUD style hooks "+changes);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path file=out.resolve(owner+".class");Files.createDirectories(file.getParent());Files.write(file,w.toByteArray());}}
}
