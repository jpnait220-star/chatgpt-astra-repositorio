from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json,hashlib,os,shutil
RELEASE=os.environ.get('DUCK_RELEASE','1.5.28-beta.2.15')
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');OUT=B/'dist';OUT.mkdir(exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True)
cp=os.pathsep.join(str(p) for p in [T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar'])
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',T/'gson.jar','-d',B/'classes',*list((B/'src').rglob('*.java')))
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',B/'classes',*[p for p in B.glob('*.java') if p.name.endswith('Patch.java') or p.name=='ClearOldCameraHooks.java'])
run('java','-cp',str(B/'classes')+os.pathsep+cp,'SpriteAssetsPatch',B/'resources/assets/duckswords/textures/particle/visual',B/'prepared-assets',Path('/workspace/duckclientz/dist-fixes9/DuckClientZ-1.21.4-1.5.28-beta.2.13-fixes.9-experimental.jar'))
run('java','-cp',str(B/'classes')+os.pathsep+cp,'IconAssetsPatch',B/'prepared-icons',T/'minecraft-1.20.1-client',Path('/workspace/duckclientz/dist-fixes9/DuckClientZ-1.21.4-1.5.28-beta.2.13-fixes.9-experimental.jar'))
run('python',B/'generate_hooks.py')
run('python',B/'generate_dressing.py')
selected=os.environ.get('DUCK_VERSIONS','1.20.1,1.21.1,1.21.4,1.21.11').split(',')
report=json.loads((B/'build-report.json').read_text()) if (B/'build-report.json').exists() else {}
for v in selected:
 if v not in ('1.20.1','1.21.1','1.21.4','1.21.11'):raise ValueError(v)
 source=Path('/workspace/duckclientz-1.21.11/dist/DuckClientZ-1.21.11-1.5.28-opt.2-experimental.jar') if v=='1.21.11' else Path(f'/workspace/duckclientz/dist-fixes9/DuckClientZ-{v}-1.5.28-beta.2.13-fixes.9-experimental.jar')
 helper=B/('gui-new' if v=='1.21.11' else 'gui-old');helperout=B/('helpers-new' if v=='1.21.11' else 'helpers-old')
 stubs=Path('/workspace/duckclientz-1.21.11/repair/stubclasses') if v=='1.21.11' else Path('/workspace/duckclientz/repair/stubclasses')
 joml=Path('/workspace/duckclientz-1.21.11/tools/joml.jar') if v=='1.21.11' else T/'joml.jar'
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',str(stubs)+os.pathsep+str(joml),'-d',helperout,*list(helper.rglob('*.java')))
 modulesout=B/('modules-new' if v=='1.21.11' else 'modules-old')
 modcp=os.pathsep.join(str(p) for p in [B/'classes',T/'gson.jar',B/('compile-stubclasses-new' if v=='1.21.11' else 'compile-stubclasses-old'),stubs,joml,source,B/'tools/lwjgl.jar',B/'tools/lwjgl-glfw.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar',B/'tools'/f'fabric-particles-{v}.jar'])
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',modcp,'-d',B/('compile-stubclasses-new' if v=='1.21.11' else 'compile-stubclasses-old'),*list((B/'compile-stubs').rglob('*.java')))
 if v=='1.21.11':run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',modcp,'-d',B/'compile-stubclasses-new',*list((B/'compile-stubs-new').rglob('*.java')))
 module_sources=list((B/'modules-src').rglob('*.java'))
 if v=='1.21.11':module_sources=[p for p in module_sources if p.name not in ('VisualParticleFactory.java','MixinPerformanceParticles.java','FreeLookControl.java')]+list((B/'modules-new-src').rglob('*.java'))
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',modcp,'-d',modulesout,*module_sources,*list((B/('camera-double' if v=='1.20.1' else 'camera-native' if v=='1.21.11' else 'camera-float')).rglob('*.java')))
 targetout=B/('target-classes-new' if v=='1.21.11' else 'target-classes-old')
 targetsrc=B/('target-new' if v=='1.21.11' else 'target-old')
 targetcp=os.pathsep.join(str(p) for p in [modulesout,source,stubs,joml,B/('compile-stubclasses-new' if v=='1.21.11' else 'compile-stubclasses-old')])
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',targetcp,'-d',targetout,*list(targetsrc.rglob('*.java')))
 patch=B/'patched'/v
 if patch.exists():shutil.rmtree(patch)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'StorageCompactPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'SearchWidgetPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'SettingsUiPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'UiCorrectionsPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'DefaultPolicyPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'SharpnessPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'FireworkDelayPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'FireworkSessionPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'ClearOldCameraHooks',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'CameraStatePatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'ModelPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'CosmeticsPatch',source,patch,v,modulesout)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'ExtraFeaturesPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'SoundsPatch',source,patch,v)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'ParticlesPatch',source,patch,v,modulesout)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'EditorInputPatch',source,patch,v,modulesout)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'DressingPropsPatch',source,patch,B/'native'/v/'dressing.tsv',modulesout)
 # TargetHUD retains its single original layout; mode selector removed.
 native=Path('/workspace/duckclientz-1.21.11/tools/minecraft-client') if v=='1.21.11' else T/f'minecraft-{v}-client'
 mapping=Path('/workspace/duckclientz-1.21.11/tools/intermediary.tiny') if v=='1.21.11' else T/f'intermediary-{v}.tiny'
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'TargetRenderPatch',source,patch,v,modulesout,native,mapping)
 run('java','-cp',str(B/'classes')+os.pathsep+cp,'NativeHooksPatch',source,patch,B/'native'/v/'hooks.tsv',native)
 with ZipFile(source) as z:data={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
 changed={}
 for p in (B/'classes/com').rglob('*.class'):changed[p.relative_to(B/'classes').as_posix()]=p.read_bytes()
 for p in targetout.rglob('*.class'):changed[p.relative_to(targetout).as_posix()]=p.read_bytes()
 for p in modulesout.rglob('*.class'):changed[p.relative_to(modulesout).as_posix()]=p.read_bytes()
 for p in helperout.rglob('*.class'):changed[p.relative_to(helperout).as_posix()]=p.read_bytes()
 for p in patch.rglob('*.class'):changed[p.relative_to(patch).as_posix()]=p.read_bytes()
 for p in (B/'resources').rglob('*'):
  if p.is_file() and p.name not in ('storage.properties','modern-sounds.json'):changed[p.relative_to(B/'resources').as_posix()]=p.read_bytes()
 for p in (B/'prepared-assets').glob('*.png'):changed['assets/duckswords/textures/particle/visual/'+p.name]=p.read_bytes()
 for p in (B/'prepared-icons').glob('*.png'):changed['assets/duckswords/textures/gui/icons/'+p.name]=p.read_bytes()
 default=json.loads(data['assets/duckswords/default-profile.json']);default['config']=(B/'resources/assets/duckswords/profiles/v3'/('l.json' if v=='1.21.11' else 'k.json')).read_text();changed['assets/duckswords/default-profile.json']=(json.dumps(default,ensure_ascii=False,indent=2)+'\n').encode()
 sounds=json.loads(data['assets/duckswords/sounds.json']);sounds.update(json.loads((B/'resources/assets/duckswords/modern-sounds.json').read_text()));changed['assets/duckswords/sounds.json']=(json.dumps(sounds,indent=2)+'\n').encode()
 mixes={'required':True,'package':'com.duckswords.mixin','compatibilityLevel':'JAVA_17' if v=='1.20.1' else 'JAVA_21','client':['MixinPerformanceEntities','MixinPerformanceParticles','MixinFixedFreeLookCamera','MixinFixedFreeLookInput','MixinFixedFreeLookScroll'],'injectors':{'defaultRequire':1}}
 mixes['client'].extend((patch/'client-draw-mixins.txt').read_text().splitlines())
 changed['duckclientz-expansion.mixins.json']=(json.dumps(mixes,indent=2)+'\n').encode()
 changed['assets/duckswords/storage.properties']=f'minecraft={v}\nsharedLegacy={str(v!="1.21.11").lower()}\n'.encode()
 meta=json.loads(data['fabric.mod.json']);meta['version']=RELEASE;meta['mixins'].append('duckclientz-expansion.mixins.json');meta.setdefault('entrypoints',{}).setdefault('main',[]).append('com.duckswords.particles.VisualParticles');meta['entrypoints'].setdefault('client',[]).append('com.duckswords.particles.VisualParticles')
 meta['description']='DuckClientZ combina HUD, cosméticos, animações e efeitos personalizáveis com controles de desempenho do lado do cliente. Crie resource packs e pinte texturas no Texture Maker, sem editar arquivos manualmente. Perfis separados por versão, compartilhamento por código compacto e opções de desenho complementares ao Sodium.'
 for mixfile in meta['mixins']:
  if mixfile=='duckclientz-expansion.mixins.json':continue
  doc=json.loads(changed.get(mixfile,data[mixfile]));doc['client']=[name for name in doc.get('client',[]) if name!='MixinRecordingCamera'];changed[mixfile]=(json.dumps(doc,indent=2)+'\n').encode()
 changed['fabric.mod.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode();jar=OUT/f'DuckClientZ-{v}-{RELEASE}.jar'
 with ZipFile(jar,'w',ZIP_DEFLATED) as z:
  for name,content in sorted((data|changed).items()):z.writestr(name,content)
 with ZipFile(jar) as z:assert z.testzip() is None
 report[v]={'jar':str(jar),'sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'changed':sorted(changed)}
 print(v,jar.stat().st_size)
(B/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
