from pathlib import Path
import json,subprocess,os
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');jar=lambda p:str(T/p)
def run(*args):subprocess.run(list(map(str,args)),check=True)
asm=os.pathsep.join([str(B/'classes'),jar('asm-9.7.1.jar'),jar('asm-tree-9.7.1.jar')])
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',B/'classes',B/'ExtractSafetyProbes.java')
common={
'net/minecraft/class_310.java':'public class class_310 {static final class_310 INSTANCE=new class_310();public class_746 field_1724;public class_437 field_1755;public static class_310 method_1551(){return INSTANCE;}}',
'net/minecraft/class_746.java':'public class class_746 {}',
'net/minecraft/class_437.java':'public class class_437 {}',
'net/minecraft/class_1937.java':'public class class_1937 {}',
'net/minecraft/class_1887.java':'public class class_1887 {}',
'net/minecraft/class_5321.java':'public class class_5321 {}',
'net/minecraft/class_6880.java':'public interface class_6880 {boolean method_40225(class_5321 key);}',
'net/minecraft/Entry.java':'public record Entry(class_5321 key) implements class_6880 {public boolean method_40225(class_5321 k){return key==k;}}',
'net/minecraft/class_9304.java':'public class class_9304 {public java.util.Map<class_6880,Integer> entries=new java.util.LinkedHashMap<>();public java.util.Set<class_6880> method_57534(){return entries.keySet();}public int method_57536(class_6880 key){return entries.getOrDefault(key,0);}}',
'net/minecraft/class_1799.java':'public class class_1799 {public int level;public class_9304 component=new class_9304();public class_1799(int n){level=n;component.entries.put(new Entry(Keys.SHARP),n);}public class_9304 method_58657(){return component;}}',
'net/minecraft/Keys.java':'public class Keys {public static final class_5321 SHARP=new class_5321();}',
'net/minecraft/class_1890.java':'public class class_1890 {public static int method_8225(class_1887 enchant,class_1799 stack){return stack.level;}}',
'com/duckswords/module/Module.java':'public class Module {}',
'com/duckswords/module/ModuleManager.java':'public class ModuleManager {public com.duckswords.modules.RecordingCamera camera=new com.duckswords.modules.RecordingCamera();public <T extends Module>T get(Class<T> type){return type.cast(camera);}}',
'com/duckswords/DucksWordsClient.java':'public class DucksWordsClient {public static final com.duckswords.module.ModuleManager MODULES=new com.duckswords.module.ModuleManager();}',
'com/duckswords/modules/RecordingCamera.java':'public class RecordingCamera extends com.duckswords.module.Module {public boolean enabled,active;public double x,y;private float distance=4;public final com.duckswords.setting.BooleanSetting lockCamera=new com.duckswords.setting.BooleanSetting("Lock","",true);public boolean isEnabled(){return enabled;}public boolean isCameraActive(){return active;}public void rotate(double a,double b){x=a;y=b;}public void zoom(double n){distance=Math.max(.5f,Math.min(10f,distance-(float)n*.5f));}public float cameraDistance(){return distance;}}'
}
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 root=B/'safety-runtime'/v;src=root/'src';out=root/'classes';out.mkdir(parents=True,exist_ok=True)
 sources=common|{'net/minecraft/class_1893.java':'public class class_1893 {public static final '+('class_1887 field_9118=new class_1887();' if v=='1.20.1' else 'class_5321 field_9118=Keys.SHARP;')+'}'}
 for file,body in sources.items():
  path=src/file;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('package '+str(Path(file).parent).replace('/','.')+';'+body+'\n')
 run('java','-cp',asm,'ExtractSafetyProbes',entry['jar'],out,v)
 cp=os.pathsep.join([str(out),entry['jar']])
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',out,*src.rglob('*.java'),B/'safety-tests/SafetyTests.java')
 run('java','-Xverify:all','-cp',cp,'SafetyTests',v)
