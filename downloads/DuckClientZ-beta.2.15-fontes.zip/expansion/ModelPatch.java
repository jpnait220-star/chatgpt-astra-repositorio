import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class ModelPatch implements Opcodes{
 public static void main(String[] a)throws Exception{Path out=Path.of(a[1]);try(ZipFile z=new ZipFile(a[0])){for(String target:List.of("ViewModel","Swing")){
 String name="com/duckswords/modules/"+target;ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,0);int methods=0,constructors=0,arrays=0;
 for(MethodNode m:c.methods){if(m.name.equals("<init>"))for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/visuals/ModernDuck",target.equals("Swing")?"attachSwing":"attachModel","(Lcom/duckswords/module/Module;)V",false));m.instructions.insertBefore(n,i);constructors++;}
 if(target.equals("Swing")&&m.name.equals("<clinit>"))for(AbstractInsnNode n:m.instructions.toArray()){
  if(n instanceof TypeInsnNode t&&t.getOpcode()==ANEWARRAY&&t.desc.equals("java/lang/String")&&n.getPrevious().getOpcode()==ICONST_5){m.instructions.set(n.getPrevious(),new IntInsnNode(BIPUSH,6));arrays++;}
  if(n instanceof FieldInsnNode f&&f.getOpcode()==PUTSTATIC&&f.name.equals("MODES")){InsnList i=new InsnList();i.add(new InsnNode(DUP));i.add(new InsnNode(ICONST_5));i.add(new LdcInsnNode("ModernDuck"));i.add(new InsnNode(AASTORE));m.instructions.insertBefore(n,i);}
 }
 boolean swing=target.equals("Swing")&&m.name.equals("apply")&&m.desc.equals(a[2].equals("1.21.11")?"(Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;F)V":"(Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;FZ)V");
 boolean pose=target.equals("ViewModel")&&m.name.equals("apply"),scale=target.equals("ViewModel")&&m.name.equals("applyItemScale");
 if(swing||pose||scale){InsnList i=new InsnList();LabelNode keep=new LabelNode();i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new VarInsnNode(ALOAD,2));
  if(swing){i.add(new VarInsnNode(FLOAD,3));i.add(new InsnNode(a[2].equals("1.21.1")||a[2].equals("1.21.11")?ICONST_0:ICONST_1));}
  String desc=swing?"(Lcom/duckswords/module/Module;Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;FZ)Z":"(Lcom/duckswords/module/Module;Lnet/minecraft/class_4587;Lnet/minecraft/class_1268;)Z";
  i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/visuals/ModernDuck",swing?"swing":pose?"pose":"scale",desc,false));i.add(new JumpInsnNode(IFEQ,keep));i.add(new InsnNode(RETURN));i.add(keep);i.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(i);methods++;
 }
 }
 if(constructors!=1||methods!=(target.equals("Swing")?1:2)||target.equals("Swing")&&arrays!=1)throw new IllegalStateException(target+" hooks "+constructors+"/"+methods+"/"+arrays);
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path file=out.resolve(name+".class");Files.createDirectories(file.getParent());Files.write(file,w.toByteArray());
 }
 String duration="com/duckswords/mixin/MixinSwingDuration";ClassNode d=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(duration+".class"))).accept(d,0);int count=0;
 for(MethodNode m:d.methods)if(m.desc.equals("(Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;)V")){InsnList i=new InsnList();LabelNode keep=new LabelNode();i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/visuals/ModernDuck","swingDuration","(Ljava/lang/Object;Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;)Z",false));i.add(new JumpInsnNode(IFEQ,keep));i.add(new InsnNode(RETURN));i.add(keep);i.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(i);count++;}
 if(count!=1)throw new IllegalStateException("Duration hook count "+count);ClassWriter dw=new ClassWriter(ClassWriter.COMPUTE_MAXS);d.accept(dw);Path df=out.resolve(duration+".class");Files.createDirectories(df.getParent());Files.write(df,dw.toByteArray());
 }}
}
