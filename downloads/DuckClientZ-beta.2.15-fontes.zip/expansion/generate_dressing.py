from generate_hooks import catalog
from pathlib import Path
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 m,f,classes,tc=catalog(v);rows=[]
 def method(key,cls,name,desc):
  found=[x for x in m(cls,name) if x[2]==desc]
  if len(found)!=1:raise AssertionError((v,key,found,m(cls,name)))
  rows.append([key,*found[0][:3]])
 method('armor','net.minecraft.world.entity.decoration.ArmorStand','<init>','(Lnet/minecraft/class_1937;DDD)V')
 method('equip','net.minecraft.world.entity.LivingEntity','setItemSlot','(Lnet/minecraft/class_1304;Lnet/minecraft/class_1799;)V')
 method('silent','net.minecraft.world.entity.Entity','setSilent','(Z)V')
 method('arms','net.minecraft.world.entity.decoration.ArmorStand','setShowArms','(Z)V')
 method('stack','net.minecraft.world.item.ItemStack','<init>','(Lnet/minecraft/class_1935;)V')
 method('itemdraw','net.minecraft.client.gui.GuiGraphics','renderItem','(Lnet/minecraft/class_1799;II)V')
 for slot,item in [('HEAD','HELMET'),('CHEST','CHESTPLATE'),('LEGS','LEGGINGS'),('FEET','BOOTS')]:
  rows.append(['slot_'+slot,*f('net.minecraft.world.entity.EquipmentSlot',slot)])
  for mat in ['IRON','DIAMOND']:rows.append([mat+'_'+slot,*f('net.minecraft.world.item.Items',mat+'_'+item)])
 rows.append(['book',*f('net.minecraft.world.item.Items','LECTERN')]);p=B/'native'/v/'dressing.tsv';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('\n'.join('\t'.join(row) for row in rows)+'\n')
