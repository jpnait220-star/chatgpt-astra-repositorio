package net.minecraft; public interface class_9779 {float method_60637(boolean ignored);}
