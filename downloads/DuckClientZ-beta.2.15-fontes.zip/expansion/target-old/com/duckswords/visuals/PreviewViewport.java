package com.duckswords.visuals;
import com.duckswords.gui.CosmeticsPreview;import net.minecraft.*;import org.joml.Matrix4f;
public final class PreviewViewport{
 public static void draw(class_332 ctx,int x1,int y1,int x2,int y2,int size,class_1309 player){
  class_4587 stack=ctx.method_51448();Matrix4f pose=stack.method_23760().method_23761();float sx=pose.m00(),sy=pose.m11(),tx=pose.m30(),ty=pose.m31();
  int left=Math.round(x1*sx+tx),top=Math.round(y1*sy+ty),right=Math.round(x2*sx+tx),bottom=Math.round(y2*sy+ty),actual=Math.max(1,Math.round(size*Math.abs(sx)));
  stack.method_22903();try{stack.method_23760().method_23761().identity();CosmeticsPreview.renderNative(ctx,left,top,right,bottom,actual,player);}finally{stack.method_22909();}
 }
}
