from pathlib import Path
import subprocess,json,os
B=Path(__file__).parent;R=Path('/workspace/duckclientz/repair');T=R.parent/'tools'
suites=['RepairTests','PerformanceTests','OffhandTests','PotionCrashTests','EffectIconTests','ElytraTests','ScoreboardTests','GeneralPerfTests']
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 if v=='1.21.11':continue
 cp=os.pathsep.join(map(str,[R/'testclasses',R/'teststubclasses',R/'perfprobes'/v,R/'stubclasses',entry['jar'],T/'gson.jar',T/'joml.jar',T/'mixin.jar',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
 for test in suites:
  if test=='OffhandTests' and v!='1.21.4':continue
  if test=='ScoreboardTests' and v!='1.21.4':continue
  args=[str(R.parent/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar'),entry['jar'],v] if test=='PotionCrashTests' else [entry['jar'],v] if test=='EffectIconTests' else [v]
  print(v,test,flush=True);subprocess.run(['java','-Xverify:all','-cp',cp,test,*args],check=True)
