import java.nio.file.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class DefaultPolicyPatch implements Opcodes {
 public static void main(String[] a)throws Exception{Path root=Path.of(a[1]);String policy="com/duckswords/profiles/DefaultProfilePolicy";for(String owner:new String[]{"com/duckswords/Config","com/duckswords/profiles/ProfileManager"}){Path path=root.resolve(owner+".class");ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(path)).accept(c,0);int hooks=0;
  for(MethodNode m:c.methods){if(owner.endsWith("/Config")&&m.name.equals("applyRoot")){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(new MethodInsnNode(INVOKESTATIC,policy,"prepare","(Lcom/google/gson/JsonObject;)V",false));m.instructions.insert(i);hooks++;}
   if(owner.endsWith("/ProfileManager")&&m.name.equals("initialize"))for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode seed&&seed.owner.equals(owner)&&seed.name.equals("writeProfile")&&seed.desc.equals("(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V")){seed.owner=policy;seed.name="seedPrepared";}
   if(owner.endsWith("/ProfileManager")&&m.name.equals("initialize"))for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode field&&field.getOpcode()==GETSTATIC&&field.owner.equals(owner)&&field.name.equals("DIRECTORY")&&hooks==0){InsnList i=new InsnList();i.add(new FieldInsnNode(GETSTATIC,owner,"DIRECTORY","Ljava/nio/file/Path;"));i.add(new MethodInsnNode(INVOKESTATIC,policy,"refresh","(Ljava/nio/file/Path;)V",false));m.instructions.insertBefore(n,i);hooks++;}
  }if(hooks!=1)throw new IllegalStateException(owner+" clean default hooks "+hooks);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(path,w.toByteArray());}
 }
}
