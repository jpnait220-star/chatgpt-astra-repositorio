package com.duckswords.mixin;
import com.duckswords.modules.RecordingCamera;import com.duckswords.camera.FreeLookControl;import net.minecraft.*;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=class_4184.class,remap=false)
public abstract class MixinFixedFreeLookCamera{
 @Shadow(remap=false) private float field_18721;
 @Shadow(remap=false) private float field_18722;
 @Shadow(remap=false) protected abstract void method_19325(float yaw,float pitch);
 @Shadow(remap=false) protected abstract void method_19327(double x,double y,double z);
 @Shadow(remap=false) protected abstract void method_19324(double x,double y,double z);
 @Shadow(remap=false) protected abstract double method_19318(double distance);
 @Inject(method="method_19321(Lnet/minecraft/class_1922;Lnet/minecraft/class_1297;ZZF)V",at=@At("TAIL"),require=1,remap=false)
 private void duck$freeLook(class_1922 world,class_1297 entity,boolean thirdPerson,boolean inverse,float delta,CallbackInfo callback){RecordingCamera camera=FreeLookControl.camera();if(camera==null||!thirdPerson||entity!=class_310.method_1551().field_1724)return;method_19325(camera.cameraYaw(),camera.cameraPitch());class_243 p=entity.method_30950(delta);method_19327(p.field_1352,p.field_1351+field_18722+(field_18721-field_18722)*delta,p.field_1350);method_19324(-method_19318(FreeLookControl.distance(camera)),0.0,0.0);}
}
