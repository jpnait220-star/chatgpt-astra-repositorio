from pathlib import Path
import subprocess,json,os
from zipfile import ZipFile
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');out=B/'profile-integration-runtime'/v;out.mkdir(parents=True,exist_ok=True)
 asm=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',str(B/'classes'),str(B/'ExtractProfileValidation.java')],check=True)
 subprocess.run(['java','-cp',asm,'ExtractProfileValidation',entry['jar'],str(out)],check=True)
 cp=os.pathsep.join(map(str,[out,r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),entry['jar'],T/'gson.jar',r.parent/'tools/joml.jar',T/'slf4j-api-2.0.9.jar',T/'slf4j-simple-2.0.9.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(B/'ProfileIntegrationTests.java'),'/workspace/duckclientz/repair/teststubs/net/fabricmc/loader/api/FabricLoader.java'],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'ProfileIntegrationTests',v],check=True)
