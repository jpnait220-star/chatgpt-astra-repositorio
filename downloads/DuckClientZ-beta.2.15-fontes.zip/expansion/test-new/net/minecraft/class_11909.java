package net.minecraft;public record class_11909(double comp_4798,double comp_4799,class_11910 comp_4800){}
