package net.minecraft;
public class class_342{
 public int x,y;public double clickedX;public boolean fail;
 public class_342(class_327 f,int x,int y,int w,int h,class_2561 text){this.x=x;this.y=y;}
 public void method_48579(class_332 ctx,int mx,int my,float delta){ctx.capture(x+8,y);if(fail)throw new IllegalStateException("test renderer failure");}
 public void method_25348(class_11909 click,boolean doubled){clickedX=click.comp_4798();}
}
