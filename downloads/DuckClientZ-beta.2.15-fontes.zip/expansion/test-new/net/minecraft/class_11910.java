package net.minecraft;public record class_11910(int comp_4801,int comp_4797){}
