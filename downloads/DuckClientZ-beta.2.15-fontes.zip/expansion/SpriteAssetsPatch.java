import java.nio.file.*;import java.util.zip.*;import java.awt.image.BufferedImage;import javax.imageio.ImageIO;
/** Convert emissive masks into straight-alpha sprites for Minecraft's native atlas. */
public class SpriteAssetsPatch {
 public static void main(String[] args)throws Exception{Path base=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectories(out);try(ZipFile client=new ZipFile(args[2])){
 for(String key:new String[]{"star","heart","bloom","sword","snowflake","firefly","capture","classic"}){
  BufferedImage input=key.equals("classic")?ImageIO.read(client.getInputStream(client.getEntry("assets/duckswords/textures/gui/logo.png"))):ImageIO.read(base.resolve(key+".png").toFile());int w=input.getWidth(),h=input.getHeight();BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
  for(int y=0;y<h;y++)for(int x=0;x<w;x++){int p=input.getRGB(x,y),alpha=p>>>24;if(!key.equals("classic"))alpha=alpha*Math.max(p>>16&255,Math.max(p>>8&255,p&255))/255;image.setRGB(x,y,(alpha<<24)|(key.equals("classic")?p&0xffffff:0xffffff));}
  int size=key.equals("capture")?128:64;BufferedImage compact=new BufferedImage(size,size,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D graphics=compact.createGraphics();try{graphics.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);graphics.drawImage(image,0,0,size,size,null);}finally{graphics.dispose();}ImageIO.write(compact,"PNG",out.resolve(key+".png").toFile());
 }
 }}
}
