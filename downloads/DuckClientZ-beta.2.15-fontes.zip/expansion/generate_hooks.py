from pathlib import Path
import re
B=Path(__file__).parent
PRIM={'void':'V','boolean':'Z','byte':'B','char':'C','short':'S','int':'I','long':'J','float':'F','double':'D'}
def catalog(v):
 root=Path('/workspace/duckclientz-1.21.11/tools') if v=='1.21.11' else Path('/workspace/duckclientz/tools');mapping=root/('minecraft-client_mappings' if v=='1.21.11' else f'minecraft-{v}-client_mappings');tiny=root/('intermediary.tiny' if v=='1.21.11' else f'intermediary-{v}.tiny');classes={};members={};sections={};name=None
 for line in mapping.read_text().splitlines():
  match=re.match(r'([^ #].*) -> (.*):$',line)
  if match:name,raw=match.groups();classes[name]=raw;sections[name]=[]
  elif name and line.startswith('    '):sections[name].append(line.strip())
 tc={};tm={};tf={};owner=None
 for line in tiny.read_text().splitlines():
  p=line.split('\t')
  if p[0]=='c':owner=p[1];tc[owner]=p[2]
  elif len(p)==5 and p[1] in ['m','f']:(tm if p[1]=='m' else tf)[(owner,p[3],p[2])]=p[4]
 def dtype(t):
  if t.endswith('[]'):return '['+dtype(t[:-2])
  return PRIM.get(t,'L'+classes.get(t,t.replace('.','/'))+';')
 def remap(d):return re.sub(r'L([^;]+);',lambda m:'L'+tc.get(m[1],m[1])+';',d)
 def methods(cls,method):
  result=[]
  for line in sections.get(cls,[]):
   m=re.match(r'(?:\d+:\d+:)?(\S+) ([^ (]+)\((.*?)\) -> (\S+)$',line)
   if m and m[2]==method:
    ret,key,params,rawname=m.groups();desc='('+''.join(dtype(t) for t in params.split(',') if t)+')'+dtype(ret);raw=classes[cls];
    mapped=tm.get((raw,rawname,desc))
    if mapped is None:
     inherited={value for (owner,key,d),value in tm.items() if key==rawname and d==desc}
     if len(inherited)==1:mapped=next(iter(inherited))
    if mapped is not None or rawname=="<init>":result.append((tc[raw],mapped or rawname,remap(desc),raw,rawname,desc))
  return result
 def field(cls,name):
  for line in sections[cls]:
   m=re.match(r'(\S+) '+re.escape(name)+r' -> (\S+)$',line)
   if m:
    raw=classes[cls];d=dtype(m[1]);return tc[raw],tf[(raw,m[2],d)],remap(d)
  raise KeyError((cls,name))
 return methods,field,classes,tc
if __name__=='__main__':
 for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
  methods,field,classes,tc=catalog(v);rows=[]
  def add(kind,cls,method,select=lambda x:True,aux=''):
   found=[x for x in methods(cls,method) if select(x)]
   if len(found)!=1:raise AssertionError((v,kind,cls,method,found))
   rows.append([kind,*found[0],aux])
  new=v=='1.21.11';old=v in ['1.20.1','1.21.1']
  add('cursor','net.minecraft.client.Minecraft','runTick',lambda x:x[2]=='(Z)V')
  add('clearparticles','net.minecraft.client.particle.ParticleEngine','clearParticles')
  add('weather','net.minecraft.client.renderer.LevelRenderer' if old else 'net.minecraft.client.renderer.WeatherEffectRenderer','renderSnowAndRain' if old else 'render',lambda x:old or new or x[2].startswith('(Lnet/minecraft/class_1937;'))
  add('shadows','net.minecraft.client.renderer.feature.ShadowFeatureRenderer' if new else 'net.minecraft.client.renderer.entity.EntityRenderDispatcher','render' if new else 'renderShadow')
  for cls in ['net.minecraft.client.renderer.entity.EntityRenderer','net.minecraft.client.renderer.entity.LivingEntityRenderer']:
   add('names',cls,'shouldShowName',lambda x:x[2].startswith('(Lnet/minecraft/class_1297;') if cls.endswith('.EntityRenderer') else x[2].startswith('(Lnet/minecraft/class_1309;'))
  add('blocks','net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher','tryExtractRenderState' if new else 'render')
  if old:add('items','net.minecraft.client.renderer.entity.ItemEntityRenderer','getRenderAmount' if v=='1.20.1' else 'getRenderedAmount')
  else:
   f=field('net.minecraft.client.renderer.entity.state.ItemClusterRenderState','count');add('itemstate','net.minecraft.client.renderer.entity.ItemEntityRenderer','extractRenderState',lambda x:x[2].startswith('(Lnet/minecraft/class_1542;'),aux='|'.join(f))
  out=B/'native'/v/'hooks.tsv';out.parent.mkdir(parents=True,exist_ok=True);out.write_text('\n'.join('\t'.join(row) for row in rows)+'\n');print(v,len(rows),'exact hooks')
