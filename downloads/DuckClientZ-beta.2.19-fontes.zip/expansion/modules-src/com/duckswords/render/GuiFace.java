package com.duckswords.render;
import com.duckswords.module.Module;import com.duckswords.setting.BooleanSetting;import com.duckswords.gui.GuiTransforms;import net.minecraft.class_332;import java.util.*;
/** Native skin draw with a cached rounded clip; bounded strips, no reflection or texture downloads. */
public final class GuiFace {
 private static BooleanSetting rounded;private record Band(int y,int height,int inset){}private static final Map<Integer,List<Band>> BANDS=new HashMap<>();
 public static void attach(Module owner){rounded=new BooleanSetting("Rosto arredondado","Cantos arredondados no rosto do TargetHUD",true);owner.getSettings().add(rounded);}
 private static List<Band> bands(int n){int radius=Math.min(8,n/2);List<Band> bands=new ArrayList<>();int from=0,previous=-1;for(int row=0;row<n;row++){int inset=0;if(row<radius||row>=n-radius){double dy=row<radius?radius-row-.5:row-(n-radius)+.5;inset=Math.max(0,(int)Math.round(radius-Math.sqrt(Math.max(0,radius*radius-dy*dy))));}if(previous!=inset){if(row>from)bands.add(new Band(from,row-from,previous));from=row;previous=inset;}}if(from<n)bands.add(new Band(from,n-from,previous));return List.copyOf(bands);}
 public static void draw(class_332 c,Object skin,int x,int y,int size){if(rounded!=null&&!rounded.getValue()){raw(c,skin,x,y,size);return;}if(size<=0)return;int n=size*2;List<Band> bands=BANDS.computeIfAbsent(n,GuiFace::bands);GuiTransforms.push(c,x,y,.5f);try{for(Band b:bands){clip(c,b.inset,b.y,n-b.inset,b.y+b.height);try{raw(c,skin,0,0,n);}finally{endClip(c);}}}finally{GuiTransforms.pop(c);}}
 public static void raw(class_332 c,Object skin,int x,int y,int size){throw new IllegalStateException("native skin adapter");}
 public static void clip(class_332 c,int x,int y,int right,int bottom){throw new IllegalStateException("native scissor adapter");}public static void endClip(class_332 c){throw new IllegalStateException("native scissor adapter");}
 public static void front(class_332 c){throw new IllegalStateException("native GUI layer adapter");}
}
