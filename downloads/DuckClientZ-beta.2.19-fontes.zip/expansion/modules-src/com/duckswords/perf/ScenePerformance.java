package com.duckswords.perf;import com.duckswords.module.Module;import com.duckswords.setting.BooleanSetting;import java.util.*;
/** Ten optional drawing passes, never world simulation. */
public final class ScenePerformance {
 private static final String[] NAMES={"Ocultar feixes de beacon","Ocultar feixes de end crystal","Ocultar raios visuais","Ocultar banners animados","Ocultar livro de encantamento","Ocultar miniatura do spawner","Ocultar cabecas de blocos","Ocultar projeteis presos","Ocultar superficie do portal End","Ocultar cordas de coleiras"};private static final IdentityHashMap<Module,BooleanSetting[]> OPTIONS=new IdentityHashMap<>();private static volatile int flags;
 public static void attach(Module m){if(OPTIONS.containsKey(m))return;BooleanSetting[] o=new BooleanSetting[10];for(int i=0;i<10;i++){o[i]=new BooleanSetting(NAMES[i],i==5?"Oculta somente o mob decorativo dentro do spawner; NAO muda spawn ou funcionamento":"Pula somente esta passagem de desenho; objetos e regras continuam funcionando",false);m.getSettings().add(o[i]);}OPTIONS.put(m,o);}
 public static void update(Module m){BooleanSetting[] o=OPTIONS.get(m);int f=0;if(o!=null&&m.isEnabled())for(int i=0;i<10;i++)if(o[i].getValue())f|=1<<i;flags=f;}public static boolean active(int index){return index>=0&&index<10&&(flags&(1<<index))!=0;}public static void disable(){flags=0;}
}
