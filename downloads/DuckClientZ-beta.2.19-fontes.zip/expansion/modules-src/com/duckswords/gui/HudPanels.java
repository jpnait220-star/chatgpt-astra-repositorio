package com.duckswords.gui;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.render.RoundedPanel;import net.minecraft.*;import java.util.*;
/** Draw only inside the same resolved-position/scaled matrix as the HUD content. */
public final class HudPanels {
 public interface Visibility {boolean duck$hudVisible();}
 private record Options(BooleanSetting on,ColorSetting color){}private static final IdentityHashMap<Module,Options> OPTIONS=new IdentityHashMap<>();private static final ThreadLocal<Module> ACTIVE=new ThreadLocal<>();
 public static boolean category(Category category,String name){return category==Category.HUD||name.equals("AutoClicker");}
 public static void attach(Module m){if(!category(m.getCategory(),m.getName())||m.getName().equals("Inventory HUD"))return;BooleanSetting on=new BooleanSetting("Ativar fundo","Fundo escuro arredondado que acompanha a posicao e escala do HUD",false);ColorSetting color=new ColorSetting("Cor do fundo HUD","Cor e opacidade do painel arredondado",0xe6101116);m.getSettings().add(on);m.getSettings().add(color);OPTIONS.put(m,new Options(on,color));}
 private static boolean visible(Module m){return class_310.method_1551().field_1724!=null&&(!(m instanceof Visibility v)||v.duck$hudVisible())&&(!(m instanceof com.duckswords.modules.AutoClicker a)||a.hud.getValue());}
 public static void begin(Module m,class_332 c){}public static void end(){}
 public static void render(Module m,class_332 c,float delta){Module previous=ACTIVE.get();Options o=OPTIONS.get(m);boolean panel=o!=null&&o.on.getValue()&&visible(m)&&m.hudX()!=null&&m.hudY()!=null;try{if(panel){RoundedPanel.draw(c,m.hudX().getInt()-3,m.hudY().getInt()-3,m.hudWidth()+6,m.hudHeight()+6,5,o.color.getDisplayValue());ACTIVE.set(m);}m.onHudRender(c,delta);}finally{if(previous==null)ACTIVE.remove();else ACTIVE.set(previous);}}
 public static int color(ColorSetting setting){if(ACTIVE.get()!=null&&(setting.getName().equals("Fundo")||setting.getName().equals("Cor do fundo")))return setting.getDisplayValue()&0xffffff;return setting.getDisplayValue();}
 public static void fill(class_332 c,int x,int y,int right,int bottom,int color){Module m=ACTIVE.get();if(m!=null&&m.hudX()!=null&&x==m.hudX().getInt()&&y==m.hudY().getInt()&&right-x==m.hudWidth()&&bottom-y==m.hudHeight())RoundedPanel.draw(c,x,y,right-x,bottom-y,5,color);else if((color>>>24)!=0)c.method_25294(x,y,right,bottom,color);}
}
