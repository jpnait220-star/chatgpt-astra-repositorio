package com.duckswords.gui;
import com.duckswords.DucksWordsClient;import com.duckswords.module.Module;import com.duckswords.modules.TextHud;import com.duckswords.Config;import net.minecraft.class_332;
/** Editor-only control, visible after selecting one HUD. */
public final class HudMinus {
 private static Object selected;private static int screenWidth=640;
 public static void clear(){selected=null;}
 private static int x(int right){return Math.max(0,Math.min(screenWidth-11,right+3));}private static int y(int top){return Math.max(42,top);}
 private static void button(class_332 c,int right,int top){int x=x(right),y=y(top);c.method_25294(x,y,x+10,y+10,0xd52a3441);c.method_25294(x+2,y+4,x+8,y+5,0xffedf2f8);}
 public static void draw(class_332 c){float scale=HudControls.scale();screenWidth=(int)(c.method_51421()/scale);GuiTransforms.push(c,0,0,scale);try{if(selected instanceof Module m&&DucksWordsClient.MODULES.getHudElements().contains(m)&&m.hudScaleSetting()!=null)button(c,m.hudX().getInt()+m.hudWidthScaled(),m.hudY().getInt());else if(selected instanceof TextHud.Entry e&&TextHud.entries().contains(e))button(c,e.x()+TextHud.entryWidth(e),e.y());else selected=null;}finally{GuiTransforms.pop(c);}}
 private static boolean hit(double px,double py,int right,int top){int xx=x(right),yy=y(top);return px>=xx&&px<xx+10&&py>=yy&&py<yy+10;}
 private static boolean inside(double x,double y,int left,int top,int width,int height){return x>=left&&x<=left+width&&y>=top&&y<=top+height;}
 public static boolean click(double rawX,double rawY,int button){if(button!=0){selected=null;return false;}float scale=HudControls.scale();double x=rawX/scale,y=rawY/scale;
  if(selected instanceof Module m&&DucksWordsClient.MODULES.getHudElements().contains(m)&&m.hudScaleSetting()!=null&&hit(x,y,m.hudX().getInt()+m.hudWidthScaled(),m.hudY().getInt())){m.hudScaleSetting().setValue(Math.max(.25,m.hudScaleSetting().getValue()-.05));Config.save();return true;}
  if(selected instanceof TextHud.Entry e&&TextHud.entries().contains(e)&&hit(x,y,e.x()+TextHud.entryWidth(e),e.y())){TextEntrySizes.set(e,TextEntrySizes.scale(e)-.05f);Config.save();return true;}
  selected=null;if(y<42)return false;
  for(TextHud.Entry e:TextHud.entries())if(inside(x,y,e.x(),e.y(),TextHud.entryWidth(e),TextHud.entryHeight(e))){selected=e;return false;}
  for(Module m:DucksWordsClient.MODULES.getHudElements())if(m.hudScaleSetting()!=null&&inside(x,y,m.hudX().getInt(),m.hudY().getInt(),m.hudWidthScaled(),m.hudHeightScaled())){selected=m;return false;}
  return false;
 }
}
