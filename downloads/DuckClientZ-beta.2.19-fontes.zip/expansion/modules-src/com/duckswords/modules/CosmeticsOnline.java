package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.social.CosmeticSharing;
public final class CosmeticsOnline extends Module {
 public static final String URL="https://duck-connect.vercel.app";
 public final ModeSetting service=add(new ModeSetting("Servico oficial","Endereco fixo: https://duck-connect.vercel.app; nao pode ser alterado","duck-connect.vercel.app","duck-connect.vercel.app"));
 public final BooleanSetting show=add(new BooleanSetting("Mostrar cosmeticos dos outros","Mostra os modelos compartilhados pelo servico configurado",true)),share=add(new BooleanSetting("Compartilhar meus cosmeticos","Envia somente UUID e IDs dos cosmeticos equipados ao servico configurado",false));
 public final StringSetting endpoint=new StringSetting("Servico de cosmeticos","Servico Duck Connect; somente conecta quando a feature esta ligada",URL,255);
 public final NumberSetting interval=add(new NumberSetting("Atualizar a cada","Intervalo das consultas, em segundos; nunca por frame",30,10,120,5));
 public CosmeticsOnline(){super("Cosmeticos Online","Compartilhamento opcional entre usuarios do Duck; requer relay configurado",Category.CLIENT);CosmeticSharing.owner(this);}
 @Override public void onEnable(){endpoint.setValue(URL);}
 @Override public void onTick(){CosmeticSharing.tick(this);}@Override public void onDisable(){CosmeticSharing.clear();}
}
