package com.duckswords.profiles;
import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
/** Frozen-base, indexed-path deltas. Neither clipboard nor disk is changed until validation succeeds. */
public final class CompactProfileCode {
 private static final int LIMIT=262144;
 private static final String PREFIX="DZ3:";
 private record Base(String id,JsonElement json,List<List<String>> paths,Map<List<String>,Integer> index){}
 private static final List<Base> BASES=loadBases();
 private static List<Base> loadBases(){
  List<Base> result=new ArrayList<>();
  for(String id:List.of("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v")){
   try(InputStream in=CompactProfileCode.class.getResourceAsStream("/assets/duckswords/profiles/v3/"+id+".json")){
    if(in==null)throw new IOException("Missing profile schema "+id);
    JsonElement json=JsonParser.parseString(new String(in.readAllBytes(),StandardCharsets.UTF_8));
    List<List<String>> paths=new ArrayList<>();enumerate(json,List.of(),paths);Map<List<String>,Integer> index=new HashMap<>();
    for(int i=0;i<paths.size();i++)index.put(paths.get(i),i);result.add(new Base(id,json,List.copyOf(paths),Map.copyOf(index)));
   }catch(IOException ex){throw new ExceptionInInitializerError(ex);}
  }return List.copyOf(result);
 }
 private static void enumerate(JsonElement e,List<String> path,List<List<String>> out){
  out.add(path);if(e.isJsonObject())for(String k:new TreeSet<>(e.getAsJsonObject().keySet())){List<String> p=new ArrayList<>(path);p.add(k);enumerate(e.getAsJsonObject().get(k),List.copyOf(p),out);}
 }
 private static JsonElement path(Base b,List<String> p){Integer id=b.index.get(p);if(id!=null)return new JsonPrimitive(id);JsonArray a=new JsonArray();p.forEach(a::add);return a;}
 private static void diff(Base b,JsonElement before,JsonElement after,List<String> p,JsonArray ops){
  if(before.equals(after))return;
  if(before.isJsonObject()&&after.isJsonObject()){
   JsonObject old=before.getAsJsonObject(),value=after.getAsJsonObject();
   for(String k:new TreeSet<>(old.keySet()))if(!value.has(k)){List<String> q=new ArrayList<>(p);q.add(k);JsonArray op=new JsonArray();op.add(path(b,q));ops.add(op);}
   for(String k:new TreeSet<>(value.keySet())){List<String> q=new ArrayList<>(p);q.add(k);if(old.has(k))diff(b,old.get(k),value.get(k),q,ops);else{JsonArray op=new JsonArray();op.add(path(b,q));op.add(value.get(k).deepCopy());ops.add(op);}}
  }else{JsonArray op=new JsonArray();op.add(path(b,p));op.add(after.deepCopy());ops.add(op);}
 }
 public static String legacyDefault(){for(Base base:BASES)if(base.id.equals("c"))return base.json.toString();throw new IllegalStateException("Missing immutable V2 profile base");}
 public static String encode(String json)throws IOException{
  if(json==null||json.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");
  JsonElement target=JsonParser.parseString(json);if(!target.isJsonObject())throw new IOException("Perfil invalido");String best=null;
  for(Base b:BASES){JsonArray ops=new JsonArray();diff(b,b.json,target,List.of(),ops);Deflater deflater=new Deflater(9,true);ByteArrayOutputStream output=new ByteArrayOutputStream();
   try(DeflaterOutputStream stream=new DeflaterOutputStream(output,deflater)){stream.write(ops.toString().getBytes(StandardCharsets.UTF_8));}finally{deflater.end();}
   String code=PREFIX+b.id+":"+Base64.getUrlEncoder().withoutPadding().encodeToString(output.toByteArray());if(best==null||code.length()<best.length())best=code;
  }return best;
 }
 public static boolean accepts(String code){return code!=null&&code.strip().startsWith(PREFIX);}
 public static String decode(String code)throws IOException{
  if(code==null||code.length()>LIMIT)throw new IOException("Codigo invalido");code=code.strip();String[] pieces=code.split(":",3);if(pieces.length!=3||!pieces[0].equals("DZ3"))throw new IOException("Codigo invalido");
  Base b=BASES.stream().filter(v->v.id.equals(pieces[1])).findFirst().orElseThrow(()->new IOException("Versao do perfil desconhecida"));
  byte[] bytes;try{bytes=Base64.getUrlDecoder().decode(pieces[2]);}catch(IllegalArgumentException e){throw new IOException("Codigo invalido",e);}
  Inflater inflater=new Inflater(true);ByteArrayOutputStream output=new ByteArrayOutputStream();
  try(InflaterInputStream stream=new InflaterInputStream(new ByteArrayInputStream(bytes),inflater)){
   byte[] buffer=new byte[4096];int n;while((n=stream.read(buffer))!=-1){if(output.size()+n>LIMIT)throw new IOException("Perfil excede o limite");output.write(buffer,0,n);}
  }finally{inflater.end();}
  try{
   JsonArray ops=JsonParser.parseString(output.toString(StandardCharsets.UTF_8)).getAsJsonArray();JsonElement result=b.json.deepCopy();
   for(JsonElement e:ops){JsonArray op=e.getAsJsonArray();if(op.size()<1||op.size()>2)throw new IllegalArgumentException();List<String> p=new ArrayList<>();JsonElement raw=op.get(0);
    if(raw.isJsonPrimitive()&&raw.getAsJsonPrimitive().isNumber()){int id=raw.getAsInt();if(id<0||id>=b.paths.size())throw new IllegalArgumentException();p.addAll(b.paths.get(id));}
    else for(JsonElement k:raw.getAsJsonArray()){if(!k.isJsonPrimitive()||!k.getAsJsonPrimitive().isString())throw new IllegalArgumentException();p.add(k.getAsString());}
    if(p.size()>64)throw new IllegalArgumentException();if(p.isEmpty()){if(op.size()!=2||!op.get(1).isJsonObject())throw new IllegalArgumentException();result=op.get(1).deepCopy();continue;}
    JsonObject parent=result.getAsJsonObject();for(int i=0;i<p.size()-1;i++)parent=parent.getAsJsonObject(p.get(i));String key=p.get(p.size()-1);if(op.size()==1)parent.remove(key);else parent.add(key,op.get(1).deepCopy());
   }String decoded=result.toString();if(decoded.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");return decoded;
  }catch(RuntimeException ex){throw new IOException("Conteudo do perfil invalido",ex);}
 }
}
