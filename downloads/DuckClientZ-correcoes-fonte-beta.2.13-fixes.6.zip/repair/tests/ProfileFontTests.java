import com.duckswords.*;
import com.duckswords.profiles.ProfileManager;
import com.duckswords.theme.HudText;
import com.duckswords.theme.Interface;
import com.google.gson.*;
import net.minecraft.*;
import java.nio.file.*;
public class ProfileFontTests {
 public static void main(String[] args)throws Exception {
  Path root=Files.createTempDirectory(Paths.get("/tmp"),"duck-profile-tests-");
  System.setProperty("duck.tests.config",root.resolve("config").toString());
  System.setProperty("user.home",root.resolve("home").toString());
  System.setProperty("duckclientz.pojav","true");
  ProfileManager.initialize();
  if(Config.exportCalls!=0)throw new AssertionError("default seeded from runtime defaults instead of embedded resource");
  JsonObject current=JsonParser.parseString(Config.current).getAsJsonObject();
  JsonObject expected=JsonParser.parseString(ProfileManager.defaultProfileConfig()).getAsJsonObject();
  if(!expected.get("Interface").equals(current.get("Interface")))throw new AssertionError("embedded theme/font not applied");
  JsonObject submitted=JsonParser.parseString(Files.readString(Paths.get(args[0]))).getAsJsonObject();
  JsonObject supplied=JsonParser.parseString(submitted.get("config").getAsString()).getAsJsonObject();
  supplied.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Fonte do HUD","Minecraft");
  if(!supplied.get("Interface").equals(current.get("Interface")))throw new AssertionError("theme differs from supplied default profile");
  Path profile=root.resolve("config/duckswords/profiles/default.json");
  if(!Files.isRegularFile(profile))throw new AssertionError("mobile profiles must remain in the local game config directory");
  if(!Files.readString(profile.resolveSibling("active-profile.txt")).equals("default"))throw new AssertionError("active profile");
  JsonObject custom=current.deepCopy();custom.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Cor 1",0xff112233);
  JsonObject existing=new JsonObject();existing.addProperty("name","Saved user's default");existing.addProperty("config",custom.toString());Files.writeString(profile,existing.toString());
  ProfileManager.initialize();
  if(!JsonParser.parseString(Config.current).getAsJsonObject().equals(custom))throw new AssertionError("existing user profile was overwritten");
  Interface ui=new Interface();DucksWordsClient.MODULES.modules.put(Interface.class,ui);ui.hudFont.setValue("GeoFont Edge");
  class_5250 ascii=(class_5250)PojavCompat.styled("DuckClientZ");
  if(ascii.style==null||!ascii.style.font.path().equals("geofont_edge"))throw new AssertionError("Pojav still forces the vanilla font");
  class_5250 accented=(class_5250)HudText.styled("Configurações");
  if(accented.style==null||!accented.style.font.path().equals("geofont_edge"))throw new AssertionError("accents force whole-string vanilla fallback");
  if(ascii.style!=accented.style)throw new AssertionError("font style cache should reuse the immutable style across texts");
  ui.hudFont.setValue("Minecraft");
  if(((class_5250)PojavCompat.styled("Minecraft")).style!=null)throw new AssertionError("explicit vanilla font choice must work");
  System.out.println("PASS: 10 profile/font regressions, actual patched ProfileManager/HudText/PojavCompat with isolated game stubs.");
 }
}
