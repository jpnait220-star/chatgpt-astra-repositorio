import com.duckswords.modules.BlockOverlay;
import com.duckswords.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.*;
public class OutlineTests {
 public static void main(String[] a) {
  BlockOverlay module=new BlockOverlay();
  var listener=WorldRenderEvents.BLOCK_OUTLINE.listeners.get(0);
  WorldRenderContext ctx=new WorldRenderContext(){};
  WorldRenderContext.BlockOutlineContext hit=()->new class_2338(123,70,-55);
  if(!listener.onBlockOutline(ctx,hit))throw new AssertionError("vanilla outline should remain while module disabled");
  module.setEnabled(true);module.onWorldRender(ctx);
  if(RenderUtil.lines!=0)throw new AssertionError("old LAST render must be inactive");
  if(listener.onBlockOutline(ctx,hit))throw new AssertionError("custom outline should replace vanilla");
  if(RenderUtil.lines!=1||!RenderUtil.last.position().equals(hit.blockPos()))throw new AssertionError("outline must use vanilla's block target");
  module.mode.setValue("Filled");listener.onBlockOutline(new WorldRenderContext(){},hit);
  if(RenderUtil.fills!=1||RenderUtil.lines!=1)throw new AssertionError("filled mode");
  module.mode.setValue("Both");listener.onBlockOutline(ctx,hit);
  if(RenderUtil.fills!=2||RenderUtil.lines!=2)throw new AssertionError("both mode");
  System.out.println("PASS: 6 block-outline regressions (native event/target, no late camera raycast).");
 }
}
