import com.duckswords.Config;
import com.duckswords.profiles.*;
import com.duckswords.theme.Interface;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
public class DefaultMigrationTests {
 static int passed;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);passed++;}
 static JsonObject obj(String s){return JsonParser.parseString(s).getAsJsonObject();}
 static JsonObject wrapper(JsonObject config){JsonObject p=new JsonObject();p.addProperty("name","Default");p.addProperty("config",config.toString());return p;}
 public static void main(String[] args)throws Exception {
  Path root=Files.createTempDirectory(Paths.get("/tmp"),"duck-auto-red-");
  System.setProperty("duck.tests.config",root.resolve("config").toString());
  System.setProperty("user.home",root.resolve("home").toString());
  System.setProperty("duckclientz.pojav","true");
  JsonObject requested=obj(ProfileManager.defaultProfileConfig());
  JsonObject supplied=obj(obj(Files.readString(Paths.get(args[0]))).get("config").getAsString());
  supplied.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Fonte do HUD","Minecraft");
  for(String key:supplied.keySet()) {
   if(key.equals("Custom Glint"))continue; // newly registered controls may be added
   check(supplied.get(key).equals(requested.get(key)),"embedded supplied config: "+key);
  }
  Interface ui=new Interface();JsonObject desired=supplied.getAsJsonObject("Interface").getAsJsonObject("settings");
  check(ui.color1.getValue().equals(desired.get("Cor 1").getAsInt())&&ui.color2.getValue().equals(desired.get("Cor 2").getAsInt()),"constructor starts with requested palette");
  check(ui.hudFont.getValue().equals(desired.get("Fonte do HUD").getAsString()),"constructor starts with requested font");
  ui.color1.setValue(123);ui.color1.reset();ui.hudFont.setValue("Minecraft");ui.hudFont.reset();
  check(ui.color1.getValue().equals(desired.get("Cor 1").getAsInt())&&ui.hudFont.getValue().equals("Minecraft"),"reset uses requested palette and font");
  JsonObject legacy=requested.deepCopy();JsonObject legacySettings=legacy.getAsJsonObject("Interface").getAsJsonObject("settings");
  legacySettings.addProperty("Cor 1",-16040049);legacySettings.addProperty("Cor 2",-11093505);legacySettings.addProperty("Fonte do HUD","Inter Frozen");
  Path dir=root.resolve("config/duckswords/profiles");Files.createDirectories(dir);
  Path profile=dir.resolve("default.json");String old=wrapper(legacy).toString();Files.writeString(profile,old);
  Files.writeString(dir.resolve("active-profile.txt"),"default");
  JsonObject other=wrapper(legacy);other.addProperty("name","Outro perfil");String otherBytes=other.toString();Files.writeString(dir.resolve("other.json"),otherBytes);
  ProfileManager.initialize();
  check(obj(Config.current).equals(requested),"existing blue/green Default replaced and loaded automatically");
  check(obj(obj(Files.readString(profile)).get("config").getAsString()).equals(requested),"replacement persisted");
  check(Files.readString(dir.resolve("other.json")).equals(otherBytes),"other saved profile untouched");
  List<Path> backups;
  try(var files=Files.list(dir)){backups=files.filter(p->p.getFileName().toString().endsWith(".bak")).toList();}
  check(backups.size()==1&&Files.readString(backups.get(0)).equals(old),"exact original backed up before replacement");
  check(Files.isRegularFile(dir.resolve("default-red-v1.applied")),"one-time marker persisted");
  check(ProfileManager.list().size()==2,"backup and marker do not appear as selectable profiles");
  // Even deliberately returning to blue/green after migration must not reset again.
  Files.writeString(profile,old);ProfileManager.initialize();
  check(obj(Config.current).equals(legacy),"later customization survives subsequent launches");
  try(var files=Files.list(dir)){check(files.filter(p->p.getFileName().toString().endsWith(".bak")).count()==1,"no repeated migration/backup");}
  Path customized=root.resolve("custom");Files.createDirectories(customized);
  JsonObject custom=requested.deepCopy();custom.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Cor 1",0xff112233);
  String customBytes=wrapper(custom).toString();Files.writeString(customized.resolve("default.json"),customBytes);
  DefaultProfileMigration.migrate(customized,requested.toString());
  check(Files.readString(customized.resolve("default.json")).equals(customBytes),"custom palette preserved on first upgrade");
  Path incomplete=root.resolve("incomplete");Files.createDirectories(incomplete);
  Files.writeString(incomplete.resolve("default.json"),wrapper(new JsonObject()).toString());
  DefaultProfileMigration.migrate(incomplete,requested.toString());
  check(obj(obj(Files.readString(incomplete.resolve("default.json"))).get("config").getAsString()).equals(requested),"missing interface defaults automatically replaced");
  Path malformed=root.resolve("malformed");Files.createDirectories(malformed);Files.writeString(malformed.resolve("default.json"),"broken");
  try{DefaultProfileMigration.migrate(malformed,requested.toString());throw new AssertionError("invalid profile must fail safely");}catch(java.io.IOException expected){}
  check(Files.readString(malformed.resolve("default.json")).equals("broken")&&!Files.exists(malformed.resolve("default-red-v1.applied")),"invalid data not overwritten or marked complete");
  Path upgrade=root.resolve("font-upgrade");Files.createDirectories(upgrade);
  JsonObject previous=requested.deepCopy();previous.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Fonte do HUD","GeoFont Edge");
  previous.addProperty("keep-other-setting",123);
  String previousBytes=wrapper(previous).toString();Files.writeString(upgrade.resolve("default.json"),previousBytes);
  Files.writeString(upgrade.resolve("default-red-v1.applied"),"already migrated red");
  DefaultProfileMigration.migrate(upgrade,requested.toString());
  JsonObject updated=obj(obj(Files.readString(upgrade.resolve("default.json"))).get("config").getAsString());
  check(updated.getAsJsonObject("Interface").getAsJsonObject("settings").get("Fonte do HUD").getAsString().equals("Minecraft"),"old standard font upgraded even when red migration already ran");
  check(updated.get("keep-other-setting").getAsInt()==123,"font migration preserves other settings");
  try(var files=Files.list(upgrade)){Path backup=files.filter(p->p.toString().endsWith(".bak")).findFirst().orElseThrow();check(Files.readString(backup).equals(previousBytes),"font migration backup preserves original bytes");}
  Files.writeString(upgrade.resolve("default.json"),previousBytes);DefaultProfileMigration.migrate(upgrade,requested.toString());
  check(Files.readString(upgrade.resolve("default.json")).equals(previousBytes),"font chosen after migration remains on next launch");
  Path explicit=root.resolve("explicit-font");Files.createDirectories(explicit);
  previous.getAsJsonObject("Interface").getAsJsonObject("settings").addProperty("Fonte do HUD","JetBrains Mono");
  String explicitBytes=wrapper(previous).toString();Files.writeString(explicit.resolve("default.json"),explicitBytes);
  DefaultProfileMigration.migrate(explicit,requested.toString());
  check(Files.readString(explicit.resolve("default.json")).equals(explicitBytes),"another explicitly selected font remains unchanged");
  System.out.println("PASS: "+passed+" automatic red-default migration assertions (includes supplied preset, constructor/reset, backup, one-time application and profile preservation).");
 }
}
