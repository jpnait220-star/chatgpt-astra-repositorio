import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.lang.reflect.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Executes exact old/new method bodies with version-shaped registry stand-ins. */
public class PotionCrashTests implements Opcodes {
 static final String EFFECT="net/minecraft/class_1291",INSTANCE="net/minecraft/class_1293",ENTRY="net/minecraft/class_6880";
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static ClassWriter base(String name,int access,String... interfaces) {
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(V17,access,name,null,"java/lang/Object",interfaces);return w;
 }
 static byte[] valueClass(String name,boolean entry,boolean instance,boolean legacy) {
  ClassWriter w=base(name,ACC_PUBLIC,entry?new String[]{ENTRY}:new String[0]);
  w.visitField(ACC_PRIVATE,"value","Ljava/lang/Object;",null,null).visitEnd();
  MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","(Ljava/lang/Object;)V",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKESPECIAL,"java/lang/Object","<init>","()V",false);m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);m.visitFieldInsn(PUTFIELD,name,"value","Ljava/lang/Object;");m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();
  String type=instance?(legacy?EFFECT:ENTRY):"java/lang/Object";
  m=w.visitMethod(ACC_PUBLIC,instance?"method_5579":"comp_349","()L"+type+";",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,name,"value","Ljava/lang/Object;");
  if(instance)m.visitTypeInsn(CHECKCAST,type);
  m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();return w.toByteArray();
 }
 static byte[] effectClass() {
  ClassWriter w=base(EFFECT,ACC_PUBLIC);MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","()V",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKESPECIAL,"java/lang/Object","<init>","()V",false);m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();return w.toByteArray();
 }
 static byte[] entryClass() {
  ClassWriter w=base(ENTRY,ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT);w.visitMethod(ACC_PUBLIC|ACC_ABSTRACT,"comp_349","()Ljava/lang/Object;",null,null).visitEnd();w.visitEnd();return w.toByteArray();
 }
 static byte[] probe(Path jar,String name)throws Exception {
  try(ZipFile z=new ZipFile(jar.toFile())) {
   ClassNode original=new ClassNode();new ClassReader(z.getInputStream(z.getEntry("com/duckswords/util/MinecraftCompat.class"))).accept(original,0);
   MethodNode body=original.methods.stream().filter(m->m.name.equals("statusEffect")).findFirst().orElseThrow();
   ClassNode c=new ClassNode();c.version=V17;c.access=ACC_PUBLIC|ACC_FINAL;c.name=name;c.superName="java/lang/Object";c.methods.add(body);
   ClassWriter w=new ClassWriter(0);c.accept(w);return w.toByteArray();
  }
 }
 static class Isolated extends ClassLoader {
  final Map<String,byte[]> classes;
  Isolated(Map<String,byte[]> c){super(PotionCrashTests.class.getClassLoader());classes=c;}
  protected Class<?> loadClass(String name,boolean resolve)throws ClassNotFoundException {
   synchronized(getClassLoadingLock(name)) {
    Class<?> c=findLoadedClass(name);byte[] data=classes.get(name.replace('.','/'));
    if(c==null)c=data==null?super.loadClass(name,false):defineClass(name,data,0,data.length);
    if(resolve)resolveClass(c);return c;
   }
  }
 }
 public static void main(String[] a)throws Exception {
  boolean legacy=a[2].equals("1.20.1");Map<String,byte[]> definitions=new HashMap<>();
  definitions.put(EFFECT,effectClass());definitions.put(INSTANCE,valueClass(INSTANCE,false,true,legacy));
  if(!legacy) {
   definitions.put(ENTRY,entryClass());
   definitions.put(ENTRY+"$class_6883",valueClass(ENTRY+"$class_6883",true,false,false));
   definitions.put(ENTRY+"$class_6881",valueClass(ENTRY+"$class_6881",true,false,false));
  }
  definitions.put("OriginalPotionProbe",probe(Paths.get(a[0]),"OriginalPotionProbe"));
  definitions.put("FixedPotionProbe",probe(Paths.get(a[1]),"FixedPotionProbe"));
  ClassLoader loader=new Isolated(definitions);Class<?> instance=loader.loadClass(INSTANCE.replace('/','.'));
  Method fixed=loader.loadClass("FixedPotionProbe").getMethod("statusEffect",instance);
  Method original=loader.loadClass("OriginalPotionProbe").getMethod("statusEffect",instance);
  Object expected=loader.loadClass(EFFECT.replace('/','.')).getConstructor().newInstance();
  Object reference=legacy?expected:loader.loadClass((ENTRY+"$class_6883").replace('/','.')).getConstructor(Object.class).newInstance(expected);
  Object effect=instance.getConstructor(Object.class).newInstance(reference);
  if(a[2].equals("1.21.1")) {
   try{original.invoke(null,effect);throw new AssertionError("Original bug did not reproduce");}
   catch(InvocationTargetException e) {
    check(e.getCause() instanceof IllegalStateException&&e.getCause().getCause() instanceof NoSuchMethodException,"same IllegalStateException/NoSuchMethodException crash reproduced");
    check(e.getCause().getCause().getMessage().contains("value"),"same missing registry value() lookup");
   }
  }
  check(fixed.invoke(null,effect)==expected,"reference effect resolves to actual status-effect type");
  for(int i=0;i<1000;i++)if(fixed.invoke(null,effect)!=expected)throw new AssertionError("Repeated HUD lookup changed type");
  check(true,"repeated HUD lookups do not throw");
  if(!legacy) {
   Object direct=loader.loadClass((ENTRY+"$class_6881").replace('/','.')).getConstructor(Object.class).newInstance(expected);
   check(fixed.invoke(null,instance.getConstructor(Object.class).newInstance(direct))==expected,"direct registry entries also work");
  }
  System.out.println("PASS: "+checks+" potion crash regressions, exact original/patched method bodies with version-shaped stubs"+(a[2].equals("1.21.1")?"; original reported crash reproduced, corrected body succeeds.":"."));
 }
}
