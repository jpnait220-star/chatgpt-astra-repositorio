import com.duckswords.perf.*;
import com.duckswords.modules.HitRange;
import com.duckswords.repair.HitRangeRing;
import com.duckswords.setting.ColorSetting;
import com.duckswords.compat.FullbrightPixels;
import com.duckswords.modules.Fullbright;
import com.duckswords.DucksWordsClient;
import net.minecraft.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import org.joml.Matrix4f;
import java.lang.invoke.*;
import java.util.*;
public class PerformanceTests {
 static int passed;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);passed++;}
 static final class Vertex implements class_4588 {
  int positions,colors,normals,ends,color;float x,y,z,nx,ny,nz;
  List<float[]> recorded;
  public class_4588 method_22918(Matrix4f m,float x,float y,float z){positions++;this.x=x;this.y=y;this.z=z;if(recorded!=null)recorded.add(new float[]{x,y,z});return this;}
  public class_4588 method_39415(int c){colors++;color=c;return this;}
  public class_4588 method_22914(float x,float y,float z){normals++;nx=x;ny=y;nz=z;return this;}
  public void method_1344(){ends++;}
 }
 public static void main(String[] a)throws Throwable {
  boolean old=a[0].equals("1.20.1");
  MethodType colorType=MethodType.methodType(void.class,class_4588.class,Object.class,float.class,float.class,float.class,int.class);
  MethodType normalType=MethodType.methodType(void.class,class_4588.class,Object.class,float.class,float.class,float.class,int.class,float.class,float.class,float.class);
  MethodHandle direct=MethodHandles.publicLookup().findStatic(Class.forName("DirectVerticesProbe"),"vertexColor",colorType);
  MethodHandle normal=MethodHandles.publicLookup().findStatic(Class.forName("DirectVerticesProbe"),"vertexColorNormal",normalType);
  MethodHandle legacy=MethodHandles.publicLookup().findStatic(Class.forName("LegacyVerticesProbe"),"vertexColor",colorType);
  Vertex v=new Vertex();class_4588 vc=v;Object matrix=new Matrix4f();
  direct.invokeExact(vc,matrix,1.25f,-2f,4f,0x12345678);
  check(v.positions==1&&v.colors==1&&v.normals==0&&v.ends==(old?1:0),"native builder chain and version-specific end");
  check(v.x==1.25f&&v.y==-2&&v.z==4&&v.color==0x12345678,"vertex coordinates/ARGB unchanged");
  normal.invokeExact(vc,matrix,3f,5f,-4f,0x87654321,0f,1f,-.5f);
  check(v.normals==1&&v.nx==0&&v.ny==1&&v.nz==-.5f&&v.ends==(old?2:0),"normal and explicit next preserved");
  // Rotations must multiply the existing pose, rather than replace it.
  for(String axis:List.of("X","Y","Z")) {
   class_4587 pose=new class_4587();pose.matrix.translate(1,2,3);
   Matrix4f expected=new Matrix4f(pose.matrix);float r=37f*((float)Math.PI/180f);
   if(axis.equals("X"))expected.rotateX(r);if(axis.equals("Y"))expected.rotateY(r);if(axis.equals("Z"))expected.rotateZ(r);
   AxisRotation.rotate(pose,axis,37);check(pose.matrix.equals(expected,1e-6f),"axis rotation "+axis);
  }
  double[] unit=CirclePoints.get(64);check(unit==CirclePoints.get(64),"unit circle reused");
  for(int i=0;i<=64;i++)check(Math.abs(unit[2*i]*unit[2*i]+unit[2*i+1]*unit[2*i+1]-1)<1e-12,"unit radius");
  class_310 client=class_310.method_1551();client.field_1724=new class_746();client.field_1687=new class_638();
  class_1309 target=new class_1309();target.x=2;target.y=.03;client.field_1687.entities.add(target);
  Vertex ring=new Vertex();ring.recorded=new ArrayList<>();class_4587 pose=new class_4587();class_4184 camera=new class_4184();camera.pos=new class_243(10,20,30);
  WorldRenderContext ctx=new WorldRenderContext(){public class_4597 consumers(){return new class_4597(){public class_4588 getBuffer(class_1921 layer){return ring;}};}public class_4587 matrixStack(){return pose;}public class_4184 camera(){return camera;}};
  HitRange module=new HitRange();module.onTick();
  check(client.field_1687.queries==1,"initial bounded world query");
  for(int i=0;i<10;i++)module.onWorldRender(ctx);
  check(client.field_1687.queries==1,"no entity scans during render frames");
  check(ring.positions==5120&&ring.color==-13244309,"same double-sided 64-segment ring and target color");
  // Match every emitted point against the previous geometry and winding.
  for(int i=0;i<64;i++) {
   double angle=Math.PI*2*i/64,next=Math.PI*2*(i+1)/64;
   double inner=HitRangeRing.innerRadius(3,30);
   double[][] points={{Math.cos(angle)*3,Math.sin(angle)*3},{Math.cos(next)*3,Math.sin(next)*3},{Math.cos(next)*inner,Math.sin(next)*inner},{Math.cos(angle)*inner,Math.sin(angle)*inner}};
   int[] order={0,1,2,3,3,2,1,0};
   for(int j=0;j<8;j++){float[] p=ring.recorded.get(i*8+j);double[] q=points[order[j]];check(p[0]==(float)(q[0]-10)&&p[1]==(float)(.03-20)&&p[2]==(float)(q[1]-30),"ring geometry/winding unchanged");}
  }
  for(int i=1;i<20;i++)module.onTick();check(client.field_1687.queries==10,"10 scans per 20 ticks");
  target.alive=false;module.onTick();module.onTick();module.onWorldRender(ctx);check(ring.color==module.color.getDisplayValue(),"dead targets excluded");
  class_638 newWorld=new class_638();client.field_1687=newWorld;module.onTick();check(newWorld.queries==1,"world change invalidates proximity result");
  client.field_1724=null;module.onTick();module.onWorldRender(ctx);check(newWorld.queries==1,"disconnect safe");
  ColorSetting setting=new ColorSetting("test","test",0xff336699);
  float[] hsb=java.awt.Color.RGBtoHSB(0x33,0x66,0x99,null);
  check(setting.hue()==hsb[0]&&setting.saturation()==hsb[1]&&setting.brightness()==hsb[2],"HSB cache exact");
  setting.setValue(0xffe02090);hsb=java.awt.Color.RGBtoHSB(0xe0,0x20,0x90,null);check(setting.hue()==hsb[0],"HSB cache invalidated by color edit");
  setting.setAlphaByte(15);check(setting.hue()==hsb[0]&&(setting.getValue()>>>24)==15,"alpha independent from HSB");
  setting.reset();check(setting.getValue()==0xff336699&&setting.hue()!=hsb[0],"profile reset updates cached HSB");
  Locale saved=Locale.getDefault(Locale.Category.FORMAT);
  try {
   Locale.setDefault(Locale.Category.FORMAT,Locale.US);
   Object[] args={1.25f};String s=HudFormatCache.format("%.1f HP",args);
   check(s.equals(String.format("%.1f HP",args)),"format semantics");check(s==HudFormatCache.format("%.1f HP",new Object[]{1.25f}),"unchanged HUD values reuse result");
   args[0]=9f;check(HudFormatCache.format("%.1f HP",args).equals("9.0 HP"),"changed values refresh formatted text");
   Locale.setDefault(Locale.Category.FORMAT,Locale.GERMANY);check(HudFormatCache.format("%.1f HP",args).equals("9,0 HP"),"locale changes honored");
   StringBuilder mutable=new StringBuilder("a");check(HudFormatCache.format("%s",new Object[]{mutable}).equals("a"),"mutable format object");mutable.append("b");check(HudFormatCache.format("%s",new Object[]{mutable}).equals("ab"),"mutable format object bypasses cache");
  } finally {Locale.setDefault(Locale.Category.FORMAT,saved);}
  if(old) {
   Fullbright full=new Fullbright();DucksWordsClient.MODULES.modules.put(Fullbright.class,full);full.setEnabled(true);
   for(double gamma:new double[]{1,1.5,10,20}) {
    full.gamma.setValue(gamma);FullbrightPixels.prepare();
    for(int i=0;i<256;i++){int p=0x7f000000|i<<16|(255-i)<<8|i;check(FullbrightPixels.preparedBrighten(p)==FullbrightPixels.adjust(p,(float)gamma),"LUT output exact");}
   }
   full.setEnabled(false);FullbrightPixels.prepare();check(FullbrightPixels.preparedBrighten(0x12345678)==0x12345678,"disable passthrough");
  }
  System.out.println("PASS: "+passed+" rendering/performance assertions (includes complete ring coordinates and lightmap LUT checks).");
  // Synthetic CPU-only comparison, same vertex calls and sink; never an in-game FPS claim.
  for(int j=0;j<4;j++){bench(legacy,vc,matrix,5000);bench(direct,vc,matrix,5000);}
  long[] before=new long[7],after=new long[7];
  for(int j=0;j<7;j++){before[j]=bench(legacy,vc,matrix,20000);after[j]=bench(direct,vc,matrix,20000);}
  Arrays.sort(before);Arrays.sort(after);
  System.out.printf(Locale.ROOT,"SYNTHETIC CPU vertexColor: original %.1f ns/vertex; direct %.1f ns/vertex; ratio %.2fx. Stub sink, no GPU; not a Minecraft FPS benchmark.%n",before[3]/20000.,after[3]/20000.,(double)before[3]/after[3]);
 }
 static long bench(MethodHandle handle,class_4588 v,Object matrix,int n)throws Throwable {
  long start=System.nanoTime();for(int i=0;i<n;i++)handle.invokeExact(v,matrix,(float)i,2f,3f,0xff336699);return System.nanoTime()-start;
 }
}
