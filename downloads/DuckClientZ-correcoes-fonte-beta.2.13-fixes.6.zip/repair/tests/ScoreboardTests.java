import com.duckswords.DucksWordsClient;
import com.duckswords.modules.ScoreboardPosition;
import com.duckswords.render.ScoreboardScope;
import net.minecraft.class_332;
import org.joml.Matrix4f;
public class ScoreboardTests {
 static int count;
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);count++;}
 public static void main(String[] args) {
  ScoreboardPosition module=new ScoreboardPosition();DucksWordsClient.MODULES.modules.put(ScoreboardPosition.class,module);
  class_332 ctx=new class_332();
  ScoreboardScope none=ScoreboardScope.begin(ctx);none.close();
  check(ctx.flushes==0&&ctx.matrices.depth==0,"disabled scoreboard does no extra drawing or pushes");
  module.setEnabled(true);
  check(ScoreboardScope.begin(ctx)==none,"default-position scope is allocation-free");
  check(ctx.flushes==0&&ctx.matrices.depth==0,"default transform does not flush GPU buffers");
  module.x.setValue(-30);module.y.setValue(15);module.scale.setValue(1.2);
  ctx.matrices.matrix.translate(4,5,0);Matrix4f before=new Matrix4f(ctx.matrices.matrix);
  ctx.pending.add("chatBefore");
  ScoreboardScope scope=ScoreboardScope.begin(ctx);
  Matrix4f scoreboard=new Matrix4f(ctx.matrices.matrix);
  check(!scoreboard.equals(before),"scoreboard receives its selected position/scale");
  ctx.pending.add("scoreboard");scope.close();
  ctx.pending.add("chatAfter");ctx.method_51452();
  check(ctx.rendered.get("chatBefore").equals(before),"earlier chat batch not shifted by scoreboard");
  check(ctx.rendered.get("scoreboard").equals(scoreboard),"only scoreboard batch uses the scoreboard transform");
  check(ctx.rendered.get("chatAfter").equals(before),"chat and other HUD after scoreboard stay in original position");
  check(ctx.matrices.matrix.equals(before)&&ctx.matrices.depth==0,"parent HUD transform restored, not reset to identity");
  int flushes=ctx.flushes;scope.close();
  check(ctx.flushes==flushes&&ctx.matrices.depth==0,"close is idempotent");
  scope=ScoreboardScope.begin(ctx);module.setEnabled(false);scope.close();
  check(ctx.matrices.depth==0&&ctx.matrices.matrix.equals(before),"disabling mid-draw cannot leak a matrix push");
  module.setEnabled(true);
  try(ScoreboardScope s=ScoreboardScope.begin(ctx)){ctx.pending.add("scoreboardError");throw new IllegalArgumentException("simulated renderer failure");}
  catch(IllegalArgumentException expected){}
  check(ctx.matrices.depth==0&&ctx.matrices.matrix.equals(before),"render failure still restores HUD matrix");
  scope=ScoreboardScope.begin(ctx);ctx.failFlush=true;
  try{scope.close();throw new AssertionError("expected flush failure");}catch(IllegalStateException expected){}
  check(ctx.matrices.depth==0&&ctx.matrices.matrix.equals(before),"buffer-flush failure still pops in finally");
  System.out.println("PASS: "+count+" scoreboard isolation/cleanup/no-op optimization regressions.");
 }
}
