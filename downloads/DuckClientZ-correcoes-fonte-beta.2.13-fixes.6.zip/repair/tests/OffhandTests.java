import com.duckswords.DucksWordsClient;
import com.duckswords.modules.ViewModel;
import com.duckswords.mixin.MixinViewModel1214;
import net.minecraft.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.lang.reflect.Method;
public class OffhandTests extends MixinViewModel1214 {
 static void call(OffhandTests target,String name,class_1268 hand,class_4587 matrices)throws Exception {
  Method m=MixinViewModel1214.class.getDeclaredMethod(name,class_742.class,float.class,float.class,class_1268.class,float.class,class_1799.class,float.class,class_4587.class,class_4597.class,int.class,CallbackInfo.class);
  m.setAccessible(true);m.invoke(target,new class_742(),0f,0f,hand,0f,new class_1799(),0f,matrices,null,0,new CallbackInfo("test",false));
 }
 public static void main(String[] a)throws Exception {
  ViewModel model=new ViewModel();model.setEnabled(true);DucksWordsClient.MODULES.modules.put(ViewModel.class,model);
  OffhandTests target=new OffhandTests();class_4587 m=new class_4587();
  model.affectFood=false;
  call(target,"duckvisuals$transformFirstPersonItem",class_1268.field_5810,m);
  if(m.depth!=1||m.translations!=1)throw new AssertionError("food toggle still removes offhand position");
  call(target,"duckvisuals$scaleRenderedItem",class_1268.field_5810,m);
  if(m.scales!=0)throw new AssertionError("food scaling should remain excluded");
  call(target,"duckvisuals$restoreMatrix",class_1268.field_5810,m);
  if(m.depth!=0)throw new AssertionError("offhand matrix stack unbalanced");
  call(target,"duckvisuals$transformFirstPersonItem",class_1268.field_5808,m);
  call(target,"duckvisuals$restoreMatrix",class_1268.field_5808,m);
  if(m.depth!=0||m.translations!=1)throw new AssertionError("main-hand food behavior changed");
  model.affectFood=true;call(target,"duckvisuals$transformFirstPersonItem",class_1268.field_5810,m);
  call(target,"duckvisuals$scaleRenderedItem",class_1268.field_5810,m);
  call(target,"duckvisuals$restoreMatrix",class_1268.field_5810,m);
  if(m.depth!=0||m.translations!=2||m.scales!=1)throw new AssertionError("affect food on should retain pose and scale");
  System.out.println("PASS: 5 offhand food/pose/scale regressions, invoking the actual patched mixin handlers.");
 }
}
