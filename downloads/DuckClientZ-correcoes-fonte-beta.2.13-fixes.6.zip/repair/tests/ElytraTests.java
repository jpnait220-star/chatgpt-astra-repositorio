import com.duckswords.render.*;
import com.duckswords.modules.ElytraFeature;
import com.duckswords.DucksWordsClient;
import net.minecraft.*;
import org.objectweb.asm.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.lang.reflect.*;
public class ElytraTests implements Opcodes {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static void near(float a,float b,String s){check(Math.abs(a-b)<1e-5,s+": "+a+" vs "+b);}
 static class State extends class_10034 implements ElytraMotion {
  long motion;public long duckclientz$getMotion(){return motion;}public void duckclientz$setMotion(long m){motion=m;}
 }
 static class SameIdEntity extends class_1309 {
  public boolean equals(Object other){return other instanceof SameIdEntity;}
  public int hashCode(){return 7;}
 }
 static class Models extends ClassLoader {
  Models(){super(ElytraTests.class.getClassLoader());}
  Class<?> model(String parent,boolean modern) {
   String name="ElytraHookProbe",accessor="com/duckswords/mixin/MixinElytraEntityModelAccessor1214";
   ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(V17,ACC_PUBLIC,name,null,parent,modern?new String[]{accessor}:new String[0]);
   if(modern)for(String side:new String[]{"Left","Right"}) {
    w.visitField(ACC_PUBLIC,side,"Lnet/minecraft/class_630;",null,null).visitEnd();
    MethodVisitor m=w.visitMethod(ACC_PUBLIC,"duckswords$get"+side+"Wing","()Lnet/minecraft/class_630;",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,name,side,"Lnet/minecraft/class_630;");m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();
   }
   MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","()V",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKESPECIAL,parent,"<init>","()V",false);m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();
   byte[] data=w.toByteArray();return defineClass(name,data,0,data.length);
  }
 }
 public static void main(String[] a)throws Exception {
  ElytraSpring spring=new ElytraSpring();
  for(int t=0;t<100;t++)check(spring.sample(t,0,0,0,0,false,false,1)==0,"stationary wings never acquire idle wobble");
  long forward=spring.sample(100,0,0,.25,0,false,false,1);
  check(ElytraSpring.pitch(forward)>0&&ElytraSpring.roll(forward)==0,"forward motion creates shared cape-like pitch");
  near(ElytraSpring.pitch(spring.sample(100,0,0,.25,0,false,false,1)),ElytraSpring.pitch(forward),"repeated render pass at same age does not advance simulation");
  for(int t=101;t<140;t++)spring.sample(t,0,0,0,0,false,false,1);
  check(spring.sample(140,0,0,0,0,false,false,1)==0,"stopping settles exactly without perpetual oscillation");
  long left=new ElytraSpring().sample(0,.2,0,0,0,false,false,1),right=new ElytraSpring().sample(0,-.2,0,0,0,false,false,1);
  near(ElytraSpring.roll(left),-ElytraSpring.roll(right),"lateral lean reverses with direction");
  near(ElytraSpring.pitch(new ElytraSpring().sample(0,-.25,0,0,90,false,false,1)),.5f,"body-relative forward motion respects yaw");
  check(new ElytraSpring().sample(0,0,0,.5,0,false,true,1)==0,"gliding retains native wing pose");
  check(new ElytraSpring().sample(0,0,0,.5,0,false,false,0)==0,"zero incline leaves pose untouched");
  check(new ElytraSpring().sample(0,Double.NaN,0,0,0,false,false,1)==0,"invalid velocity cannot poison model angles");
  ElytraSpring slow=new ElytraSpring(),fast=new ElytraSpring();slow.sample(0,0,0,0,0,false,false,1);fast.sample(0,0,0,0,0,false,false,1);
  long s=0,f=0;
  for(int i=1;i<=20;i++)s=slow.sample(i,0,0,.2,0,false,false,1);
  for(int i=1;i<=60;i++)f=fast.sample(i/3f,0,0,.2,0,false,false,1);
  near(ElytraSpring.pitch(s),ElytraSpring.pitch(f),"equal elapsed ticks yield same lean at different FPS");
  check(Float.isFinite(ElytraSpring.pitch(slow.sample(-1,0,0,.2,0,false,false,2))),"age reset/world transition stays finite");
  ElytraFeature feature=new ElytraFeature();DucksWordsClient.MODULES.modules.put(ElytraFeature.class,feature);feature.setEnabled(true);
  class_1309 entity=new class_1309();entity.velocity=new class_243(0,0,.2);
  class_630 l=new class_630(),r=new class_630();l.field_3654=r.field_3654=.26f;l.field_3674=-.26f;r.field_3674=.26f;
  ElytraPhysics.render(entity,l,r,1);
  near(l.field_3654,r.field_3654,"both wings lean together instead of alternating flap");check(l.field_3654>.26f,"movement affects model pitch");
  near(l.field_3674,-.26f,"native left spread preserved");near(r.field_3674,.26f,"native right spread preserved");
  SameIdEntity oldWorld=new SameIdEntity(),newWorld=new SameIdEntity();oldWorld.velocity=new class_243(0,0,.4);
  ElytraPhysics.render(oldWorld,new class_630(),new class_630(),5);
  class_630 fresh=new class_630();ElytraPhysics.render(newWorld,fresh,new class_630(),5);
  near(fresh.field_3654,0,"equal numeric entity IDs do not share motion across worlds");
  feature.physics.setValue(false);float before=l.field_3654;ElytraPhysics.render(entity,l,r,2);near(l.field_3654,before,"physics disabled leaves model untouched");feature.physics.setValue(true);
  boolean modern=a[0].equals("1.21.4");
  State state=new State();
  if(modern) {
   // Execute the actual new injection handler, then verify state reuse is safe.
   var captureClass=Class.forName("com.duckswords.mixin.MixinElytraMotionCapture");Object capture=captureClass.getConstructor().newInstance();
   Method hook=captureClass.getDeclaredMethod("duckclientz$capture",class_1309.class,class_10042.class,float.class,CallbackInfo.class);hook.setAccessible(true);
   entity.chest.item=class_1802.field_8833;hook.invoke(capture,entity,state,.5f,new CallbackInfo("capture",false));check(state.motion!=0,"1.21.4 captures equipped Elytra wearer motion");
   class_1309 other=new class_1309();hook.invoke(capture,other,state,.5f,new CallbackInfo("capture",false));check(state.motion==0,"reused render state cannot leak another entity's lean");
   hook.invoke(capture,entity,state,.5f,new CallbackInfo("capture",false));
   ElytraMotion carrier=(ElytraMotion)Class.forName("com.duckswords.mixin.MixinElytraMotionState").getConstructor().newInstance();carrier.duckclientz$setMotion(state.motion);check(carrier.duckclientz$getMotion()==state.motion,"actual carrier getter/setter preserve data");
  }
  // Invoke exact patched old/new model handlers with their original signatures.
  String parent="com/duckswords/mixin/"+(modern?"MixinElytraEntityModel1214":"RepairElytraModel");Class<?> base=Class.forName(parent.replace('/','.'));
  Object model=new Models().model(parent,modern).getConstructor().newInstance();
  l=new class_630();r=new class_630();l.field_3654=r.field_3654=.26f;
  if(modern){model.getClass().getField("Left").set(model,l);model.getClass().getField("Right").set(model,r);}
  else for(String name:new String[]{"field_3365","field_27412"}){Field wing=base.getDeclaredField(name);wing.setAccessible(true);wing.set(model,name.equals("field_3365")?l:r);}
  if(modern){Method hook=base.getDeclaredMethod("duckswords$animateWings",class_10034.class,CallbackInfo.class);hook.setAccessible(true);hook.invoke(model,state,new CallbackInfo("angles",false));}
  else {Method hook=base.getDeclaredMethod("animate",class_1309.class,float.class,float.class,float.class,float.class,float.class,CallbackInfo.class);hook.setAccessible(true);hook.invoke(model,entity,0f,0f,3f,0f,0f,new CallbackInfo("angles",false));}
  check(l.field_3654>.26f&&l.field_3654==r.field_3654,"actual patched model hook applies symmetric motion incline");
  System.out.println("PASS: "+checks+" Elytra motion assertions (idle/stop/strafe/yaw/gliding/FPS independence, module gating and actual patched hooks).");
 }
}
