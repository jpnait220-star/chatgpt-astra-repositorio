from pathlib import Path
root=Path(__file__).parent/'stubs'
files={p.relative_to(root).as_posix():p.read_text() for p in root.rglob('*.java')}
for name,source in files.items():
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
