"""Re-run isolated regressions and real-Minecraft member/injection checks. Requires prepared tools."""
from pathlib import Path
import subprocess,os,json,sys
ROOT=Path(__file__).resolve().parent.parent
B=ROOT/'repair';T=ROOT/'tools'
def cp(*paths):return os.pathsep.join(str(p) for p in paths)
fixture=Path(sys.argv[1])
classpath=cp(B/'testclasses',B/'teststubclasses',B/'stubclasses',B/'classes',T/'joml.jar',T/'mixin.jar',T/'gson.jar',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',ROOT/'dist-fixes6/DuckClientZ-1.21.4-1.5.28-beta.2.13-fixes.6-experimental.jar')
sources=list((B/'tests').rglob('*.java'))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',classpath,'-d',str(B/'testclasses'),*[str(p) for p in sources]],check=True)
logs=[]
loadercp=cp(B/'toolclasses',T/'fabric-loader-0.16.10.jar')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',loadercp,'-d',str(B/'toolclasses'),str(B/'FabricMetadataTest.java')],check=True)
extractcp=cp(B/'toolclasses',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',T/'asm-commons-9.7.1.jar')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',extractcp,'-d',str(B/'toolclasses'),str(B/'ExtractVertexProbe.java')],check=True)
for v,report in json.loads((ROOT/'build-report.json').read_text()).items():
 changed=B/f'changed-{v}.txt';changed.write_text('\n'.join(report['changed_or_added']))
 jar=ROOT/'dist-fixes6'/Path(report['jar']).name
 asm=cp(B/'toolclasses',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',T/'asm-commons-9.7.1.jar',T/'asm-analysis-9.7.1.jar')
 commands=[['java','-cp',loadercp,'FabricMetadataTest',str(jar)],['java','-cp',asm,'VerifyArtifacts',str(T/f'intermediary-{v}.tiny'),str(T/f'minecraft-{v}-client'),str(jar),v,str(changed)]]
 probes=B/'perfprobes'/v
 for inputjar,name in [(ROOT/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar','LegacyVerticesProbe'),(jar,'DirectVerticesProbe')]:
  subprocess.run(['java','-cp',extractcp,'ExtractVertexProbe',str(inputjar),str(probes),name],check=True)
 runtime=cp(probes,B/'testclasses',B/'teststubclasses',B/'stubclasses',jar,T/'joml.jar',T/'mixin.jar',T/'gson.jar',T/'slf4j-api-2.0.9.jar',T/'slf4j-simple-2.0.9.jar')
 potioncp=cp(runtime,T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar')
 commands += [['java','-Xverify:all','-cp',potioncp,'ElytraTests',v],['java','-Xverify:all','-cp',potioncp,'PotionCrashTests',str(ROOT/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar'),str(jar),v],['java','-Xverify:all','-cp',runtime,'ScoreboardTests'],['java','-Xverify:all','-cp',runtime,'RepairTests',v],['java','-Xverify:all','-cp',runtime,'PerformanceTests',v],['java','-Xverify:all','-cp',runtime,'ProfileFontTests',str(fixture)],['java','-Xverify:all','-cp',runtime,'DefaultMigrationTests',str(fixture)]]
 if v=='1.21.1':commands.append(['java','-Xverify:all','-cp',runtime,'OutlineTests'])
 if v=='1.21.4':commands.append(['java','-Xverify:all','-cp',runtime,'OffhandTests'])
 for command in commands:
  result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  print(v,result.stdout.strip(),flush=True)
  logs.append(v+': '+result.stdout.strip())
  if result.returncode:
   (ROOT/'validation-failed.txt').write_text('\n'.join(logs))
   raise SystemExit(result.returncode)
(ROOT/'VALIDACAO_TECNICA.txt').write_text('DuckClientZ 1.5.28-beta.2.13-fixes.6\n\n'+'\n'.join(logs)+'\n\nLimites: testes isolados em JVM 21/Linux, com stubs de Minecraft para executar a logica.\nMembros e alvos de injeção conferidos nos JARs reais de cada versao do Minecraft.\nMinecraft/Fabric completo e Pojav/Android NAO foram iniciados.\nNao foi confirmada a aparencia dentro do jogo nem compatibilidade com outros mods/renderizadores.\n',encoding='utf-8')
