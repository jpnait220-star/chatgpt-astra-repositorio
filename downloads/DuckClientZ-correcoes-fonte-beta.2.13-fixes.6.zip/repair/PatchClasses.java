import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class PatchClasses implements Opcodes {
    public static void main(String[] args)throws Exception {
        Path out=Paths.get(args[1]);Files.createDirectories(out);
        try(ZipFile jar=new ZipFile(args[0])) {
            patch(jar,out,"com/duckswords/profiles/ProfileManager",0);
            patch(jar,out,"com/duckswords/PojavCompat",1);
            patch(jar,out,"com/duckswords/theme/HudText",2);
            patch(jar,out,"com/duckswords/mixin/MixinScoreboardPosition",5);
            if(args.length>2&&args[2].equals("1.21.4")) {
                patch(jar,out,"com/duckswords/mixin/MixinViewModel1214",3);
                patch(jar,out,"com/duckswords/modules/ViewModel",4);
            }
        }
        tailorScoreboard(Paths.get(args[3]),out,args[2]);
    }
    static void tailorScoreboard(Path compiled,Path out,String version)throws Exception {
        String name="com/duckswords/mixin/MixinScopedScoreboard";
        ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(compiled.resolve(name+".class"))).accept(c,0);
        String caller=version.equals("1.20.1")?"method_1753(Lnet/minecraft/class_332;F)V":"method_55803(Lnet/minecraft/class_332;Lnet/minecraft/class_9779;)V";
        int changed=0;
        for(MethodNode m:c.methods)if(m.visibleAnnotations!=null)for(AnnotationNode an:m.visibleAnnotations)
            if(an.desc.equals("Lorg/spongepowered/asm/mixin/injection/Redirect;"))
                for(int i=0;i<an.values.size();i+=2)if(an.values.get(i).equals("method")) {an.values.set(i+1,new ArrayList<>(List.of(caller)));changed++;}
        if(changed!=1)throw new IllegalStateException("Missing scoreboard redirect annotation");
        ClassWriter w=new ClassWriter(0);c.accept(w);Path target=out.resolve(name+".class");Files.createDirectories(target.getParent());Files.write(target,w.toByteArray());
        System.out.println(version+": isolated scoreboard caller "+caller);
    }
    static void patch(ZipFile jar,Path out,String name,int kind)throws Exception {
        ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getEntry(name+".class"))).accept(c,0);
        int edits=0; int mobileReads=0; int fontStyles=0;
        if(kind==5) {
            int before=c.methods.size();
            c.methods.removeIf(m->m.name.equals("duckswords$pushScoreboardOffset")||m.name.equals("duckswords$popScoreboardOffset"));
            edits=before-c.methods.size();
        }
        for(MethodNode m:c.methods) {
            if(kind==1&&m.name.equals("styled")) {
                m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;
                m.instructions.add(new VarInsnNode(ALOAD,0));
                m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/theme/HudText","duck$styledDesktop","(Ljava/lang/String;)Lnet/minecraft/class_2561;",false));
                m.instructions.add(new InsnNode(ARETURN));edits++;
            }
            if(kind==1&&m.name.equals("isPojav")) {
                for(AbstractInsnNode ins:m.instructions.toArray())
                    if(ins.getOpcode()==IRETURN)m.instructions.insertBefore(ins,new MethodInsnNode(INVOKESTATIC,"com/duckswords/compat/MobileRuntime","resolve","(Z)Z",false));
            }
            for(AbstractInsnNode ins:m.instructions.toArray()) {
                if(kind==1&&!m.name.equals("isPojav")&&ins instanceof FieldInsnNode field&&field.getOpcode()==GETSTATIC&&field.owner.equals("com/duckswords/PojavCompat")&&field.name.equals("POJAV")) {
                    m.instructions.set(ins,new MethodInsnNode(INVOKESTATIC,"com/duckswords/PojavCompat","isPojav","()Z",false));mobileReads++;
                }
                if(kind==4&&m.name.equals("<init>")&&ins instanceof LdcInsnNode text&&text.cst instanceof String value&&value.startsWith("Aplica o ViewModel ao comer;")) {
                    text.cst="Aplica escala e pose ao comer; posicao da mao secundaria permanece independente";edits++;
                }
                if(!(ins instanceof MethodInsnNode call))continue;
                if(kind==0&&m.name.equals("initialize")&&call.owner.equals("com/duckswords/Config")&&call.name.equals("exportProfileJson")) {
                    call.owner="com/duckswords/profiles/ProfileManager";call.name="defaultProfileConfig";edits++;
                }
                if(kind==0&&m.name.equals("initialize")&&call.owner.equals("com/duckswords/profiles/ProfileManager")&&call.name.equals("duck$seedDefaultIfMissing")) {
                    InsnList list=new InsnList();
                    list.add(new FieldInsnNode(GETSTATIC,c.name,"DIRECTORY","Ljava/nio/file/Path;"));
                    list.add(new MethodInsnNode(INVOKESTATIC,c.name,"defaultProfileConfig","()Ljava/lang/String;",false));
                    list.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/profiles/DefaultProfileMigration","migrate","(Ljava/nio/file/Path;Ljava/lang/String;)V",false));
                    m.instructions.insert(call,list);edits++;
                }
                if(kind==2&&m.name.equals("duck$styledDesktop")&&call.owner.equals("java/util/stream/IntStream")&&call.name.equals("anyMatch")) {
                    AbstractInsnNode lambda=call.getPrevious();while(lambda.getOpcode()<0)lambda=lambda.getPrevious();
                    AbstractInsnNode codepoints=lambda.getPrevious();while(codepoints.getOpcode()<0)codepoints=codepoints.getPrevious();
                    AbstractInsnNode value=codepoints.getPrevious();while(value.getOpcode()<0)value=value.getPrevious();
                    if(!(lambda instanceof InvokeDynamicInsnNode)||!(codepoints instanceof MethodInsnNode cp)||!cp.owner.equals("java/lang/String")||!cp.name.equals("codePoints")||!(value instanceof VarInsnNode v)||v.getOpcode()!=ALOAD||v.var!=0)throw new IllegalStateException("Unexpected font fallback expression");
                    m.instructions.insertBefore(call,new InsnNode(ICONST_0));
                    m.instructions.remove(value);m.instructions.remove(codepoints);m.instructions.remove(lambda);m.instructions.remove(call);edits++;
                }
                if(kind==2&&m.name.equals("duck$styledDesktop")&&call.owner.equals("net/minecraft/class_2583")&&call.name.equals("method_27704")) {
                    call.setOpcode(INVOKESTATIC);call.owner="com/duckswords/render/FontStyleCache";call.name="withFont";
                    call.desc="(Lnet/minecraft/class_2583;Lnet/minecraft/class_2960;)Lnet/minecraft/class_2583;";call.itf=false;fontStyles++;
                }
                if(kind==3&&(m.name.contains("transformFirstPersonItem")||m.name.contains("restoreMatrix"))&&call.owner.equals("com/duckswords/modules/ViewModel")&&call.name.equals("shouldApply")) {
                    // Offhand pose is independent. Preserve main-hand food behavior and item-scale gating.
                    if(!call.desc.equals("(Lnet/minecraft/class_742;Lnet/minecraft/class_1268;Lnet/minecraft/class_1799;)Z"))throw new IllegalStateException(call.desc);
                    InsnList list=new InsnList();list.add(new VarInsnNode(ALOAD,4));
                    list.add(new FieldInsnNode(GETSTATIC,"net/minecraft/class_1268","field_5810","Lnet/minecraft/class_1268;"));
                    list.add(new MethodInsnNode(INVOKESTATIC,"java/util/Objects","equals","(Ljava/lang/Object;Ljava/lang/Object;)Z",false));
                    list.add(new InsnNode(IOR));m.instructions.insert(call,list);edits++;
                }
            }
        }
        if(kind==1&&mobileReads!=2)throw new IllegalStateException("Expected two mobile path checks, got "+mobileReads);
        if(kind==2&&fontStyles!=1)throw new IllegalStateException("Font style cache hook absent");
        int expected=(kind==0||kind==3||kind==5)?2:1;
        if(edits!=expected)throw new IllegalStateException(name+": expected "+expected+" edits, found "+edits);
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(writer);
        Path target=out.resolve(name+".class");Files.createDirectories(target.getParent());Files.write(target,writer.toByteArray());
        System.out.println(name+": "+edits+" verified edit(s)");
    }
}
