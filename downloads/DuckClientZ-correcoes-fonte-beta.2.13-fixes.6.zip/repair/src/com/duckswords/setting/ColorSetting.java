/*
 * Decompiled with CFR 0.152.
 */
package com.duckswords.setting;

import com.duckswords.setting.Setting;
import java.awt.Color;

public class ColorSetting
extends Setting<Integer> {
    private int value;
    private int hsbColor;
    private boolean hsbValid;
    private final float[] hsbCache = new float[3];
    private float[] cachedHsb() {
        int rgb = this.value & 0xFFFFFF;
        if (!hsbValid || hsbColor != rgb) {
            Color.RGBtoHSB(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255, hsbCache);
            hsbColor = rgb; hsbValid = true;
        }
        return hsbCache;
    }
    private final int defaultValue;
    private boolean rgbAllowed;
    private boolean rgbEnabled;

    public ColorSetting(String name, String description, int argb) {
        super(name, description);
        this.value = argb;
        this.defaultValue = argb;
    }

    @Override
    public void reset() {
        this.value = this.defaultValue;
        this.rgbEnabled = false;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    public int getDisplayValue() {
        if (!this.rgbAllowed || !this.rgbEnabled) {
            return this.value;
        }
        long phaseOffset = Integer.toUnsignedLong(System.identityHashCode(this)) * 31L;
        int rgb = Color.HSBtoRGB((float)((System.currentTimeMillis() + phaseOffset) % 6000L) / 6000.0f, 1.0f, 1.0f) & 0xFFFFFF;
        return this.value & 0xFF000000 | rgb;
    }

    public void allowRgb() {
        this.rgbAllowed = true;
    }

    public boolean isRgbAllowed() {
        return this.rgbAllowed;
    }

    public boolean isRgbEnabled() {
        return this.rgbEnabled;
    }

    public void setRgbEnabled(boolean enabled) {
        this.rgbEnabled = this.rgbAllowed && enabled;
    }

    public void setValue(int argb) {
        this.value = argb;
    }

    public float r() {
        return (float)(this.value >> 16 & 0xFF) / 255.0f;
    }

    public float g() {
        return (float)(this.value >> 8 & 0xFF) / 255.0f;
    }

    public float b() {
        return (float)(this.value & 0xFF) / 255.0f;
    }

    public float a() {
        return (float)(this.value >>> 24 & 0xFF) / 255.0f;
    }

    public int withAlpha(float alpha) {
        int a = (int)(Math.max(0.0f, Math.min(1.0f, alpha)) * 255.0f);
        return a << 24 | this.value & 0xFFFFFF;
    }

    public void setHue(float hue) {
        float[] hsb = this.cachedHsb();
        int rgb = Color.HSBtoRGB(Math.max(0.0f, Math.min(1.0f, hue)), hsb[1], hsb[2]) & 0xFFFFFF;
        this.value = this.value & 0xFF000000 | rgb;
    }

    public void setSaturation(float saturation) {
        float[] hsb = this.cachedHsb();
        int rgb = Color.HSBtoRGB(hsb[0], Math.max(0.0f, Math.min(1.0f, saturation)), hsb[2]) & 0xFFFFFF;
        this.value = this.value & 0xFF000000 | rgb;
    }

    public void setBrightness(float brightness) {
        float[] hsb = this.cachedHsb();
        int rgb = Color.HSBtoRGB(hsb[0], hsb[1], Math.max(0.0f, Math.min(1.0f, brightness))) & 0xFFFFFF;
        this.value = this.value & 0xFF000000 | rgb;
    }

    public float hue() {
        return this.cachedHsb()[0];
    }

    public float saturation() {
        return this.cachedHsb()[1];
    }

    public float brightness() {
        return this.cachedHsb()[2];
    }

    public void setAlphaByte(int alpha) {
        this.value = (alpha & 0xFF) << 24 | this.value & 0xFFFFFF;
    }
}

