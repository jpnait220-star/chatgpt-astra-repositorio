/*
 * Decompiled with CFR 0.152.
 */
package com.duckswords.theme;

import com.duckswords.DucksWordsClient;
import com.duckswords.module.Category;
import com.duckswords.module.Module;
import com.duckswords.setting.BooleanSetting;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.ModeSetting;
import com.duckswords.setting.NumberSetting;

public class Interface
extends Module {
    public final ColorSetting color1 = this.add(new ColorSetting("Cor 1", "Cor inicial do gradiente", -1885381));
    public final ColorSetting color2 = this.add(new ColorSetting("Cor 2", "Cor final do gradiente", -10608351));
    public final ModeSetting themeMode = this.add(new ModeSetting("Tema da interface", "Escolhe o esquema de cores base dos menus", "Dark", "Dark", "Azulado", "Claro"));
    public final ColorSetting menuButtonColor = this.add(new ColorSetting("Cor dos botoes do menu", "Cor de destaque dos botoes dos menus Duck ClientZ", -3917768));
    public final BooleanSetting menuBackgroundEnabled = this.add(new BooleanSetting("Exibir fundo do menu", "Ativa o fundo colorido nos menus; desligado mant\u00e9m o jogo vis\u00edvel sem camada vermelha", true));
    public final BooleanSetting menuBackgroundFollowsTheme = this.add(new BooleanSetting("Fundo do menu acompanha o tema", "Usa a cor de destaque da interface no fundo dos menus", false));
    public final ColorSetting menuBackgroundColor = this.add(new ColorSetting("Cor de fundo do menu", "Cor personalizada usada quando o fundo nao acompanha o tema", -16777216));
    public final NumberSetting menuPanelBrightness = this.add(new NumberSetting("Clarear / escurecer as GUIs", "Clareia ou escurece os paineis e cards das interfaces; nao altera o mundo atras do menu", -1.0, -1.0, 1.0, 0.05));
    public final BooleanSetting gradient = this.add(new BooleanSetting("Gradiente", "Usa gradiente entre as duas cores", true));
    public final ColorSetting hoverColor = this.add(new ColorSetting("Cor da selecao", "Cor do card sob o mouse", -65536));
    public final ColorSetting hoverGradientColor = this.add(new ColorSetting("Cor do gradiente de selecao", "Cor do gradiente exibido ao passar o mouse sobre cards", -65536));
    public final NumberSetting hoverGradientStrength = this.add(new NumberSetting("Forca do gradiente de selecao", "Intensidade do gradiente exibido ao passar o mouse sobre cards", 2.0, 0.0, 2.0, 0.05));
    public final NumberSetting hoverGradientFade = this.add(new NumberSetting("Fade do gradiente de selecao (ms)", "Duracao da transicao do gradiente ao passar ou retirar o mouse", 410.0, 50.0, 600.0, 10.0));
    public final NumberSetting featureBackgroundDarkness = this.add(new NumberSetting("Escurecer fundo das features", "Escurece apenas o preenchimento dos cards de features, sem alterar texto, icones, controles ou cores do tema", 0.9, 0.0, 0.9, 0.05));
    public final BooleanSetting hoverGlow = this.add(new BooleanSetting("Brilho na selecao", "Contorno brilhante ao passar o mouse", true));
    public final ColorSetting enabledColor = this.add(new ColorSetting("Cor ativado", "Cor da feature ativada", -3914160));
    public final ColorSetting disabledColor = this.add(new ColorSetting("Cor desativado", "Cor da feature desligada", -8618884));
    public final BooleanSetting fixScale = this.add(new BooleanSetting("Escala 2x", "Se a escala da GUI for 3x, desenha como 2x", true));
    public final BooleanSetting hudColors = this.add(new BooleanSetting("Cor global do HUD", "Pinta todos os HUDs com a cor da interface", false));
    public final ModeSetting hudFont = this.add(new ModeSetting("Fonte do HUD", "Fonte usada nos HUDs e menus DuckClientZ sem alterar a fonte do Minecraft", "Minecraft", "Inter Frozen", "JetBrains Mono", "DM Sans", "Google Sans", "Oswald", "Changa One", "Archivo Black", "BBH Hegarty", "VT323", "GeoFont Edge", "Minecraft"));
    public final NumberSetting bgAlpha = this.add(new NumberSetting("Opacidade", "Opacidade do fundo dos paineis", 0.7000000000000001, 0.2, 1.0, 0.05));

    public Interface() {
        super("Interface", "Cores, selecao e gradiente do client", Category.CLIENT);
        this.setEnabled(true);
    }

    public static Interface get() {
        return DucksWordsClient.MODULES.get(Interface.class);
    }

    @Override
    public void setEnabled(boolean value) {
        super.setEnabled(true);
    }
}

