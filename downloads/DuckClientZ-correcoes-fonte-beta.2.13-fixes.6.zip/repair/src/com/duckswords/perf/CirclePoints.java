package com.duckswords.perf;
import java.util.LinkedHashMap;
import java.util.Map;
/** Immutable-by-contract unit coordinates, bounded to eight common resolutions. */
public final class CirclePoints {
    private static final Map<Integer,double[]> CACHE=new LinkedHashMap<Integer,double[]>(8,.75f,true) {
        protected boolean removeEldestEntry(Map.Entry<Integer,double[]> e){return size()>8;}
    };
    public static synchronized double[] get(int segments) {
        if(segments<3||segments>4096)throw new IllegalArgumentException("segments");
        double[] points=CACHE.get(segments);
        if(points==null) {
            points=new double[(segments+1)*2];
            for(int i=0;i<=segments;i++) {
                double angle=Math.PI*2*i/segments;
                points[i*2]=Math.cos(angle);points[i*2+1]=Math.sin(angle);
            }
            CACHE.put(segments,points);
        }
        return points;
    }
}
