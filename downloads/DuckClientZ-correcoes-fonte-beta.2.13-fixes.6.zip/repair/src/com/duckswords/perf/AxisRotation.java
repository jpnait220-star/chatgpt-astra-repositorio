package com.duckswords.perf;
import net.minecraft.class_4587;
import org.joml.Quaternionf;
/** Exact positive-axis rotations without reflective discovery on each call. */
public final class AxisRotation {
    public static void rotate(class_4587 matrices,String axis,float degrees) {
        float radians=degrees*((float)Math.PI/180.0f);
        Quaternionf rotation=new Quaternionf();
        switch(axis) {
            case "X": rotation.rotationX(radians);break;
            case "Y": rotation.rotationY(radians);break;
            case "Z": rotation.rotationZ(radians);break;
            default: throw new IllegalArgumentException("Unknown rotation axis: "+axis);
        }
        matrices.method_22907(rotation);
    }
}
