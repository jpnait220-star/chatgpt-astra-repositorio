package com.duckswords.perf;
import java.util.*;
/** Cache only immutable numeric/String HUD arguments; preserve Locale and formatter errors. */
public final class HudFormatCache {
    private static final Map<String,Entry> CACHE=new LinkedHashMap<String,Entry>(16,.75f,true) {
        protected boolean removeEldestEntry(Map.Entry<String,Entry> e){return size()>32;}
    };
    private record Entry(Locale locale,Object[] args,String result) {}
    public static synchronized String format(String pattern,Object[] args) {
        if(pattern==null||args==null)return String.format(pattern,args);
        for(Object arg:args)
            if(arg!=null&&!(arg instanceof String||arg instanceof Byte||arg instanceof Short||arg instanceof Integer||arg instanceof Long||arg instanceof Float||arg instanceof Double||arg instanceof Boolean||arg instanceof Character))
                return String.format(pattern,args);
        Locale locale=Locale.getDefault(Locale.Category.FORMAT);
        Entry entry=CACHE.get(pattern);
        if(entry!=null&&entry.locale.equals(locale)&&Arrays.equals(entry.args,args))return entry.result;
        String result=String.format(locale,pattern,args);
        CACHE.put(pattern,new Entry(locale,args.clone(),result));
        return result;
    }
}
