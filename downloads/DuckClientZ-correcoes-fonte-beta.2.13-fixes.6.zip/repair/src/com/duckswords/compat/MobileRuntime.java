package com.duckswords.compat;
import java.util.Map;
public final class MobileRuntime {
    public static boolean resolve(boolean original) {
        return resolve(original,System.getProperty("duckclientz.pojav"),System.getenv());
    }
    public static boolean resolve(boolean original,String override,Map<String,String> environment) {
        if("false".equalsIgnoreCase(override))return false;
        if("true".equalsIgnoreCase(override))return true;
        return original||(environment.containsKey("ANDROID_ROOT")&&environment.containsKey("ANDROID_DATA"));
    }
}
