package com.duckswords.profiles;
import com.duckswords.DuckSharedPaths;
import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
/** One-time replacement of the accidentally seeded blue/green Default. */
public final class DefaultProfileMigration {
    private static final String MARKER="default-red-v1.applied";
    public static void migrate(Path directory,String requestedConfig)throws IOException {
        migrateRed(directory,requestedConfig);
        migrateFont(directory,requestedConfig);
    }
    private static void migrateFont(Path directory,String requestedConfig)throws IOException {
        Path marker=directory.resolve("default-minecraft-font-v1.applied");
        if(Files.exists(marker))return;
        Path path=directory.resolve("default.json");
        JsonObject wrapper=parseObject(Files.readString(path));
        JsonObject config=parseObject(wrapper.get("config").getAsString());
        JsonObject settings=config.getAsJsonObject("Interface").getAsJsonObject("settings");
        JsonObject defaults=parseObject(requestedConfig).getAsJsonObject("Interface").getAsJsonObject("settings");
        String font=settings.has("Fonte do HUD")?settings.get("Fonte do HUD").getAsString():"";
        boolean oldDefault=font.equals("GeoFont Edge")&&color(settings.get("Cor 1"))==color(defaults.get("Cor 1"))&&color(settings.get("Cor 2"))==color(defaults.get("Cor 2"));
        if(font.isEmpty()||oldDefault) {
            Path backup=Files.createTempFile(directory,"default-fonte-anterior-",".bak");
            Files.write(backup,Files.readAllBytes(path));
            settings.addProperty("Fonte do HUD","Minecraft");
            wrapper.addProperty("config",config.toString());
            DuckSharedPaths.writeStringSafely(path,wrapper.toString());
        }
        DuckSharedPaths.writeStringSafely(marker,"minecraft-font-v1\n");
    }
    private static void migrateRed(Path directory,String requestedConfig)throws IOException {
        if(Files.exists(directory.resolve(MARKER)))return;
        JsonObject requested=parseObject(requestedConfig);
        Path profile=directory.resolve("default.json");
        JsonObject wrapper;
        boolean replace=!Files.exists(profile);
        if(replace) {
            wrapper=new JsonObject();wrapper.addProperty("name","Default");
        } else {
            wrapper=parseObject(Files.readString(profile));
            if(!wrapper.has("config")||!wrapper.get("config").isJsonPrimitive())throw new IOException("Invalid Default configuration");
            JsonObject old=parseObject(wrapper.get("config").getAsString());
            replace=isLegacy(old);
        }
        if(replace) {
            // Keep the original bytes before replacing settings, including unknown properties.
            if(Files.exists(profile)) {
                byte[] original=Files.readAllBytes(profile);
                Path backup=Files.createTempFile(directory,"default-azul-verde-",".bak");
                Files.write(backup,original);
            }
            wrapper.addProperty("config",requested.toString());
            DuckSharedPaths.writeStringSafely(profile,wrapper.toString());
        }
        // Once handled, later deliberate customization is never reset on startup.
        DuckSharedPaths.writeStringSafely(directory.resolve(MARKER),"red-default-v1\n");
    }
    private static boolean isLegacy(JsonObject config) {
        if(!config.has("Interface"))return true;
        JsonElement ui=config.get("Interface");
        if(!ui.isJsonObject()||!ui.getAsJsonObject().has("settings"))return true;
        JsonElement raw=ui.getAsJsonObject().get("settings");
        if(!raw.isJsonObject())return true;
        JsonObject settings=raw.getAsJsonObject();
        if(!settings.has("Cor 1")||!settings.has("Cor 2"))return true;
        return color(settings.get("Cor 1"))==-16040049&&color(settings.get("Cor 2"))==-11093505;
    }
    private static int color(JsonElement value) {
        if(value==null)return 0;
        if(value.isJsonObject())value=value.getAsJsonObject().get("value");
        try {return value==null?0:value.getAsInt();}catch(RuntimeException e){return 0;}
    }
    private static JsonObject parseObject(String value)throws IOException {
        try {return JsonParser.parseString(value).getAsJsonObject();}
        catch(RuntimeException e){throw new IOException("Invalid Default profile JSON",e);}
    }
}
