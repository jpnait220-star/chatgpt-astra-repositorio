package com.duckswords.render;
import com.duckswords.DucksWordsClient;
import com.duckswords.modules.ScoreboardPosition;
import net.minecraft.class_332;
import net.minecraft.class_4587;
/** Isolates both matrix state and queued GUI buffers to the scoreboard draw call. */
public final class ScoreboardScope implements AutoCloseable {
    private static final ScoreboardScope NONE=new ScoreboardScope(null,null);
    private final class_332 context;
    private final class_4587 matrices;
    private boolean closed;
    private ScoreboardScope(class_332 context,class_4587 matrices){this.context=context;this.matrices=matrices;}
    public static ScoreboardScope begin(class_332 context) {
        ScoreboardPosition module=DucksWordsClient.MODULES==null?null:DucksWordsClient.MODULES.get(ScoreboardPosition.class);
        if(module==null||!module.isEnabled())return NONE;
        float x=module.x.getFloat(),y=module.y.getFloat(),scale=module.scale.getFloat();
        // Default position needs neither an allocation, matrix push nor extra GPU flush.
        if(x==0&&y==0&&scale==1)return NONE;
        context.method_51452(); // Earlier HUD/chat batches must be drawn before the offset.
        class_4587 matrices=context.method_51448();
        float width=context.method_51421(),height=context.method_51443();
        matrices.method_22903();
        try {
            matrices.method_46416(width+x,height*.5f+y,0);
            matrices.method_22905(scale,scale,1);
            matrices.method_46416(-width,-height*.5f,0);
            return new ScoreboardScope(context,matrices);
        }catch(RuntimeException|Error failure){matrices.method_22909();throw failure;}
    }
    @Override public void close() {
        if(context==null||closed)return;
        closed=true;
        try {context.method_51452();} // Complete this batch while its transform is active.
        finally {matrices.method_22909();} // Never re-read enabled/scale at RETURN.
    }
}
