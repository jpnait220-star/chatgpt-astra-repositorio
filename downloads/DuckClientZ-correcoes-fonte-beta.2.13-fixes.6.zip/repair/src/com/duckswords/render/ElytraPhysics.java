package com.duckswords.render;
import com.duckswords.DucksWordsClient;
import com.duckswords.modules.ElytraFeature;
import net.minecraft.*;
public final class ElytraPhysics {
    private static final ElytraMotionCache MOTION=new ElytraMotionCache();
    private static ElytraFeature settings() {
        ElytraFeature feature=DucksWordsClient.MODULES.get(ElytraFeature.class);
        return feature!=null&&feature.isEnabled()&&feature.physics.getValue()?feature:null;
    }
    private static long sample(class_1309 entity,float age,ElytraFeature feature) {
        class_243 v=entity.method_18798();
        ElytraSpring spring=MOTION.get(entity);
        return spring.sample(age,v.field_1352,v.field_1351,v.field_1350,entity.field_6283,entity.method_18276(),entity.method_6128(),feature.leanMultiplier.getFloat());
    }
    private static void apply(class_630 left,class_630 right,long motion) {
        float pitch=ElytraSpring.pitch(motion),roll=ElytraSpring.roll(motion);
        // Move both wings together like a cape; preserve their vanilla mirrored opening.
        left.field_3654+=pitch;right.field_3654+=pitch;
        left.field_3674+=roll;right.field_3674+=roll;
    }
    public static void render(class_1309 entity,class_630 left,class_630 right,float age) {
        ElytraFeature feature=settings();if(feature==null)return;
        apply(left,right,sample(entity,age,feature));
    }
    /** 1.21.4 separates entities from render models. Snapshot only Elytra wearers. */
    public static void capture(class_1309 entity,Object state,float tickDelta) {
        if(!(state instanceof ElytraMotion))return;
        ElytraMotion carrier=(ElytraMotion)state;carrier.duckclientz$setMotion(0);
        ElytraFeature feature=settings();
        if(feature==null||!entity.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833))return;
        carrier.duckclientz$setMotion(sample(entity,entity.field_6012+tickDelta,feature));
    }
    public static void renderState(Object state,class_630 left,class_630 right) {
        if(settings()==null||!(state instanceof ElytraMotion))return;
        apply(left,right,((ElytraMotion)state).duckclientz$getMotion());
    }
}
