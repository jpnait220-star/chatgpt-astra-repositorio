package com.duckswords.render;
/** Per-render-state data; never retain a rendered entity in a shared model. */
public interface ElytraMotion {
    long duckclientz$getMotion();
    void duckclientz$setMotion(long motion);
}
