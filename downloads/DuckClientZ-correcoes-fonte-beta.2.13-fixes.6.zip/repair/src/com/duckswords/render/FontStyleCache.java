package com.duckswords.render;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
/** Cache only font styles derived from immutable Style.EMPTY; preserve all other styles. */
public final class FontStyleCache {
    private static final ConcurrentMap<class_2960,class_2583> FONTS=new ConcurrentHashMap<>();
    public static class_2583 withFont(class_2583 base,class_2960 font) {
        if(base!=class_2583.field_24360||font==null)return base.method_27704(font);
        class_2583 found=FONTS.get(font);
        if(found!=null)return found;
        class_2583 created=base.method_27704(font);
        found=FONTS.putIfAbsent(font,created);
        return found==null?created:found;
    }
}
