package com.duckswords.render;
import net.minecraft.class_1309;
import java.lang.ref.*;
import java.util.*;
/** Entity.equals uses numeric IDs, which can repeat across worlds. Use weak identity. */
final class ElytraMotionCache {
    private final ReferenceQueue<class_1309> queue=new ReferenceQueue<>();
    private final Map<Object,ElytraSpring> values=new HashMap<>();
    private final Probe probe=new Probe();
    private static final class Key extends WeakReference<class_1309> {
        private final int hash;
        Key(class_1309 entity,ReferenceQueue<class_1309> queue){super(entity,queue);hash=System.identityHashCode(entity);}
        public int hashCode(){return hash;}
        public boolean equals(Object other){return this==other||other instanceof Key&&get()!=null&&get()==((Key)other).get();}
    }
    private static final class Probe {
        class_1309 entity;
        public int hashCode(){return System.identityHashCode(entity);}
        public boolean equals(Object other){return other instanceof Key&&((Key)other).get()==entity;}
    }
    synchronized ElytraSpring get(class_1309 entity) {
        Reference<? extends class_1309> expired;
        while((expired=queue.poll())!=null)values.remove(expired);
        ElytraSpring spring;
        probe.entity=entity;
        try{spring=values.get(probe);}finally{probe.entity=null;}
        if(spring==null){spring=new ElytraSpring();values.put(new Key(entity,queue),spring);}
        return spring;
    }
}
