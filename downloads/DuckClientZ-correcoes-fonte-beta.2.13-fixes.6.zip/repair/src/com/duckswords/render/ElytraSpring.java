package com.duckswords.render;
/** Frame-rate independent, non-oscillating response in Minecraft tick units. */
public final class ElytraSpring {
    private float pitch,roll,lastAge;
    private boolean initialized;
    public long sample(float age,double vx,double vy,double vz,float bodyYaw,boolean crouch,boolean gliding,float factor) {
        if(!Float.isFinite(age)||!Float.isFinite(bodyYaw)||!Double.isFinite(vx)||!Double.isFinite(vy)||!Double.isFinite(vz)) {
            initialized=false;pitch=roll=0;return 0;
        }
        double forward=0,side=0;
        if(!gliding&&(vx!=0||vz!=0)) {
            double yaw=Math.toRadians(bodyYaw),sin=Math.sin(yaw),cos=Math.cos(yaw);
            forward=-vx*sin+vz*cos;side=vx*cos+vz*sin;
        }
        float targetPitch=gliding?0:(float)Math.min(.9,Math.max(0,forward)*2+Math.abs(side)*.4+Math.max(0,-vy-.08)*.6+(crouch?.12:0));
        float targetRoll=gliding?0:(float)Math.max(-.25,Math.min(.25,-side*.9));
        if(!initialized||age<lastAge||age-lastAge>20) {
            initialized=true;lastAge=age;pitch=targetPitch;roll=targetRoll;
        } else {
            float dt=Math.min(2,age-lastAge);lastAge=age;
            if(dt>0&&(pitch!=targetPitch||roll!=targetRoll)) {
                float blend=(float)-Math.expm1(-.5*dt);
                pitch+=(targetPitch-pitch)*blend;roll+=(targetRoll-roll)*blend;
                if(Math.abs(targetPitch-pitch)<1e-5f)pitch=targetPitch;
                if(Math.abs(targetRoll-roll)<1e-5f)roll=targetRoll;
            }
        }
        if(!Float.isFinite(factor))factor=0;
        factor=Math.max(0,Math.min(2,factor));
        float p=Math.min(1.1f,pitch*factor),r=Math.max(-.4f,Math.min(.4f,roll*factor));
        if(p==0&&r==0)return 0; // Canonical zero also covers negative floating-point zero.
        return (long)Float.floatToRawIntBits(p)<<32|Integer.toUnsignedLong(Float.floatToRawIntBits(r));
    }
    public static float pitch(long packed){return Float.intBitsToFloat((int)(packed>>>32));}
    public static float roll(long packed){return Float.intBitsToFloat((int)packed);}
}
