package com.duckswords.glint;
import com.duckswords.modules.CustomGlint;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
public final class StableGlint {
    public static boolean apply(float vanillaScale) {
        CustomGlint module=CustomGlint.active;
        if(module==null||!module.isEnabled())return false;
        double seconds=module.clock.advance(System.nanoTime(),module.speed.getValue());
        float scale=vanillaScale*.5f/module.size.getFloat();
        RenderSystem.setTextureMatrix(new Matrix4f().translation(-GlintClock.offsetX(seconds),GlintClock.offsetY(seconds),0)
            .rotateZ(.17453292f).scale(scale));
        return true;
    }
}
