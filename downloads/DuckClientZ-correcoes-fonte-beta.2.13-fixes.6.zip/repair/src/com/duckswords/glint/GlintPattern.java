package com.duckswords.glint;
/** Seamless static tile. RGB is masked too: vanilla glint uses SRC_COLOR, not SRC_ALPHA. */
public final class GlintPattern {
    public static final int SIZE=64;
    private static final double[] MASK=buildMask();
    private static double[] buildMask() {
        double[] pixels=new double[SIZE*SIZE];
        for(int y=0;y<SIZE;y++)for(int x=0;x<SIZE;x++) {
            double band=.5+.5*Math.cos((x+y)*Math.PI*8/SIZE);
            double value=Math.max(0,Math.min(1,(band-.62)/.38));
            value=value*value*(3-2*value);
            pixels[y*SIZE+x]=value*(.86+.14*Math.cos((2*x+3*y)*Math.PI*2/SIZE));
        }
        return pixels;
    }
    public static int pixel(int x,int y,int argb,float strength) { return pixel(x,y,argb,strength,false); }
    public static int pixel(int x,int y,int argb,float strength,boolean rainbow) {
        if(rainbow) {
            float[] hsb=java.awt.Color.RGBtoHSB(argb>>16&255,argb>>8&255,argb&255,null);
            int rgb=java.awt.Color.HSBtoRGB(hsb[0]+(x+y)/(float)SIZE,1,1)&0xffffff;
            argb=(argb&0xff000000)|rgb;
        }
        double mask=MASK[(y&63)*SIZE+(x&63)];
        double opacity=Math.max(0,Math.min(10,strength))*(argb>>>24)/255.0;
        double brightness=mask*Math.sqrt(opacity);
        int r=Math.min(255,(int)Math.round((argb>>16&255)*brightness));
        int g=Math.min(255,(int)Math.round((argb>>8&255)*brightness));
        int b=Math.min(255,(int)Math.round((argb&255)*brightness));
        // Glint shaders discard alpha < 0.1. Keep coverage opaque and encode
        // opacity in RGB so low nonzero strengths do not suddenly disappear.
        int a=opacity>0&&mask>0?255:0;
        return a<<24|r<<16|g<<8|b;
    }
}
