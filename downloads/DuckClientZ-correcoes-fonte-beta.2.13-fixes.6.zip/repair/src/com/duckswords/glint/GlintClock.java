package com.duckswords.glint;
/** Integrated elapsed time: changing speed never multiplies the absolute JVM clock. */
public final class GlintClock {
    private long last;
    private boolean started;
    private double seconds;
    public synchronized void reset() { started=false; seconds=0; }
    public synchronized double advance(long now, double speed) {
        if (started) {
            double dt=Math.max(0,Math.min(.25,(now-last)*1e-9));
            seconds=(seconds+dt*Math.max(0,Math.min(5,Double.isFinite(speed)?speed:0)))%330;
        }
        last=now; started=true;
        return seconds;
    }
    public static float offsetX(double seconds) { return (float)((seconds*4000%110000)/110000); }
    public static float offsetY(double seconds) { return (float)((seconds*4000%30000)/30000); }
}
