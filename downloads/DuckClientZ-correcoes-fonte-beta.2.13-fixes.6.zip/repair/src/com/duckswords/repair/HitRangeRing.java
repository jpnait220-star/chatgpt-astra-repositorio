/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext
 *  net.minecraft.class_243
 *  net.minecraft.class_4588
 *  org.joml.Matrix4f
 */
package com.duckswords.repair;

import com.duckswords.util.MinecraftCompat;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

public final class HitRangeRing {
    public static double innerRadius(double d, float f) {
        return Math.max(0.0, d - Math.max(0.01, Math.min(0.6, (double)f / 100.0)));
    }

    public static void drawCircle(WorldRenderContext worldRenderContext, double d, double d2, double d3, double d4, int n, int n2, float f) {
        if (worldRenderContext == null || worldRenderContext.consumers() == null || worldRenderContext.matrixStack() == null || n2 < 3 || d4 <= 0.0 || !Float.isFinite(f) || f <= 0.0f) {
            return;
        }
        class_243 class_2432 = worldRenderContext.camera().method_19326();
        Matrix4f matrix4f = worldRenderContext.matrixStack().method_23760().method_23761();
        class_4588 class_45882 = worldRenderContext.consumers().getBuffer(MinecraftCompat.debugQuadLayer());
        double d5 = HitRangeRing.innerRadius(d4, f);
        double[] unit = com.duckswords.perf.CirclePoints.get(n2);
        double baseX=d-class_2432.field_1352, baseZ=d3-class_2432.field_1350;
        float height=(float)(d2-class_2432.field_1351);
        for (int i = 0; i < n2; ++i) {
            double cosA=unit[i*2], sinA=unit[i*2+1], cosB=unit[(i+1)*2], sinB=unit[(i+1)*2+1];
            float f2 = (float)(baseX + cosA * d4);
            float f3 = (float)(baseZ + sinA * d4);
            float f4 = (float)(baseX + cosB * d4);
            float f5 = (float)(baseZ + sinB * d4);
            float f6 = (float)(baseX + cosB * d5);
            float f7 = (float)(baseZ + sinB * d5);
            float f8 = (float)(baseX + cosA * d5);
            float f9 = (float)(baseZ + sinA * d5);
            float f10 = height;
            HitRangeRing.vertex(class_45882, matrix4f, f2, f10, f3, n);
            HitRangeRing.vertex(class_45882, matrix4f, f4, f10, f5, n);
            HitRangeRing.vertex(class_45882, matrix4f, f6, f10, f7, n);
            HitRangeRing.vertex(class_45882, matrix4f, f8, f10, f9, n);
            HitRangeRing.vertex(class_45882, matrix4f, f8, f10, f9, n);
            HitRangeRing.vertex(class_45882, matrix4f, f6, f10, f7, n);
            HitRangeRing.vertex(class_45882, matrix4f, f4, f10, f5, n);
            HitRangeRing.vertex(class_45882, matrix4f, f2, f10, f3, n);
        }
    }

    private static void vertex(class_4588 class_45882, Object object, float f, float f2, float f3, int n) {
        MinecraftCompat.vertexColor(class_45882, object, f, f2, f3, n);
    }
}

