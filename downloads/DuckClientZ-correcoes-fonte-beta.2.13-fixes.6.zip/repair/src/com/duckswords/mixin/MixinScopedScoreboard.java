package com.duckswords.mixin;
import com.duckswords.render.ScoreboardScope;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_266;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(value=class_329.class,remap=false)
public abstract class MixinScopedScoreboard {
    @Shadow(remap=false)
    private void method_1757(class_332 context,class_266 objective){throw new AssertionError("Unapplied shadow");}
    @Redirect(method="DUCK_SCOREBOARD_CALLER",at=@At(value="INVOKE",target="Lnet/minecraft/class_329;method_1757(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V"),require=1,remap=false)
    private void duckclientz$isolatedScoreboard(class_329 self,class_332 context,class_266 objective) {
        ScoreboardScope scope=ScoreboardScope.begin(context);
        try {method_1757(context,objective);}
        finally {scope.close();}
    }
}
