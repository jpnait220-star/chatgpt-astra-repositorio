package com.duckswords.mixin;
import com.duckswords.render.ElytraPhysics;
import net.minecraft.class_1309;
import net.minecraft.class_10042;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=net.minecraft.class_922.class,remap=false)
public class MixinElytraMotionCapture {
    @Inject(method="method_62355(Lnet/minecraft/class_1309;Lnet/minecraft/class_10042;F)V",at=@At("TAIL"),require=1,remap=false)
    private void duckclientz$capture(class_1309 entity,class_10042 state,float tickDelta,CallbackInfo ci) {
        ElytraPhysics.capture(entity,state,tickDelta);
    }
}
