package com.duckswords.mixin;
import com.duckswords.render.ElytraMotion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
@Mixin(value=net.minecraft.class_10034.class,remap=false)
public class MixinElytraMotionState implements ElytraMotion {
    @Unique private long duckclientz$motion;
    public long duckclientz$getMotion(){return duckclientz$motion;}
    public void duckclientz$setMotion(long motion){duckclientz$motion=motion;}
}
