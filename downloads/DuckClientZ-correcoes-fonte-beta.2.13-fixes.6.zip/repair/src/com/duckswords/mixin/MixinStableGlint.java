package com.duckswords.mixin;
import com.duckswords.glint.StableGlint;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=net.minecraft.class_4668.class,remap=false)
public abstract class MixinStableGlint {
    @Inject(method="method_23517(F)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
    private static void duckclientz$stableGlint(float scale,CallbackInfo ci) {
        if(StableGlint.apply(scale))ci.cancel();
    }
}
