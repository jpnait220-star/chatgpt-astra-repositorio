import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.impl.metadata.*;
public class FabricMetadataTest {
 public static void main(String[] a)throws Exception {
  Path config=Files.createTempDirectory("duck-fabric-metadata-");
  try(ZipFile z=new ZipFile(a[0])) {
   Set<String> names=new HashSet<>();int count=0;
   for(ZipEntry entry:Collections.list(z.entries())) {
    if(!names.add(entry.getName()))throw new AssertionError("Duplicate ZIP entry "+entry.getName());
    CRC32 crc=new CRC32();long bytes=0;
    try(var stream=z.getInputStream(entry)) {
     byte[] buffer=new byte[65536];int n;while((n=stream.read(buffer))!=-1){crc.update(buffer,0,n);bytes+=n;}
    }
    if(bytes!=entry.getSize()||crc.getValue()!=entry.getCrc())throw new AssertionError("Corrupt ZIP entry "+entry.getName());count++;
   }
   var metadata=ModMetadataParser.parseMetadata(z.getInputStream(z.getEntry("fabric.mod.json")),a[0],List.of(),new VersionOverrides(),new DependencyOverrides(config),false);
   if(!metadata.getId().equals("duckswords")||!metadata.loadsInEnvironment(EnvType.CLIENT))throw new AssertionError("Invalid mod identity/environment");
   for(String mixin:metadata.getMixinConfigs(EnvType.CLIENT))if(z.getEntry(mixin)==null)throw new AssertionError("Missing mixin config "+mixin);
   for(var nested:metadata.getJars())if(z.getEntry(nested.getFile())==null)throw new AssertionError("Missing nested jar "+nested.getFile());
   System.out.println("PASS: Fabric Loader 0.16.10 metadata parser; Java ZipFile read/CRC for all "+count+" entries; declared mixin/nested files present. Discovery prerequisites only, not a game launch.");
  } finally {Files.delete(config);}
 }
}
