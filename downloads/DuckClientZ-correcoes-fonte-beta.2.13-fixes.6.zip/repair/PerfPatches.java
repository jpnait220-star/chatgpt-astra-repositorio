import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Version-specific direct calls. Native members verified separately against Mojang jars. */
public final class PerfPatches implements Opcodes {
 static MethodNode replace(ClassNode c,String name) {
  MethodNode found=null;
  for(MethodNode m:c.methods)if(m.name.equals(name)) {
   if(found!=null)throw new IllegalStateException("Ambiguous method "+name);
   found=m;
  }
  if(found==null)throw new IllegalStateException("Missing "+name);
  found.instructions.clear();found.tryCatchBlocks.clear();found.localVariables=null;
  return found;
 }
 static void call(InsnList i,int opcode,String owner,String name,String desc,boolean itf){i.add(new MethodInsnNode(opcode,owner,name,desc,itf));}
 static void load(InsnList i,int opcode,int var){i.add(new VarInsnNode(opcode,var));}
 static void vertex(ClassNode c,String name,boolean normal,boolean legacy) {
  InsnList i=replace(c,name).instructions;
  String vc="net/minecraft/class_4588",ret="L"+vc+";";
  load(i,ALOAD,0);load(i,ALOAD,1);i.add(new TypeInsnNode(CHECKCAST,"org/joml/Matrix4f"));
  for(int v=2;v<=4;v++)load(i,FLOAD,v);
  call(i,INVOKEINTERFACE,vc,"method_22918","(Lorg/joml/Matrix4f;FFF)"+ret,true);
  load(i,ILOAD,5);call(i,INVOKEINTERFACE,vc,"method_39415","(I)"+ret,true);
  if(normal){for(int v=6;v<=8;v++)load(i,FLOAD,v);call(i,INVOKEINTERFACE,vc,"method_22914","(FFF)"+ret,true);}
  i.add(new InsnNode(POP));
  // 1.20 requires explicit next() on the original consumer, after the builder chain.
  if(legacy){load(i,ALOAD,0);call(i,INVOKEINTERFACE,vc,"method_1344","()V",true);}
  i.add(new InsnNode(RETURN));
 }
 static void write(ClassNode c,Path out)throws Exception {
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);
  Path p=out.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
 public static void main(String[] args)throws Exception {
  Path out=Paths.get(args[1]);String version=args[2];int formats=0;
  try(ZipFile z=new ZipFile(args[0])) {
   String name="com/duckswords/util/MinecraftCompat";
   ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,0);
   vertex(c,"vertexColor",false,version.equals("1.20.1"));
   vertex(c,"vertexColorNormal",true,version.equals("1.20.1"));
   InsnList i=replace(c,"rotate").instructions;
   load(i,ALOAD,0);load(i,ALOAD,1);load(i,FLOAD,2);
   call(i,INVOKESTATIC,"com/duckswords/perf/AxisRotation","rotate","(Lnet/minecraft/class_4587;Ljava/lang/String;F)V",false);i.add(new InsnNode(RETURN));
   i=replace(c,"getCurrentFps").instructions;load(i,ALOAD,0);
   call(i,INVOKEVIRTUAL,"net/minecraft/class_310","method_47599","()I",false);i.add(new InsnNode(IRETURN));
   i=replace(c,"getTickDelta").instructions;load(i,ALOAD,0);
   if(version.equals("1.20.1"))call(i,INVOKEVIRTUAL,"net/minecraft/class_310","method_1488","()F",false);
   else {
    call(i,INVOKEVIRTUAL,"net/minecraft/class_310",version.equals("1.21.1")?"method_60646":"method_61966","()Lnet/minecraft/class_9779;",false);
    i.add(new InsnNode(ICONST_0));call(i,INVOKEINTERFACE,"net/minecraft/class_9779","method_60637","(Z)F",true);
   }
   i.add(new InsnNode(FRETURN));
   i=replace(c,"debugQuadLayer").instructions;
   call(i,INVOKESTATIC,"net/minecraft/class_1921","method_49042","()Lnet/minecraft/class_1921;",false);i.add(new InsnNode(ARETURN));
   i=replace(c,"statusEffect").instructions;load(i,ALOAD,0);
   if(version.equals("1.20.1")) {
    call(i,INVOKEVIRTUAL,"net/minecraft/class_1293","method_5579","()Lnet/minecraft/class_1291;",false);
   } else {
    call(i,INVOKEVIRTUAL,"net/minecraft/class_1293","method_5579","()Lnet/minecraft/class_6880;",false);
    call(i,INVOKEINTERFACE,"net/minecraft/class_6880","comp_349","()Ljava/lang/Object;",true);
    i.add(new TypeInsnNode(CHECKCAST,"net/minecraft/class_1291"));
   }
   i.add(new InsnNode(ARETURN));
   write(c,out);
   // Replace the old age-driven wing wobble; retain its already registered injection.
   boolean modern=version.equals("1.21.4");
   String hook="com/duckswords/mixin/"+(modern?"MixinElytraEntityModel1214":"RepairElytraModel");
   c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(hook+".class"))).accept(c,0);
   i=replace(c,modern?"duckswords$animateWings":"animate").instructions;
   load(i,ALOAD,1);
   for(String wing:List.of("Left","Right")) {
    load(i,ALOAD,0);
    if(modern) {
     String accessor="com/duckswords/mixin/MixinElytraEntityModelAccessor1214";
     i.add(new TypeInsnNode(CHECKCAST,accessor));
     call(i,INVOKEINTERFACE,accessor,"duckswords$get"+wing+"Wing","()Lnet/minecraft/class_630;",true);
    } else i.add(new FieldInsnNode(GETFIELD,hook,wing.equals("Left")?"field_3365":"field_27412","Lnet/minecraft/class_630;"));
   }
   if(!modern)load(i,FLOAD,4);
   call(i,INVOKESTATIC,"com/duckswords/render/ElytraPhysics",modern?"renderState":"render",modern?"(Ljava/lang/Object;Lnet/minecraft/class_630;Lnet/minecraft/class_630;)V":"(Lnet/minecraft/class_1309;Lnet/minecraft/class_630;Lnet/minecraft/class_630;F)V",false);
   i.add(new InsnNode(RETURN));write(c,out);
   // Numeric HUD data is often unchanged between frames. Avoid repeated Formatter work.
   for(ZipEntry entry:Collections.list(z.entries())) {
    if(!entry.getName().startsWith("com/duckswords/modules/")||!entry.getName().endsWith(".class"))continue;
    c=new ClassNode();new ClassReader(z.getInputStream(entry)).accept(c,0);int changed=0;
    for(MethodNode m:c.methods)for(AbstractInsnNode n:m.instructions)
     if(n instanceof MethodInsnNode call&&call.owner.equals("java/lang/String")&&call.name.equals("format")&&call.desc.equals("(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;")) {
      call.owner="com/duckswords/perf/HudFormatCache";changed++;
     }
    if(changed>0){if(Files.exists(out.resolve(c.name+".class")))throw new IllegalStateException("Conflicting patch "+c.name);write(c,out);formats+=changed;}
   }
  }
  if(formats<5)throw new IllegalStateException("HUD formatting hooks missing: "+formats);
  System.out.println(version+": 7 direct render paths including potion registry unwrapping; "+formats+" HUD format sites");
 }
}
