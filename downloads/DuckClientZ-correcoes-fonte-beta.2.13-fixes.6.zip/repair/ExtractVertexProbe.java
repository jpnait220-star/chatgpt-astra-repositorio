import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.commons.*;
/** Test-only extraction: retain exact vertex bodies without loading unrelated game APIs. */
public class ExtractVertexProbe {
 public static void main(String[] a)throws Exception {
  String original="com/duckswords/util/MinecraftCompat",probe=a[2];
  try(ZipFile z=new ZipFile(a[0])) {
   ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(original+".class"))).accept(c,0);
   c.fields.clear();c.methods.removeIf(m->!m.name.equals("vertexColor")&&!m.name.equals("vertexColorNormal")&&!m.name.equals("invoke")&&!m.name.startsWith("lambda$vertexColor"));
   ClassWriter w=new ClassWriter(0);
   c.accept(new ClassRemapper(w,new SimpleRemapper(original,probe)));
   Path p=Paths.get(a[1]).resolve(probe+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
  }
 }
}
