import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.commons.*;
public class InspectHud {
 public static void main(String[] a)throws Exception {
  String owner="";Map<String,String> cs=new HashMap<>(),ms=new HashMap<>();String obf="";
  for(String s:Files.readAllLines(Paths.get(a[0]))){String[] p=s.split("\t");if(p[0].equals("c")){owner=p[1];cs.put(p[1],p[2]);if(p[2].equals("net/minecraft/class_329"))obf=p[1];}else if(p.length==5&&p[1].equals("m"))ms.put(owner+" "+p[3]+p[2],p[4]);}
  Remapper r=new Remapper(){public String map(String n){return cs.getOrDefault(n,n);}public String mapMethodName(String o,String n,String d){return ms.getOrDefault(o+" "+n+d,n);}};
  try(ZipFile z=new ZipFile(a[1])) {ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(obf+".class"))).accept(new ClassRemapper(c,r),0);
   for(MethodNode m:c.methods) {
    if(m.name.equals("method_1757")) {System.out.println("SCOREBOARD BODY "+m.name+m.desc);for(AbstractInsnNode ins:m.instructions)if(ins instanceof MethodInsnNode x)System.out.println("  "+x.owner+"."+x.name+x.desc);}
    for(AbstractInsnNode ins:m.instructions)if(ins instanceof MethodInsnNode x&&x.owner.equals(c.name)&&x.name.equals("method_1757"))System.out.println("CALLER "+m.name+m.desc+" static="+((m.access&Opcodes.ACC_STATIC)!=0));
   }
  }
 }
}
