package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.gui.CrosshairCanvasScreen;import net.minecraft.*;import java.util.*;
public final class CrosshairEditor extends Module {
 public static final int N=33;private static CrosshairEditor current;
 public final StringSetting pixels=add(new StringSetting("Desenho","Desenho salvo junto ao perfil; use o editor para pintar",defaultPixels(),512));
 public final ModeSetting editor=add(new ModeSetting("Editar desenho","Escolha Abrir com a feature ligada para desenhar","Fechado","Fechado","Abrir"));
 public final ColorSetting color=add(new ColorSetting("Cor da mira","Cor, opacidade e RGB da mira",0xfff4f4f4)),outline=add(new ColorSetting("Cor do contorno","Contorno externo para contraste",0xb9000000));
 public final BooleanSetting border=add(new BooleanSetting("Contorno","Desenha uma borda em volta dos pixels",true));
 public final NumberSetting size=add(new NumberSetting("Tamanho do pixel","Escala de cada pixel do desenho",1,1,6,1));
 private String previous="";private boolean[] bitmap=new boolean[N*N],edges=new boolean[N*N];
 public CrosshairEditor(){super("Crosshair Editor","Desenhe a mira no painel e configure cor, RGB e tamanho",Category.VISUALS);color.allowRgb();outline.allowRgb();current=this;}
 public static String defaultPixels(){boolean[] p=new boolean[N*N];for(int i=11;i<=21;i++)if(i<14||i>18){p[16*N+i]=true;p[i*N+16]=true;}p[16*N+16]=true;return encode(p);}
 public static String encode(boolean[] cells){byte[] b=new byte[(N*N+7)/8];for(int i=0;i<N*N;i++)if(cells[i])b[i/8]|=1<<(i%8);return Base64.getEncoder().encodeToString(b);}
 public static boolean[] decode(String value){boolean[] p=new boolean[N*N];try{byte[] b=Base64.getDecoder().decode(value);if(b.length!=(N*N+7)/8)return p;for(int i=0;i<p.length;i++)p[i]=(b[i/8]&(1<<(i%8)))!=0;}catch(IllegalArgumentException ignored){}return p;}
 @Override public void onTick(){if(editor.is("Abrir")){editor.setValue("Fechado");if(mc.field_1755!=null)mc.method_1507(new CrosshairCanvasScreen(mc.field_1755,this));}refresh();}
 private void refresh(){String value=pixels.getValue();if(value.equals(previous))return;previous=value;bitmap=decode(value);edges=new boolean[N*N];for(int y=0;y<N;y++)for(int x=0;x<N;x++)if(bitmap[y*N+x])for(int yy=Math.max(0,y-1);yy<=Math.min(N-1,y+1);yy++)for(int xx=Math.max(0,x-1);xx<=Math.min(N-1,x+1);xx++)if(!bitmap[yy*N+xx])edges[yy*N+xx]=true;}
 public static boolean draw(class_332 ctx){CrosshairEditor m=current;if(m==null||!m.isEnabled()||class_310.method_1551().field_1755!=null||!com.duckswords.client.ClientData.firstPerson())return false;m.refresh();int scale=m.size.getInt(),x=ctx.method_51421()/2-N/2*scale,y=ctx.method_51443()/2-N/2*scale;if(m.border.getValue())raster(ctx,m.edges,x,y,scale,m.outline.getDisplayValue());raster(ctx,m.bitmap,x,y,scale,m.color.getDisplayValue());return true;}
 public static void raster(class_332 ctx,boolean[] bitmap,int x,int y,int scale,int color){if((color>>>24)==0)return;for(int row=0;row<N;row++){int col=0;while(col<N){if(!bitmap[row*N+col]){col++;continue;}int start=col++;while(col<N&&bitmap[row*N+col])col++;ctx.method_25294(x+start*scale,y+row*scale,x+col*scale,y+(row+1)*scale,color);}}}
}
