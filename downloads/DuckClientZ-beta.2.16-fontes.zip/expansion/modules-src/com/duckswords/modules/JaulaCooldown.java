package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.client.ClientData;import com.duckswords.theme.HudText;import org.lwjgl.glfw.GLFW;import java.util.*;
/** Manual local estimate: observes physical click edges, never uses/sends items or server packets. */
public final class JaulaCooldown extends Module {
 public final NumberSetting x=add(new NumberSetting("X","Posicao horizontal",10,0,4000,1)),y=add(new NumberSetting("Y","Posicao vertical",200,0,4000,1));
 public final StringSetting item=add(new StringSetting("Item da jaula","ID, exemplo minecraft:glass_pane","minecraft:glass_pane",128)),server=add(new StringSetting("Servidor","IP exato; vazio aceita qualquer servidor","",255));
 public final ModeSetting button=add(new ModeSetting("Botao do mouse","Clique que inicia a estimativa","Direito","Esquerdo","Direito","Meio"));
 public final NumberSetting cooldown=add(new NumberSetting("Cooldown","Segundos para usar novamente",60,1,3600,1)),duration=add(new NumberSetting("Duracao da jaula","Segundos ate a jaula estourar; zero esconde",10,0,600,.5));
 public final ColorSetting color=add(new ColorSetting("Cor","Cor dos textos; suporta RGB",0xffffc65b)),background=add(new ColorSetting("Fundo","Cor do painel",0xb5141820)),readyColor=add(new ColorSetting("Cor pronto","Cor quando o cooldown termina",0xff77e6aa));
 private boolean down;private Object world,player;private long began;private String stamp="",address="",itemKey="",cachedServer="",cachedItem="";
 public JaulaCooldown(){super("Jaula Cooldown","Temporizador local de jaula por item, servidor e clique; nao confirma o uso",Category.HUD);}
 public int hudWidth(){return 164;}public int hudHeight(){return 34;}
 public static boolean serverMatches(String expected,String actual){String a=expected.trim().toLowerCase(Locale.ROOT),b=actual.trim().toLowerCase(Locale.ROOT);if(a.endsWith(":25565"))a=a.substring(0,a.length()-6);if(b.endsWith(":25565"))b=b.substring(0,b.length()-6);return a.isEmpty()||a.equals(b);}
 public double remaining(double seconds,long now){return began==0?0:Math.max(0,seconds-(now-began)/1e9);}
 @Override public void onTick(){boolean pressed=GLFW.glfwGetMouseButton(mc.method_22683().method_4490(),button.is("Esquerdo")?0:button.is("Direito")?1:2)==GLFW.GLFW_PRESS;boolean fresh=world!=mc.field_1687||player!=mc.field_1724;if(fresh){began=0;world=mc.field_1687;player=mc.field_1724;down=pressed;}if(mc.field_1724==null||mc.field_1687==null||!mc.field_1724.method_5805()){began=0;down=pressed;return;}if(!Objects.equals(cachedItem,item.getValue())){cachedItem=item.getValue();itemKey=ClientData.normalize(cachedItem);}if(pressed&&!down&&mc.field_1755==null&&remaining(cooldown.getValue(),System.nanoTime())==0&&serverMatches(server.getValue(),ClientData.server())&&(itemKey.equals(ClientData.key(ClientData.held(false)))||itemKey.equals(ClientData.key(ClientData.held(true))))){began=System.nanoTime();}down=pressed;}
 @Override public void onDisable(){began=0;down=false;world=player=null;}
 @Override public void onHudRender(net.minecraft.class_332 ctx,float delta){if(mc.field_1724==null)return;int xx=x.getInt(),yy=y.getInt();long now=System.nanoTime();double ready=remaining(cooldown.getValue(),now),burst=remaining(duration.getValue(),now);ctx.method_25294(xx,yy,xx+hudWidth(),yy+hudHeight(),background.getDisplayValue());HudText.draw(ctx,ready>0?"Jaula: "+seconds(ready):"Jaula: pronta",xx+5,yy+5,ready>0?color.getDisplayValue():readyColor.getDisplayValue());HudText.draw(ctx,burst>0?"Estoura em "+seconds(burst):"Estimativa local",xx+5,yy+20,color.getDisplayValue());}
 private static String seconds(double value){return String.format(Locale.ROOT,"%.1fs",value);}
}
