package com.duckswords.client;
import net.minecraft.*;import java.util.*;
/** Exact version adapters are generated at build time; registry lookups are cached by item/type. */
public final class ClientData {
 private static final Map<Object,String> ITEMS=new IdentityHashMap<>(),ENTITIES=new IdentityHashMap<>();
 public static String key(class_1799 stack){if(stack==null)return "";Object item=item(stack);return ITEMS.computeIfAbsent(item,ClientData::rawItemId);}
 public static String entityKey(class_1297 e){Object type=entityType(e);return ENTITIES.computeIfAbsent(type,ClientData::rawEntityId);}
 public static String normalize(String key){String s=key==null?"":key.trim().toLowerCase(Locale.ROOT);return s.isEmpty()?"":s.contains(":")?s:"minecraft:"+s;}
 public static boolean firstPerson(){throw new IllegalStateException("adapter");}
 public static Object item(class_1799 s){throw new IllegalStateException("adapter");}
 public static Object entityType(class_1297 e){throw new IllegalStateException("adapter");}
 public static String rawItemId(Object value){throw new IllegalStateException("adapter");}
 public static String rawEntityId(Object value){throw new IllegalStateException("adapter");}
 public static class_1799 inventory(int slot){throw new IllegalStateException("adapter");}
 public static class_1799 held(boolean off){throw new IllegalStateException("adapter");}
 public static int count(class_1799 stack){throw new IllegalStateException("adapter");}
 public static String server(){throw new IllegalStateException("adapter");}
 public static void decorate(class_332 ctx,class_1799 stack,int x,int y){throw new IllegalStateException("adapter");}
}
