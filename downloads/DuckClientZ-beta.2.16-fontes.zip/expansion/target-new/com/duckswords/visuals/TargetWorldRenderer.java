package com.duckswords.visuals;
import com.duckswords.modules.Visuals;import com.duckswords.util.RenderUtil;import net.minecraft.*;import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
public final class TargetWorldRenderer{
 private static final long START=System.nanoTime();
 public static void draw(Visuals settings,WorldRenderContext ctx){
  class_1309 target=settings.target();if(target==null||!target.method_5805())return;String style=settings.targetStyle.getValue();if(!style.equals("Circle")&&!style.equals("Crystals"))return;
  int color=settings.targetColor.getValue();if((color>>>24)==0)return;class_243 p=target.method_30950(TargetFrame.delta());double radius=settings.targetSize.getValue(),phase=(System.nanoTime()-START)*1e-9*settings.targetSpeed.getValue();
  if(style.equals("Circle")){double scan=.9+.75*Math.sin(phase*2);RenderUtil.drawCircle(ctx,p.field_1352,p.field_1351+scan,p.field_1350,radius,color,32,2);return;}
  double cs=Math.cos(phase),sn=Math.sin(phase),size=.22*radius;
  for(int i=0;i<4;i++){double a=i==0?1:i==2?-1:0,b=i==1?1:i==3?-1:0,x=p.field_1352+radius*(a*cs-b*sn),z=p.field_1350+radius*(a*sn+b*cs),y=p.field_1351+1+.12*Math.sin(phase*2+i);
   for(int j=0;j<4;j++){double mx=x+(j==0?size:j==2?-size:0),mz=z+(j==1?size:j==3?-size:0);RenderUtil.drawLine(ctx,mx,y,mz,x,y+size,z,color,1.5f);RenderUtil.drawLine(ctx,mx,y,mz,x,y-size,z,color,1.5f);}
  }
 }
}
