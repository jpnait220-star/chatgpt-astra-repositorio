from pathlib import Path
from zipfile import ZipFile
import json,hashlib,struct
B=Path(__file__).parent
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 p=Path(entry['jar']);assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
 with ZipFile(p) as z:
  assert z.testzip() is None;names=set(z.namelist());meta=json.loads(z.read('fabric.mod.json'));assert meta['version']=='1.5.28-beta.2.16'
  assert not any(n.startswith(('net/minecraft/','net/fabricmc/','org/lwjgl/')) for n in names),'Compile fixtures must never enter mod'
  for mix in meta['mixins']:
   doc=json.loads(z.read(mix));assert 'MixinRecordingCamera' not in doc.get('client',[])
   for name in doc.get('client',[]):assert (doc['package'].replace('.','/')+'/'+name.replace('.','/')+'.class') in names
  for kind in ['main','client']:assert 'com.duckswords.particles.VisualParticles' in meta['entrypoints'][kind]
  for name in names:
   if name.startswith('assets/duckswords/particles/') and name.endswith('.json'):
    for tex in json.loads(z.read(name))['textures']:
     namespace,path=tex.split(':');assert f'assets/{namespace}/textures/particle/{path}.png' in names,(name,tex)
  sounds=json.loads(z.read('assets/duckswords/sounds.json'))
  for key,val in sounds.items():
   if True:
    for sound in val['sounds']:
     path=sound if isinstance(sound,str) else sound['name'];namespace,path=path.split(':');assert f'assets/{namespace}/sounds/{path}.ogg' in names
  default=json.loads(json.loads(z.read('assets/duckswords/default-profile.json'))['config']);assert default['$duckDefaultClean'] is True
  for module,data in default.items():
   if not module.startswith('$') and module!='Interface':
    assert not data['enabled']
    assert data['settings']==({'Escala do pop':.65} if module=='Totem Editor' else {})
  assert 'Texture Maker' not in default
  assert not any('texturemaker/' in name.lower() or 'texturemaker.class' in name.lower() or name.endswith('/texturemaker.png') for name in names)
  for module in ['Crosshair Editor','Inventory HUD','Jaula Cooldown']:assert not default[module]['enabled']
  for icon in ['crosshaireditor','inventoryhud','jaulacooldown']:assert 'assets/duckswords/textures/gui/icons/'+icon+'.png' in names
  assert default['Interface']['enabled']
  assert not default['Visuals']['enabled'] and not default['Mouse Icon']['enabled']
  assert z.read('assets/duckswords/storage.properties').decode().startswith('minecraft='+v+'\n')
 print('PASS: final CRC/hash, metadata/mixins/entrypoints, particle/audio assets, scoped version and no compile stubs:',v)
