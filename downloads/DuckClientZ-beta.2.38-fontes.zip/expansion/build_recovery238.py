from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
B=Path(__file__).parent;report={}
for game in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 base=B/f'dist/DuckClientZ-{game}-1.5.28-beta.2.36.jar';dest=B/f'dist/DuckClientZ-{game}-1.5.28-beta.2.38.jar'
 with ZipFile(base) as source:
  data={n:source.read(n) for n in source.namelist()};meta=json.loads(data['fabric.mod.json']);meta['version']='1.5.28-beta.2.38';data['fabric.mod.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode()
 with ZipFile(dest,'w',ZIP_DEFLATED) as z:
  for n,v in data.items():z.writestr(n,v)
 with ZipFile(base) as old,ZipFile(dest) as new:
  assert old.namelist()==new.namelist();assert new.testzip() is None
  assert all(old.read(n)==new.read(n) for n in old.namelist() if n!='fabric.mod.json')
 report[game]={'jar':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'changed':['fabric.mod.json']}
 print('PASS all code/resources/config bytes equal tested2.36; only version metadata advances to2.38',game)
(B/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
