# beta.2.38 recovery
User reports worse world gameplay/menu on237;236 four-version bundle was better
in gameplay and mostly slow in menu. Also cosmetics/chat disconnected. Requests
speed, weekly allowance10% in prior turn. No new optimization experiment now.

Recovery: build_recovery238.py copies exact immutable published236 jars and
changes only fabric.mod.json.version to238. Every other entry/order/code/resource/
config is byte-equal, tested all4. Allows signed updater to move forward from237.
Restore SodiumBatch234 and RenderProbe234 source from236 source bundle; disable
237 cosmetic/HUD/world patches in normal build.py, remove unused237 module source
helpers. New recovery pack sources include reproduction script referencing236 jars.
User GUI/performance choices/configs preserved. No graphics/FPS run or guarantee.

Service: ordinary production /health, /profiles and /announcements return503.
Vercel auth restored via existing saved CLI refresh token; private production
storage credentials pulled only to /tmp/duck238-private/production.env chmod600.
DO NOT print/package/commit .env/auth/tokens. Direct authenticated Redis PING via
Python returns HTTP200 with ERR max requests limit exceeded, Limit500000 Usage500000.
This explains disconnected services independently of client render version.
No paid plan/subscription enabled, no new database created to bypass provider
limits. Production storage needs owner capacity/reset; client rollback cannot fix
quota. Avoid claiming service restored. Update manifest route works separately.

Publish recovery238 all4 and validate updater/downloads; final clearly distinguish
restored236 client code vs still-blocked storage. No unsolicited announcements.
