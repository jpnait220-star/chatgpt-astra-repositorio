package com.duckswords.mixin;
/** Exact native field accessor annotation is supplied for each build. */
public interface MixinSlimArms224 {boolean duck$slim224();}
