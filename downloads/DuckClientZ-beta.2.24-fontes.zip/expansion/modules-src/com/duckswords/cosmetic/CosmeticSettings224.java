package com.duckswords.cosmetic;
import java.util.Set;
/** Remove retired effect controls even when old profile data still contains them. */
public final class CosmeticSettings224 {
 public static void clean(){Cosmetic hat=CosmeticManager.byId("chinaHat");if(hat!=null)hat.getSettings().removeIf(s->Set.of("Estrelas","Densidade","Raio").contains(s.getName()));}
}
