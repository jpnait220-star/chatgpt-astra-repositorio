from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,hashlib,io
B=Path(__file__).parent;m=json.loads((B/'cosmetics224-manifest.json').read_text());assert len(m['items'])==31 and len(m['removed'])==14
changed=set(m['adjustments']);geometry_names={k.lower() for k in changed};original_models={}
for version,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{version}-1.5.28-beta.2.23.jar') as old:
  for key in m['removed']:assert not any(n.startswith('assets/duckswords/cosmetics/'+key.lower()+'/') for n in z.namelist()),key
  # Every texture/audio/profile remains exactly as shipped; only these model/animation/icon changes are allowed.
  for name in old.namelist():
   if name.startswith('assets/duckswords/profiles/'):assert z.read(name)==old.read(name),name
   if name.startswith('assets/duckswords/') and name.endswith(('.png','.ogg')):
    if any(name.startswith('assets/duckswords/cosmetics/'+k.lower()+'/') for k in m['removed']):continue
    if name.startswith('assets/duckswords/cosmetics/') and name.split('/')[3] in {k.lower() for k in m['original_fist_frames']} and name.endswith('/texture.png'):continue
    if name.startswith('assets/duckswords/cosmetics/') and name.endswith('/icon.png') and name.split('/')[3] in geometry_names:continue
    assert z.read(name)==old.read(name),name
  def geo(key,archive=z):return json.loads(archive.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json'))['minecraft:geometry'][0]
  for key,axis,delta in [('summer2024PropellerHat',1,1),('fall2025OwlMask',1,-3),('gamerGameOverSign',2,1)]:
   original=geo(key,old);current=geo(key)
   for a,b in zip(original['bones'],current['bones']):
    assert a['name']==b['name']
    if a['name'].startswith('anchor_'):assert a['pivot']==b['pivot']
    elif 'pivot' in a:assert abs(b['pivot'][axis]-a['pivot'][axis]-delta)<1e-6
    for ca,cb in zip(a.get('cubes',[]),b.get('cubes',[])):
     assert ca['size']==cb['size'] and ca['uv']==cb['uv'];assert abs(cb['origin'][axis]-ca['origin'][axis]-delta)<1e-6
  ring=geo('spring2025RainbowAura')['bones'];assert len(ring)==2 and len(ring[1]['cubes'])==1;assert ring[1]['rotation']==[0,0,0] and ring[1]['cubes'][0]['origin'][1]==12
  fire=geo('flameFragsFireRing')['bones'];assert len(fire)==4;assert sum(len(b.get('cubes',[])) for b in fire)==2;assert all(b['pivot']==[0,12,0] for b in fire if b['name']!='anchor_body')
  reaper=geo('halloween2024ReaperPet');head=next(b for b in reaper['bones'] if b['name']=='head');assert len(head['cubes'])==1 and head['cubes'][0]['uv']['north']=={'uv':[10,10],'uv_size':[16,16]}
  knight=geo('demon2024DemonKnightHelmet');plate=knight['bones'][0]['cubes'][-1];assert plate['size'][2]==.25 and plate['rotation']==[0,0,0];shell=knight['bones'][0]['cubes'][2];assert plate['origin'][2]+plate['size'][2]<shell['origin'][2]-shell['inflate']
  from render_cosmetic_icons223 import rotation
  import numpy as np
  for key,target in [('duckFoxPet',-6),('duckAxolotlPet',6)]:
   g=geo(key);bones={b['name']:b for b in g['bones']};cache={}
   def transform(b):
    if b['name'] not in cache:
     local=rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));cache[b['name']]=transform(bones[b['parent']])@local if 'parent' in b else local
    return cache[b['name']]
   points=[]
   for b in g['bones']:
    for c in b.get('cubes',[]):
     lo=np.array(c['origin']);hi=lo+c['size'];t=transform(b)@rotation(c.get('rotation',[0,0,0]),c.get('pivot',((lo+hi)/2).tolist()));points.extend([(t@np.array([x,y,z,1]))[:3] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
   low=np.min(points,axis=0);high=np.max(points,axis=0);assert abs(low[1]-24.1)<1e-6 and abs((low[0]+high[0])/2-target)<1e-6
   a=json.loads(z.read('assets/duckswords/cosmetics/'+key.lower()+'/animation.json'));assert all('anchor_body' not in t.get('bones',{}) for t in a['animations'].values())
  ghost=geo('halloween2024GhostPet');lamp=next(b for b in ghost['bones'] if b['name']=='bone4');hand=next(b for b in ghost['bones'] if b['name']=='bone3');rod=lamp['cubes'][0];grip=np.array([rod['origin'][0]+rod['size'][0]/2,rod['origin'][1]+rod['size'][1]/2,rod['origin'][2]+rod['size'][2],1]);assert np.max(np.abs((rotation(lamp['rotation'],lamp['pivot'])@grip)[:3]-np.array(hand['pivot'])))<1e-6
  body=ghost['bones'][0]['cubes'][0];assert body['uv']['up']=={'uv':[10,0],'uv_size':[12,10]} and body['uv']['down']=={'uv':[10,10],'uv_size':[12,-10]}
  with ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip') as pack:
   import io
   animation=json.loads(z.read('assets/duckswords/cosmetics/animated-textures.json'))
   for key,frames in m['original_fist_frames'].items():
    source=Image.open(io.BytesIO(pack.read('game/cosmetics/arm/'+key+'.webp')));assert len(frames)==source.n_frames and animation[key]==frames
    for i,frame in enumerate(frames):
     source.seek(i);source.load();texture=Image.open(io.BytesIO(z.read('assets/duckswords/cosmetics/'+key.lower()+'/'+frame['file']))).convert('RGBA');assert texture.tobytes()==source.convert('RGBA').tobytes();assert frame['duration']==max(20,min(5000,int(source.info.get('duration',100))))
  for key in changed:
   prefix='assets/duckswords/cosmetics/'+key.lower()+'/';g=geo(key);names={b['name'] for b in g['bones']}
   for bone in g['bones']:
    if 'parent' in bone:assert bone['parent'] in names
   if prefix+'animation.json' in z.namelist():
    animation=json.loads(z.read(prefix+'animation.json'))
    for track in animation['animations'].values():assert set(track.get('bones',{}))<=names,key
   icon=Image.open(io.BytesIO(z.read(prefix+'icon.png'))).convert('RGBA');assert icon.size==(128,128) and icon.getchannel('A').getbbox()
  for key in ['halloween2024ReaperPet','springKatana','spring2025RainbowAura','flameFragsFireRing','demon2024DemonKnightHelmet']:original_models.setdefault(key,z.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json'));assert original_models[key]==z.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json')
 print('PASS 224 assets:',version,'31 catalog additions, 14 removed IDs/assets, exact hat/back offsets, joined rings, single full-atlas hood, knight plate clears shell, original texture pixels/audio and frozen profile schemas preserved')
