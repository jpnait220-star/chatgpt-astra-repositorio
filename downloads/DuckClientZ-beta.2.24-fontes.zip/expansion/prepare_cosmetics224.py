"""Small geometry/UV corrections against the frozen, published 2.23 assets."""
from pathlib import Path
from zipfile import ZipFile
import json,re,shutil
B=Path(__file__).parent;R=B/'resources/assets/duckswords/cosmetics'
REMOVED={'cyberpunkOniMask','spaceAura','demon2024DemonScythe','summer2024Surfboard','springCowboyHat','cloudAura','hellLordAura','halloween2024FrankensteinMask'}
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n')
def boxuv(u,v,w,h,d):
 return {f:{'uv':a,'uv_size':s} for f,a,s in [('north',[u+d,v+d],[w,h]),('south',[u+2*d+w,v+d],[w,h]),('east',[u+d+w,v+d],[d,h]),('west',[u,v+d],[d,h]),('up',[u+d,v],[w,d]),('down',[u+d+w,v+d],[w,-d])]}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.23.jar') as old:
 def model(key):return json.loads(old.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json'))
 for key,dy in [('summer2024PropellerHat',1),('fall2025OwlMask',-3)]:
  m=model(key)
  for b in m['minecraft:geometry'][0]['bones']:
   # Anchor remains the vanilla head's reference; only the accessory moves.
   if not b['name'].startswith('anchor_') and 'pivot' in b:b['pivot'][1]+=dy
   for c in b.get('cubes',[]):
    c['origin'][1]+=dy
    if 'pivot' in c:c['pivot'][1]+=dy
  save(R/key.lower()/'model.json',m)
 m=model('spring2025RainbowAura');g=m['minecraft:geometry'][0];ring=next(b for b in g['bones'] if b['name']=='bone4');ring['pivot']=[0,12,0];ring['rotation']=[0,0,0]
 for c in ring['cubes']:c['origin'][1]=12;c['pivot']=[0,12,0];c['rotation']=[0,0,0]
 g['bones']=[b for b in g['bones'] if b['name']=='anchor_body']+[ring];save(R/'spring2025rainbowaura/model.json',m)
 a=json.loads(old.read('assets/duckswords/cosmetics/spring2025rainbowaura/animation.json'))
 for track in a['animations'].values():track['bones']={k:v for k,v in track.get('bones',{}).items() if k!='bone3'}
 save(R/'spring2025rainbowaura/animation.json',a)
 m=model('halloween2024ReaperPet');head=next(b for b in m['minecraft:geometry'][0]['bones'] if b['name']=='head')
 # The inflated inner cube extended beyond the hood and covered its face.
 # Use the original complete hood atlas net on one cube, with both eyes intact.
 head['cubes']=head['cubes'][:1];head['cubes'][0]['uv']=boxuv(0,0,16,16,10)
 save(R/'halloween2024reaperpet/model.json',m)
 animation=json.loads(old.read('assets/duckswords/cosmetics/halloween2024reaperpet/animation.json'));names={b['name'] for b in m['minecraft:geometry'][0]['bones']}
 animation['animations']={k:v for k,v in animation['animations'].items() if '.idle' in k}
 for a in animation['animations'].values():a['bones']={k:v for k,v in a['bones'].items() if k in names}
 save(R/'halloween2024reaperpet/animation.json',animation)
 m=model('gamerGameOverSign')
 for b in m['minecraft:geometry'][0]['bones']:
  if not b['name'].startswith('anchor_') and 'pivot' in b:b['pivot'][2]+=1
  for c in b.get('cubes',[]):
   c['origin'][2]+=1
   if 'pivot' in c:c['pivot'][2]+=1
 save(R/'gamergameoversign/model.json',m)
 m=model('springKatana');g=m['minecraft:geometry'][0]
 # Flip the complete assembled sword around its current center, preserving its back offset.
 import numpy as np
 from render_cosmetic_icons223 import rotation
 root=next(b for b in g['bones'] if b['name']=='root');points=[]
 for c in root['cubes']:
  lo=np.array(c['origin']);hi=lo+c['size'];transform=rotation(root.get('rotation',[0,0,0]),root['pivot'])@rotation(c.get('rotation',[0,0,0]),c.get('pivot',((lo+hi)/2).tolist()))
  points.extend([(transform@np.array([x,y,z,1]))[:3] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
 center=((np.min(points,axis=0)+np.max(points,axis=0))/2).tolist();root['parent']='blade_down224';g['bones'].insert(1,{'name':'blade_down224','parent':'anchor_body','pivot':center,'rotation':[0,0,180]});save(R/'springkatana/model.json',m)
 m=model('flameFragsFireRing');g=m['minecraft:geometry'][0];keep={'anchor_body','bone4','bone6','bone7'};g['bones']=[b for b in g['bones'] if b['name'] in keep]
 for b in g['bones']:
  if b['name']=='anchor_body':continue
  b['pivot']=[0,12,0];b['rotation']=[90,0,0] if b['name']=='bone4' else [0,0,0]
  for c in b.get('cubes',[]):c['origin']=[-18.5,-2.5,0];c['pivot']=[0,12,0];c['rotation']=[0,0,0 if b['name']=='bone6' else 180]
 save(R/'flamefragsfirering/model.json',m)
 animation=json.loads(old.read('assets/duckswords/cosmetics/flamefragsfirering/animation.json'));animation['animations']={k:v for k,v in animation['animations'].items() if '.idle' in k}
 for a in animation['animations'].values():a['bones']={k:v for k,v in a['bones'].items() if k in {'bone6','bone7'}}
 save(R/'flamefragsfirering/animation.json',animation)
 m=model('demon2024DemonKnightHelmet');g=m['minecraft:geometry'][0];face=g['bones'][0]['cubes'][-1]
 assert face['size']==[6.5484,8.7312,6.5484]
 # The diagonal opaque face box intersected the inflated helmet on its right side.
 # Retain its original face atlas, as a thin centered plate clear of the helmet shell.
 face['origin']=[-3.2742,face['origin'][1],-5.3];face['size'][2]=.25;face['rotation']=[0,0,0];face.pop('pivot',None)
 save(R/'demon2024demonknighthelmet/model.json',m)
 m=model('halloween2024GhostPet');g=m['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']};body=bones['anchor_body']['cubes'][0]
 body['uv']['up']={'uv':[10,0],'uv_size':[12,10]};body['uv']['down']={'uv':[10,10],'uv_size':[12,-10]}
 lamp=bones['bone4'];hand=bones['bone3'];rod=lamp['cubes'][0];grip=np.array([rod['origin'][0]+rod['size'][0]/2,rod['origin'][1]+rod['size'][1]/2,rod['origin'][2]+rod['size'][2],1]);grip=(rotation(lamp.get('rotation',[0,0,0]),lamp['pivot'])@grip)[:3];delta=np.array(hand['pivot'])-grip
 lamp['pivot']=(np.array(lamp['pivot'])+delta).tolist()
 for c in lamp['cubes']:
  c['origin']=(np.array(c['origin'])+delta).tolist()
  if 'pivot' in c:c['pivot']=(np.array(c['pivot'])+delta).tolist()
 save(R/'halloween2024ghostpet/model.json',m);animation=json.loads(old.read('assets/duckswords/cosmetics/halloween2024ghostpet/animation.json'));animation['animations']={k:v for k,v in animation['animations'].items() if '.idle' in k};save(R/'halloween2024ghostpet/animation.json',animation)
 # Render the original shoe model for its icon instead of displaying the flat atlas.
 root=R/'springanimalsneakers';root.mkdir(exist_ok=True)
 for name in ['model.json','texture.png']:(root/name).write_bytes(old.read('assets/duckswords/cosmetics/springanimalsneakers/'+name))
 for key,shoulder in [('duckFoxPet',-6),('duckAxolotlPet',6)]:
  m=model(key);g=m['minecraft:geometry'][0];bones={b['name']:b for b in g['bones']};cache={}
  def transform(b):
   if b['name'] not in cache:
    local=rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));cache[b['name']]=transform(bones[b['parent']])@local if 'parent' in b else local
   return cache[b['name']]
  points=[]
  for b in g['bones']:
   for c in b.get('cubes',[]):
    lo=np.array(c['origin']);hi=lo+c['size'];t=transform(b)@rotation(c.get('rotation',[0,0,0]),c.get('pivot',((lo+hi)/2).tolist()))
    points.extend([(t@np.array([x,y,z,1]))[:3] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2])])
  low=np.min(points,axis=0);high=np.max(points,axis=0);delta=[shoulder-(low[0]+high[0])/2,24.1-low[1],-(low[2]+high[2])/2]
  for b in g['bones']:
   if not b['name'].startswith('anchor_') and 'pivot' in b:b['pivot']=[x+d for x,d in zip(b['pivot'],delta)]
   for c in b.get('cubes',[]):
    c['origin']=[x+d for x,d in zip(c['origin'],delta)]
    if 'pivot' in c:c['pivot']=[x+d for x,d in zip(c['pivot'],delta)]
  save(R/key.lower()/'model.json',m);animation=json.loads(old.read('assets/duckswords/cosmetics/'+key.lower()+'/animation.json'))
  for a in animation['animations'].values():a.get('bones',{}).pop('anchor_body',None)
  save(R/key.lower()/'animation.json',animation)
 # Use the actual animated WebP frames from the user's pack, with its durations.
 from PIL import Image
 import io
 textures=json.loads((R/'animated-textures.json').read_text());fist_frames={}
 with ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip') as game:
  for key in ['springFireFists','demon2024BloodFists','springIceFists','beenTakenCorruptedFists']:
   root=R/key.lower();root.mkdir(exist_ok=True);(root/'model.json').write_bytes(old.read('assets/duckswords/cosmetics/'+key.lower()+'/model.json'));im=Image.open(io.BytesIO(game.read('game/cosmetics/arm/'+key+'.webp')));frames=[]
   for index in range(im.n_frames):
    im.seek(index);im.load();name='texture.png' if index==0 else f'frame_{index:03d}.png';im.convert('RGBA').save(root/name);frames.append({'file':name,'duration':max(20,min(5000,int(im.info.get('duration',100))))})
   textures[key]=frames;fist_frames[key]=frames
 save(R/'animated-textures.json',textures)
for key in REMOVED:shutil.rmtree(R/key.lower(),ignore_errors=True)
p=B/'modules-src/com/duckswords/cosmetic/CosmeticCatalog222.java';s=p.read_text()
for key in REMOVED:
 s=re.sub(r'Map\.entry\("'+key+r'","[^"]*"\),?\s*','',s)
 start=s.index('public static final List<String> IDS=');end=s.index(';',start);s=s[:start]+s[start:end].replace('"'+key+'",','').replace(',"'+key+'"','')+s[end:]
start=s.index('private static final Set<String> REMOVED=Set.of(');end=s.index(');',start);previous=set(re.findall(r'"([^"]+)"',s[start:end]));s=s[:start]+'private static final Set<String> REMOVED=Set.of('+','.join(json.dumps(k) for k in sorted(previous|REMOVED))+s[end:];p.write_text(s)
m=json.loads((B/'cosmetics223-manifest.json').read_text());m['items']=[e for e in m['items'] if e['id'] not in REMOVED];m['removed']=sorted(set(m['removed'])|REMOVED);m['revision']=224;m['adjustments']={'summer2024PropellerHat':{'y_pixels':1},'fall2025OwlMask':{'y_pixels':-3},'gamerGameOverSign':{'z_pixels':1},'springKatana':'assembled sword flipped 180 degrees around its center','spring2025RainbowAura':'single horizontal animated ring at body Y12','flameFragsFireRing':'two aligned halves of one rotating ring; detached ring removed','demon2024DemonKnightHelmet':'thin centered face plate clear of helmet shell','halloween2024ReaperPet':'one hood cube; full original atlas net; valid idle tracks only','duckFoxPet':'left shoulder X-6, base Y24.1, no root bobbing','duckAxolotlPet':'right shoulder X6, base Y24.1, no root bobbing'};save(B/'cosmetics224-manifest.json',m)
m['adjustments'].update({'halloween2024GhostPet':'closed caps and original lantern grip aligned with hand','springAnimalSneakers':'original geometry; model thumbnail icon'});m['original_fist_frames']=fist_frames;save(B/'cosmetics224-manifest.json',m)
print('Prepared 224: removals/poses/pets/auras; original animated fist frames', {k:len(v) for k,v in fist_frames.items()})
