CÓDIGO DAS CORREÇÕES INCREMENTAIS
===============================

Este diretório contém apenas o código novo, as alterações pontuais de bytecode
(PatchClasses.java e PerfPatches.java), stubs para compilação/testes e o empacotamento. Não é o
projeto Gradle original nem contém o Minecraft descompilado.

Para recompilar, use JDK 21 e Python 3 e coloque os três JARs originais enviados
em uma pasta originals/ ao lado de repair/, com os nomes:
DuckClientZ-1.20.1-1.5.28-beta.2.12-experimental.jar
DuckClientZ-1.21.1-1.5.28-beta.2.12-experimental.jar
DuckClientZ-1.21.4-1.5.28-beta.2.12-experimental.jar

Execute: python repair/rebuild.py
As dependências são baixadas de Maven Central/Fabric via HTTPS e verificadas
contra o checksum publicado. Os resultados ficam em dist-fixes8/.

Os stubs em stubs/ e teststubs/ são SOMENTE para compilar/executar testes isolados.
NENHUMA dessas classes substitutas de Minecraft/Fabric vai para os JARs finais.

VerifyArtifacts.java e validate.py documentam as verificações adicionais feitas.
A validação requer também os artefatos e mappings reais de Minecraft de cada
versão e as ferramentas listadas no script, além da configuração de referência
fornecida para o teste do tema. Esses arquivos externos não estão neste pacote.

Fonte/arquivo a investigar para cada correção:
- src/com/duckswords/glint/ e modules/CustomGlint.java: padrão RGB, fase e velocidade.
- mixin/MixinStableGlint.java: matriz de textura por frame.
- modules/BlockOverlay.java: evento nativo de outline.
- compat/FullbrightPixels.java e mixin/MixinFullbrightPixels.java: lightmap 1.20.1.
- PatchClasses.java: offhand 1.21.4, fonte e seed do perfil padrão.
- compat/MobileRuntime.java: detecção Android sem forçar fonte vanilla.

- render/ScoreboardScope.java e mixin/MixinScopedScoreboard.java: isolamento do placar.
- render/FontStyleCache.java: cache de estilos imutaveis sem reutilizar texto mutavel.

Desempenho fixes.3:
- PerfPatches.java: chamadas diretas de vértices/normais/FPS/delta/camada e
  rotação; encaminhamento das formatações numéricas do HUD para cache limitado.
- perf/AxisRotation.java: rotação sem reflexão, com semântica de multiplicação.
- perf/CirclePoints.java e repair/HitRangeRing.java: círculo reutilizado.
- modules/HitRange.java: consulta espacial de alvos no tick, independente de FPS.
- setting/ColorSetting.java: HSB invalidado por alteração de cor.
- perf/HudFormatCache.java: resultados apenas para argumentos imutáveis e locale.
- compat/FullbrightPixels.java: tabela de níveis preparada por atualização.
- tests/PerformanceTests.java: geometria, alvos, rotação, HUD, HSB e tabela gamma.
- ExtractVertexProbe.java: extração dos corpos reais antes/depois para comparação
  sintética de CPU com stub, sem dependência do jogo completo nem uso de GPU.
- FabricMetadataTest.java: parser real do Fabric e CRC de todas as entradas.
  Exige fabric-loader-0.16.10.jar de Maven Fabric, com checksum publicado.

Preset e migração fixes.4:
- resources/default-profile-requested.json: perfil enviado pelo usuário.
- build_jars.py incorpora o preset em cada versão, mantendo extras compatíveis.
- profiles/DefaultProfileMigration.java: migração única do Default azul/verde,
  com backup anterior à escrita e marcador após sucesso.
- PatchClasses.java chama a migração após criar o Default e antes de carregá-lo.
- theme/Interface.java: valores iniciais e de reset iguais ao preset enviado.
- tests/DefaultMigrationTests.java: aplicação automática na mesma inicialização,
  backup, preservação de perfis/mudanças posteriores e falha segura em JSON inválido.

Potion HUD e glint fixes.5:
- PerfPatches.java: substitui statusEffect pela API direta de cada versão,
  evitando a descoberta reflexiva que causava o crash na 1.21.1.
- tests/PotionCrashTests.java: executa os corpos original/corrigido com stubs
  correspondentes à versão; reproduz a mesma exceção no original da 1.21.1.
- modules/CustomGlint.java: slider Forca 0..10.
- glint/GlintPattern.java: limite de cálculo também 10, preservando faixa 0..2.
- tests/RepairTests.java: verifica o limite, a intensidade real acima de 2 e alfa 0.

Elytra e revisão adicional fixes.5:
- render/ElytraSpring.java: inclinação de movimento com resposta exponencial
  independente do FPS, sem oscilador por idade e sem modificar o voo.
- render/ElytraPhysics.java e ElytraMotionCache.java: aplicação visual, referências
  fracas por identidade e captura apenas de usuários de Elytra na 1.21.4.
- render/ElytraMotion.java, mixin/MixinElytraMotionState.java e
  mixin/MixinElytraMotionCapture.java: separação entidade/render state 1.21.4.
- PerfPatches.java: troca os corpos dos antigos métodos de animação, preservando
  seus hooks já registrados. Os novos mixins de estado só entram na 1.21.4.
- tests/ElytraTests.java: movimento/repouso/FPS, isolamento por entidade e métodos
  reais modificados; VerifyArtifacts também confere a cadeia de atualização dos
  renderizadores nativos de jogador/bípede até o hook da 1.21.4.
- GlintPattern.java: máscara estática em cache. RepairTests compara todos os
  pixels da máscara anterior para garantir que essa otimização preserve a imagem.

Fonte padrão fixes.6:
- Interface.java e build_jars.py usam Minecraft como fonte inicial e do preset.
- DefaultProfileMigration migra a fonte do Default vermelho anterior uma vez,
  com backup e marcador independente da migração vermelha, preservando o resto.
- DefaultMigrationTests cobre upgrade de fonte, backup, reset e personalização.

HUD e ícones fixes.8:
- hud/HudLayout.java: coordenadas canônicas do perfil e projeção/inversão para
  a janela atual; fallback legado determinístico e métricas por passagem.
- hud/HudRender.java e HudMatrix.java: escopos de renderização/restauração.
- HudPatch.java: wrappers de Module/TextHud e coordenadas de entrada do editor;
  cancela arrastes no init/resize e no fechamento. Não altera Config.createRoot.
- EffectIconsPatch.java: adaptador nativo específico para cada uma das três
  versões e chamada por linha do Potion HUD.
- tests/HudLayoutTests.java e EffectIconTests.java: persistência/resize/editor e
  adaptação do atlas real, com stubs isolados e bytecode final.
- O backend 1.21.11 é separado: Matrix3x2fStack em vez de MatrixStack.

fixes.8: WorldRenderPatch.java troca LAST por AFTER_ENTITIES e delega cinco
rotinas de RenderUtil para perf/WorldGeometry. BlockOverlay aplica-se agora
às três versões. TargetHighlight usa consulta espacial/top-k e frustum.
WorldRenderTests testa geometria/precisão/normais/batches/seleção/fade.
VerifyArtifacts valida também o evento e os acessores de WorldRenderContext
contra fabric-rendering-v1.jar (1.21.1) e fabric-rendering-v1-<versao>.jar.
Bibliotecas Fabric usadas na validação (não incluídas neste ZIP):
1.20.1: fabric-rendering-v1 3.0.9+1802ada577 (Fabric API 0.92.6+1.20.1)
1.21.4: fabric-rendering-v1 10.2.1+0d31b09f04 (Fabric API 0.119.4+1.21.4)
Os stubs de compilação/testes não fazem parte dos JARs distribuídos.
