# beta.2.29

Active: fix menu lag and cosmetic corruption using uploaded four builds;
retain corrected annotations and1.21.11 VerifyError fix. Added owner-only
Mojang-authenticated client announcements, original purple back scythe,
and signed automatic updater. Then investigate full1.19.2 port separately.

User cannot identify the optimizing mod; maybe1.20.1 or1.21.4. Sodium0.5.13
source confirms intercepted ModelPart entry and constructor-time cuboid
copies. Explicit Duck-only part/child/cube dispatch bypasses that entry.
Native11 deferred submission left intact. This is an engineering fix,
not a confirmation of the unknown user's mod combination.

Menu atlas matches old half-pixel coverage.7 radii x5 modes x4 alpha values
per version compare actual production geometry with atlas texels.325->15
submissions per panel. No FPS claim. Existing fonts/controls/configs intact.

Announcement nonce consumed once; backend verifies Mojang hasJoined for
DuckTheKiller UUID/name, not community nick claims. No privileged live
broadcast in testing. Public service deployment and non-owner403 verified.
Question about original/offline account unanswered so far: secure original
account mode used. Offline authentication cannot safely be based on nick.

Updater tests use exact Java17 artifact helpers and real loopback download
plus child processes waiting for a fixture parent exit. Ed25519, MC/version,
URL/hash/size/mod-ID validation, partial cleanup, backup and no manual-change
overwrite. No actual Minecraft/Windows/Pojav/GPU/FPS execution.
Private release signing key kept outside repo/output, only public key ships.
