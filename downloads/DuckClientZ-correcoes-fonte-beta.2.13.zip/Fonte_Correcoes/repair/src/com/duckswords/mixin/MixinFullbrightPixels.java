package com.duckswords.mixin;
import com.duckswords.compat.FullbrightPixels;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(value=net.minecraft.class_765.class,remap=false)
public abstract class MixinFullbrightPixels {
    @Shadow(remap=false) private boolean field_4135;
    @Unique private boolean duckclientz$wasBright;
    @Inject(method="method_3314()V",at=@At("TAIL"),require=1,remap=false)
    private void duckclientz$refresh(CallbackInfo ci) {
        boolean bright=FullbrightPixels.enabled();
        if(bright||duckclientz$wasBright)field_4135=true;
        duckclientz$wasBright=bright;
    }
    @ModifyArg(method="method_3313(F)V",at=@At(value="INVOKE",target="Lnet/minecraft/class_1011;method_4305(III)V"),index=2,require=1,remap=false)
    private int duckclientz$brightPixel(int abgr) { return FullbrightPixels.brighten(abgr); }
}
