package com.duckswords.modules;
import com.duckswords.module.Category;
import com.duckswords.module.Module;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.NumberSetting;
import com.duckswords.util.MinecraftCompat;
import com.duckswords.glint.GlintClock;
import com.duckswords.glint.GlintPattern;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;

public class CustomGlint extends Module {
    private static final class_2960 ITEM_GLINT=MinecraftCompat.identifier("minecraft","textures/misc/enchanted_glint_item.png");
    private static final class_2960 ENTITY_GLINT=MinecraftCompat.identifier("minecraft","textures/misc/enchanted_glint_entity.png");
    public static CustomGlint active;
    public final ColorSetting color=add(new ColorSetting("Cor","Cor e opacidade do glint",-12199937));
    public final NumberSetting speed=add(new NumberSetting("Velocidade","0 congela; 1 normal; ate 5x sem saltos",1,0,5,.1));
    public final NumberSetting strength=add(new NumberSetting("Forca","Forca / opacidade do reflexo; 0 oculta o glint",1,0,2,.05));
    public final NumberSetting size=add(new NumberSetting("Tamanho","Tamanho das faixas do glint",.5,.25,2,.05));
    public final GlintClock clock=new GlintClock();
    private class_1043 itemTexture,entityTexture;
    private int appliedColor;
    private boolean appliedRgb;
    private float appliedStrength=Float.NaN;
    public CustomGlint() { super("Custom Glint","Glint continuo de itens e armaduras",Category.VISUALS);color.allowRgb(); }
    @Override public void onEnable() { active=this;clock.reset();appliedStrength=Float.NaN; }
    @Override public void onTick() {
        active=this;
        clock.advance(System.nanoTime(),speed.getValue());
        // Rotation is supplied per frame; never rewrite the user's global video options.
        int argb=color.getValue();
        boolean rgb=color.isRgbEnabled();
        float force=strength.getFloat();
        if(itemTexture==null||argb!=appliedColor||force!=appliedStrength||rgb!=appliedRgb) {
            itemTexture=update(itemTexture,argb,force,rgb);
            entityTexture=update(entityTexture,argb,force,rgb);
            mc.method_1531().method_4616(ITEM_GLINT,itemTexture);
            mc.method_1531().method_4616(ENTITY_GLINT,entityTexture);
            appliedColor=argb;appliedStrength=force;appliedRgb=rgb;
        }
    }
    private class_1043 update(class_1043 texture,int argb,float force,boolean rgb) {
        class_1011 image=texture==null?new class_1011(64,64,true):texture.method_4525();
        for(int y=0;y<64;y++)for(int x=0;x<64;x++)
            MinecraftCompat.setPixel(image,x,y,GlintPattern.pixel(x,y,argb,force,rgb));
        if(texture==null)return new class_1043(image);
        texture.method_4524();return texture;
    }
    @Override public void onDisable() {
        if(itemTexture!=null)mc.method_1531().method_4615(ITEM_GLINT);
        if(entityTexture!=null)mc.method_1531().method_4615(ENTITY_GLINT);
        itemTexture=null;entityTexture=null;appliedStrength=Float.NaN;
        clock.reset();if(active==this)active=null;
    }
}
