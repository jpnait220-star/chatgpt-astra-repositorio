package com.duckswords.compat;
import com.duckswords.DucksWordsClient;
import com.duckswords.modules.Fullbright;
public final class FullbrightPixels {
    public static boolean enabled() {
        if(DucksWordsClient.MODULES==null)return false;
        Fullbright module=DucksWordsClient.MODULES.get(Fullbright.class);
        return module!=null&&module.isEnabled();
    }
    public static int brighten(int abgr) {
        if(!enabled())return abgr;
        Fullbright module=DucksWordsClient.MODULES.get(Fullbright.class);
        return adjust(abgr,module.gamma.getFloat());
    }
    public static int adjust(int abgr,float gamma) {
        double value=Math.max(1,Math.min(20,gamma));
        if(!Double.isFinite(value)||value<=1)return abgr;
        int r=255-(int)Math.round((255-(abgr&255))/value);
        int g=255-(int)Math.round((255-(abgr>>8&255))/value);
        int b=255-(int)Math.round((255-(abgr>>16&255))/value);
        return abgr&0xff000000|b<<16|g<<8|r;
    }
}
