package com.duckswords.glint;
/** Seamless static tile. RGB is masked too: vanilla glint uses SRC_COLOR, not SRC_ALPHA. */
public final class GlintPattern {
    public static final int SIZE=64;
    public static int pixel(int x,int y,int argb,float strength) { return pixel(x,y,argb,strength,false); }
    public static int pixel(int x,int y,int argb,float strength,boolean rainbow) {
        if(rainbow) {
            float[] hsb=java.awt.Color.RGBtoHSB(argb>>16&255,argb>>8&255,argb&255,null);
            int rgb=java.awt.Color.HSBtoRGB(hsb[0]+(x+y)/(float)SIZE,1,1)&0xffffff;
            argb=(argb&0xff000000)|rgb;
        }
        double band=.5+.5*Math.cos((x+y)*Math.PI*8/SIZE);
        double mask=Math.max(0,Math.min(1,(band-.62)/.38));
        mask=mask*mask*(3-2*mask);
        mask*=.86+.14*Math.cos((2*x+3*y)*Math.PI*2/SIZE);
        double opacity=Math.max(0,Math.min(2,strength))*(argb>>>24)/255.0;
        double brightness=mask*Math.sqrt(opacity);
        int r=Math.min(255,(int)Math.round((argb>>16&255)*brightness));
        int g=Math.min(255,(int)Math.round((argb>>8&255)*brightness));
        int b=Math.min(255,(int)Math.round((argb&255)*brightness));
        int a=Math.min(255,(int)Math.round(255*mask*opacity));
        return a<<24|r<<16|g<<8|b;
    }
}
