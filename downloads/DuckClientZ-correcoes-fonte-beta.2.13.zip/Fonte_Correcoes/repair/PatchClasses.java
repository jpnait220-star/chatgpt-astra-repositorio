import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class PatchClasses implements Opcodes {
    public static void main(String[] args)throws Exception {
        Path out=Paths.get(args[1]);Files.createDirectories(out);
        try(ZipFile jar=new ZipFile(args[0])) {
            patch(jar,out,"com/duckswords/profiles/ProfileManager",0);
            patch(jar,out,"com/duckswords/PojavCompat",1);
            patch(jar,out,"com/duckswords/theme/HudText",2);
            if(args.length>2&&args[2].equals("1.21.4")) {
                patch(jar,out,"com/duckswords/mixin/MixinViewModel1214",3);
                patch(jar,out,"com/duckswords/modules/ViewModel",4);
            }
        }
    }
    static void patch(ZipFile jar,Path out,String name,int kind)throws Exception {
        ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getEntry(name+".class"))).accept(c,0);
        int edits=0; int mobileReads=0;
        for(MethodNode m:c.methods) {
            if(kind==1&&m.name.equals("styled")) {
                m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;
                m.instructions.add(new VarInsnNode(ALOAD,0));
                m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/theme/HudText","duck$styledDesktop","(Ljava/lang/String;)Lnet/minecraft/class_2561;",false));
                m.instructions.add(new InsnNode(ARETURN));edits++;
            }
            if(kind==1&&m.name.equals("isPojav")) {
                for(AbstractInsnNode ins:m.instructions.toArray())
                    if(ins.getOpcode()==IRETURN)m.instructions.insertBefore(ins,new MethodInsnNode(INVOKESTATIC,"com/duckswords/compat/MobileRuntime","resolve","(Z)Z",false));
            }
            for(AbstractInsnNode ins:m.instructions.toArray()) {
                if(kind==1&&!m.name.equals("isPojav")&&ins instanceof FieldInsnNode field&&field.getOpcode()==GETSTATIC&&field.owner.equals("com/duckswords/PojavCompat")&&field.name.equals("POJAV")) {
                    m.instructions.set(ins,new MethodInsnNode(INVOKESTATIC,"com/duckswords/PojavCompat","isPojav","()Z",false));mobileReads++;
                }
                if(kind==4&&m.name.equals("<init>")&&ins instanceof LdcInsnNode text&&text.cst instanceof String value&&value.startsWith("Aplica o ViewModel ao comer;")) {
                    text.cst="Aplica escala e pose ao comer; posicao da mao secundaria permanece independente";edits++;
                }
                if(!(ins instanceof MethodInsnNode call))continue;
                if(kind==0&&m.name.equals("initialize")&&call.owner.equals("com/duckswords/Config")&&call.name.equals("exportProfileJson")) {
                    call.owner="com/duckswords/profiles/ProfileManager";call.name="defaultProfileConfig";edits++;
                }
                if(kind==2&&m.name.equals("duck$styledDesktop")&&call.owner.equals("java/util/stream/IntStream")&&call.name.equals("anyMatch")) {
                    InsnList list=new InsnList();list.add(new InsnNode(POP));list.add(new InsnNode(ICONST_0));m.instructions.insert(call,list);edits++;
                }
                if(kind==3&&(m.name.contains("transformFirstPersonItem")||m.name.contains("restoreMatrix"))&&call.owner.equals("com/duckswords/modules/ViewModel")&&call.name.equals("shouldApply")) {
                    // Offhand pose is independent. Preserve main-hand food behavior and item-scale gating.
                    if(!call.desc.equals("(Lnet/minecraft/class_742;Lnet/minecraft/class_1268;Lnet/minecraft/class_1799;)Z"))throw new IllegalStateException(call.desc);
                    InsnList list=new InsnList();list.add(new VarInsnNode(ALOAD,4));
                    list.add(new FieldInsnNode(GETSTATIC,"net/minecraft/class_1268","field_5810","Lnet/minecraft/class_1268;"));
                    list.add(new MethodInsnNode(INVOKESTATIC,"java/util/Objects","equals","(Ljava/lang/Object;Ljava/lang/Object;)Z",false));
                    list.add(new InsnNode(IOR));m.instructions.insert(call,list);edits++;
                }
            }
        }
        if(kind==1&&mobileReads!=2)throw new IllegalStateException("Expected two mobile path checks, got "+mobileReads);
        int expected=kind==3?2:1;
        if(edits!=expected)throw new IllegalStateException(name+": expected "+expected+" edits, found "+edits);
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(writer);
        Path target=out.resolve(name+".class");Files.createDirectories(target.getParent());Files.write(target,writer.toByteArray());
        System.out.println(name+": "+edits+" verified edit(s)");
    }
}
