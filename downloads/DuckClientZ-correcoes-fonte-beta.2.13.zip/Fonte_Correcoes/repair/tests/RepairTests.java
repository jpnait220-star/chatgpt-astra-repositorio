import com.duckswords.glint.*;
import com.duckswords.modules.CustomGlint;
import com.duckswords.modules.Fullbright;
import com.duckswords.compat.*;
import com.duckswords.DucksWordsClient;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.*;
import java.util.*;
public class RepairTests {
 static int passed;
 static void test(boolean result,String text) { if(!result)throw new AssertionError(text);passed++; }
 static void near(double a,double b,String text){test(Math.abs(a-b)<1e-7,text+": "+a+" != "+b);}
 public static void main(String[] args)throws Exception {
  GlintClock clock=new GlintClock();long now=8_000_000_000_000_000L;
  near(clock.advance(now,1),0,"initial phase independent of JVM uptime");
  near(clock.advance(now+100_000_000,1),.1,"elapsed time");
  near(clock.advance(now+100_000_000,5),.1,"speed change has no instantaneous jump");
  near(clock.advance(now+200_000_000,0),.1,"speed zero freezes phase");
  near(clock.advance(now+300_000_000,2),.3,"2x speed integrates elapsed time");
  near(clock.advance(now+10_300_000_000L,1),.55,"long pause is clamped, not teleported");
  clock.reset();near(clock.advance(1,1),0,"reset phase");
  near(GlintClock.offsetX(330),GlintClock.offsetX(0),"seamless clock wrap X");
  near(GlintClock.offsetY(330),GlintClock.offsetY(0),"seamless clock wrap Y");
  boolean black=false,bright=false;
  for(int y=0;y<64;y++)for(int x=0;x<64;x++) {
   test(GlintPattern.pixel(x,y,0xff87baff,0)==0,"zero strength hides RGB and alpha");
   test(GlintPattern.pixel(x,y,0x0087baff,2)==0,"zero color opacity hides RGB");
   int p=GlintPattern.pixel(x,y,0xffffffff,1);black|=(p&0xffffff)==0;bright|=(p&0xffffff)>0;
   test(GlintPattern.pixel(x,y,0xff87baff,1)==GlintPattern.pixel(x+64,y,0xff87baff,1),"horizontal tile seam");
  }
  test(black&&bright,"visible bands with transparent gaps");
  test((GlintPattern.pixel(0,0,0xff405080,1)&255)>(GlintPattern.pixel(0,0,0xff405080,.25f)&255),"strength changes actual RGB intensity");
  CustomGlint glint=new CustomGlint();
  test(glint.getSettings().stream().anyMatch(s->s==glint.speed),"speed is registered in UI/profile");
  test(glint.getSettings().stream().anyMatch(s->s==glint.strength),"strength is registered in UI/profile");
  glint.setEnabled(true);glint.onTick();
  class_1060 manager=class_310.method_1551().textures;
  test(manager.textures.size()==2,"item and entity/armor textures both registered");
  class_1043 tex=(class_1043)manager.textures.get(new class_2960("minecraft","textures/misc/enchanted_glint_item.png"));
  test(tex!=null,"item texture bound");
  for(int i=0;i<24;i++) {glint.speed.setValue(i%6);glint.onTick();}
  test(tex.uploads==1,"speed changes do not recreate/upload the texture every four ticks");
  test(manager.textures.get(new class_2960("minecraft","textures/misc/enchanted_glint_item.png"))==tex,"texture identity remains stable");
  glint.speed.setValue(0);StableGlint.apply(8);org.joml.Matrix4f first=new org.joml.Matrix4f(RenderSystem.last);
  Thread.sleep(20);StableGlint.apply(8);
  test(first.equals(RenderSystem.last),"render matrix really freezes at speed 0");
  glint.size.setValue(2);StableGlint.apply(8);near(RenderSystem.last.m00(),Math.cos(.17453292)*2,"size adjusts UV scale");
  glint.color.setRgbEnabled(true);glint.onTick();int rgbUploads=tex.uploads;
  for(int i=0;i<24;i++)glint.onTick();
  test(tex.uploads==rgbUploads,"RGB motion also uses the UV matrix, not repeated CPU texture uploads");
  int beforeZero=tex.uploads;
  glint.strength.setValue(0);glint.onTick();
  test(Arrays.stream(tex.image.pixels).allMatch(x->x==0),"strength zero uploads black/transparent texture");
  test(tex.uploads==beforeZero+1,"strength update reuses the native texture");
  glint.onDisable();
  test(manager.textures.isEmpty(),"disable releases both custom texture bindings");
  test(!StableGlint.apply(8),"disabled module returns control to vanilla");
  near((Double)class_310.method_1551().field_1690.strength.method_41753(),.75,"global glint strength untouched");
  near((Double)class_310.method_1551().field_1690.speed.method_41753(),.5,"global glint speed untouched");
  if(args[0].equals("1.20.1")) {
  test(FullbrightPixels.adjust(0xff123456,1)==0xff123456,"gamma 1 preserves lightmap");
  test((FullbrightPixels.adjust(0xff000000,10)&0xffffff)==0xe5e5e5,"gamma 10 brightens dark lightmap to 229");
  test(FullbrightPixels.adjust(0xffffffff,20)==0xffffffff,"white remains white");
  test((FullbrightPixels.adjust(0x7f123456,10)>>>24)==0x7f,"lightmap alpha preserved");
  test(FullbrightPixels.brighten(0xff123456)==0xff123456,"disabled fullbright leaves pixel untouched");
  Fullbright fb=new Fullbright();DucksWordsClient.MODULES.modules.put(Fullbright.class,fb);fb.setEnabled(true);
  test(FullbrightPixels.brighten(0xff000000)==0xffe5e5e5,"enabled fullbright uses module gamma");
  }
  test(MobileRuntime.resolve(false,null,Map.of("ANDROID_ROOT","a","ANDROID_DATA","b")),"detect Android launchers without a Pojav-branded JVM path");
  test(!MobileRuntime.resolve(true,"false",Map.of("ANDROID_ROOT","a","ANDROID_DATA","b")),"explicit desktop override honored");
  test(!MobileRuntime.resolve(false,null,Map.of()),"ordinary desktop remains desktop");
  test(MobileRuntime.resolve(false,"true",Map.of()),"explicit mobile override honored");
  System.out.println("PASS: "+passed+" logic assertions (includes complete 64x64 pixel checks).");
 }
}
