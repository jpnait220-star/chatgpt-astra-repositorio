from pathlib import Path
root=Path(__file__).parent/'stubs'
files={
'net/minecraft/class_4668.java':'package net.minecraft; public class class_4668 {}',
'net/minecraft/class_765.java':'package net.minecraft; public class class_765 {}', 
'net/minecraft/class_310.java':'''package net.minecraft; public class class_310 { private static final class_310 INSTANCE=new class_310(); public static class_310 method_1551(){return INSTANCE;} public final class_315 field_1690=new class_315(); public final class_1060 textures=new class_1060(); public class_1060 method_1531(){return textures;} }''',
'net/minecraft/class_315.java':'''package net.minecraft; public class class_315 { public final class_7172 speed=new class_7172(.5),strength=new class_7172(.75); public class_7172 method_48580(){return speed;} public class_7172 method_48581(){return strength;} }''',
'net/minecraft/class_7172.java':'''package net.minecraft; public class class_7172 { private Object value; public class_7172(Object v){value=v;} public Object method_41753(){return value;} public void method_41748(Object v){value=v;} }''',
'net/minecraft/class_1060.java':'''package net.minecraft; import java.util.*; public class class_1060 { public final Map<class_2960,class_1044> textures=new HashMap<>(); public void method_4616(class_2960 id,class_1044 tex){textures.put(id,tex);} public void method_4615(class_2960 id){textures.remove(id);} }''',
'net/minecraft/class_1044.java':'package net.minecraft; public class class_1044 {}',
'net/minecraft/class_1043.java':'''package net.minecraft; public class class_1043 extends class_1044 { public final class_1011 image; public int uploads; public class_1043(class_1011 im){image=im;uploads=1;} public class_1011 method_4525(){return image;} public void method_4524(){uploads++;} }''',
'net/minecraft/class_1011.java':'''package net.minecraft; public class class_1011 { public final int width,height; public final int[] pixels; public class_1011(int w,int h,boolean b){width=w;height=h;pixels=new int[w*h];} }''',
'net/minecraft/class_2960.java':'''package net.minecraft; public record class_2960(String namespace,String path) {}''',
'net/minecraft/class_1297.java':'package net.minecraft; public class class_1297 {}',
'net/minecraft/class_332.java':'package net.minecraft; public class class_332 {}',
'net/minecraft/class_2338.java':'package net.minecraft; public record class_2338(int x,int y,int z) {}',
'net/minecraft/class_238.java':'package net.minecraft; public record class_238(class_2338 position) {}',
'net/minecraft/class_1268.java':'package net.minecraft; public enum class_1268 { field_5808,field_5810 }',
'net/minecraft/class_4587.java':'''package net.minecraft; public class class_4587 { public int depth,translations,scales; public void method_22903(){depth++;} public void method_22909(){depth--;} public void method_46416(float x,float y,float z){translations++;} public void method_22905(float x,float y,float z){scales++;} }''',
'net/minecraft/class_742.java':'package net.minecraft; public class class_742 { public boolean method_31550(){return false;} }',
'net/minecraft/class_1799.java':'package net.minecraft; public class class_1799 {}',
'net/minecraft/class_4597.java':'package net.minecraft; public interface class_4597 {}',
'com/duckswords/util/MinecraftCompat.java':'''package com.duckswords.util; import net.minecraft.*; public class MinecraftCompat { public static class_2960 identifier(String namespace,String path){return new class_2960(namespace,path);} public static void setPixel(class_1011 im,int x,int y,int argb){im.pixels[y*im.width+x]=argb;} public static void rotate(class_4587 m,String axis,float angle){} }''',
'com/duckswords/module/ModuleManager.java':'''package com.duckswords.module; import java.util.*; public class ModuleManager { public final Map<Class<?>,Module> modules=new HashMap<>(); public <T extends Module> T get(Class<T> type){return type.cast(modules.get(type));} }''',
'com/duckswords/DucksWordsClient.java':'package com.duckswords; import com.duckswords.module.ModuleManager; public class DucksWordsClient { public static ModuleManager MODULES=new ModuleManager(); }',
'com/mojang/blaze3d/systems/RenderSystem.java':'package com.mojang.blaze3d.systems; import org.joml.Matrix4f; public class RenderSystem { public static Matrix4f last; public static void setTextureMatrix(Matrix4f value){last=value;} }',
'net/fabricmc/fabric/api/event/Event.java':'package net.fabricmc.fabric.api.event; import java.util.*; public class Event<T> { public final List<T> listeners=new ArrayList<>(); public void register(T listener){listeners.add(listener);} }',
'net/fabricmc/fabric/api/client/rendering/v1/WorldRenderContext.java':'''package net.fabricmc.fabric.api.client.rendering.v1; import net.minecraft.class_2338; public interface WorldRenderContext { interface BlockOutlineContext { class_2338 blockPos(); } }''',
'net/fabricmc/fabric/api/client/rendering/v1/WorldRenderEvents.java':'''package net.fabricmc.fabric.api.client.rendering.v1; import net.fabricmc.fabric.api.event.Event; public class WorldRenderEvents { public static final Event<BlockOutline> BLOCK_OUTLINE=new Event<>(); public interface BlockOutline { boolean onBlockOutline(WorldRenderContext ctx,WorldRenderContext.BlockOutlineContext outline); } }''',
'com/duckswords/util/RenderUtil.java':'''package com.duckswords.util; import net.minecraft.class_238; import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext; public class RenderUtil { public static int lines,fills;public static class_238 last; public static void drawBox(WorldRenderContext ctx,class_238 box,float r,float g,float b,float a){lines++;last=box;} public static void drawFilledBox(WorldRenderContext ctx,class_238 box,float r,float g,float b,float a){fills++;last=box;} }''',
}
for name,source in files.items():
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
