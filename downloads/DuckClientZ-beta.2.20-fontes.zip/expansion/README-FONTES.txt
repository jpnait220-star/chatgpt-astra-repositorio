Fontes incrementais da atualização DuckClientZ beta.2.20.

Este pacote contém os helpers, transformações ASM, recursos e testes escritos
para a atualização. Não é uma recuperação integral do projeto original do client.
Compile-stubs e fixtures existem somente para compilação/testes: nunca devem
entrar no JAR do mod. validate_artifacts.py verifica essa separação.

Base: fixes.9 nas três versões anteriores e opt.2 na 1.21.11, publicadas na
branch asasa de jpnait220-star/chatgpt-astra-repositorio, pasta downloads.
As fontes das correções anteriores estão incluídas em bases-fontes/.
Os JARs originais de referência do Soup e o Minecraft não são redistribuídos
neste pacote de fontes. Os arquivos de crash do usuário também não estão nele.

Ambiente usado: Java 21, Python 3, ASM 9.7.1, Gson 2.10.1, JOML por versão,
Fabric Loader/Mixin e API de partículas Fabric por versão, LWJGL apenas para
compilar o cursor. As bibliotecas do jogo não são embutidas no resultado.

build.py usa os caminhos do workspace da sessão:
/workspace/duckclientz-expansion
/workspace/duckclientz/{tools,repair,dist-fixes9}
/workspace/duckclientz-1.21.11/{tools,repair,dist}
Disponibilize as bases e dependências nesses diretórios ou ajuste os caminhos.
A compilação Java usa java -m jdk.compiler/com.sun.tools.javac.Main -proc:none.
Execute python build.py. DUCK_VERSIONS seleciona versões separadas por vírgula;
DUCK_RELEASE define o identificador de versão. build-report.json registra hashes.

Testes:
python check_native.py           APIs oficiais remapeadas e novos mixins
python test_search.py            campo de busca nativo gerado
python test_safety.py            câmera/zoom/Sharpness/cosméticos/delay
python test_settings.py          modelos/swing/menus/limites/disabled paths
python test_particles.py         fábrica nativa, fade, morte e ancoragem
python test_profile_integration.py   Config/ProfileManager reais
python test_regressions.py       correções anteriores nas três versões
python test_native_regressions.py    correções anteriores na 1.21.11
python validate_artifacts.py     metadados, recursos e ausência de stubs
ProfileCodeTests.java e StorageTests.java cobrem codec e migração isolados.
Os testes usam fixtures do Minecraft; não representam execução dentro do jogo.

IMPORTANTE: os esquemas a-v em assets/duckswords/profiles/v3 são imutáveis.
Nunca substitua uma base existente, pois invalidaria códigos já compartilhados.
Acrescente novos identificadores em futuras versões quando necessário.

Atualização2.15: generate_hooks.py e generate_dressing.py usam os mapeamentos
oficiais/Tiny por versão para escrever TSVs com descritores exatos.
NativeHooksPatch/DressingPropsPatch constroem adaptadores a partir desses dados.
SpriteAssetsPatch prepara transparência e resolução dos sprites durante o build,
sem editar os recursos originais. IconAssetsPatch reutiliza ícones existentes.
Texture Maker removido das classes/recursos ativos e do registro de módulos.
Schemas a-l continuam imutáveis; m/n são as bases limpas da2.16.
Final216Patch produz bridges exatos de inventário, registros, perspectiva e som;
SoundsPatch preserva nomes existentes e adiciona reprodução local com parâmetros
volume/pitch corretos, inclusive Instakill fixo1.0x. generate_hooks inclui slots,
crosshair, nuvens e fogo. ExtendedPerformance controla oito categorias de desenho
sem mudar simulação. Nenhuma biblioteca nativa ou classe fake vai para o JAR.
Testes novos: test_final216.py e test_assets216.py; testes anteriores continuam
cobrindo persistência, HUD, câmera, modelos, partículas e limites. As fixtures
servem somente para testes/compilação e não substituem verificação no jogo.

CleanDefaultTests verifica a atualização automática, backup, outros perfis,
tema/fonte e persistência de edições feitas após a atualização.
Recursos Bibata incluídos com licença e fonte no CREDITOS.

Relay opcional em cosmetics-relay/relay.py; python relay.py --bind 127.0.0.1 --port 8765. O backend público atual usa Vercel/Redis; o relay local é apenas um protótipo.
O script prepare_health217.py usa o JAR de referência disponível no ambiente;
os sprites preparados e as máscaras finais estão também em resources/.

Duck Connect agora está publicado em https://duck-connect.vercel.app; fontes Vercel
em https://github.com/jpnait220-star/chatgpt-astra-repositorio/tree/asasa/duck-cosmetics.
A pasta cosmetics-relay mantém o protótipo Python de testes, não o backend publicado.

Revisão 2.18: Followup218Patch, Gui218Patch, AutoMining218Patch, WebOutline218Patch,
WebLayer218Patch e FireworkTiming218Patch são aplicados após a base incremental.
Tests adicionais: test_revision218.py, test_followup218.py (inclui F11 repetido),
test_handhooks218.py, test_regression218.py, test_assets218.py, test_online218.py.
As bases u/v acrescentam o novo Padrão; a-t permanecem imutáveis.

Correção 2.19: Startup219Patch troca NativeImage.setPixel por chamadas nativas
exatas e remove o inicializador reflexivo; WebLayer218Patch gera suas pontes
estáticas com ACC_SYNTHETIC, exigido pelo Mixin para esse tipo de método gerado.
test_startup219.py reproduz a falha da 2.18 e aplica os mixins corrigidos às classes
reais do jogo, usando Mixin do Fabric Loader 0.19.3 e serviço isolado de testes.
Dependência adicional: tools/mixin-loader-0.19.3.jar, obtida de
https://maven.fabricmc.net/net/fabricmc/sponge-mixin/0.17.3+mixin.0.8.7/sponge-mixin-0.17.3+mixin.0.8.7.jar
Não é incluída no JAR do mod. test_image_startup219.py cobre nomes intermediários,
inicialização e canais/alpha; test_release_diff219.py limita o diff da correção.

Revisão 2.20: Gui220Patch, Revision220Patch, Menu220Patch, TargetQuery220Patch,
CosmeticAnimation220Patch e Social220Patch. AutoMining218Patch não é aplicado:
cliques sintéticos continuam com mineração física permitida, sem cancelar o bloco.
Identidades usam GameProfile do servidor. prepare_identity220.py baixa authlib
oficial e verifica SHA1 pelo manifesto Mojang; não é embutida no mod/fontes.
prepare_models220.py e clean_icon_edges220.py usam o JAR beta.2.19 imutável em dist/;
obtenha-o em downloads/ da mesma branch para reproduzir a preparação dos recursos.
Os recursos resultantes já estão em resources/. Bases a-v imutáveis, w/x novas.
Testes atuais: test_startup220, test_runtime220, test_identity220, test_remote220,
test_worker220, test_burst220, test_defaults220 e test_assets220, além das regressões
listadas em VALIDACAO.txt. Dawn/GPU/FPS não foram executados. O status de conexão
não entra no perfil salvo. Não houve alteração no backend nesta revisão.
