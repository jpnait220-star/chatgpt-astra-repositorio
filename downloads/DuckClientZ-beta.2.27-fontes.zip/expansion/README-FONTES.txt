Fontes incrementais da atualização Duck Client beta.2.27.

Este pacote contém os helpers, transformações ASM, recursos e testes escritos
para a atualização. Não é uma recuperação integral do projeto original do client.
Compile-stubs e fixtures existem somente para compilação/testes: nunca devem
entrar no JAR do mod. validate_artifacts.py verifica essa separação.

Base: fixes.9 nas três versões anteriores e opt.2 na 1.21.11, publicadas na
branch asasa de jpnait220-star/chatgpt-astra-repositorio, pasta downloads.
As fontes das correções anteriores estão incluídas em bases-fontes/.
Os JARs originais de referência do Soup e o Minecraft não são redistribuídos
neste pacote de fontes. Os arquivos de crash do usuário também não estão nele.

Ambiente usado: Java 21, Python 3, ASM 9.7.1, Gson 2.10.1, JOML por versão,
Fabric Loader/Mixin e API de partículas Fabric por versão, LWJGL apenas para
compilar o cursor. As bibliotecas do jogo não são embutidas no resultado.

build.py usa os caminhos do workspace da sessão:
/workspace/duckclientz-expansion
/workspace/duckclientz/{tools,repair,dist-fixes9}
/workspace/duckclientz-1.21.11/{tools,repair,dist}
Disponibilize as bases e dependências nesses diretórios ou ajuste os caminhos.
A compilação Java usa java -m jdk.compiler/com.sun.tools.javac.Main -proc:none.
Execute python build.py. DUCK_VERSIONS seleciona versões separadas por vírgula;
DUCK_RELEASE define o identificador de versão. build-report.json registra hashes.

Testes:
python check_native.py           APIs oficiais remapeadas e novos mixins
python test_search.py            campo de busca nativo gerado
python test_safety.py            câmera/zoom/Sharpness/cosméticos/delay
python test_settings.py          modelos/swing/menus/limites/disabled paths
python test_particles.py         fábrica nativa, fade, morte e ancoragem
python test_profile_integration.py   Config/ProfileManager reais
python test_regressions.py       correções anteriores nas três versões
python test_native_regressions.py    correções anteriores na 1.21.11
python validate_artifacts.py     metadados, recursos e ausência de stubs
ProfileCodeTests.java e StorageTests.java cobrem codec e migração isolados.
Os testes usam fixtures do Minecraft; não representam execução dentro do jogo.

IMPORTANTE: os esquemas a-v em assets/duckswords/profiles/v3 são imutáveis.
Nunca substitua uma base existente, pois invalidaria códigos já compartilhados.
Acrescente novos identificadores em futuras versões quando necessário.

Atualização2.15: generate_hooks.py e generate_dressing.py usam os mapeamentos
oficiais/Tiny por versão para escrever TSVs com descritores exatos.
NativeHooksPatch/DressingPropsPatch constroem adaptadores a partir desses dados.
SpriteAssetsPatch prepara transparência e resolução dos sprites durante o build,
sem editar os recursos originais. IconAssetsPatch reutiliza ícones existentes.
Texture Maker removido das classes/recursos ativos e do registro de módulos.
Schemas a-l continuam imutáveis; m/n são as bases limpas da2.16.
Final216Patch produz bridges exatos de inventário, registros, perspectiva e som;
SoundsPatch preserva nomes existentes e adiciona reprodução local com parâmetros
volume/pitch corretos, inclusive Instakill fixo1.0x. generate_hooks inclui slots,
crosshair, nuvens e fogo. ExtendedPerformance controla oito categorias de desenho
sem mudar simulação. Nenhuma biblioteca nativa ou classe fake vai para o JAR.
Testes novos: test_final216.py e test_assets216.py; testes anteriores continuam
cobrindo persistência, HUD, câmera, modelos, partículas e limites. As fixtures
servem somente para testes/compilação e não substituem verificação no jogo.

CleanDefaultTests verifica a atualização automática, backup, outros perfis,
tema/fonte e persistência de edições feitas após a atualização.
Recursos Bibata incluídos com licença e fonte no CREDITOS.

Relay opcional em cosmetics-relay/relay.py; python relay.py --bind 127.0.0.1 --port 8765. O backend público atual usa Vercel/Redis; o relay local é apenas um protótipo.
O script prepare_health217.py usa o JAR de referência disponível no ambiente;
os sprites preparados e as máscaras finais estão também em resources/.

Duck Connect agora está publicado em https://duck-connect.vercel.app; fontes Vercel
em https://github.com/jpnait220-star/chatgpt-astra-repositorio/tree/asasa/duck-cosmetics.
A pasta cosmetics-relay mantém o protótipo Python de testes, não o backend publicado.

Revisão 2.18: Followup218Patch, Gui218Patch, AutoMining218Patch, WebOutline218Patch,
WebLayer218Patch e FireworkTiming218Patch são aplicados após a base incremental.
Tests adicionais: test_revision218.py, test_followup218.py (inclui F11 repetido),
test_handhooks218.py, test_regression218.py, test_assets218.py, test_online218.py.
As bases u/v acrescentam o novo Padrão; a-t permanecem imutáveis.

Correção 2.19: Startup219Patch troca NativeImage.setPixel por chamadas nativas
exatas e remove o inicializador reflexivo; WebLayer218Patch gera suas pontes
estáticas com ACC_SYNTHETIC, exigido pelo Mixin para esse tipo de método gerado.
test_startup219.py reproduz a falha da 2.18 e aplica os mixins corrigidos às classes
reais do jogo, usando Mixin do Fabric Loader 0.19.3 e serviço isolado de testes.
Dependência adicional: tools/mixin-loader-0.19.3.jar, obtida de
https://maven.fabricmc.net/net/fabricmc/sponge-mixin/0.17.3+mixin.0.8.7/sponge-mixin-0.17.3+mixin.0.8.7.jar
Não é incluída no JAR do mod. test_image_startup219.py cobre nomes intermediários,
inicialização e canais/alpha; test_release_diff219.py limita o diff da correção.

Revisão 2.20: Gui220Patch, Revision220Patch, Menu220Patch, TargetQuery220Patch,
CosmeticAnimation220Patch e Social220Patch. AutoMining218Patch não é aplicado:
cliques sintéticos continuam com mineração física permitida, sem cancelar o bloco.
Identidades usam GameProfile do servidor. prepare_identity220.py baixa authlib
oficial e verifica SHA1 pelo manifesto Mojang; não é embutida no mod/fontes.
prepare_models220.py e clean_icon_edges220.py usam o JAR beta.2.19 imutável em dist/;
obtenha-o em downloads/ da mesma branch para reproduzir a preparação dos recursos.
Os recursos resultantes já estão em resources/. Bases a-v imutáveis, w/x novas.
Testes atuais: test_startup220, test_runtime220, test_identity220, test_remote220,
test_worker220, test_burst220, test_defaults220 e test_assets220, além das regressões
listadas em VALIDACAO.txt. Dawn/GPU/FPS não foram executados. O status de conexão
não entra no perfil salvo. Não houve alteração no backend nesta revisão.

Revisão 2.21: Cleaner221Patch e Tags221Patch, além do AutoMining218Patch reativado
para impedir início/progresso de mineração com AutoClicker executando. Painel de
ação Cleaner sem enabled; modo/applied persistem nas configurações normais.
Escopos de emissão de partículas usam try/finally. Guardas preservam tipos Duck,
F5 e câmeras alternativas. Não importa os 1.225 rótulos sem implementação do Cleaner
original; os botões descrevem somente controles implementados. Não há System.gc.
prepare_mask221.py corrige a escala do atlas nas quatro caixas com box UV; nariz
com UV explícito permanece byte/semanticamente inalterado. Geometria preservada.
Testes: test_cleaner221.py, test_assets221.py, test_startup221.py e relatórios221.
Dependência offlinenametagicon removida; não incluir companion nos ZIPs.
COSMETIC.zip (>32MiB) não foi transferido, portanto os 14 novos modelos aguardam
arquivo acessível; não existem recursos fictícios ocupando suas vagas.

Revisão 2.22: Revision222Patch registra 28 modelos/atlas animados e predicados de
conteúdo de HUD; RenderOpt222Patch adapta anel/glint às APIs reais de cada versão.
prepare_cosmetics222.py lê game.zip fornecido, sem executar código do arquivo;
render_cosmetic_icons222.py renderiza miniaturas a partir dos próprios modelos.
cosmetics222-manifest.json registra IDs, origem e mudanças de âncoras.
O dicionário profiles/v5/a.dict e as bases profiles/v3/a-z.json são imutáveis.
Não regenere arquivos congelados ao mudar os padrões: crie novos identificadores
e preserve os anteriores para compatibilidade de códigos. D5 exige 2.22+.

Testes atuais: test_profiles222.py, test_defaults222.py, test_cosmetics222.py,
test_assets222.py, test_render222.py, test_hud222.py, test_cleaner222.py,
test_startup222.py, test_runtime220.py, test_worker222.py e test_burst220.py.
Os dois scripts com nomes anteriores são executados contra os JARs do build-report
atual. CheckAddedApi.java verifica chamadas nativas contra bytecode real remapeado.
VALIDACAO.txt registra o que foi simulado; não comprova FPS ou resultado em GPU.

Revisão 2.23: CosmeticFit223Patch corrige origem BODY, posições de máscaras
e sombrero. A 1.20.1 tem enum único, as demais têm subclasses de Anchor.
saveSelected recalcula frames só nos métodos alterados e resolve hierarquia Java
para preservar Throwable/Exception; não regrave frames de métodos não alterados.
Menu223Patch arredonda painel/cartões e deixa de desenhar cartões fora da janela.
Settings223Patch usa pixels de tela em todas as dimensões da barra de configuração.
ScrollHandle mantém o valor de scroll em unidades lógicas e converte só o desenho.

prepare_cosmetics223.py importa o catálogo atualizado do game.zip; em seguida
prepare_pets223.py corrige UV dos pets e gera três miniaturas com texturas/dimensões
vanilla. As texturas são originais; não gera artes de terceiros. Para ícones,
execute render_cosmetic_icons223.py e renderize também os dois pets existentes
com a função render do mesmo script. Recursos finais já estão em resources/.
Prepare assets ANTES da compilação, nunca durante build.py. Não rode scripts
antigos de preparação que possam sobrescrever a seleção/UV atuais.

Bases a-z e o dicionário D5 ficam imutáveis. Novas bases 0/1 são o padrão223;
a partir deste lançamento elas também ficam congeladas. Crie outros IDs futuros.

Testes atuais223: test_cosmetics223.py, test_assets223.py, test_defaults223.py,
test_startup223.py, test_cleaner223.py, test_hud223.py, test_ui223.py,
validate_artifacts.py, check_native.py; regressões reutilizadas test_runtime220.py,
test_worker222.py, test_burst220.py, test_profiles222.py contra build-report atual.
42 modelos são carregados/bakeados/animados com -Xverify:all; cenários de UI incluem
cantos transparentes e tela/escala diferentes. ExtractScroll223 extrai os getters
e setter REAIS da SettingsScreen e substitui apenas os dados de layout do teste.
TestMixinApply223 confirma os hooks de mineração em2910/2902/2899 reais.
Não houve execução gráfica em Minecraft/Pojav nem teste com Dawn ou medição de FPS.

Revisão 2.24: Menu224Patch altera DuckScreen.card/button, sem tocar
nenhum overload de toggleButton. Painéis SettingsScreen e DuckCosmeticsScreen
usam MenuPanels223.menu; acentos insetados não cobrem os cantos. Pesquisa/abas
herdam os controles arredondados. Vestiário: moldura e piso arredondados.
Scrollbar de Settings fica content-right+2 em unidades lógicas, dentro da borda
content-right+8 mesmo em escala 0,5. A barra da lista principal avança 1 pixel.
Somente cartões visíveis de cosméticos são desenhados, com modelo intacto.

prepare_cosmetics224.py parte dos recursos da beta.2.23 publicada e grava somente
os modelos corrigidos. Remoções no CosmeticCatalog222 e filtro final de build.py;
manifesto cosmetics224-manifest.json lista 31 adições vigentes e 14 IDs removidos
no total. Geometria corrigida, texturas/sons originais conservados. Não rode os
preparadores anteriores depois deste. Ícones dos oito modelos alterados são
renderizados com render_cosmetic_icons223.render. Recursos finais já incluídos.
Perfis congelados a-z/0/1 não mudam; não há nova migração ou reset nesta revisão.

Testes atuais224: test_assets224.py, test_cosmetics224.py, test_ui224.py e
InspectUi224.java; demais verificações listadas em package_release.py foram
reexecutadas contra os JARs do build-report atual. VALIDACAO.txt contém resultados.
Sem teste visual em GPU/Minecraft/Pojav ou medição de FPS.

AutoClick224Patch: gera MixinAutoClickActions224 com Invoker exato/remap=false
para method_1536()Z, method_1583()V e method_1511()V nas quatro versões.
ClientData.worldClick usa esses métodos e registra CPS/som sem duplicar a fila
de mouse. clearAttackInput libera o KeyMapping de ataque e drena clicks físicos.
MixinAutoClickHold222 agora modifica somente o argumento booleano de
method_1590(Z)V para false. Não cancela o corpo: a limpeza vanilla de cooldown/
mineração ao soltar ataque é preservada. Os guards de 2910/2902/2899 permanecem.
AutoClickerRuntime remove a combinação serial+polling que podia inverter Toggle
em dobro. Borda única e estado de evento suportam entradas virtuais/hold.
Testes test_autoclick224.py executam os corpos reais dos adapters com objetos
nativos simulados; test_startup224.py aplica Invoker/ModifyVariable reais ao
bytecode de Minecraft. Não equivale a testar client/Dawn/Pojav executando.
CosmeticFit223Patch.zOffset223 também avança palhaço e japonesa 1 pixel.

Cosmetic224Patch remove as opções e emissão das estrelas do China Hat, inclusive
se um perfil antigo/estado remoto solicitar a flag Estrelas. Chapéu preservado.
Raposa/axolote: geometria integral transladada com pivôs, X-6/+6, base Y24.1
e Z central; raiz sem bounce, mantendo cauda/brânquias. test_assets224 calcula
os limites transformados reais; test_cosmetics224 confirma flags/controles.

AuraAnchor224 recebe o ModelPart real e o modelo: auras usam somente o pivot
de posição; rotação transitória de bater/colocar blocos é ignorada. Demais
cosméticos continuam usando rotate/translate vanilla. BoxingGloves e SpringClaws
usam accessor field_3480 de PlayerModel para detectar slim (Alex); escala X
0,75 e compensação de centro de mão 0,25 pixel, em matriz isolada. Steve intacto.
MixinSlimArms224 aplica ao class_591 em todas as quatro versões.

Ghost: caps usam rede branca original; extremidade do cabo transformada é
alinhada ao pivot da mão, incluindo pivôs de todos os cubos da lâmpada.
Punhos usam quadros originais WebP do game.zip: Fire3, Blood3, Ice3, Corrupted8.
AnimatedCosmetic222 recebe a tabela de quadros/durações extraída, com cache
de materiais; sem animações procedurais novas. test_assets224 compara todos
os pixels/tempos com o pack. Ícone do tênis gerado da geometria original.
test_cosmetic_pose224 testa matriz real dos adapters, 60 poses de ataque em
7 auras, ajuste slim/wide e ausência de mutação do ModelPart.

Revisão 2.25 (atual): SmoothOutline225 usa cobertura amostrada (4x4 por célula
na malha de meio pixel) e coalesce retângulos por cor/posição. Contorno suave,
raios8/11 e faixa superior em arco/linha/arco. Cache de geometria compartilhado;
não muda RoundedPanel dos HUDs nem o desenho dos botões de ativar/desativar.

AutoClick225Patch restaura o estado físico de ataque ao parar a execução.
blockMining agora requer running, foco, left, mundo/jogador atuais e ausência de
pausa/GUI/consumo/captura. on/off da feature sozinho não bloqueia o usuário.
Teste dedicado225 executa corpos nativos reais dos adapters com objetos mockados.

prepare_cosmetics225.py parte da beta.2.24 publicada, retira cavaleiro, corrige
UV/pose/foice do ceifador e gera preview-headroom225.json com limites transformados
dos modelos de cabeça. Perfil/códigos e animações de punhos ficam imutáveis.
PreviewSizing225 carrega a tabela uma vez e só reavalia ao mudar a lista equipada.
A prévia usa a largura e o topo completos. Luva/garras mantêm o ajuste Alex/Steve
da beta.2.24; AuraAnchor224.fit e o accessor slim permanecem ativos.

Testes novos: test_ui225.py, test_autoclick225.py, test_assets225.py,
test_cosmetics225.py, test_preview225.py, test_startup225.py, test_hud225.py,
test_cleaner225.py e test_cosmetic_pose225.py. Regressões antigas são executadas
contra o build-report atual; package_release.py exige todos os relatórios finais.
Build e pacote seguem build.py / package_release.py. Recursos finais já inclusos;
não execute preparadores antigos sobre os novos. Sem teste gráfico ou FPS medido.

225: modulo de comunidade com presenca real, chat e skins nativas; resolver de
perfis/skins e I/O em segundo plano, cache limitado; PUBLICAR-SITE.txt explica a
publicacao manual do servico no projeto Duck Connect existente.

226: ajuste animado das auras (+12px); luvas/garras mantem tamanho225 com
UVs originais por face; topo fisico do bone usa o atlas opaco; botao chat20x18;
compensacao do inset do gradiente nativo nas juncao das faixas superiores.
Servico Duck Connect publicado e validado publicamente. A preparacao de
recursos usa prepare_aura226.py e prepare_texture226.py; build.py usa os
recursos ja preparados, sem reconstruir modelos em cada frame.

227: AuraEnvelope227 aplica uma matriz constante apenas em springSparklesAura
e winter2024ShardsAura. Dimensoes comparadas com Money no ciclo completo;
centro acompanha o corpo, mantendo todas as animacoes/recursos da226.
