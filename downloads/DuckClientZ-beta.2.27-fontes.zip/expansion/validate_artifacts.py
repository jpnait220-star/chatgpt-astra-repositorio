from pathlib import Path
from zipfile import ZipFile
import json,hashlib,struct
B=Path(__file__).parent
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 p=Path(entry['jar']);assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
 with ZipFile(p) as z:
  assert z.testzip() is None;names=set(z.namelist());meta=json.loads(z.read('fabric.mod.json'));assert meta['version']=='1.5.28-beta.2.27'
  assert not any(n.startswith(('net/minecraft/','net/fabricmc/','org/lwjgl/')) for n in names),'Compile fixtures must never enter mod'
  for mix in meta['mixins']:
   doc=json.loads(z.read(mix));assert 'MixinRecordingCamera' not in doc.get('client',[])
   for name in doc.get('client',[]):assert (doc['package'].replace('.','/')+'/'+name.replace('.','/')+'.class') in names
  for kind in ['main','client']:assert 'com.duckswords.particles.VisualParticles' in meta['entrypoints'][kind]
  for name in names:
   if name.startswith('assets/duckswords/particles/') and name.endswith('.json'):
    for tex in json.loads(z.read(name))['textures']:
     namespace,path=tex.split(':');assert f'assets/{namespace}/textures/particle/{path}.png' in names,(name,tex)
  sounds=json.loads(z.read('assets/duckswords/sounds.json'))
  for key,val in sounds.items():
   if True:
    for sound in val['sounds']:
     path=sound if isinstance(sound,str) else sound['name'];namespace,path=path.split(':');assert f'assets/{namespace}/sounds/{path}.ogg' in names
  default=json.loads(json.loads(z.read('assets/duckswords/default-profile.json'))['config']);assert default['$duckDefaultPreset'].startswith('uploaded-v223-')
  supplied=json.loads(Path('/workspace/attachments/f70430e0-aed1-41b6-b9c7-127a733371f8/config.json').read_text())
  supplied['AutoClicker']['settings']['Som']=True
  supplied['FireworkKey']['settings']['Delay (ticks)']=5
  supplied['Totem Editor']['settings']['Escala do pop']=2.35
  supplied['Mouse Icon']['enabled']=True
  supplied['Mouse Icon']['settings']['Icone']='Espada de diamante'
  supplied['Cosmeticos Online']={'enabled':True,'favorite':False,'settings':{'Mostrar cosmeticos dos outros':True,'Compartilhar meus cosmeticos':True,'Servico oficial':'duck-connect.vercel.app','Tag Duck no nick e TAB':True,'Compartilhar tag Duck':True,'Atualizar a cada':30}}
  for cosmetic in json.loads((B/'cosmetics223-manifest.json').read_text())['items']:supplied['$cosmetics'][cosmetic['id']]={'equipped':False,'settings':{}}
  for cosmetic in json.loads((B/'cosmetics223-manifest.json').read_text())['removed']:supplied['$cosmetics'].pop(cosmetic,None)
  for key,val in supplied.items():
   if key!='Jaula Cooldown':assert default[key]==val,('uploaded config mismatch',v,key)
  assert 'Jaula Cooldown' not in default
  assert 'Texture Maker' not in default
  assert not any('texturemaker/' in name.lower() or 'texturemaker.class' in name.lower() or name.endswith('/texturemaker.png') for name in names)
  for module in ['Crosshair Editor','Inventory HUD']:assert not default[module]['enabled']
  for icon in ['crosshaireditor','inventoryhud','healthbar']:assert 'assets/duckswords/textures/gui/icons/'+icon+'.png' in names
  assert default['Interface']['enabled']
  assert not default['Visuals']['enabled'] and default['Mouse Icon']['enabled']
  assert z.read('assets/duckswords/storage.properties').decode().startswith('minecraft='+v+'\n')
 print('PASS: final CRC/hash, metadata/mixins/entrypoints, particle/audio assets, scoped version and no compile stubs:',v)
