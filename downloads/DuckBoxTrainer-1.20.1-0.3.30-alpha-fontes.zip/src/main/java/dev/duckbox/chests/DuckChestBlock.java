package dev.duckbox.chests;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.math.BlockPos;

public final class DuckChestBlock extends ChestBlock {
  public final int baseRole;

  public DuckChestBlock(int role, Settings settings) {
    super(settings, () -> MapChests.TYPE);
    baseRole = role;
  }

  public BlockState getPlacementState(ItemPlacementContext context) {
    return super.getPlacementState(context).with(CHEST_TYPE, ChestType.SINGLE);
  }

  public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
    return new DuckChestEntity(pos, state);
  }
}
