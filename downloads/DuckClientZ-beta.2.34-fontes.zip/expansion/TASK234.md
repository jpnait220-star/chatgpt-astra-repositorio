# beta.2.34
Latest clarification: sustained FPS reduction during ordinary gameplay rendering
OTHER players' cosmetics, rather than menu/inventory spikes. No MC version given.
Do not promise full optimization or a measured FPS gain without a game/GPU run.

Implemented optional Sodium public VertexBufferWriter bulk path using live
custom-cube vertices/UVs. Version-aware ModelVertex/EntityVertex layout verified
(36-byte stride, offsets, actual format class); white tint and <=6 faces only.
Unsupported API/consumer uses previous native direct path. Thread-local reusable
buffers support nested transfers and finally cleanup; no quality/distance cut.

ModuleManager skips inherited empty world/HUD callbacks, preserves HUD category
panels, live enabled state and order. Adds local opt-in /duckperf10s CPU diagnostic,
per-module HUD plus total HUD/world/cosmetic preparation timings, callback intervals,
actual Sodium batch/vertex counts, bounded consumer-class fallback list. Writes
config/duckclientz/<MC>/render-profile.txt asynchronously; no network/upload.
No clock read in inactive begin; timers preserve exceptions. Thin delegate wrappers
retain original method stack-map frames, including loader exception merges.
A regression test caught an invalid Throwable merge caused by whole-renderer
frame recomputation in an unpublished draft; restricted frame generation to new
thin wrappers and retained all original loader bodies/frames. Revalidate final.

No new defaults migration or cleaner choices reset. All233 UI/HUD/cosmetic cache
optimizations retained. Native1.21.11 deferred submission retained. Native bulk
API0.6.13 fixture used for modern versions, not all actual Sodium versions/GPU.
Real-game measurement still required; ask user /duckperf while watching players.
Publish immutable234 four JARs/bundles + exact signed fixed manifest only after
all final tests; verify production bytes and all remote hashes. No chat broadcast.
