from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json,hashlib
BASE=Path(__file__).parent
INPUTS={v:BASE.parent/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar'
        for v in ('1.20.1','1.21.1','1.21.4')}
VERSION='1.5.28-beta.2.13-fixes.3'
OUT=BASE.parent/'dist-fixes3';OUT.mkdir(exist_ok=True)
report={}
for v,original in INPUTS.items():
 with ZipFile(original) as z:
  contents={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
 assert not any(n.startswith('META-INF/') and n.endswith(('.SF','.RSA','.DSA')) for n in contents), 'Signed input needs explicit re-signing'
 changes={}
 for p in (BASE/'classes').rglob('*.class'):
  name=p.relative_to(BASE/'classes').as_posix()
  if name.endswith('BlockOverlay.class') and v!='1.21.1':continue
  if ('FullbrightPixels' in name) and v!='1.20.1':continue
  assert name.startswith('com/duckswords/'),name
  changes[name]=p.read_bytes()
 for p in (BASE/'patched'/v).rglob('*.class'):
  changes[p.relative_to(BASE/'patched'/v).as_posix()]=p.read_bytes()
 metadata=json.loads(contents['fabric.mod.json'])
 assert metadata['depends']['minecraft']==v
 metadata['version']=VERSION
 metadata.setdefault('custom',{})['duckclientz_repair_status']='regression-and-bytecode-checked; game-testing-required'
 metadata['custom']['duckclientz_glint_fix']='frame-texture-matrix-integrated-clock-registered-controls-premultiplied-rgb'
 metadata['custom']['duckclientz_scoreboard_scope']='isolated-call-and-buffers-try-finally-noop-default'
 metadata['custom']['duckclientz_performance']='direct-vertices-normals-rotation-tick-fps-layer; cached-circle; spatial-hit-range-10hz; cached-hsb-hud-format; lightmap-lut1201'
 metadata['custom']['duckclientz_213']='default-profile-resource-pojav-font-offhand-pose-outline-event-fullbright-pixels'
 metadata['mixins'].append('duckclientz-visual-fixes.mixins.json')
 changes['fabric.mod.json']=(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode()
 mixes={'required':True,'package':'com.duckswords.mixin','compatibilityLevel':'JAVA_17' if v=='1.20.1' else 'JAVA_21',
        'client':['MixinStableGlint','MixinScopedScoreboard'],'injectors':{'defaultRequire':1}}
 if v=='1.20.1':
  mixes['client'].append('MixinFullbrightPixels')
  for name in metadata['mixins'][:-1]:
   data=json.loads(contents[name]); data['client']=[x for x in data.get('client',[]) if x!='MixinFullbright']
   changes[name]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 changes['duckclientz-visual-fixes.mixins.json']=(json.dumps(mixes,indent=2)+'\n').encode()
 profile=json.loads(contents['assets/duckswords/default-profile.json']);cfg=json.loads(profile['config'])
 cfg['Custom Glint']['settings'].setdefault('Velocidade',1)
 cfg['Custom Glint']['settings'].setdefault('Forca',1)
 profile['config']=json.dumps(cfg,ensure_ascii=False,indent=2)
 changes['assets/duckswords/default-profile.json']=(json.dumps(profile,ensure_ascii=False,indent=2)+'\n').encode()
 jar=OUT/f'DuckClientZ-{v}-{VERSION}-experimental.jar'
 with ZipFile(jar,'w',ZIP_DEFLATED) as z:
  for name,data in sorted((contents|changes).items()):z.writestr(name,data)
 with ZipFile(jar) as z:assert z.testzip() is None
 report[v]={'input_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),
 'output_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'changed_or_added':sorted(changes),'jar':str(jar)}
 print(v,jar.name,jar.stat().st_size)
(BASE.parent/'build-report.json').write_text(json.dumps(report,indent=2))
