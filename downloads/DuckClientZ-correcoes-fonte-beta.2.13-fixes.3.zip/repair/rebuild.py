"""Rebuild the incremental repair from the three original user-provided JARs. Requires JDK 21."""
from pathlib import Path
import subprocess,urllib.request,hashlib,os,shutil
BASE=Path(__file__).resolve().parent
ROOT=BASE.parent
TOOLS=ROOT/'tools';TOOLS.mkdir(exist_ok=True)
def fetch(name,url):
 path=TOOLS/name
 with urllib.request.urlopen(url+'.sha1',timeout=60) as r:checksum=r.read().decode().strip().split()[0]
 if not path.exists() or hashlib.sha1(path.read_bytes()).hexdigest()!=checksum:
  with urllib.request.urlopen(url,timeout=60) as r:data=r.read()
  if hashlib.sha1(data).hexdigest()!=checksum:raise RuntimeError('Checksum mismatch: '+name)
  path.write_bytes(data)
for a in ['asm','asm-tree','asm-commons','asm-analysis']:
 fetch(a+'-9.7.1.jar',f'https://repo.maven.apache.org/maven2/org/ow2/asm/{a}/9.7.1/{a}-9.7.1.jar')
fetch('joml.jar','https://repo.maven.apache.org/maven2/org/joml/joml/1.10.5/joml-1.10.5.jar')
fetch('mixin.jar','https://maven.fabricmc.net/net/fabricmc/sponge-mixin/0.15.4+mixin.0.8.7/sponge-mixin-0.15.4+mixin.0.8.7.jar')
def run(*cmd):subprocess.run([str(x) for x in cmd],cwd=ROOT,check=True)
def cp(*paths):return os.pathsep.join(str(x) for x in paths)
def compile(out,classpath,sources):
 run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',classpath,'-d',out,*sources)
import sys
run(sys.executable,BASE/'make_stubs.py')
original=ROOT/'originals'/'DuckClientZ-1.20.1-1.5.28-beta.2.12-experimental.jar'
compile(BASE/'stubclasses',cp(TOOLS/'joml.jar',original),(BASE/'stubs').rglob('*.java'))
compile(BASE/'classes',cp(BASE/'stubclasses',TOOLS/'joml.jar',TOOLS/'mixin.jar',original),(BASE/'src').rglob('*.java'))
asm=cp(TOOLS/'asm-9.7.1.jar',TOOLS/'asm-tree-9.7.1.jar')
compile(BASE/'toolclasses',asm,[BASE/'PatchClasses.java',BASE/'PerfPatches.java'])
for v in ('1.20.1','1.21.1','1.21.4'):
 if (BASE/'patched'/v).exists():shutil.rmtree(BASE/'patched'/v)
 run('java','-cp',cp(BASE/'toolclasses',TOOLS/'asm-9.7.1.jar',TOOLS/'asm-tree-9.7.1.jar'),'PatchClasses',
     ROOT/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar',BASE/'patched'/v,v,BASE/'classes')
 run('java','-cp',cp(BASE/'toolclasses',TOOLS/'asm-9.7.1.jar',TOOLS/'asm-tree-9.7.1.jar'),'PerfPatches',
     ROOT/'originals'/f'DuckClientZ-{v}-1.5.28-beta.2.12-experimental.jar',BASE/'patched'/v,v)
run(sys.executable,BASE/'build_jars.py')
