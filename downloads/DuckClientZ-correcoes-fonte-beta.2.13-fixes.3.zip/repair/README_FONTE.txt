CÓDIGO DAS CORREÇÕES INCREMENTAIS
===============================

Este diretório contém apenas o código novo, as alterações pontuais de bytecode
(PatchClasses.java e PerfPatches.java), stubs para compilação/testes e o empacotamento. Não é o
projeto Gradle original nem contém o Minecraft descompilado.

Para recompilar, use JDK 21 e Python 3 e coloque os três JARs originais enviados
em uma pasta originals/ ao lado de repair/, com os nomes:
DuckClientZ-1.20.1-1.5.28-beta.2.12-experimental.jar
DuckClientZ-1.21.1-1.5.28-beta.2.12-experimental.jar
DuckClientZ-1.21.4-1.5.28-beta.2.12-experimental.jar

Execute: python repair/rebuild.py
As dependências são baixadas de Maven Central/Fabric via HTTPS e verificadas
contra o checksum publicado. Os resultados ficam em dist-fixes3/.

Os stubs em stubs/ e teststubs/ são SOMENTE para compilar/executar testes isolados.
NENHUMA dessas classes substitutas de Minecraft/Fabric vai para os JARs finais.

VerifyArtifacts.java e validate.py documentam as verificações adicionais feitas.
A validação requer também os artefatos e mappings reais de Minecraft de cada
versão e as ferramentas listadas no script, além da configuração de referência
fornecida para o teste do tema. Esses arquivos externos não estão neste pacote.

Fonte/arquivo a investigar para cada correção:
- src/com/duckswords/glint/ e modules/CustomGlint.java: padrão RGB, fase e velocidade.
- mixin/MixinStableGlint.java: matriz de textura por frame.
- modules/BlockOverlay.java: evento nativo de outline.
- compat/FullbrightPixels.java e mixin/MixinFullbrightPixels.java: lightmap 1.20.1.
- PatchClasses.java: offhand 1.21.4, fonte e seed do perfil padrão.
- compat/MobileRuntime.java: detecção Android sem forçar fonte vanilla.

- render/ScoreboardScope.java e mixin/MixinScopedScoreboard.java: isolamento do placar.
- render/FontStyleCache.java: cache de estilos imutaveis sem reutilizar texto mutavel.

Desempenho fixes.3:
- PerfPatches.java: chamadas diretas de vértices/normais/FPS/delta/camada e
  rotação; encaminhamento das formatações numéricas do HUD para cache limitado.
- perf/AxisRotation.java: rotação sem reflexão, com semântica de multiplicação.
- perf/CirclePoints.java e repair/HitRangeRing.java: círculo reutilizado.
- modules/HitRange.java: consulta espacial de alvos no tick, independente de FPS.
- setting/ColorSetting.java: HSB invalidado por alteração de cor.
- perf/HudFormatCache.java: resultados apenas para argumentos imutáveis e locale.
- compat/FullbrightPixels.java: tabela de níveis preparada por atualização.
- tests/PerformanceTests.java: geometria, alvos, rotação, HUD, HSB e tabela gamma.
- ExtractVertexProbe.java: extração dos corpos reais antes/depois para comparação
  sintética de CPU com stub, sem dependência do jogo completo nem uso de GPU.
- FabricMetadataTest.java: parser real do Fabric e CRC de todas as entradas.
  Exige fabric-loader-0.16.10.jar de Maven Fabric, com checksum publicado.
