package com.duckswords.input;
import com.duckswords.DucksWordsClient;import com.duckswords.modules.AutoClicker;import com.duckswords.client.ClientData;import com.duckswords.gui.DuckScreen;import com.duckswords.util.Keys;import net.minecraft.*;import java.util.*;import java.util.concurrent.ThreadLocalRandom;
/** Main-thread, monotonic input scheduling. Uses Minecraft's mouse pipeline, never attack/cooldown bypasses. */
public final class AutoClickerRuntime {
 private static final IdentityHashMap<AutoClicker,State> STATES=new IdentityHashMap<>();private static int synthetic;private static long serial;
 private static final class State {boolean running,wasPressed,ready;Object world,player;String binding="",mode="",button="";long seen,next;final long[] clicks=new long[64];int head,size;void prune(long now){while(size>0&&now-clicks[head]>=1_000_000_000L){head=(head+1)%clicks.length;size--;}}void add(long now){prune(now);if(size==clicks.length){head=(head+1)%clicks.length;size--;}clicks[(head+size++)%clicks.length]=now;}}
 private static State state(AutoClicker c){return STATES.computeIfAbsent(c,k->new State());}
 private static AutoClicker owner(){return DucksWordsClient.MODULES.get(AutoClicker.class);}
 public static boolean foodAction(String name){return "EAT".equals(name)||"DRINK".equals(name);}
 public static boolean synthetic(){return synthetic>0;}
 private static boolean allowed(AutoClicker c){class_310 mc=class_310.method_1551();return ClientData.focused()&&mc.field_1724!=null&&mc.field_1687!=null&&!(mc.field_1755 instanceof DuckScreen)&&(mc.field_1755==null||c.runWithGui.getValue());}
 public static void key(int key,int action,int mods){if(action!=1||synthetic())return;AutoClicker c=owner();if(c==null||!c.isEnabled()||c.bind.isListening()||!allowed(c))return;if(c.bind.getKey()==key&&(mods&c.bind.getMods())==c.bind.getMods()){State s=state(c);if(!s.ready||!s.binding.equals(c.bind.serialize()))update(c,System.nanoTime(),false);serial++;}}
 public static void mouse(int button,int action,int mods){key(-100-button,action,mods);}
 public static void tick(AutoClicker c){update(c,System.nanoTime(),false);}
 public static void frame(){AutoClicker c=owner();if(c!=null&&c.isEnabled())update(c,System.nanoTime(),true);}
 private static void stop(State s,boolean pressed){s.running=false;s.wasPressed=pressed;s.next=0;s.seen=serial;}
 public static void disable(AutoClicker c){State s=STATES.remove(c);if(s!=null)stop(s,false);}
 public static int cpsAt(AutoClicker c,long now){State s=STATES.get(c);if(s==null)return 0;s.prune(now);return s.size;}
 public static boolean running(AutoClicker c){State s=STATES.get(c);return s!=null&&s.running;}public static int cps(AutoClicker c){State s=STATES.get(c);if(s==null)return 0;s.prune(System.nanoTime());return s.size;}
 public static void update(AutoClicker c,long now,boolean emit){State s=state(c);class_310 mc=class_310.method_1551();boolean pressed=!c.bind.isListening()&&c.bind.isPressed(true);String binding=c.bind.serialize(),mode=c.mode.getValue(),button=c.button.getValue();boolean changed=!s.ready||s.world!=mc.field_1687||s.player!=mc.field_1724||!s.binding.equals(binding)||!s.mode.equals(mode)||!s.button.equals(button);if(changed){stop(s,pressed);s.world=mc.field_1687;s.player=mc.field_1724;s.binding=binding;s.mode=mode;s.button=button;s.ready=true;s.size=s.head=0;}
  if(!c.isEnabled()||!allowed(c)||c.bind.isListening()){stop(s,pressed);return;}long edges=serial-s.seen;s.seen=serial;if(c.mode.is("Segurar"))s.running=pressed;else if((edges&1)!=0||(edges==0&&pressed&&!s.wasPressed))s.running=!s.running;s.wasPressed=pressed;
  if(!s.running||ClientData.usingConsumable()){s.next=0;return;}if(!emit||now<s.next)return;
  int b=c.button.is("Direito")?1:c.button.is("Meio")?2:0;boolean held=Keys.isMouseDown(b);int mods=Keys.modifiers();boolean restore=false;synthetic++;try{if(held){ClientData.mouseInput(b,0,mods);restore=true;ClientData.mouseInput(b,1,mods);restore=false;}else{restore=true;ClientData.mouseInput(b,1,mods);}s.add(now);}catch(RuntimeException error){stop(s,pressed);System.err.println("[DuckClientZ] AutoClicker interrompido: "+error.getClass().getSimpleName());}finally{try{if(restore)ClientData.mouseInput(b,held?1:0,mods);}catch(RuntimeException error){stop(s,pressed);}finally{synthetic--;}}
  double speed=Math.max(1,Math.min(15,c.cps.getValue())),variation=Math.max(0,Math.min(.5,c.jitter.getValue()));speed=Math.max(1,Math.min(15,speed*(1+(ThreadLocalRandom.current().nextDouble()-.5)*variation)));long interval=(long)Math.ceil(1_000_000_000/speed);if(s.next==0||now-s.next>interval*2)s.next=now;s.next+=interval;
 }
 public static void mouseSound(boolean right){AutoClicker c=owner();if(!synthetic()||c!=null&&c.sound.getValue())com.duckswords.util.UiSound.mouse(right);}
}
