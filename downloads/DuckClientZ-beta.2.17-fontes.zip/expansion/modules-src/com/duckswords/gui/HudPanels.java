package com.duckswords.gui;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.modules.JaulaCooldown;import net.minecraft.*;import java.util.*;
public final class HudPanels {
 private record Options(BooleanSetting enabled,ColorSetting color){}private static final IdentityHashMap<Module,Options> OPTIONS=new IdentityHashMap<>();private static final ThreadLocal<Deque<Module>> ACTIVE=ThreadLocal.withInitial(ArrayDeque::new);
 public interface Visibility {boolean duck$hudVisible();}
 public static boolean category(com.duckswords.module.Category category,String name){return category==com.duckswords.module.Category.HUD||name.equals("AutoClicker");}
 public static void attach(Module m){if((m.getCategory()!=Category.HUD&&!m.getName().equals("AutoClicker"))||OPTIONS.containsKey(m))return;BooleanSetting on=new BooleanSetting("Ativar fundo","Mostra um painel escuro atras deste HUD",false);ColorSetting color=new ColorSetting("Cor do fundo HUD","Cor e opacidade do fundo opcional",0xb5141820);m.getSettings().add(on);m.getSettings().add(color);OPTIONS.put(m,new Options(on,color));}
 public static boolean visible(Module m){if(class_310.method_1551().field_1724==null)return false;if(m instanceof com.duckswords.modules.AutoClicker auto&&!auto.hud.getValue())return false;if(m instanceof JaulaCooldown cage)return cage.activeCount()>0;return !(m instanceof Visibility v)||v.duck$hudVisible();}
 public static void begin(Module m,class_332 c){ACTIVE.get().addLast(m);Options o=OPTIONS.get(m);if(o==null||!o.enabled.getValue()||!visible(m)||m.hudX()==null||m.hudY()==null)return;int x=m.hudX().getInt(),y=m.hudY().getInt();c.method_25294(x-3,y-3,x+m.hudWidthScaled()+3,y+m.hudHeightScaled()+3,o.color.getValue());}
 public static void end(){Deque<Module> stack=ACTIVE.get();if(!stack.isEmpty())stack.removeLast();}
 public static int color(ColorSetting setting){if(!ACTIVE.get().isEmpty()&&(setting.getName().equals("Fundo")||setting.getName().equals("Cor do fundo")))return setting.getDisplayValue()&0xffffff;return setting.getDisplayValue();}
}
