package com.duckswords.camera;
import com.duckswords.module.Module;import com.duckswords.setting.*;import com.duckswords.client.ClientData;import java.util.*;
public final class CameraOptions {
 private record Options(BooleanSetting lock,BooleanSetting scroll){}private static final IdentityHashMap<Module,Options> ALL=new IdentityHashMap<>();
 public static void attach(Module m){BooleanSetting lock=null;for(Setting<?> s:m.getSettings())if(s instanceof BooleanSetting b&&s.getName().startsWith("Travar"))lock=b;if(lock==null){lock=new BooleanSetting("Travar cabeca","Ligado gira somente a camera; desligado a cabeca acompanha",true);m.getSettings().add(lock);}BooleanSetting scroll=new BooleanSetting("Zoom com rolagem","Permite aproximar e afastar a camera com a roda do mouse",true);m.getSettings().add(scroll);ALL.put(m,new Options(lock,scroll));}
 public static boolean locked(Module m){Options o=ALL.get(m);return o==null||o.lock.getValue();}public static boolean scrolling(Module m){Options o=ALL.get(m);return o==null||o.scroll.getValue();}
 public static float yaw(Module m,float fallback){return locked(m)||net.minecraft.class_310.method_1551().field_1724==null?fallback:ClientData.playerYaw();}public static float pitch(Module m,float fallback){return locked(m)||net.minecraft.class_310.method_1551().field_1724==null?fallback:ClientData.playerPitch();}
}
