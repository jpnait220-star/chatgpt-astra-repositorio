package com.duckswords.particles;
import net.fabricmc.api.*;import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.*;import java.util.*;import com.duckswords.modules.Visuals;
public final class VisualParticles implements ModInitializer,ClientModInitializer{
 public static final String[] SHAPES={"Estrelas","Coracoes","Brilho","Espadas","Neve","Vagalumes","Classico","Marcador"};
 public static final String[] KEYS={"star","heart","bloom","sword","snowflake","firefly","classic","capture"};
 private static final long START=System.nanoTime();
 private static final Map<String,class_2400> TYPES=new LinkedHashMap<>();private static Object world;private static int live;
 public void onInitialize(){if(!TYPES.isEmpty())return;for(String key:KEYS)for(String channel:List.of("hit_","ambient_","target_")){String name="visual_"+channel+key;class_2400 type=FabricParticleTypes.simple();ParticleBridge.register(name,type);TYPES.put(name,type);}}
 public void onInitializeClient(){for(var entry:TYPES.entrySet()){int channel=entry.getKey().contains("ambient_")?1:entry.getKey().contains("target_")?2:0;ParticleFactoryRegistry.getInstance().register(entry.getValue(),provider->new VisualParticleFactory(provider,channel));}}
 public static void cleared(){world=null;live=0;Visuals v=Visuals.current();if(v!=null)v.particlesCleared();}
 public static void reset(Object current){if(world!=current){world=current;live=0;}}
 public static void created(Object current){reset(current);live++;}
 public static void died(Object current){if(world==current&&live>0)live--;}
 public static boolean capacity(){return live<160;}
 public static int live(){return live;}
 public static class_2400 type(String shape,boolean ambient){return type(shape,ambient?1:0);}
 public static class_2400 type(String shape,int channel){int index=switch(shape){case "Coracoes"->1;case "Brilho"->2;case "Espadas"->3;case "Neve"->4;case "Vagalumes"->5;case "Classico"->6;case "Marcador"->7;default->0;};return TYPES.get("visual_"+(channel==1?"ambient_":channel==2?"target_":"hit_")+KEYS[Math.max(0,index)]);}
 public static double position(class_1297 e,int axis,double offset,float spin){double base=axis==0?e.method_23317():axis==1?e.method_23318():e.method_23321();if(spin==0)return base+offset;if(axis==1)return base+1.15;class_1297 player=class_310.method_1551().field_1724;if(player==null)return base;double dx=player.method_23317()-e.method_23317(),dz=player.method_23321()-e.method_23321(),d=Math.sqrt(dx*dx+dz*dz);return d<.001?base:base+(axis==0?dx:dz)/d*.38;}
 public static boolean keepMarker(class_1297 entity){Visuals v=Visuals.current();return v!=null&&v.isEnabled()&&v.targetStyle.is("Legacy")&&v.target()==entity&&entity!=null&&entity.method_5805();}
 public static boolean spawn(class_2394 type,double x,double y,double z,double vx,double vy,double vz){class_310 mc=class_310.method_1551();return mc.field_1687!=null&&mc.field_1713!=null&&com.duckswords.perf.ParticleBudget.allow(x,y,z)&&mc.field_1713.method_3056(type,x,y,z,vx,vy,vz)!=null;}
 public static int color(int channel){Visuals v=Visuals.current();return v==null?-1:(channel==2?v.targetColor:channel==1?v.ambientColor:v.hitColor).getValue();}
 public static float size(int channel){Visuals v=Visuals.current();return v==null?.15f:channel==2?(v.targetStyle.is("Legacy")?v.targetSize.getFloat():.14f*v.targetSize.getFloat()):(channel==1?v.ambientSize:v.hitSize).getFloat();}
 public static int life(int channel){Visuals v=Visuals.current();return v==null?30:channel==2?(v.targetStyle.is("Legacy")?2:6):(channel==1?v.ambientLife:v.hitLife).getInt();}
 public static boolean physics(int channel){Visuals v=Visuals.current();return channel==0&&v!=null&&v.physics.getValue();}
 public static class_1297 anchor(int channel){Visuals v=Visuals.current();return channel==2&&v!=null?v.target():null;}
 public static float spin(int channel){Visuals v=Visuals.current();return channel==2&&v!=null&&v.targetStyle.is("Legacy")?.1f*v.targetSpeed.getFloat():0;}
 public static float rotation(){Visuals v=Visuals.current();return (float)((System.nanoTime()-START)*1e-9*2*(v==null?1:v.targetSpeed.getValue()));}
 public static boolean bright(){Visuals v=Visuals.current();return v==null||v.style.is("ModernDuck");}
}
