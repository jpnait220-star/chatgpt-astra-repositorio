package com.duckswords.cosmetic;
import java.util.*;
/** Stable profile/network identifiers, loaded lazily by the model renderer. */
public final class CosmeticCatalog222 {
 private static final Map<String,String> LABELS=Map.ofEntries(
  Map.entry("cyberpunkLEDMask","Máscara LED"),
  Map.entry("cyberpunkOniMask","Máscara Oni"),
  Map.entry("fall2025OwlMask","Máscara de coruja"),
  Map.entry("halloween2024FrankensteinMask","Máscara Frankenstein"),
  Map.entry("summer2024GasMask","Máscara de gás"),
  Map.entry("cloudMask","Máscara de nuvem"),
  Map.entry("spaceMask","Máscara espacial"),
  Map.entry("angelGloves","Punhos angelicais"),
  Map.entry("cyberNinjaGloves","Punhos cyber ninja"),
  Map.entry("dragonFestivalGloves","Punhos do dragão"),
  Map.entry("knightGloves","Punhos de cavaleiro"),
  Map.entry("natureGloves","Punhos da natureza"),
  Map.entry("voidGloves","Punhos do vazio"),
  Map.entry("gamerRGBFists","Punhos RGB"),
  Map.entry("spaceAura","Aura espacial"),
  Map.entry("jan2025BlackHoleAura","Aura de buraco negro"),
  Map.entry("jan2025SolarSystemAura","Aura do sistema solar"),
  Map.entry("cloudAura","Aura de nuvens"),
  Map.entry("flameFragsFireRing","Aura de fogo"),
  Map.entry("spring2025RainbowAura","Aura de arco-íris"),
  Map.entry("hellLordAura","Aura infernal"),
  Map.entry("springKatana","Katana nas costas"),
  Map.entry("springShield","Escudo nas costas"),
  Map.entry("springLeatherBackpack","Mochila de couro"),
  Map.entry("springTurtleShell","Casco de tartaruga"),
  Map.entry("summer2024Surfboard","Prancha de surfe"),
  Map.entry("demon2024DemonScythe","Foice demoníaca"),
  Map.entry("summer2024FishingRod","Vara de pesca")
 );
 public static final List<String> IDS=List.of("cyberpunkLEDMask","cyberpunkOniMask","fall2025OwlMask","halloween2024FrankensteinMask","summer2024GasMask","cloudMask","spaceMask","angelGloves","cyberNinjaGloves","dragonFestivalGloves","knightGloves","natureGloves","voidGloves","gamerRGBFists","spaceAura","jan2025BlackHoleAura","jan2025SolarSystemAura","cloudAura","flameFragsFireRing","spring2025RainbowAura","hellLordAura","springKatana","springShield","springLeatherBackpack","springTurtleShell","summer2024Surfboard","demon2024DemonScythe","summer2024FishingRod");
 public static List<String> extend(List<String> original){List<String> all=new ArrayList<>(original);all.addAll(IDS);return List.copyOf(all);}
 public static String label(String id){return LABELS.get(id);}
 public static String description(String id){return LABELS.containsKey(id)?"Modelo original do pacote enviado; texturas e animações preservadas":null;}
}
