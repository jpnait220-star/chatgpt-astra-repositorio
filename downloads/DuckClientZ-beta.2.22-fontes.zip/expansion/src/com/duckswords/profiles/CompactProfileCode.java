package com.duckswords.profiles;
import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
/** Frozen-base, indexed-path deltas. Neither clipboard nor disk is changed until validation succeeds. */
public final class CompactProfileCode {
 private static final int LIMIT=262144;
 private static final String PREFIX="DZ3:";
 private record Base(String id,JsonElement json,List<List<String>> paths,Map<List<String>,Integer> index){}
 private static final List<Base> BASES=loadBases();
 private static List<Base> loadBases(){
  List<Base> result=new ArrayList<>();
  for(String id:List.of("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z")){
   try(InputStream in=CompactProfileCode.class.getResourceAsStream("/assets/duckswords/profiles/v3/"+id+".json")){
    if(in==null)throw new IOException("Missing profile schema "+id);
    JsonElement json=JsonParser.parseString(new String(in.readAllBytes(),StandardCharsets.UTF_8));
    List<List<String>> paths=new ArrayList<>();enumerate(json,List.of(),paths);Map<List<String>,Integer> index=new HashMap<>();
    for(int i=0;i<paths.size();i++)index.put(paths.get(i),i);result.add(new Base(id,json,List.copyOf(paths),Map.copyOf(index)));
   }catch(IOException ex){throw new ExceptionInInitializerError(ex);}
  }return List.copyOf(result);
 }
 private static void enumerate(JsonElement e,List<String> path,List<List<String>> out){
  out.add(path);if(e.isJsonObject())for(String k:new TreeSet<>(e.getAsJsonObject().keySet())){List<String> p=new ArrayList<>(path);p.add(k);enumerate(e.getAsJsonObject().get(k),List.copyOf(p),out);}
 }
 private static JsonElement path(Base b,List<String> p){Integer id=b.index.get(p);if(id!=null)return new JsonPrimitive(id);JsonArray a=new JsonArray();p.forEach(a::add);return a;}
 private static void diff(Base b,JsonElement before,JsonElement after,List<String> p,JsonArray ops){
  if(before.equals(after))return;
  if(before.isJsonObject()&&after.isJsonObject()){
   JsonObject old=before.getAsJsonObject(),value=after.getAsJsonObject();
   for(String k:new TreeSet<>(old.keySet()))if(!value.has(k)){List<String> q=new ArrayList<>(p);q.add(k);JsonArray op=new JsonArray();op.add(path(b,q));ops.add(op);}
   for(String k:new TreeSet<>(value.keySet())){List<String> q=new ArrayList<>(p);q.add(k);if(old.has(k))diff(b,old.get(k),value.get(k),q,ops);else{JsonArray op=new JsonArray();op.add(path(b,q));op.add(value.get(k).deepCopy());ops.add(op);}}
  }else{JsonArray op=new JsonArray();op.add(path(b,p));op.add(after.deepCopy());ops.add(op);}
 }
 public static String legacyDefault(){for(Base base:BASES)if(base.id.equals("c"))return base.json.toString();throw new IllegalStateException("Missing immutable V2 profile base");}
 public static String encodeV3(String json)throws IOException{
  if(json==null||json.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");
  JsonElement target=JsonParser.parseString(json);if(!target.isJsonObject())throw new IOException("Perfil invalido");String best=null;
  for(Base b:BASES){JsonArray ops=new JsonArray();diff(b,b.json,target,List.of(),ops);Deflater deflater=new Deflater(9,true);ByteArrayOutputStream output=new ByteArrayOutputStream();
   try(DeflaterOutputStream stream=new DeflaterOutputStream(output,deflater)){stream.write(ops.toString().getBytes(StandardCharsets.UTF_8));}finally{deflater.end();}
   String code=PREFIX+b.id+":"+Base64.getUrlEncoder().withoutPadding().encodeToString(output.toByteArray());if(best==null||code.length()<best.length())best=code;
  }return best;
 }
 public static boolean accepts(String code){return code!=null&&(code.strip().startsWith(PREFIX)||code.strip().startsWith("D4:")||code.strip().startsWith("D5:"));}
 private static String decodeV3(String code)throws IOException{
  if(code==null||code.length()>LIMIT)throw new IOException("Codigo invalido");code=code.strip();String[] pieces=code.split(":",3);if(pieces.length!=3||!pieces[0].equals("DZ3"))throw new IOException("Codigo invalido");
  Base b=BASES.stream().filter(v->v.id.equals(pieces[1])).findFirst().orElseThrow(()->new IOException("Versao do perfil desconhecida"));
  byte[] bytes;try{bytes=Base64.getUrlDecoder().decode(pieces[2]);}catch(IllegalArgumentException e){throw new IOException("Codigo invalido",e);}
  Inflater inflater=new Inflater(true);ByteArrayOutputStream output=new ByteArrayOutputStream();
  try(InflaterInputStream stream=new InflaterInputStream(new ByteArrayInputStream(bytes),inflater)){
   byte[] buffer=new byte[4096];int n;while((n=stream.read(buffer))!=-1){if(output.size()+n>LIMIT)throw new IOException("Perfil excede o limite");output.write(buffer,0,n);}
  }finally{inflater.end();}
  try{
   JsonArray ops=JsonParser.parseString(output.toString(StandardCharsets.UTF_8)).getAsJsonArray();JsonElement result=b.json.deepCopy();
   for(JsonElement e:ops){JsonArray op=e.getAsJsonArray();if(op.size()<1||op.size()>2)throw new IllegalArgumentException();List<String> p=new ArrayList<>();JsonElement raw=op.get(0);
    if(raw.isJsonPrimitive()&&raw.getAsJsonPrimitive().isNumber()){int id=raw.getAsInt();if(id<0||id>=b.paths.size())throw new IllegalArgumentException();p.addAll(b.paths.get(id));}
    else for(JsonElement k:raw.getAsJsonArray()){if(!k.isJsonPrimitive()||!k.getAsJsonPrimitive().isString())throw new IllegalArgumentException();p.add(k.getAsString());}
    if(p.size()>64)throw new IllegalArgumentException();if(p.isEmpty()){if(op.size()!=2||!op.get(1).isJsonObject())throw new IllegalArgumentException();result=op.get(1).deepCopy();continue;}
    JsonObject parent=result.getAsJsonObject();for(int i=0;i<p.size()-1;i++)parent=parent.getAsJsonObject(p.get(i));String key=p.get(p.size()-1);if(op.size()==1)parent.remove(key);else parent.add(key,op.get(1).deepCopy());
   }String decoded=result.toString();if(decoded.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");return decoded;
  }catch(RuntimeException ex){throw new IOException("Conteudo do perfil invalido",ex);}
 } public static String encodeV4(String json)throws IOException{
  if(json==null||json.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");JsonElement target=JsonParser.parseString(json);if(!target.isJsonObject())throw new IOException("Perfil invalido");String best=null;
  for(Base b:BASES){JsonArray ops=new JsonArray();diff(b,b.json,target,List.of(),ops);if(ops.isEmpty())return "D4:"+b.id;ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(DataOutputStream data=new DataOutputStream(bytes)){varint(data,ops.size());for(JsonElement e:ops){JsonArray op=e.getAsJsonArray();JsonElement p=op.get(0);if(p.isJsonPrimitive())varint(data,p.getAsInt()+1);else{varint(data,0);varint(data,p.getAsJsonArray().size());for(JsonElement k:p.getAsJsonArray())string(data,k.getAsString());}data.writeBoolean(op.size()==2);if(op.size()==2)value(data,op.get(1));}}
   byte[] raw=bytes.toByteArray();Deflater deflater=new Deflater(9,true);ByteArrayOutputStream compressed=new ByteArrayOutputStream();try(DeflaterOutputStream stream=new DeflaterOutputStream(compressed,deflater)){stream.write(raw);}finally{deflater.end();}byte[] small=compressed.toByteArray();boolean zip=small.length<raw.length;ByteArrayOutputStream wire=new ByteArrayOutputStream();wire.write(zip?1:0);wire.write(zip?small:raw);CRC32 crc=new CRC32();crc.update(raw);try(DataOutputStream out=new DataOutputStream(wire)){out.writeInt((int)crc.getValue());}String code="D4:"+b.id+":"+Base64.getUrlEncoder().withoutPadding().encodeToString(wire.toByteArray());if(best==null||code.length()<best.length())best=code;
   Deflater legacyDeflate=new Deflater(9,true);ByteArrayOutputStream legacyBytes=new ByteArrayOutputStream();try(DeflaterOutputStream stream=new DeflaterOutputStream(legacyBytes,legacyDeflate)){stream.write(ops.toString().getBytes(StandardCharsets.UTF_8));}finally{legacyDeflate.end();}String legacy=PREFIX+b.id+":"+Base64.getUrlEncoder().withoutPadding().encodeToString(legacyBytes.toByteArray());if(legacy.length()<best.length())best=legacy;
  }return best;
 }
 private static void varint(DataOutputStream out,long n)throws IOException{do{int b=(int)n&127;n>>>=7;out.writeByte(n==0?b:b|128);}while(n!=0);}
 private static long varint(DataInputStream in)throws IOException{long n=0;for(int i=0;i<10;i++){int b=in.readUnsignedByte();if(i==9&&(b&254)!=0)throw new IOException("Varint invalido");n|=(long)(b&127)<<(i*7);if((b&128)==0)return n;}throw new IOException("Varint invalido");}
 private static int count(DataInputStream in,int max)throws IOException{long n=varint(in);if(n<0||n>max)throw new IOException("Limite do perfil");return (int)n;}
 private static void string(DataOutputStream out,String text)throws IOException{byte[] bytes=text.getBytes(StandardCharsets.UTF_8);varint(out,bytes.length);out.write(bytes);}
 private static String string(DataInputStream in)throws IOException{int n=count(in,LIMIT);byte[] bytes=in.readNBytes(n);if(bytes.length!=n)throw new EOFException();return new String(bytes,StandardCharsets.UTF_8);}
 private static void value(DataOutputStream out,JsonElement value)throws IOException{if(value.isJsonNull()){out.writeByte(0);return;}if(value.isJsonPrimitive()){JsonPrimitive p=value.getAsJsonPrimitive();if(p.isBoolean()){out.writeByte(p.getAsBoolean()?2:1);return;}if(p.isString()){out.writeByte(5);string(out,p.getAsString());return;}try{long n=Long.parseLong(p.getAsString());out.writeByte(3);varint(out,(n<<1)^(n>>63));return;}catch(NumberFormatException ignored){}double d=p.getAsDouble();if(Double.isFinite(d)&&new java.math.BigDecimal(p.getAsString()).compareTo(new java.math.BigDecimal(Double.toString(d)))==0){out.writeByte(4);out.writeDouble(d);return;}out.writeByte(7);string(out,p.getAsString());return;}out.writeByte(6);string(out,value.toString());}
 private static JsonElement value(DataInputStream in)throws IOException{return switch(in.readUnsignedByte()){case 0->JsonNull.INSTANCE;case 1->new JsonPrimitive(false);case 2->new JsonPrimitive(true);case 3->{long n=varint(in);yield new JsonPrimitive((n>>>1)^-(n&1));}case 4->{double d=in.readDouble();if(!Double.isFinite(d))throw new IOException("Numero invalido");yield new JsonPrimitive(d);}case 5->new JsonPrimitive(string(in));case 6->JsonParser.parseString(string(in));case 7->new JsonPrimitive(new java.math.BigDecimal(string(in)));default->throw new IOException("Tipo invalido");};}
 public static String decodeV4(String code)throws IOException{if(code==null||code.length()>LIMIT)throw new IOException("Codigo invalido");code=code.strip();if(!code.startsWith("D4:"))return decodeV3(code);String[] parts=code.split(":",-1);if(parts.length<2||parts.length>3)throw new IOException("Codigo invalido");Base b=BASES.stream().filter(v->v.id.equals(parts[1])).findFirst().orElseThrow(()->new IOException("Versao do perfil desconhecida"));if(parts.length==2)return b.json.toString();
  try{byte[] wire=Base64.getUrlDecoder().decode(parts[2]);if(wire.length<6||wire[0]<0||wire[0]>1)throw new IOException("Codigo invalido");byte[] payload=Arrays.copyOfRange(wire,1,wire.length-4);if(wire[0]==1){Inflater inflater=new Inflater(true);try(InflaterInputStream in=new InflaterInputStream(new ByteArrayInputStream(payload),inflater);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){if(out.size()+n>LIMIT)throw new IOException("Perfil excede o limite");out.write(buf,0,n);}payload=out.toByteArray();}finally{inflater.end();}}CRC32 crc=new CRC32();crc.update(payload);int expected=new DataInputStream(new ByteArrayInputStream(wire,wire.length-4,4)).readInt();if(expected!=(int)crc.getValue())throw new IOException("Codigo incompleto ou alterado");JsonElement result=b.json.deepCopy();try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(payload))){int total=count(in,LIMIT);for(int j=0;j<total;j++){int id=count(in,b.paths.size());List<String> p;if(id==0){List<String> dynamic=new ArrayList<>();int depth=count(in,64);for(int k=0;k<depth;k++)dynamic.add(string(in));p=dynamic;}else p=b.paths.get(id-1);boolean set=in.readBoolean();JsonElement v=set?value(in):null;if(p.isEmpty()){if(!set||!v.isJsonObject())throw new IOException("Raiz invalida");result=v;continue;}JsonObject parent=result.getAsJsonObject();for(int k=0;k<p.size()-1;k++)parent=parent.getAsJsonObject(p.get(k));if(set)parent.add(p.get(p.size()-1),v);else parent.remove(p.get(p.size()-1));}if(in.read()!=-1)throw new IOException("Dados extras");}String json=result.toString();if(json.getBytes(StandardCharsets.UTF_8).length>LIMIT)throw new IOException("Perfil excede o limite");return json;}catch(RuntimeException e){throw new IOException("Conteudo do perfil invalido",e);}
 }

 public static String encode(String json)throws IOException{return ProfileCode222.encode(json);}
 public static String decode(String code)throws IOException{return code!=null&&code.strip().startsWith("D5:")?ProfileCode222.decode(code.strip()):decodeV4(code);}
}
