package com.duckswords.render;
import org.joml.Vector3f;import org.joml.Vector4f;
/** Only for Duck world geometry; matrix math is copied from each native game API. */
public final class WorldVertex237 {
 private static final class Scratch{final Vector3f three=new Vector3f();final Vector4f four=new Vector4f();}
 private static final ThreadLocal<Scratch> SCRATCH=ThreadLocal.withInitial(Scratch::new);
 public static Vector3f vector3(){return SCRATCH.get().three.zero();}public static Vector4f vector4(){return SCRATCH.get().four.zero();}
}
