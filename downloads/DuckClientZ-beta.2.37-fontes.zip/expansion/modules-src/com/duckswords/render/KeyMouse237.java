package com.duckswords.render;
import net.minecraft.class_332;import java.util.*;
/** Exact solid rectangles, merged only across adjacent rows with identical insets. */
public final class KeyMouse237 {
 public interface View {int duck$mouseScale237();int duck$mouseInset237(int row,int width,int height);}
 private record Key(int width,int height,int scale){}private record Run(int y,int height,int inset){}
 private static final Map<View,Map<Key,List<Run>>> CACHE=new WeakHashMap<>();
 private static List<Run> runs(View view,int w,int h){Map<Key,List<Run>> cache=CACHE.computeIfAbsent(view,k->new LinkedHashMap<>());Key key=new Key(w,h,view.duck$mouseScale237());List<Run> runs=cache.get(key);if(runs!=null)return runs;ArrayList<Run> result=new ArrayList<>();int first=0,inset=view.duck$mouseInset237(0,w,h);for(int y=1;y<h;y++){int next=view.duck$mouseInset237(y,w,h);if(next!=inset){result.add(new Run(first,y-first,inset));first=y;inset=next;}}result.add(new Run(first,h-first,inset));runs=List.copyOf(result);if(cache.size()>=96)cache.clear();cache.put(key,runs);return runs;}
 public static void fill(View view,class_332 c,int x,int y,int w,int h,int color){if(w<=0||h<=0)return;for(Run r:runs(view,w,h))if(w>2*r.inset)c.method_25294(x+r.inset,y+r.y,x+w-r.inset,y+r.y+r.height,color);}
 public static void border(View view,class_332 c,int x,int y,int w,int h,int color){if(h<=0)return;List<Run> runs=runs(view,w,h);for(Run r:runs){c.method_25294(x+r.inset,y+r.y,x+r.inset+1,y+r.y+r.height,color);c.method_25294(x+w-r.inset-1,y+r.y,x+w-r.inset,y+r.y+r.height,color);}int top=runs.get(0).inset,bottom=runs.get(runs.size()-1).inset;c.method_25294(x+top,y,x+w-top,y+1,color);c.method_25294(x+bottom,y+h-1,x+w-bottom,y+h,color);}
}
