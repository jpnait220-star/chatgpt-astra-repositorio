# beta.2.37
User reports severe sustained gameplay cost near players/cosmetics, HUDs/HitRange
also cost FPS. Requests all4 versions and speed because weekly budget10% remains.
No subagents. Latest artifact236; no candidate236 rollback required: menu closed,
world code unchanged since234. Keep menu caches and validated dynamic settings.

User supplied local CPU capture (do not package raw upload). Confirmed MC1.21.4.
HUD total2.12584ms/frame, FullKeystrokes0.78231, Inventory0.65078, Vida0.44270;
world Duck0.03796; cosmetic preparation0.00297,0 Sodium batches/no fallback types.
Capture includes174 menu frames out of1466. No GPU measurement, cannot dismiss
near-player GPU cost or claim actual FPS gain. Prioritize actual CPU leaders.

Changes: exact solid row-run caches for Keystrokes rounded mouse fill/border;
older3 MinecraftCompat.drawPlayerSkin->native GuiFace.raw and drawItemCount->
native renderItemDecorations (native11 already direct). World vertex emitters copy
each native VertexConsumer matrix-position body but replace one newVector3/4 per
vertex with thread-local scratch consumed as primitives before consumer callback.
HitRange/circle mesh/camera/segments untouched. Optional Sodium custom geometry
batches span marked model parts and children; bounded4096 vertex state. Consumer
identity scopes borrow/release, direct tint fallback flushes pending order, push
reentrancy isolates state; per-cube cachedState removes per-vertex ThreadLocal.
Default unsupported/noSodium path retained. Report prefix adds client/MC version.
Review all module sources/shared paths, do not claim changed every module or
solved all lag. NativeInventory item pipeline stays live; no unsafe FBO/caching
that would freeze durability/glint/cooldown or change resource-pack appearance.

Validate all4 final artifacts/MC API/mixins, old-vs-new solid HUD pixels, native
world vertex semantics, actual Sodium API data/chunks/tint/fallback/cleanup and
signed updater. Publish immutable237 only after passing; verify downloads and
production manifest exactly; no unsolicited chat/cloud announcement.

Reviewed decompiled module set: AutoClicker, BlockOverlay, Cleaner, ClickSounds, ClockHud, ColorFilters, ComboCounter, CoordsHud, CosmeticsOnline, CpsDisplay, CritEffects, CrosshairEditor, CustomGlint, CustomKills, DirectionHud, ElytraFeature, EnderChestViewer, FireworkKey, FixOptimizer, FpsHud, Fullbright, HealthBar, HealthHud, HitColor, HitMarker, HitParticles, HitRange, HitSound, InventoryHud, JumpParticles, KeystrokesHud, KillEffect, KillEffectScale, KillFeed, KillIntro, KillMessage, LightningKill, LowHealthAlert, MouseIcon, NoBlockShading, NoHurtCam, Performance, PotionHud, ReachTrail, RecordingCamera, ScoreboardPosition, SessionTimer, SprintKeeper, Swing, TargetHighlight, TargetHud, TextHud, TotemFeature, TwoDItems, ViewModel, VisualRatio, Visuals, Watermark. Shared code changes targeted actual CPU profile, not a claim of changing every module.
