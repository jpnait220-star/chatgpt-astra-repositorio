# beta.2.36
User: optimize feature menu further; asks whether icons might cause FPS loss.
Confirmed repeated per-frame icon name normalization/regex/Identifier allocation
and repeated text trimming. Implement bounded lookup/uppercase/trim caches with
locale/font/reload invalidation, reusable fixed icon IDs, shared original-pixel
atlas with extruded gutters and resource-pack identity fallback per icon. Atlas
retains source pixels/dimensions; no icon removed/downsampled;1 quad/icon remains.
Native1.21.11 has no Icons.draw: its GUI_TEXTURED full-image calls use a new thin
bridge, preserving original pipeline/cropped draw when not a full mapped icon.

Static menu panel fill/stroke masks use3 horizontal slices per layer,15->6
submissions for common heights80/17/16/26/18. Same half-pixel coverage, colors,
alpha and layer order; other sizes/unsupported contexts use previous path.
Per-event expanded-settings snapshots; native render/input/layout/opening bytecode
comparison allows only cache-call substitutions and native texture bridge.
Local /duckperf includes CPU Menu: features, no automatic capture/network.
Preserve234 updates and preferences, no new defaults migration, no FPS promise.
No actual Minecraft/GPU/Pojav/Dawn run. Validate final artifacts, pixels, APIs,
startup mixins, HUD and signed updater before publication. Never overwrite old
immutable filenames; fixed update manifest is the only mutable artifact.

Publication correction:235 briefly published, then fixed update manifest held at234.
Final review caught snapshots passed to persistent SettingsScreen, which froze
mode-dependent visibility and hidden-setting reset. Restricted snapshot replacement
to render/extraHeight/updateSetting only. Input handlers pass original dynamic
VisibleSettings.View. Added structural regression guard against snapshot escape.
236 supersedes candidate235 without overwriting its immutable public files.
