package com.duckswords.perf;
import com.duckswords.module.Module;import com.duckswords.setting.*;import net.minecraft.*;import java.util.*;
/** Client drawing limits only. No entity ticking, packets or server simulation are changed. */
public final class GamePerformance {
 private record Options(BooleanSetting entities,NumberSetting items,NumberSetting mobs,NumberSetting players,BooleanSetting particles,NumberSetting distance,NumberSetting budget,BooleanSetting shadows,BooleanSetting weather,BooleanSetting names,NumberSetting nameRange,BooleanSetting blocks,NumberSetting blockRange,BooleanSetting itemCopies){}
 private static final IdentityHashMap<Module,Options> OPTIONS=new IdentityHashMap<>();
 public static volatile boolean entitiesActive,particlesActive,shadowsActive,weatherActive,namesActive,blocksActive,itemsActive;
 private static double itemSquared=1024,mobSquared=4096,playerSquared=16384,particleSquared=576,nameSquared=1024,blockSquared=4096;private static int maximum=512,tick=Integer.MIN_VALUE,used;private static Object world;
 private static <T extends Setting<?>>T add(Module m,T s){m.getSettings().add(s);return s;}
 private static BooleanSetting flag(Module m,String name,String detail){return add(m,new BooleanSetting(name,detail,false));}
 private static NumberSetting range(Module m,String name,int value){return add(m,new NumberSetting(name,"Distancia de desenho em blocos; nao altera o servidor",value,8,256,8));}
 public static void attach(Module m){ScenePerformance.attach(m);ExtendedPerformance.attach(m);if(OPTIONS.containsKey(m))return;OPTIONS.put(m,new Options(
  flag(m,"Limitar entidades distantes","Oculta apenas o desenho de entidades alem do alcance escolhido"),range(m,"Alcance de itens no chao",32),range(m,"Alcance de criaturas",64),range(m,"Alcance de jogadores",128),
  flag(m,"Limitar particulas do jogo","Limita novas particulas vanilla/mods; reduz detalhes quando atinge o limite"),range(m,"Alcance das particulas do jogo",24),add(m,new NumberSetting("Particulas do jogo por tick","Maximo de novas particulas por tick",512,32,4096,32)),
  flag(m,"Desativar sombras de entidades","Evita desenhar sombras de entidades; nao altera luz do mundo"),
  flag(m,"Ocultar chuva e neve","Evita desenhar precipitacao; clima e regras do servidor permanecem iguais"),
  flag(m,"Limitar nomes distantes","Evita desenhar nomes de entidades distantes"),range(m,"Alcance dos nomes",32),
  flag(m,"Limitar blocos especiais distantes","Evita renderizar block entities distantes, como baus e placas; eles continuam funcionando"),range(m,"Alcance dos blocos especiais",32),
  flag(m,"Simplificar pilhas de itens","Desenha uma copia visual por pilha no chao; quantidade real e coleta permanecem iguais")));
 }
 private static double square(double v){return v*v;}
 public static void update(Module m){ScenePerformance.update(m);ExtendedPerformance.update(m);Options o=OPTIONS.get(m);if(o==null)return;boolean on=m.isEnabled();entitiesActive=on&&o.entities.getValue();particlesActive=on&&o.particles.getValue();shadowsActive=on&&o.shadows.getValue();weatherActive=on&&o.weather.getValue();namesActive=on&&o.names.getValue();blocksActive=on&&o.blocks.getValue();itemsActive=on&&o.itemCopies.getValue();itemSquared=square(o.items.getValue());mobSquared=square(o.mobs.getValue());playerSquared=square(o.players.getValue());particleSquared=square(o.distance.getValue());nameSquared=square(o.nameRange.getValue());blockSquared=square(o.blockRange.getValue());maximum=o.budget.getInt();}
 public static void disable(){ScenePerformance.disable();ExtendedPerformance.disable();entitiesActive=particlesActive=shadowsActive=weatherActive=namesActive=blocksActive=itemsActive=false;world=null;used=0;tick=Integer.MIN_VALUE;}
 public static boolean cull(class_1297 e,double x,double y,double z){if(com.duckswords.cleaner.CleanerRuntime.cull(e,x,y,z)||ExtendedPerformance.cull(e,x,y,z))return true;if(!entitiesActive||e==null||e==class_310.method_1551().field_1724)return false;double cap;if(e instanceof class_1542)cap=itemSquared;else if(e instanceof class_1657)cap=playerSquared;else if(e instanceof class_1309)cap=mobSquared;else return false;return squared(e.method_23317()-x,e.method_23318()-y,e.method_23321()-z)>cap;}
 private static double squared(double x,double y,double z){return x*x+y*y+z*z;}
 public static boolean cullName(class_1297 e){class_746 p=class_310.method_1551().field_1724;return namesActive&&p!=null&&e!=null&&e!=p&&squared(e.method_23317()-p.method_23317(),e.method_23318()-p.method_23318(),e.method_23321()-p.method_23321())>nameSquared;}
 public static boolean cullBlock(class_2586 block){if(!blocksActive||block==null)return false;class_746 p=class_310.method_1551().field_1724;if(p==null)return false;class_2338 pos=block.method_11016();return squared(pos.method_10263()+.5-p.method_23317(),pos.method_10264()+.5-p.method_23318(),pos.method_10260()+.5-p.method_23321())>blockSquared;}
 public static int copies(int original){return com.duckswords.cleaner.CleanerRuntime.copies(itemsActive?Math.min(original,1):original);}
 public static boolean dropParticle(double x,double y,double z){if(!particlesActive)return false;class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1687==null)return false;if(world!=mc.field_1687||tick!=mc.field_1724.field_6012){world=mc.field_1687;tick=mc.field_1724.field_6012;used=0;}if(squared(x-mc.field_1724.method_23317(),y-mc.field_1724.method_23318(),z-mc.field_1724.method_23321())>particleSquared||used>=maximum)return true;used++;return false;}
}
