package com.duckswords.cleaner;
import com.duckswords.DucksWordsClient;import com.duckswords.client.ClientData;import com.duckswords.modules.Cleaner;import com.duckswords.particles.VisualParticles;import net.minecraft.*;
/** Reversible draw policy. Never writes GameOptions, HUD positions or client effect settings. */
public final class CleanerRuntime {
 private static final int[] PLAYERS={0,128,96,72,48},ENTITIES={0,96,72,56,40},PARTICLES={0,64,48,36,28},BUDGET={0,768,512,320,192};private static Cleaner owner;private static Object world;private static int tick=Integer.MIN_VALUE,used;private static float yaw=Float.NaN,pitch=Float.NaN;private static double lx,ly,lz;
 public static Cleaner owner(){if(owner==null)owner=DucksWordsClient.MODULES.get(Cleaner.class);return owner;}
 public static int level(){Cleaner c=owner();return c==null||!c.applied.getValue()?0:switch(c.level.getValue()){case "Low"->1;case "High"->3;case "Ultra High"->4;default->2;};}
 public static void apply(Cleaner c){owner=c;c.applied.setValue(true);reset();com.duckswords.Config.save();}
 public static void disable(Cleaner c){owner=c;c.applied.setValue(false);reset();com.duckswords.Config.save();}
 private static void reset(){world=null;tick=Integer.MIN_VALUE;used=0;yaw=pitch=Float.NaN;}
 public static void open(Cleaner c){owner=c;class_310 mc=class_310.method_1551();mc.method_1507(new com.duckswords.gui.CleanerScreen(mc.field_1755,c));}
 public static boolean action(Object m){return m instanceof Cleaner||m instanceof com.duckswords.profiles.Profiles;}
 public static class_437 screen(class_437 parent){return new com.duckswords.gui.CleanerScreen(parent,owner());}
 public static class_437 actionScreen(class_437 parent,Object module){return module instanceof Cleaner?screen(parent):profile(parent);}
 public static class_437 profile(class_437 parent){throw new IllegalStateException("native profile screen adapter");}
 public static String title(Object m){return m instanceof Cleaner?"CLEANER":"PERFIS";}
 public static String button(Object m){return m instanceof Cleaner?"ABRIR OTIMIZACAO":"GERENCIAR PERFIS";}
 public static float cameraYaw(){throw new IllegalStateException("camera adapter");}public static float cameraPitch(){throw new IllegalStateException("camera adapter");}
 public static boolean attachedCamera(){throw new IllegalStateException("camera adapter");}
 public static float previousYaw(){throw new IllegalStateException("previous view adapter");}public static float previousPitch(){throw new IllegalStateException("previous view adapter");}
 private static boolean interpolated(float actual,float previous,float current){double step=Math.IEEEremainder(current-previous,360),value=Math.IEEEremainder(actual-previous,360);return Double.isFinite(step)&&Double.isFinite(value)&&value>=Math.min(0,step)-1.5&&value<=Math.max(0,step)+1.5;}
 public static boolean normalView(){class_310 mc=class_310.method_1551();return mc.field_1724!=null&&mc.field_1687!=null&&mc.field_1755==null&&ClientData.firstPerson()&&attachedCamera()&&com.duckswords.camera.FreeLookControl.camera()==null&&interpolated(cameraYaw(),previousYaw(),ClientData.playerYaw())&&interpolated(cameraPitch(),previousPitch(),ClientData.playerPitch());}
 public static boolean behind(double dx,double dy,double dz,double radius){float y=cameraYaw(),p=cameraPitch();if(!Float.isFinite(y)||!Float.isFinite(p))return false;if(y!=yaw||p!=pitch){yaw=y;pitch=p;double a=Math.toRadians(y),b=Math.toRadians(p);lx=-Math.sin(a)*Math.cos(b);ly=-Math.sin(b);lz=Math.cos(a)*Math.cos(b);}return dx*lx+dy*ly+dz*lz < -radius;}
 public static boolean cull(class_1297 e,double x,double y,double z){int level=level();if(level==0||e==null||e==class_310.method_1551().field_1724||!normalView())return false;double dx=e.method_23317()-x,dy=e.method_23318()-y,dz=e.method_23321()-z,d=dx*dx+dy*dy+dz*dz;double range=e instanceof class_1657?PLAYERS[level]:ENTITIES[level];if(d>range*range)return true;return level>=2&&d>64&&behind(dx,dy,dz,Math.max(4,VisualParticles.width(e)+2));}
 public static boolean visible(class_1297 e){return e!=null&&e.method_5805()&&!hidden(e);}
 public static boolean hidden(class_1297 e){if(e==null||level()==0||!normalView())return false;return cull(e,viewX(),viewY(),viewZ());}
 public static double viewX(){throw new IllegalStateException("camera adapter");}public static double viewY(){throw new IllegalStateException("camera adapter");}public static double viewZ(){throw new IllegalStateException("camera adapter");}
 public static boolean skipParticle(class_2394 effect,double x,double y,double z){if(ClientParticleScope.active()||VisualParticles.owns(effect))return false;return com.duckswords.perf.GamePerformance.dropParticle(x,y,z)||drop(x,y,z);}
 public static boolean drop(double x,double y,double z){int level=level();if(level==0)return false;class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1687==null)return false;if(world!=mc.field_1687||tick!=mc.field_1724.field_6012){world=mc.field_1687;tick=mc.field_1724.field_6012;used=0;}double dx=x-viewX(),dy=y-viewY(),dz=z-viewZ(),range=PARTICLES[level];if(dx*dx+dy*dy+dz*dz>range*range)return true;if(level>=2&&normalView()&&dx*dx+dy*dy+dz*dz>64&&behind(dx,dy,dz,4))return true;int max=BUDGET[level];return ++used>max;}
 public static boolean shadows(){return com.duckswords.perf.GamePerformance.shadowsActive||level()>=1;}
 public static boolean weather(){return com.duckswords.perf.GamePerformance.weatherActive||level()>=3;}
 public static boolean clouds(){return com.duckswords.perf.ExtendedPerformance.cloudsActive||level()>=2;}
 public static boolean fire(){return com.duckswords.perf.ExtendedPerformance.fireActive;}
 public static int copies(int original){return level()>0?Math.min(original,1):original;}
 public static boolean scene(int index){int l=level();return l>=4||l>=3&&(index==0||index==4||index==5);}
}
