from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,shutil
B=Path(__file__).parent;OUT=B/'release';OUT.mkdir(exist_ok=True);publish=Path('/workspace/duck-publish218/downloads');version='beta.2.21'
report=json.loads((B/'build-report.json').read_text());logs=['native221-check.log', 'startup221-check.log', 'artifact221-check.log', 'cleaner221-check.log', 'runtime221-check.log', 'worker221-check.log', 'burst221-check.log', 'defaults221-check.log', 'assets221-check.log']
for name in logs:
 text=(B/name).read_text();assert 'PASS' in text and 'Traceback' not in text and 'Exception in thread' not in text,name
validation='DuckClientZ 1.5.28-beta.2.21 — validação técnica\n\nTestes com fixtures/assinaturas reais das APIs; não houve execução de Minecraft, Pojav ou teste em GPU/FPS.\n\n'
validation+='\nRelatórios 221 verificam os JARs desta revisão. Alguns testes mantêm nomes de scripts de revisões anteriores e foram executados novamente contra o build-report atual. Testes simulam conflitos de identidade/HTTP; não comprovam compatibilidade com Dawn em execução. Não há medição de FPS.\n'
for name in logs:validation+='\n'+name+'\n'+(B/name).read_text()
(B/'VALIDACAO.txt').write_text(validation)
source=OUT/f'DuckClientZ-{version}-fontes.zip'
source_dirs=['src','modules-src','modules-new-src','gui-old','gui-new','target-old','target-new','camera-double','camera-float','camera-native','compile-stubs','compile-stubs-new','resources','test-old','test-new','settings-test-src','safety-tests','native-regression-src','cosmetics-relay']
with ZipFile(source,'w',ZIP_DEFLATED) as z:
 for directory in source_dirs:
  for path in sorted((B/directory).rglob('*')):
   if path.is_file() and path.suffix not in ('.class','.pyc') and '__pycache__' not in path.parts:z.write(path,'expansion/'+path.relative_to(B).as_posix())
 for path in sorted(B.glob('*')):
  if path.is_file() and (path.suffix in ('.java','.py') or path.name in ['README-FONTES.txt','LEIA-ME.txt','CREDITOS.txt','LICENSE-REFERENCIA-SOUP.txt','VALIDACAO.txt','build-report.json']):z.write(path,'expansion/'+path.name)
 for path in sorted((B/'native').glob('*/*.tsv')):z.write(path,'expansion/'+path.relative_to(B).as_posix())
 for name in ['expanded-settings-1.21.4.json','expanded-settings-1.21.11.json']:z.write(B/name,'expansion/'+name)
 z.write('/workspace/duckclientz/dist-fixes9/DuckClientZ-correcoes-fonte-beta.2.13-fixes.9.zip','bases-fontes/DuckClientZ-correcoes-fonte-beta.2.13-fixes.9.zip')
 z.write('/workspace/duckclientz-1.21.11/dist/DuckClientZ-1.21.11-1.5.28-opt.2-fonte.zip','bases-fontes/DuckClientZ-1.21.11-1.5.28-opt.2-fonte.zip')
artifacts={}
for game,entry in report.items():
 path=Path(entry['jar']);assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256'];artifacts[f'{game}/mods/{path.name}']=path.read_bytes()
for name in ['LEIA-ME.txt','CREDITOS.txt','LICENSE-REFERENCIA-SOUP.txt']:artifacts[name]=(B/name).read_bytes()
artifacts['validacao/VALIDACAO.txt']=(B/'VALIDACAO.txt').read_bytes();artifacts['validacao/build-report.json']=(B/'build-report.json').read_bytes();artifacts['fontes/'+source.name]=source.read_bytes()
def bundle(path,items):
 with ZipFile(path,'w',ZIP_DEFLATED) as z:
  for name,data in items.items():z.writestr(name,data)
  z.writestr('SHA256SUMS.txt',''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in items.items()))
 with ZipFile(path) as z:assert z.testzip() is None
allzip=OUT/f'DuckClientZ-{version}-4-versoes.zip';bundle(allzip,artifacts)
nativezip=OUT/f'DuckClientZ-1.21.11-{version}.zip';bundle(nativezip,{(name[len('1.21.11/'):] if name.startswith('1.21.11/') else name):data for name,data in artifacts.items() if name.startswith('1.21.11/') or name in ('LEIA-ME.txt','CREDITOS.txt','LICENSE-REFERENCIA-SOUP.txt','validacao/VALIDACAO.txt')})
readme=OUT/f'DuckClientZ-{version}-LEIA-ME.txt';shutil.copy2(B/'LEIA-ME.txt',readme)
checksum=allzip.with_suffix('.zip.sha256');checksum.write_text(hashlib.sha256(allzip.read_bytes()).hexdigest()+'  '+allzip.name+'\n')
files=[Path(entry['jar']) for entry in report.values()]+[allzip,nativezip,source,readme,checksum]
manifest={}
for path in files:
 dest=publish/path.name
 if dest.exists():assert dest.read_bytes()==path.read_bytes(),'Published filename already has different contents: '+dest.name
 else:shutil.copy2(path,dest)
 manifest[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
(B/'release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: packaged and staged',len(manifest),'files; combined ZIP',allzip.stat().st_size,'bytes; source ZIP',source.stat().st_size,'bytes')
