package com.duckswords.gui;
import com.duckswords.theme.HudText;import java.util.*;import java.util.concurrent.atomic.AtomicLong;
/** Native fit algorithm, bounded caches and no temporary composite-string keys on hits. */
public final class KeyFit239 {
 private static final AtomicLong REVISION=new AtomicLong();private static final Map<Object,State> OWNERS=new WeakHashMap<>();
 private static final class Widths {int count,lastWidth=Integer.MIN_VALUE;String last;final int[] widths=new int[64];final String[] labels=new String[64];}
 private static final class State {long revision=-1;String font="";final Map<String,Widths> labels=new HashMap<>();}
 public static void clear(){REVISION.incrementAndGet();}
 public static String fit(Object owner,String label,int width){String font=HudTextCache220.font();State s=OWNERS.computeIfAbsent(owner,k->new State());long revision=REVISION.get();if(s.revision!=revision||!s.font.equals(font)){s.labels.clear();s.revision=revision;s.font=font;}Widths w=s.labels.get(label);if(w!=null){if(w.lastWidth==width)return w.last;for(int i=0;i<w.count;i++)if(w.widths[i]==width){w.lastWidth=width;return w.last=w.labels[i];}}String visible=label;while(!visible.isEmpty()&&HudText.width(visible)>width-2)visible=visible.substring(0,visible.length()-1);if(label.length()>256)return visible;if(w==null){if(s.labels.size()>=256)s.labels.clear();w=new Widths();s.labels.put(label,w);}if(w.count<64){w.widths[w.count]=width;w.labels[w.count++]=visible;}w.lastWidth=width;return w.last=visible;}
}
