package com.duckswords.cosmetic;
import java.util.Map;import java.util.function.Function;
/** Already baked models use the read-only lookup; lazy loads keep the original atomic path. */
public final class ModelLookup239 {
 public static Object get(Map<String,Object> models,String id,Function<String,Object> loader){Object baked=models.get(id);return baked!=null?baked:models.computeIfAbsent(id,loader);}
}
