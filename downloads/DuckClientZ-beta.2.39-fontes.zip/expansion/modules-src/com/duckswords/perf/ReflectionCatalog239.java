package com.duckswords.perf;
import java.lang.reflect.Method;import java.util.concurrent.ConcurrentHashMap;
/** Compatibility helpers only; callers read these tables without modifying them. */
public final class ReflectionCatalog239 {
 private static final ClassValue<Method[]> METHODS=new ClassValue<>(){protected Method[] computeValue(Class<?> type){return type.getMethods();}};
 private static final ClassValue<ConcurrentHashMap<String,Method>> ZERO=new ClassValue<>(){protected ConcurrentHashMap<String,Method> computeValue(Class<?> type){return new ConcurrentHashMap<>();}};
 private static final ConcurrentHashMap<String,Class<?>> CLASSES=new ConcurrentHashMap<>();
 public static Method[] methods(Class<?> type){return METHODS.get(type);}
 public static Class<?> rawClass(String name)throws ClassNotFoundException{throw new ClassNotFoundException("native class resolver");}
 public static Method rawMethod(Class<?> type,String name,Class<?>[] args)throws NoSuchMethodException{throw new NoSuchMethodException("native method resolver");}
 public static Class<?> forName(String name)throws ClassNotFoundException{Class<?> type=CLASSES.get(name);if(type!=null)return type;type=rawClass(name);if(CLASSES.size()<1024)CLASSES.putIfAbsent(name,type);return type;}
 public static Method getMethod(Class<?> type,String name,Class<?>[] args)throws NoSuchMethodException{if(args!=null&&args.length!=0)return rawMethod(type,name,args);var cache=ZERO.get(type);Method method=cache.get(name);if(method!=null)return method;method=rawMethod(type,name,args);if(cache.size()<1024)cache.putIfAbsent(name,method);return method;}
}
