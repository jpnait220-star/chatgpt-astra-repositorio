package com.duckswords.perf;
import java.text.SimpleDateFormat;import java.util.*;
/** Only the private HH:mm:ss Clock HUD formatter uses this helper. */
public final class ClockText239 {
 private static final Map<SimpleDateFormat,Entry> CACHE=new IdentityHashMap<>();private static final class Entry{long second=Long.MIN_VALUE;String text;}
 public static String text(SimpleDateFormat format){return at(format,System.currentTimeMillis());}
 public static String at(SimpleDateFormat format,long now){synchronized(format){long second=Math.floorDiv(now+(long)format.getTimeZone().getOffset(now),1000);Entry e=CACHE.get(format);if(e!=null&&e.second==second)return e.text;String value=format.format(new Date(now));if(e==null){if(CACHE.size()>=16)CACHE.clear();e=new Entry();CACHE.put(format,e);}e.second=second;return e.text=value;}}
}
