package com.duckswords.perf;
import com.duckswords.setting.Setting;import com.duckswords.setting.NumberSetting;import java.util.*;
/** Mutable List semantics, with first-number lookup rebuilt only after mutation. */
public final class IndexedSettings239 extends AbstractList<Setting<?>> implements RandomAccess {
 private final ArrayList<Setting<?>> values=new ArrayList<>();private final Map<String,NumberSetting> numbers=new HashMap<>();private boolean ready,custom;
 public int size(){return values.size();}public Setting<?> get(int i){return values.get(i);}
 public void add(int i,Setting<?> value){values.add(i,value);ready=false;modCount++;}
 public Setting<?> set(int i,Setting<?> value){Setting<?> old=values.set(i,value);ready=false;return old;}
 public Setting<?> remove(int i){Setting<?> old=values.remove(i);ready=false;modCount++;return old;}
 protected void removeRange(int from,int to){values.subList(from,to).clear();ready=false;modCount++;}
 private NumberSetting indexed(String name){if(!ready){numbers.clear();custom=false;for(Setting<?> s:values)if(s instanceof NumberSetting n){if(n.getClass()!=NumberSetting.class||n.getName()==null)custom=true;numbers.putIfAbsent(n.getName(),n);}ready=true;}return custom?scan(this,name):numbers.get(name);}
 private static NumberSetting scan(List<Setting<?>> settings,String name){for(Setting<?> s:settings)if(s instanceof NumberSetting n&&s.getName().equals(name))return n;return null;}
 public static NumberSetting number(List<Setting<?>> settings,String name){return settings instanceof IndexedSettings239 indexed?indexed.indexed(name):scan(settings,name);}
}
