from PIL import Image
from io import BytesIO
import struct

def prepare(data):
 source=Image.open(BytesIO(data['assets/duckswords/textures/gui/shapes229.png'])).convert('RGBA');atlas=Image.new('RGBA',(1024,2048),(255,255,255,0));regions={};x=0;y=0;row_height=0
 for h in range(240,1,-1):
  r=min(5,h//2);n=r*2;ww=r*4+4;hh=h*2
  if x+ww+4>1024:x=0;y+=row_height;row_height=0
  row_height=max(row_height,hh+4);assert y+row_height<=2048
  xx=x+2;yy=y+2;regions[h]=(xx,yy)
  for py in range(hh):
   for px in range(ww):
    cx=min(px,ww-1-px);cy=min(py,hh-1-py);a=source.getpixel((2+cx,(r-1)*(r+4)+2+cy))[3] if cx<n and cy<n else 255
    atlas.putpixel((xx+px,yy+py),(255,255,255,a))
  x+=ww+4
 out=BytesIO();atlas.save(out,format='PNG');return {'assets/duckswords/textures/gui/hud239.png':out.getvalue(),'assets/duckswords/textures/gui/hud239.bin':b''.join(struct.pack('>HH',*regions[h]) for h in range(2,241))}
