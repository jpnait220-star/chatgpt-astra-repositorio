from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import os,subprocess,hashlib,json,shutil
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');asm=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',str(B/'classes'),str(B/'Cache239Patch.java'),str(B/'Reflection239Patch.java'),str(B/'HudMask239Patch.java'),str(B/'CosmeticCache239Patch.java')],check=True)
report={}
for game in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 base=B/f'dist/DuckClientZ-{game}-1.5.28-beta.2.38.jar';out=B/'cache239-build'/game;compiled=out/'compiled';patch=out/'patch';shutil.rmtree(out,ignore_errors=True);compiled.mkdir(parents=True,exist_ok=True);patch.mkdir(exist_ok=True);new=game=='1.21.11';root=Path('/workspace/duckclientz-1.21.11' if new else '/workspace/duckclientz');cp=os.pathsep.join(map(str,[base,root/'repair/stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old')]))
 sources=[B/'modules-src'/p for p in ['com/duckswords/perf/IndexedSettings239.java','com/duckswords/gui/KeyFit239.java','com/duckswords/perf/ClockText239.java','com/duckswords/perf/ReflectionCatalog239.java','com/duckswords/render/HudMask239.java','com/duckswords/cosmetic/ModelLookup239.java']]
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-source','17','-target','17','-cp',cp,'-d',str(compiled),*map(str,sources)],check=True)
 subprocess.run(['java','-cp',asm,'Cache239Patch',str(base),str(patch),game,str(compiled)],check=True)
 subprocess.run(['java','-cp',asm,'Reflection239Patch',str(base),str(patch),game,str(compiled)],check=True)
 subprocess.run(['java','-cp',asm,'HudMask239Patch',str(base),str(patch),game,str(compiled)],check=True)
 subprocess.run(['java','-cp',asm,'CosmeticCache239Patch',str(base),str(patch),game,str(compiled)],check=True)
 with ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
 changed={p.relative_to(folder).as_posix():p.read_bytes() for folder in [compiled,patch] for p in folder.rglob('*.class')};meta=json.loads(data['fabric.mod.json']);meta['version']='1.5.28-beta.2.39';changed['fabric.mod.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode();dest=B/f'dist/DuckClientZ-{game}-1.5.28-beta.2.39.jar'
 from prepare_hud239 import prepare
 changed.update(prepare(data))
 with ZipFile(dest,'w',ZIP_DEFLATED) as z:
  for name,value in (data|changed).items():z.writestr(name,value)
 report[game]={'jar':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'changed':sorted(changed)}
 with ZipFile(dest) as z:assert z.testzip() is None
 print('PASS239 incremental stable238 base; only approved classes/resources changed',game)
(B/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
