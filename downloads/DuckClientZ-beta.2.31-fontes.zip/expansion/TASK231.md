# beta.2.31 final
All four builds complete. User requested Cleaner Ultra enabled initially,
minimal Mod Menu description, and more optimization focused on entities and
players. Implemented Ultra constructor/bundled defaults and one-time per-game
migration respecting later disable; exact two-line description plus mod title.
Cleaner culling skips expensive view checks for safe near entities and uses
native firework type instead of registry strings. Added reversible circle LOD
and distant names to Cleaner. Animated texture selection caches interval and
uses binary search with identical timing. Menu cache avoids transient key on hits.
All previous230 optimizations preserved. Existing Totem Editor behavior retained;
no unsupported claim that every source of FPS loss has been identified.
Native/mixin/CRC/migration/culling/camera/render/text/menu/texture/remote/particle
and signed updater tests passed. No GPU/FPS run. Publish final231 artifacts and
verify remote hashes + production signed manifest.230 and older immutable.
