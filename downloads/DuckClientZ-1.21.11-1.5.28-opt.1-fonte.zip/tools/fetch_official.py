from pathlib import Path
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor
from zipfile import ZipFile
import json,hashlib
root=Path(__file__).resolve().parent
version='1.21.11'
def read(url):
 with urlopen(url,timeout=90) as r:return r.read()
def save(name,url,sha1):
 p=root/name
 if not p.exists() or hashlib.sha1(p.read_bytes()).hexdigest()!=sha1:
  data=read(url);assert hashlib.sha1(data).hexdigest()==sha1,name;p.write_bytes(data)
 print('verified',name,flush=True);return p
manifest=json.loads(read('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'))
entry=next(e for e in manifest['versions'] if e['id']==version)
p=save('minecraft.json',entry['url'],entry['sha1']);meta=json.loads(p.read_text())
with ThreadPoolExecutor(max_workers=2) as pool:
 jobs=[pool.submit(save,'minecraft-'+key,info['url'],info['sha1']) for key,info in meta['downloads'].items() if key in ['client','client_mappings']]
 for f in jobs:f.result()
url=f'https://maven.fabricmc.net/net/fabricmc/intermediary/{version}/intermediary-{version}-v2.jar'
p=save('intermediary.jar',url,read(url+'.sha1').decode().strip())
with ZipFile(p) as z:(root/'intermediary.tiny').write_bytes(z.read('mappings/mappings.tiny'))
