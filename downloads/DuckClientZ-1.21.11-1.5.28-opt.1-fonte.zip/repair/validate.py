from pathlib import Path
import subprocess,os,json
B=Path(__file__).resolve().parent;R=B.parent;T=R/'tools';J=R/'dist'/'DuckClientZ-1.21.11-1.5.28-opt.1-experimental.jar'
def cp(*v):return os.pathsep.join(str(x) for x in v)
def run(args):
 r=subprocess.run([str(x) for x in args],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(r.stdout,flush=True);logs.append(r.stdout)
 if r.returncode:raise SystemExit(r.returncode)
logs=[]
asm=cp(T/'asm.jar',T/'asm-tree.jar',T/'asm-analysis.jar',T/'asm-commons.jar')
run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',cp(asm,T/'fabric-loader.jar'),'-d',B/'toolclasses',B/'Verify12111.java',B/'ExtractProbes.java',B/'FabricMetadataTest.java'])
report=json.loads((R/'build-report.json').read_text());(B/'changed.txt').write_text('\n'.join(report['changed']))
run(['java','-cp',cp(B/'toolclasses',asm),'Verify12111',T/'intermediary.tiny',T/'minecraft-client',J,B/'changed.txt'])
run(['java','-cp',cp(B/'toolclasses',T/'fabric-loader.jar'),'FabricMetadataTest',J])
for inputjar,kind,target in [(R/'DuckClientZ-1.21.11-1.5.27.jar','com/duckswords/modules/Swing','BaselineSwing'),(R/'DuckClientZ-1.21.11-1.5.27.jar','com/duckswords/util/RenderUtil','OriginalCircle'),(J,'com/duckswords/util/RenderUtil','OptimizedCircle')]:
 run(['java','-cp',cp(B/'toolclasses',asm),'ExtractProbes',inputjar,B/'probes',kind,target])
runtime=cp(B/'testclasses',B/'probes',B/'stubclasses',J,T/'joml.jar',T/'gson.jar',T/'mixin.jar')
run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',runtime,'-d',B/'testclasses',B/'Tests12111.java',B/'HudLayoutTests.java'])
run(['java','-Xverify:all','-cp',runtime,'Tests12111'])
run(['java','-Xverify:all','-cp',runtime,'HudLayoutTests'])
(R/'VALIDACAO_TECNICA.txt').write_text('DuckClientZ 1.21.11 / 1.5.28-opt.1\n\n'+'\n'.join(logs)+'\nLimites: verificacao de API com JAR oficial e testes isolados com stubs. Minecraft/Fabric completo, Pojav e modpack nao foram iniciados. Sem benchmark de FPS ou GPU.\n')
