from pathlib import Path
from zipfile import ZipFile
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');root=B/'startup220-runtime';root.mkdir(exist_ok=True)
service=root/'META-INF/services';service.mkdir(parents=True,exist_ok=True)
(service/'org.spongepowered.asm.service.IMixinService').write_text('TestMixinService219\n');(service/'org.spongepowered.asm.service.IGlobalPropertyService').write_text('TestMixinService219\n')
libs=[B/'tools/mixin-loader-0.19.3.jar',B/'tools/mixinextras-fabric-0.5.4.jar',B/'tools/sodium-1.20.1.jar']+[T/n for n in ['asm-9.7.1.jar','asm-tree-9.7.1.jar','asm-commons-9.7.1.jar','asm-util-9.7.1.jar','asm-analysis-9.7.1.jar','gson.jar']]
cp=os.pathsep.join(map(str,[root,*libs,Path('/workspace/duckclientz/repair/toolclasses'),Path('/workspace/duckclientz-1.21.11/repair/toolclasses')]))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(root),str(B/'TestMixinService219.java'),str(B/'TestSodium230.java')],check=True)
for v,e in json.loads((B/'build-report.json').read_text()).items():
 if v!='1.20.1':continue
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/tools') if new else T;names=['MixinWebPipeline218','MixinWebLines218'] if new else ['MixinWebLines218']
 names+=['MixinGuiBlit220','MixinTextReload220','MixinPerformanceEntities','MixinPerformanceParticles','MixinAutoClickMining218','MixinAutoClickHold222','MixinAutoClickActions224','MixinSlimArms224','MixinFirstPersonFists225','MixinLegacyFov225','MixinDuckTab221','MixinDuckName221']
 names += ['MixinGlintStrength'] if new else ['MixinStableGlint']
 if v in ['1.21.4','1.21.11']:names+=['MixinCosmeticIdentity220']
 if v=='1.21.4':names+=['MixinViewModel1214','MixinLivingEntityRenderer1214']
 names += ['MixinCosmeticPart217','MixinCosmeticCube217','MixinAnnouncements229']
 if os.environ.get('DUCK_TEST_VERSION') and v!=os.environ['DUCK_TEST_VERSION']:continue
 with ZipFile(e['jar']) as z:
  for n in names:
   p=root/'com/duckswords/mixin'/(n+'.class');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read('com/duckswords/mixin/'+n+'.class'))
 (root/'sodium230.mixins.json').write_text(json.dumps({'required':True,'minVersion':'0.8.7','package':'me.jellysquid.mods.sodium.mixin','compatibilityLevel':'JAVA_17','client':['features.render.entity.ModelPartMixin','features.render.entity.CuboidMixin']}))
 (root/'startup220.mixins.json').write_text(json.dumps({'required':True,'minVersion':'0.8.7','package':'com.duckswords.mixin','compatibilityLevel':'JAVA_17' if v=='1.20.1' else 'JAVA_21','client':names}))
 targets=root/'targets.txt';targets.write_text(('net/minecraft/class_10799\nnet/minecraft/class_12249\n' if new else 'net/minecraft/class_1921\n')+('net/minecraft/class_11284\n' if new else 'net/minecraft/class_4668\n')+'net/minecraft/class_408\nnet/minecraft/class_630\nnet/minecraft/class_630$class_628\nnet/minecraft/class_757\nnet/minecraft/class_332\nnet/minecraft/class_310\nnet/minecraft/class_591\n'+('net/minecraft/class_1007\n' if v in ['1.21.4','1.21.11'] else 'net/minecraft/class_1007\n')+('net/minecraft/class_759\nnet/minecraft/class_922\n' if v=='1.21.4' else '')+'net/minecraft/class_636\nnet/minecraft/class_355\nnet/minecraft/class_898\nnet/minecraft/class_702\n'+('net/minecraft/class_897\n' if v in ['1.21.4','1.21.11'] else ''))
 command=['java','-Xverify:all','-cp',cp,'TestSodium230','Verify12111' if new else 'VerifyArtifacts',str(r/('intermediary.tiny' if new else f'intermediary-{v}.tiny')),str(r/('minecraft-client' if new else f'minecraft-{v}-client')),e['jar'],str(targets),v]
 subprocess.run(command,check=True)
