from pathlib import Path
from PIL import Image
import struct
B=Path(__file__).parent;out=B/'resources/assets/duckswords/gui-particles';out.mkdir(exist_ok=True)
atlas=Image.new('RGBA',(128,16),(255,255,255,0))
keys=['star','heart','bloom','sword','snowflake','firefly','classic','capture']
for p in (B/'prepared-assets').glob('*.png'):
 im=Image.open(p).convert('RGBA').resize((12,12),Image.Resampling.LANCZOS);runs=[]
 for y in range(12):
  x=0
  while x<12:
   a=round(im.getpixel((x,y))[3]/32)*32;a=min(a,255);start=x;x+=1
   while x<12 and min(255,round(im.getpixel((x,y))[3]/32)*32)==a:x+=1
   if a:runs.append((start,y,x-start,a))
 (out/(p.stem+'.bin')).write_bytes(struct.pack('>H',len(runs))+b''.join(bytes(r) for r in runs))
 for x,y,w,a in runs:
  for xx in range(x,x+w):atlas.putpixel((keys.index(p.stem)*16+2+xx,y+2),(255,255,255,a))
atlas.save(B/'resources/assets/duckswords/textures/gui/particles230.png')
