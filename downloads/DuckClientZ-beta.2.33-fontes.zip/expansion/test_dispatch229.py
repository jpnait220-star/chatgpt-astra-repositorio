from pathlib import Path
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');asm=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',T/'asm-commons-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',str(B/'classes'),str(B/'ExtractDispatch229.java')],check=True)
java=r'''import net.minecraft.*;import com.duckswords.cosmetic.*;import java.util.*;public class Dispatch229Jvm {static int count;static float u,x,y,z;public static void record(float a,float b,float c,float d){count++;u=a;x=b;y=c;z=d;}static void check(boolean b){if(!b)throw new AssertionError("live geometry traversal");}static class_630 part(){class_630 p=new class_630();p.field_3663=new ArrayList<>();p.field_3661=new LinkedHashMap<>();p.field_3665=true;return p;}public static void main(String[] args){class_630 root=part(),child=part();root.field_3661.put("animated",child);root.field_3657=.25f;child.field_3657=.5f;child.field_3656=.125f;class_630$class_628 cube=new class_630$class_628();cube.liveU=.81f;child.field_3663.add(cube);class_4587 stack=new class_4587();CALL;check(count==1&&u==.81f&&x==.75f&&y==.125f&&z==0&&stack.depth==0&&stack.matrix.m30()==0);count=0;cube.liveU=.29f;child.field_3657=1f;CALL;check(count==1&&u==.29f&&x==1.25f&&stack.depth==0);count=0;child.field_3665=false;CALL;check(count==0&&stack.depth==0);child.field_3665=true;child.field_38456=true;CALL;check(count==0&&stack.depth==0);System.out.println("PASS exact production part/child/cube dispatch avoids intercepted native entry, reads live UV endpoint/animated pose, obeys visibility and restores matrix "+args[0]);}}'''
for v,e in json.loads((B/'build-report.json').read_text()).items():
 if v=='1.21.11':continue
 out=B/'dispatch229-runtime'/v;out.mkdir(parents=True,exist_ok=True)
 subprocess.run(['java','-cp',asm,'ExtractDispatch229',e['jar'],str(out)],check=True)
 call='GeometryDispatch229.part(root,stack,null,123,456,'+('1f,1f,1f,1f' if v=='1.20.1' else '-1')+')'
 p=out/'Dispatch229Jvm.java';p.write_text(java.replace('CALL',call))
 cp=os.pathsep.join(map(str,[out,B/'runtime220'/v/'classes',e['jar'],T/'joml.jar',Path('/workspace/duckclientz/repair/stubclasses')]))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(p)],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'Dispatch229Jvm',v],check=True)
