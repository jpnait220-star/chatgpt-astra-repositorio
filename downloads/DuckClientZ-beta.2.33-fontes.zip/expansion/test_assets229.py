from pathlib import Path
from zipfile import ZipFile
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');report=json.loads((B/'build-report.json').read_text());inputs=json.loads((B/'inputs229.json').read_text())
cp=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(B/'classes'),str(B/'CompareAnnotations229.java')],check=True)
for v,e in report.items():
 with ZipFile(inputs[v]) as old,ZipFile(e['jar']) as new:
  before=set(old.namelist());after=set(new.namelist());assert not before-after,(v,before-after)
  assets=[n for n in before if n.startswith('assets/')];assert all(old.read(n)==new.read(n) for n in assets if n!='assets/duckswords/cosmetics/animated-textures.json'),v
  before_frames=json.loads(old.read('assets/duckswords/cosmetics/animated-textures.json'));after_frames=json.loads(new.read('assets/duckswords/cosmetics/animated-textures.json'));assert {k:after_frames[k] for k in before_frames if k!='demon2024DemonScythe'}=={k:v for k,v in before_frames.items() if k!='demon2024DemonScythe'};assert set(after_frames)-set(before_frames)<={'demon2024DemonScythe'}
  assert {n for n in after-before if not n.startswith(('com/duckswords/update/','com/duckswords/gui/UpdateScreen229','assets/duckswords/cosmetics/demon2024demonscythe/'))} <= {'assets/duckswords/textures/gui/shapes229.png','com/duckswords/render/GuiShapes229.class','com/duckswords/cosmetic/GeometryDispatch229.class','com/duckswords/cosmetic/GeometryDispatch229$Part.class','com/duckswords/cosmetic/GeometryDispatch229$Cube.class','com/duckswords/social/ClientAnnouncements229.class','com/duckswords/social/ClientAnnouncements229$Notice.class','com/duckswords/mixin/MixinAnnouncements229.class'}
  assert json.loads(new.read('fabric.mod.json'))['version']=='1.5.28-beta.2.29'
  if v=='1.21.11':
   cosmetics=[n for n in before if (n.startswith('com/duckswords/cosmetic/') and 'CosmeticCatalog222' not in n) or n.startswith('com/duckswords/mixin/MixinCosmetic')]
   assert all(old.read(n)==new.read(n) for n in cosmetics),'native11 cosmetic path changed'
 subprocess.run(['java','-cp',cp,'CompareAnnotations229',inputs[v],e['jar'],v],check=True)
 print('PASS uploaded assets, profiles/config schemas, original animations/textures/geometry all byte-identical; GUI atlas and explicitly requested original scythe added',v)
