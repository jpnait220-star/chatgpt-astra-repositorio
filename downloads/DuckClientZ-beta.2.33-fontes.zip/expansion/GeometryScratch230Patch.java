import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Replace only known allocations in the copied Duck cube body, never vanilla/Sodium. */
public class GeometryScratch230Patch extends Revision218Patch {
 public static void main(String[] a)throws Exception{out=Path.of(a[1]);compiled=Path.of(a[3]);try(ZipFile z=new ZipFile(a[0])){zip=z;
  ClassNode cube=read("com/duckswords/mixin/MixinCosmeticCube217");MethodNode body=Cleaner221Patch.method(cube,"duck$vanilla217$method_32089");int normal=0,position=0,empty=0;boolean old=a[2].equals("1.20.1");int normalLocal=body.maxLocals++,positionLocal=body.maxLocals++;
  if(old){InsnList head=new InsnList();head.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/cosmetic/GeometryScratch230","vector3","()Lorg/joml/Vector3f;",false));head.add(new VarInsnNode(ASTORE,normalLocal));head.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/cosmetic/GeometryScratch230","vector4","()Lorg/joml/Vector4f;",false));head.add(new VarInsnNode(ASTORE,positionLocal));body.instructions.insert(head);}
  for(AbstractInsnNode n:body.instructions.toArray())if(n instanceof TypeInsnNode allocation&&n.getOpcode()==NEW&&List.of("org/joml/Vector3f","org/joml/Vector4f").contains(allocation.desc)){
   AbstractInsnNode dup=n.getNext();if(dup.getOpcode()!=DUP)throw new IllegalStateException("Unexpected vector allocation");
   MethodInsnNode ctor=null;for(AbstractInsnNode p=dup.getNext();p!=null;p=p.getNext())if(p instanceof MethodInsnNode call&&call.owner.equals(allocation.desc)&&call.name.equals("<init>")){ctor=call;break;}
   if(ctor==null)throw new IllegalStateException("Vector constructor missing");String method;
   if(allocation.desc.equals("org/joml/Vector4f")&&ctor.desc.equals("(FFFF)V")){method="position";position++;}
   else if(allocation.desc.equals("org/joml/Vector3f")&&ctor.desc.equals("(Lorg/joml/Vector3fc;)V")){method="normal";normal++;}
   else if(allocation.desc.equals("org/joml/Vector3f")&&ctor.desc.equals("()V")){method="vector3";empty++;}
   else throw new IllegalStateException("Unknown vector constructor "+ctor.desc);
   String result=allocation.desc;if(!method.equals("vector3")){body.instructions.insertBefore(n,new VarInsnNode(ALOAD,method.equals("normal")?normalLocal:positionLocal));ctor.setOpcode(INVOKEVIRTUAL);ctor.name="set";}else{ctor.setOpcode(INVOKESTATIC);ctor.owner="com/duckswords/cosmetic/GeometryScratch230";ctor.name="vector3";}
   body.instructions.remove(n);body.instructions.remove(dup);ctor.desc=ctor.desc.substring(0,ctor.desc.length()-1)+"L"+result+";";ctor.itf=false;
  }
  if(old?(normal!=1||position!=1||empty!=0):(normal!=0||position!=0||empty!=1))throw new IllegalStateException("Unexpected cube loop "+normal+"/"+position+"/"+empty);
  ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS){protected String getCommonSuperClass(String x,String y){return "java/lang/Object";}};cube.accept(writer);Path target=out.resolve(cube.name+".class");Files.createDirectories(target.getParent());Files.write(target,writer.toByteArray());
  System.out.println("230 reusable Duck cube vectors; "+(old?"30 allocations per six-face cube -> zero after thread warmup":"1 allocation per cube -> zero after thread warmup")+" "+a[2]);
 }}
}
