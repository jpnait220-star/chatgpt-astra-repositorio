package com.duckswords.profiles;
import com.google.gson.*;import java.io.*;import java.nio.file.*;import java.util.*;import net.fabricmc.loader.api.FabricLoader;
/** One migration per Minecraft version. A later explicit disable remains respected. */
public final class CleanerDefaults231 {
 private static Path pending;
 public static Path marker()throws IOException{Properties p=new Properties();try(InputStream in=CleanerDefaults231.class.getResourceAsStream("/assets/duckswords/storage.properties")){if(in==null)throw new IOException("Missing version");p.load(in);}String version=p.getProperty("minecraft","");if(!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+"))throw new IOException("Invalid version");return FabricLoader.getInstance().getConfigDir().resolve("duckclientz").resolve(version).resolve("cleaner-ultra-v231.applied");}
 public static void prepare(JsonObject root){try{Path path=marker();if(Files.exists(path))return;JsonObject cleaner=root.has("Cleaner")&&root.get("Cleaner").isJsonObject()?root.getAsJsonObject("Cleaner"):new JsonObject();JsonObject settings=cleaner.has("settings")&&cleaner.get("settings").isJsonObject()?cleaner.getAsJsonObject("settings"):new JsonObject();settings.addProperty("Intensidade","Ultra High");settings.addProperty("Otimizacao aplicada",true);cleaner.add("settings",settings);root.add("Cleaner",cleaner);pending=path;}catch(IOException ignored){}}
 public static void finish(){Path marker=pending;if(marker==null)return;pending=null;try{com.duckswords.Config.save();Files.createDirectories(marker.getParent());Files.writeString(marker,"Ultra inicializado; escolhas futuras preservadas.\n");}catch(IOException ignored){}}
}
