package com.duckswords.update;
import com.google.gson.*;import java.net.URI;import java.security.*;import java.security.spec.*;import java.util.*;
/** Verify the signed bytes before parsing any download URL or release metadata. */
public final class UpdateManifest229 {
 public record Release(String game,String version,String url,String sha256,long size){}
 public static boolean newer(String candidate,String current){
  String pattern="[0-9]+\\.[0-9]+\\.[0-9]+(?:-beta\\.[0-9]+\\.[0-9]+)?";
  if(!candidate.matches(pattern)||!current.matches(pattern))return false;
  String[] a=candidate.split("-",2),b=current.split("-",2);String[] x=a[0].split("\\."),y=b[0].split("\\.");
  for(int i=0;i<3;i++){long left=Long.parseLong(x[i]),right=Long.parseLong(y[i]);if(left!=right)return left>right;}
  if(a.length!=b.length)return a.length==1;if(a.length==1)return false;
  x=a[1].substring(5).split("\\.");y=b[1].substring(5).split("\\.");for(int i=0;i<2;i++){long left=Long.parseLong(x[i]),right=Long.parseLong(y[i]);if(left!=right)return left>right;}return false;
 }
 public static Release verify(String envelope,String publicKey,String game,String current)throws Exception{
  if(envelope.length()>65536)throw new SecurityException("Manifest too large");JsonObject signed=JsonParser.parseString(envelope).getAsJsonObject();
  byte[] payload=Base64.getDecoder().decode(signed.get("payload").getAsString()),signature=Base64.getDecoder().decode(signed.get("signature").getAsString());if(payload.length>32768)throw new SecurityException("Payload too large");
  PublicKey key=KeyFactory.getInstance("Ed25519").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKey)));Signature verifier=Signature.getInstance("Ed25519");verifier.initVerify(key);verifier.update(payload);if(!verifier.verify(signature))throw new SecurityException("Invalid update signature");
  JsonObject root=JsonParser.parseString(new String(payload,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();if(root.get("protocol").getAsInt()!=1)throw new SecurityException("Unknown update protocol");JsonElement value=root.getAsJsonObject("releases").get(game);if(value==null)return null;JsonObject r=value.getAsJsonObject();String version=r.get("version").getAsString();if(version.length()>64||!newer(version,current))return null;
  String url=r.get("url").getAsString(),sha=r.get("sha256").getAsString();long size=r.get("size").getAsLong();URI uri=URI.create(url);
  String path="/jpnait220-star/chatgpt-astra-repositorio/asasa/downloads/DuckClientZ-"+game+"-"+version+".jar";
  if(!"https".equals(uri.getScheme())||!"raw.githubusercontent.com".equals(uri.getHost())||uri.getUserInfo()!=null||uri.getPort()!=-1||uri.getQuery()!=null||uri.getFragment()!=null||!path.equals(uri.getRawPath())||!sha.matches("[0-9a-f]{64}")||size<100000||size>33554432)throw new SecurityException("Invalid release metadata");
  return new Release(game,version,url,sha,size);
 }
}
