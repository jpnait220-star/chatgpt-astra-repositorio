package com.duckswords.update;
import net.fabricmc.loader.api.FabricLoader;import java.io.*;import java.nio.file.*;import java.util.*;import java.util.concurrent.*;
/** One startup check, no network work on the render thread and no replacing loaded classes. */
public final class ClientUpdater229 {
 private static final String KEY="MCowBQYDK2VwAyEAsGruKukaAwPgI5PChxvclKUNfyoDFx0efRpHZF8355o=";
 private static final String MANIFEST="https://duck-connect.vercel.app/updates";
 private static boolean started,shown;private static volatile boolean popup;private static volatile String status="Verificando atualizacao...",version="";private static volatile int percent;
 public static String status(){return status;}public static String version(){return version;}public static int percent(){return percent;}
 public static boolean canShow(){throw new IllegalStateException("native title screen check");}public static void show(){throw new IllegalStateException("native update window");}
 public static void frame(){if(!started){started=true;Thread worker=new Thread(ClientUpdater229::check,"Duck-Update");worker.setDaemon(true);worker.start();}if(popup&&!shown&&canShow()){shown=true;show();}}
 private static void check(){try{
  var loader=FabricLoader.getInstance();var mod=loader.getModContainer("duckswords").orElseThrow();String current=mod.getMetadata().getVersion().getFriendlyString();Properties storage=new Properties();try(InputStream in=ClientUpdater229.class.getResourceAsStream("/assets/duckswords/storage.properties")){if(in==null)return;storage.load(in);}String game=storage.getProperty("minecraft");if(game==null||!game.matches("[0-9]+\\.[0-9]+\\.[0-9]+"))return;
  Path folder=loader.getConfigDir().resolve("duckclientz").resolve(game).resolve("updater");Properties options=new Properties();Path settings=folder.resolve("settings.properties");if(Files.isRegularFile(settings))try(InputStream in=Files.newInputStream(settings)){options.load(in);}if(!Boolean.parseBoolean(options.getProperty("automatic","true")))return;
  var origin=mod.getOrigin();if(origin.getKind()!=net.fabricmc.loader.api.metadata.ModOrigin.Kind.PATH||origin.getPaths().size()!=1)return;Path target=origin.getPaths().get(0).toAbsolutePath();if(!Files.isRegularFile(target)||!target.getFileName().toString().endsWith(".jar"))return;
  var c=UpdateDownload229.connection(MANIFEST);String manifest;try{if(c.getResponseCode()!=200)return;try(InputStream in=c.getInputStream()){byte[] bytes=in.readNBytes(65537);if(bytes.length>65536)return;manifest=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);}}finally{c.disconnect();}
  var release=UpdateManifest229.verify(manifest,KEY,game,current);if(release==null)return;String oldHash=InstallHelper229.hash(target);version=release.version();status="Baixando atualizacao...";popup=true;
  Path staged=UpdateDownload229.download(release,folder,bytes->percent=(int)(bytes*100/release.size()));status="Preparando instalacao...";
  Path classes=folder.resolve("installer"),classFile=classes.resolve("com/duckswords/update/InstallHelper229.class");Files.createDirectories(classFile.getParent());try(InputStream in=InstallHelper229.class.getResourceAsStream("InstallHelper229.class")){if(in==null)throw new IOException("Installer unavailable");Files.copy(in,classFile,StandardCopyOption.REPLACE_EXISTING);}
  Path backups=folder.resolve("backups"),log=folder.resolve("install.log");String java=Path.of(System.getProperty("java.home"),"bin",System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")?"java.exe":"java").toString();
  try{new ProcessBuilder(java,"-cp",classes.toString(),"com.duckswords.update.InstallHelper229",Long.toString(ProcessHandle.current().pid()),staged.toString(),target.toString(),release.sha256(),oldHash,backups.toString()).redirectErrorStream(true).redirectOutput(log.toFile()).start();}
  catch(IOException error){Runtime.getRuntime().addShutdownHook(new Thread(()->{try{InstallHelper229.install(staged,target,release.sha256(),oldHash,backups);}catch(Exception failed){try{Files.writeString(log,"Nao foi possivel aplicar a atualizacao automaticamente. O arquivo baixado foi preservado.\n");}catch(IOException ignored){}}},"Duck-Install-On-Close"));}
  percent=100;status="Pronto! Feche e abra o Minecraft para aplicar.";
 }catch(Exception error){if(popup)status="Falha na atualizacao. Sua versao atual foi mantida.";}}
}
