package com.duckswords.update;
import java.nio.file.*;import java.io.*;import java.security.*;import java.util.*;
/** Standalone Java17 installer. Runs from loose class files, so Windows does not lock the old mod JAR. */
public final class InstallHelper229 {
 public static String hash(Path file)throws Exception{MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=Files.newInputStream(file)){byte[] data=new byte[65536];int n;while((n=in.read(data))!=-1)digest.update(data,0,n);}return HexFormat.of().formatHex(digest.digest());}
 public static void install(Path staged,Path target,String expected,String oldHash,Path backups)throws Exception{
  if(!expected.matches("[0-9a-f]{64}")||!oldHash.matches("[0-9a-f]{64}")||!target.getFileName().toString().endsWith(".jar"))throw new SecurityException("Invalid install request");
  if(!hash(staged).equals(expected))throw new SecurityException("Downloaded JAR changed");
  if(!Files.isRegularFile(target)||!hash(target).equals(oldHash))throw new SecurityException("Installed mod changed; refusing overwrite");
  Files.createDirectories(backups);Path backup=backups.resolve(target.getFileName()+"."+oldHash.substring(0,12)+".bak");if(!Files.exists(backup)||!hash(backup).equals(oldHash))Files.copy(target,backup,StandardCopyOption.REPLACE_EXISTING);if(!hash(backup).equals(oldHash))throw new IOException("Backup incomplete");
  Path temp=Files.createTempFile(target.getParent(),".duck-update-",".tmp");
  try{Files.copy(staged,temp,StandardCopyOption.REPLACE_EXISTING);if(!hash(temp).equals(expected))throw new SecurityException("Incomplete install copy");if(!Files.isRegularFile(target)||!hash(target).equals(oldHash))throw new SecurityException("Installed mod changed during copy");try{Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}Files.deleteIfExists(staged);}finally{Files.deleteIfExists(temp);}
  try(var files=Files.list(backups)){List<Path> old=files.filter(p->p.getFileName().toString().endsWith(".bak")).sorted((a,b)->{try{return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a));}catch(IOException e){return 0;}}).toList();for(int i=2;i<old.size();i++)Files.deleteIfExists(old.get(i));}
 }
 public static void main(String[] args)throws Exception{
  if(args.length!=6)throw new IllegalArgumentException("Installer arguments");long parent=Long.parseLong(args[0]);ProcessHandle process=ProcessHandle.of(parent).orElse(null);if(process!=null)process.onExit().get();
  Path staged=Path.of(args[1]).toAbsolutePath(),target=Path.of(args[2]).toAbsolutePath(),backups=Path.of(args[5]).toAbsolutePath();
  for(int attempt=0;;attempt++){try{install(staged,target,args[3],args[4],backups);break;}catch(java.nio.file.AccessDeniedException e){if(attempt>=119)throw e;Thread.sleep(250);}}
 }
}
