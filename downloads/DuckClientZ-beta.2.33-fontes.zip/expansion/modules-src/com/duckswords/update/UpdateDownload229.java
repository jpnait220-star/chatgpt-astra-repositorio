package com.duckswords.update;
import com.google.gson.*;import java.nio.file.*;import java.net.*;import java.io.*;import java.util.zip.*;import java.util.function.LongConsumer;
public final class UpdateDownload229 {
 public static HttpURLConnection connection(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)URI.create(url).toURL().openConnection();c.setConnectTimeout(5000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","DuckClientZ-Updater/1");c.setRequestProperty("Cache-Control","no-cache");return c;}
 public static Path download(UpdateManifest229.Release release,Path folder,LongConsumer progress)throws Exception{
  Files.createDirectories(folder);Path partial=Files.createTempFile(folder,"download-",".part");HttpURLConnection c=connection(release.url());
  try{if(c.getResponseCode()!=200)throw new IOException("Download unavailable");try(InputStream in=c.getInputStream();OutputStream out=Files.newOutputStream(partial)){byte[] buffer=new byte[65536];long total=0;int n;while((n=in.read(buffer))!=-1){total+=n;if(total>release.size())throw new SecurityException("Download too large");out.write(buffer,0,n);progress.accept(total);}if(total!=release.size())throw new IOException("Incomplete download");}validate(partial,release);Path staged=folder.resolve("DuckClientZ-"+release.game()+"-"+release.version()+".jar.pending");Files.move(partial,staged,StandardCopyOption.REPLACE_EXISTING);return staged;}finally{c.disconnect();Files.deleteIfExists(partial);}
 }
 public static void validate(Path file,UpdateManifest229.Release release)throws Exception{
  if(Files.size(file)!=release.size()||!InstallHelper229.hash(file).equals(release.sha256()))throw new SecurityException("Update hash mismatch");
  try(ZipFile jar=new ZipFile(file.toFile())){ZipEntry metadata=jar.getEntry("fabric.mod.json");if(metadata==null||metadata.getSize()>65536)throw new SecurityException("Invalid mod JAR");try(InputStream in=jar.getInputStream(metadata)){byte[] bytes=in.readNBytes(65537);if(bytes.length>65536)throw new SecurityException("Invalid mod metadata");JsonObject mod=JsonParser.parseString(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();if(!"duckswords".equals(mod.get("id").getAsString())||!release.version().equals(mod.get("version").getAsString()))throw new SecurityException("Wrong mod release");}}
 }
}
