package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.visuals.LegacyMarker225;
/** Static slot geometry prepared once. Item contents and highlights stay live. */
public final class InventoryPanel233 {
 private static Object texture;
 public static Object identifier(){throw new IllegalStateException("native inventory atlas Identifier");}
 public static boolean draw(class_332 c,int x,int y,boolean dark,int color){if(!(c instanceof LegacyMarker225.Blit blit))return false;if(texture==null)texture=identifier();if(dark)c.method_25294(x,y,x+170,y+62,color);int row=dark?66:2;GuiFace.begin(c);try{blit.duck$marker225(texture,x,x+170,y,y+62,2/256f,172/256f,row/256f,(row+62)/256f,-1);}finally{GuiFace.end(c);}return true;}
}
