package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.gui.GuiTransforms;import com.duckswords.visuals.LegacyMarker225;import java.util.*;
/** Immutable quadratic-alpha texture; only merged corner bands, never a column loop per frame. */
public final class GuiFade230 {
 private record Band(int y,int h,int inset){}
 private static final Map<Integer,List<Band>> CACHE=new HashMap<>();
 private static Object texture;
 private static List<Band> bands(int r){int n=r*2;int[] edge=new int[n];for(int x=0;x<n;x++){double dx=n-x-.5;edge[x]=(int)Math.round(n-Math.sqrt(Math.max(0,n*n-dx*dx)));}List<Band> rows=new ArrayList<>();int start=0,last=-1;for(int y=0;y<n;y++){int inset=0;while(inset<n&&edge[inset]>y)inset++;if(last!=inset){if(y>start)rows.add(new Band(start,y-start,last));start=y;last=inset;}}if(start<n)rows.add(new Band(start,n-start,last));return List.copyOf(rows);}
 private static void strip(LegacyMarker225.Blit blit,int left,int y,int right,int bottom,int width,int color){if(right<=left||bottom<=y)return;blit.duck$marker225(texture,left,right,y,bottom,left/(float)width,right/(float)width,2000/2048f,2001/2048f,color);}
 public static boolean draw(class_332 c,int x,int y,int w,int h,int radius,int color,float strength,float alpha){if(w<=0||h<=0||alpha<=0||strength<=0)return true;if(!((Object)c instanceof LegacyMarker225.Blit blit))return false;int r=Math.max(0,Math.min(radius,Math.min(w,h)/2));if(r>32)return false;if(texture==null)texture=GuiShapes229.identifier();int a=Math.round(Math.min(1,strength*alpha)*255);if(a==0)return true;color=(color&0xffffff)|a<<24;int width=w*2,height=h*2,n=r*2;GuiTransforms.push(c,x,y,.5f);GuiFace.begin(c);try{strip(blit,0,n,width,height-n,width,color);for(Band b:CACHE.computeIfAbsent(r,GuiFade230::bands)){strip(blit,b.inset,b.y,width-b.inset,b.y+b.h,width,color);strip(blit,b.inset,height-b.y-b.h,width-b.inset,height-b.y,width,color);}}finally{GuiFace.end(c);GuiTransforms.pop(c);}return true;}
}
