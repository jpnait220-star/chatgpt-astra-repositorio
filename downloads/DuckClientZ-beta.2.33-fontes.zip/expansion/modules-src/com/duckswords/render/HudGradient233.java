package com.duckswords.render;
import com.duckswords.theme.HudText;import com.duckswords.gui.HudTextCache220;import net.minecraft.class_332;import java.util.*;
/** Bounded glyph layout cache. Colors remain live, including animated gradients. */
public final class HudGradient233 {
 private record Plan(String[] glyphs,int[] offsets,float[] fractions){}
 private static final Map<String,Plan> CACHE=new LinkedHashMap<>(64,.75f,true){protected boolean removeEldestEntry(Map.Entry<String,Plan> e){return size()>256;}};
 private static String font="";private static volatile boolean dirty;
 public static void clear(){dirty=true;}
 private static Plan plan(String text){int count=text.codePointCount(0,text.length());String[] glyphs=new String[count];int[] offsets=new int[count];float[] fractions=new float[count];int at=0,x=0;for(int i=0;i<text.length();){int cp=text.codePointAt(i);String glyph=new String(Character.toChars(cp));glyphs[at]=glyph;offsets[at]=x;fractions[at]=count<=1?0:(float)at/(count-1);x+=HudText.width(glyph);at++;i+=Character.charCount(cp);}return new Plan(glyphs,offsets,fractions);}
 public static void draw(class_332 c,String text,int x,int y,int from,int to){String selected=HudTextCache220.font();if(dirty||!font.equals(selected)){CACHE.clear();font=selected;dirty=false;}Plan p=text.length()>1024?plan(text):CACHE.computeIfAbsent(text,HudGradient233::plan);for(int i=0;i<p.glyphs.length;i++)HudText.draw(c,p.glyphs[i],x+p.offsets[i],y,blend(from,to,p.fractions[i]));}
 public static int blend(int from,int to,float fraction){throw new IllegalStateException("original native gradient blend");}
}
