package com.duckswords.render;
import net.minecraft.class_332;
import com.duckswords.visuals.LegacyMarker225;
/** Four atlas corners and straight spans replace hundreds of per-pixel GUI submissions. */
public final class GuiShapes229 {
 private static Object texture;
 private static final int ATLAS_W=512,ATLAS_H=2048,MAX_RADIUS=32;
 public static Object identifier(){throw new IllegalStateException("native shape atlas Identifier");}
 private static boolean available(class_332 c,int radius,int thickness){return radius>0&&radius<=MAX_RADIUS&&thickness<=4&&(Object)c instanceof LegacyMarker225.Blit;}
 private static int row(int radius){return (radius-1)*(radius+4);}
 private static void corner(class_332 c,int x,int y,int radius,int kind,boolean right,boolean bottom,int color){
  if((color>>>24)==0)return;
  if(texture==null)texture=identifier();
  int n=radius*2,xx=kind*68+2,yy=row(radius)+2;
  float u0=xx/(float)ATLAS_W,u1=(xx+n)/(float)ATLAS_W,v0=yy/(float)ATLAS_H,v1=(yy+n)/(float)ATLAS_H;
  ((LegacyMarker225.Blit)(Object)c).duck$marker225(texture,x,x+radius,y,y+radius,right?u1:u0,right?u0:u1,bottom?v1:v0,bottom?v0:v1,color);
 }
 private static void corners(class_332 c,int x,int y,int w,int h,int r,int kind,boolean bottom,int first,int second){
  GuiFace.begin(c);
  try{corner(c,x,y,r,kind,false,false,first);corner(c,x+w-r,y,r,kind,true,false,second);if(bottom){corner(c,x,y+h-r,r,kind,false,true,first);corner(c,x+w-r,y+h-r,r,kind,true,true,second);}}finally{GuiFace.end(c);}
 }
 public static boolean rounded(class_332 c,int x,int y,int w,int h,int radius,int color){
  if(w<=0||h<=0||(color>>>24)==0)return true;
  int r=Math.max(0,Math.min(radius,Math.min(w,h)/2));if(!available(c,r,0))return false;
  c.method_25294(x,y+r,x+w,y+h-r,color);c.method_25294(x+r,y,x+w-r,y+r,color);c.method_25294(x+r,y+h-r,x+w-r,y+h,color);
  corners(c,x,y,w,h,r,0,true,color,color);return true;
 }
 public static boolean outline(class_332 c,int x,int y,int w,int h,int radius,int color){
  if(w<3||h<3||(color>>>24)==0)return true;int r=Math.max(1,Math.min(radius,Math.min(w,h)/2));if(!available(c,r,1))return false;
  c.method_25294(x+r,y,x+w-r,y+1,color);c.method_25294(x+r,y+h-1,x+w-r,y+h,color);c.method_25294(x,y+r,x+1,y+h-r,color);c.method_25294(x+w-1,y+r,x+w,y+h-r,color);
  corners(c,x,y,w,h,r,1,true,color,color);return true;
 }
 public static boolean top(class_332 c,int x,int y,int w,int r,int thickness,int first,int second){
  if(w<=2*r)return true;if(!available(c,r,thickness)||thickness<1)return false;
  corners(c,x,y,w,r*2,r,thickness,false,first,second);return true;
 }
}
