package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.visuals.LegacyMarker225;
/** Immutable artwork + color masks; at most two quads per clipped health segment. */
public final class HealthSprites232 {
 private static Object texture;
 public static Object identifier(){throw new IllegalStateException("native health atlas Identifier");}
 private static int index(String key){return switch(key){case "empty"->0;case "full"->1;case "intermediate"->2;case "poison"->3;case "wither"->4;case "frozen"->5;case "absorption"->6;default->-1;};}
 private static void quad(LegacyMarker225.Blit blit,int row,int column,int left,int right,int y,int color){int x=column*84+2,v=row*16+2;blit.duck$marker225(texture,left,right,y,y+9,(x+left)/512f,(x+right)/512f,v/128f,(v+9)/128f,color);}
 public static boolean draw(class_332 c,String key,int from,int to,int y,int color,boolean recolor,boolean gold){
  if(to<=from||(color>>>24)==0)return true;int row=index(key);if(row<0||!(c instanceof LegacyMarker225.Blit blit))return false;int left=Math.max(0,from),right=Math.min(80,to);if(right<=left)return true;
  if(texture==null)texture=identifier();GuiFace.begin(c);try{if(!recolor)quad(blit,row,0,left,right,y,color|0xffffff);else{int column=gold?3:1;quad(blit,row,column,left,right,y,color|0xffffff);quad(blit,row,column+1,left,right,y,color);}}finally{GuiFace.end(c);}return true;
 }
}
