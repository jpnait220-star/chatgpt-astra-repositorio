package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.theme.*;
/** Static controls: opening fade stays, pointer overlays/glow do not. */
public final class FeatureChrome233 {
 public static void card(class_332 c,int x,int y,int w,int h,boolean active,float alpha){Interface settings=Interface.get();float darkness=h==80&&settings!=null?settings.featureBackgroundDarkness.getFloat():0;int fill=DuckTheme.darken(active?DuckTheme.surfaceAlt():DuckTheme.surface(),darkness),border=active?DuckTheme.enabled():DuckTheme.border();MenuPanels223.panel(c,x,y,w,h,DuckTheme.fade(fill,alpha),DuckTheme.fade(border,alpha));}
 public static void toggle(class_332 c,int x,int y,int w,int h,boolean on,float alpha){int color=DuckTheme.menuButtonColor();MenuPanels223.panel(c,x,y,w,h,DuckTheme.fade(DuckTheme.surface(),alpha),DuckTheme.fade(on?color:DuckTheme.border(),alpha));String label=on?"ATIVADO":"DESATIVADO";HudText.draw(c,label,x+(w-HudText.width(label))/2,y+(h-8)/2+1,DuckTheme.fade(on?color:DuckTheme.textMuted(),alpha));}
}
