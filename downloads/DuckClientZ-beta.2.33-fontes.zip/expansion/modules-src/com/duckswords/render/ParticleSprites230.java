package com.duckswords.render;
import net.minecraft.class_332;
import com.duckswords.gui.GuiTransforms;
import com.duckswords.visuals.LegacyMarker225;
/** The same 12px alpha masks as the GUI run renderer, packed once at build time. */
public final class ParticleSprites230 {
 private static Object texture;
 public static Object identifier(){throw new IllegalStateException("native HUD particle atlas Identifier");}
 private static int index(String shape){return switch(shape){case "Coracoes"->1;case "Brilho"->2;case "Espadas"->3;case "Neve"->4;case "Vagalumes"->5;case "Classico"->6;case "Marcador"->7;default->0;};}
 public static boolean draw(class_332 c,String shape,float x,float y,float size,int color){
  if((color>>>24)==0||size<=0)return true;
  if(!((Object)c instanceof LegacyMarker225.Blit blit))return false;
  if(texture==null)texture=identifier();int start=index(shape)*16+2;
  GuiTransforms.push(c,x-size/2,y-size/2,size/12);GuiFace.begin(c);
  try{blit.duck$marker225(texture,0,12,0,12,start/128f,(start+12)/128f,2/16f,14/16f,color);}
  finally{GuiFace.end(c);GuiTransforms.pop(c);}return true;
 }
}
