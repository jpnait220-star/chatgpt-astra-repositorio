package com.duckswords.cosmetic;
import net.minecraft.class_4587;import java.util.Set;import com.duckswords.mixin.MixinSlimArms224;
/** Body origin follows the player; aura orientation ignores attack/placement torso twists. */
public final class AuraAnchor224 {
 private static final Set<String> AURAS=Set.of("sharkilzBubblesAura","theobaldMoneyAura","jan2025BlackHoleAura","jan2025SolarSystemAura","flameFragsFireRing","spring2025RainbowAura","gamerControllerAura","gamerJoystickAura","springSparklesAura","winter2024ShardsAura");
 public static boolean isAura(String id){return AURAS.contains(id);}
 public static void fit(float pivotX,class_4587 matrices,String id,Object model){if((id.equals("spring2025BoxingGloves")||id.equals("springClaws"))&&model instanceof MixinSlimArms224 arms&&arms.duck$slim224()){matrices.method_46416(pivotX>0?-.015625f:.015625f,0,0);matrices.method_22905(.75f,1,1);}}
 public static void apply(Object part,class_4587 matrices,String id,Object model){throw new IllegalStateException("native aura origin adapter");}
}
