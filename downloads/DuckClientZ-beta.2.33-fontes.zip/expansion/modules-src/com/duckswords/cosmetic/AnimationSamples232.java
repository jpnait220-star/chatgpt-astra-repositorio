package com.duckswords.cosmetic;
import java.util.List;
/** Captured into primitive locals before applying the pose; no arrays escape to renderers. */
public final class AnimationSamples232 {
 public interface Frame {float time();float[] vector();}
 private static final ThreadLocal<float[]> SCRATCH=ThreadLocal.withInitial(()->new float[3]);
 public static float[] scratch(){return SCRATCH.get();}
 public static void sample(List<?> frames,float time,float[] out,float fallback){
  if(frames==null||frames.isEmpty()){out[0]=out[1]=out[2]=fallback;return;}
  Frame first=(Frame)frames.get(0);float[] value;
  if(frames.size()==1||time<=first.time())value=first.vector();
  else{for(int i=1;i<frames.size();i++){Frame next=(Frame)frames.get(i);if(!(time<=next.time()))continue;Frame previous=(Frame)frames.get(i-1);float span=next.time()-previous.time(),progress=span<=0?1:(time-previous.time())/span;float[] a=previous.vector(),b=next.vector();for(int axis=0;axis<3;axis++)out[axis]=a[axis]+(b[axis]-a[axis])*progress;return;}value=((Frame)frames.get(frames.size()-1)).vector();}
  out[0]=value[0];out[1]=value[1];out[2]=value[2];
 }
}
