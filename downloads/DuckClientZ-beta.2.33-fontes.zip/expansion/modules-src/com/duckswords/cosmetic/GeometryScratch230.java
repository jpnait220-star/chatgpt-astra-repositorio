package com.duckswords.cosmetic;
import org.joml.Vector3f;
import org.joml.Vector4f;
/** Only for Duck's copied cube loop. All components are consumed as primitives
 * before calling a vertex consumer; neither temporary escapes to a consumer. */
public final class GeometryScratch230 {
 private static final class Scratch {
  final Vector3f normal=new Vector3f();
  final Vector4f position=new Vector4f();
 }
 private static final ThreadLocal<Scratch> LOCAL=ThreadLocal.withInitial(Scratch::new);
 public static Vector3f vector3(){return LOCAL.get().normal.zero();}
 public static Vector4f vector4(){return LOCAL.get().position.zero();}
}
