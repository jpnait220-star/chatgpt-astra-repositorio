package com.duckswords.cleaner;
/** Cache only the pure angle predicate. Camera mode/world/screen guards stay live. */
public final class ViewAngles233 {
 private static final class State {boolean ready,result;float ay,ap,py,pp,cy,cp;}
 private static final ThreadLocal<State> CACHE=ThreadLocal.withInitial(State::new);
 private static boolean interpolated(float actual,float previous,float current){double step=Math.IEEEremainder(current-previous,360),value=Math.IEEEremainder(actual-previous,360);return Double.isFinite(step)&&Double.isFinite(value)&&value>=Math.min(0,step)-1.5&&value<=Math.max(0,step)+1.5;}
 public static boolean normal(float actualYaw,float actualPitch,float previousYaw,float previousPitch,float currentYaw,float currentPitch){State s=CACHE.get();if(s.ready&&s.ay==actualYaw&&s.ap==actualPitch&&s.py==previousYaw&&s.pp==previousPitch&&s.cy==currentYaw&&s.cp==currentPitch)return s.result;s.ay=actualYaw;s.ap=actualPitch;s.py=previousYaw;s.pp=previousPitch;s.cy=currentYaw;s.cp=currentPitch;s.ready=true;return s.result=interpolated(actualYaw,previousYaw,currentYaw)&&interpolated(actualPitch,previousPitch,currentPitch);}
}
