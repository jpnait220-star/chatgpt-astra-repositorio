package com.duckswords.social;
import com.google.gson.*;import com.duckswords.modules.CosmeticsOnline;import java.util.*;import java.util.concurrent.*;
/** Public announcements use bounded background polling; administrator proof goes only to Mojang. */
public final class ClientAnnouncements229 {
 private record Notice(String id,String text){}
 private static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Duck-Announcements");t.setDaemon(true);return t;});
 private static final Queue<String> feedback=new ConcurrentLinkedQueue<>();
 private static volatile Notice pending;private static volatile boolean busy,first=true;private static volatile String seen="";private static volatile long next;private static long commandAfter;
 public static boolean ready(){throw new IllegalStateException("native world check");}
 public static void chat(String text){throw new IllegalStateException("native chat output");}
 public static void title(String text){throw new IllegalStateException("native title output");}
 public static void prove(String challenge)throws Exception{throw new IllegalStateException("native Mojang session proof");}
 private static void feedback(String text){if(feedback.size()<8)feedback.add(text);}
 public static boolean command(String raw){
  if(raw==null)return false;String value=raw.trim(),prefix="/anunciarclient";
  if(!value.equalsIgnoreCase(prefix)&&!(value.length()>prefix.length()&&value.regionMatches(true,0,prefix,0,prefix.length())&&Character.isWhitespace(value.charAt(prefix.length()))))return false;
  if(!"DuckTheKiller".equalsIgnoreCase(Community225.name())){feedback("[Duck] Apenas DuckTheKiller pode anunciar.");return true;}
  String text=value.substring(prefix.length()).trim();
  if(text.isEmpty()||text.length()>160||text.matches("(?s).*[\\p{Cntrl}§].*")){feedback("[Duck] Use /anunciarclient mensagem (ate 160 caracteres).");return true;}
  long now=System.nanoTime();if(busy||now<commandAfter){feedback("[Duck] Aguarde antes de anunciar novamente.");return true;}commandAfter=now+10_000_000_000L;busy=true;
  IO.execute(()->{try{JsonObject identity=new JsonObject();identity.addProperty("uuid",Community225.uuid());identity.addProperty("name",Community225.name());JsonObject result=JsonParser.parseString(CosmeticSharing.request(CosmeticsOnline.URL+"/announcement-challenge",identity.toString())).getAsJsonObject();String challenge=result.get("challenge").getAsString();if(!challenge.matches("[0-9a-f]{40}"))throw new IllegalStateException("Invalid challenge");prove(challenge);identity.addProperty("challenge",challenge);identity.addProperty("text",text);JsonObject sent=JsonParser.parseString(CosmeticSharing.request(CosmeticsOnline.URL+"/announce",identity.toString())).getAsJsonObject();if(!sent.get("ok").getAsBoolean())throw new IllegalStateException("Denied");first=false;next=0;feedback("[Duck] Anuncio enviado aos jogadores do client.");}catch(Exception e){feedback("[Duck] Falha no anuncio. Entre na conta original DuckTheKiller e tente novamente.");}finally{busy=false;}});return true;
 }
 public static void tick(){
  if(ready()){String text;while((text=feedback.poll())!=null)chat(text);Notice n=pending;if(n!=null){pending=null;chat("Duckzin falou: "+n.text);title(n.text);}}
  long now=System.nanoTime();if(busy||now<next)return;next=now+20_000_000_000L;busy=true;
  IO.execute(()->{try{JsonObject data=JsonParser.parseString(CosmeticSharing.request(CosmeticsOnline.URL+"/announcements",null)).getAsJsonObject();JsonElement value=data.get("announcement");if(value!=null&&!value.isJsonNull()){JsonObject n=value.getAsJsonObject();String id=n.get("id").getAsString(),text=n.get("text").getAsString();UUID.fromString(id);if(!seen.equals(id)&&!text.isBlank()&&text.length()<=160&&!text.matches("(?s).*[\\p{Cntrl}§].*")){seen=id;if(!first)pending=new Notice(id,text);}}first=false;}catch(Exception ignored){}finally{busy=false;}});
 }
}
