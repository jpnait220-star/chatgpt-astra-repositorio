package com.duckswords.gui;
import net.minecraft.*;import com.duckswords.update.ClientUpdater229;import com.duckswords.render.*;import com.duckswords.theme.HudText;
/** Non-blocking progress window; Escape continues while the background download finishes. */
public final class UpdateScreen229 extends DuckScreen {
 private final class_437 parent;
 public UpdateScreen229(class_437 parent){super("Atualizacao Duck");this.parent=parent;}
 private static String fit(String text,int width){int n=text.length();while(n>0&&HudText.width(text.substring(0,n))>width)n--;return text.substring(0,n);}
 public void method_25394(class_332 c,int mouseX,int mouseY,float delta){int w=Math.min(340,uiWidth()-20),h=156,x=(uiWidth()-w)/2,y=(uiHeight()-h)/2;pushScale(c);try{MenuPanels223.menu(c,x,y,w,h,0xfc131821,0xffd16079);HudText.draw(c,"ATUALIZACAO DUCK CLIENT",x+14,y+13,0xffff9eb7);HudText.draw(c,fit("Versao "+ClientUpdater229.version(),w-28),x+14,y+33,0xffbbc8dc);HudText.draw(c,fit(ClientUpdater229.status(),w-28),x+14,y+52,-1);RoundedPanel.draw(c,x+14,y+74,w-28,8,4,0xff283243);int progress=Math.max(0,Math.min(100,ClientUpdater229.percent()));RoundedPanel.draw(c,x+14,y+74,Math.max(0,(w-28)*progress/100),8,4,0xffd16079);HudText.draw(c,progress+"%",x+14,y+89,0xffc9d2e0);HudText.draw(c,fit("Depois do download, reinicie o Minecraft.",w-28),x+14,y+105,0xffffc98d);HudText.draw(c,fit("Sem reiniciar, voce continua na versao antiga.",w-28),x+14,y+118,0xffffc98d);HudText.draw(c,"ESC: continuar",x+14,y+140,0xff9faec3);}finally{popScale(c);}}
 public void method_25419(){class_310.method_1551().method_1507(parent);}
}
