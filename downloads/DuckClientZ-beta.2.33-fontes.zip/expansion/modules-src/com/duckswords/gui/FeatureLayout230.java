package com.duckswords.gui;
import com.duckswords.module.Module;import java.util.*;
/** One row-height pass per frame/input event; card coordinates are constant-time lookups. */
public final class FeatureLayout230 {
 public interface View {int duck$gridTop230();int duck$gridBottom230();int duck$columns230();int duck$scroll230();int duck$extraHeight230(Module module);}
 private static final Map<View,State> STATES=new WeakHashMap<>();
 private static final class State {boolean valid;List<Module> modules;int columns,size,content;int[] rows=new int[0];}
 public static void begin(View view){State state=STATES.get(view);if(state!=null)state.valid=false;}
 private static State layout(View view,List<Module> modules){State s=STATES.computeIfAbsent(view,k->new State());int cols=Math.max(1,view.duck$columns230());if(s.valid&&s.modules==modules&&s.size==modules.size()&&s.columns==cols)return s;s.valid=true;s.modules=modules;s.size=modules.size();s.columns=cols;int count=(s.size+cols-1)/cols;if(s.rows.length<count)s.rows=new int[count];int content=0;for(int row=0;row<count;row++){s.rows[row]=content;int height=80,limit=Math.min(s.size,(row+1)*cols);for(int i=row*cols;i<limit;i++)height=Math.max(height,80+view.duck$extraHeight230(modules.get(i)));content+=height;if(row+1<count)content+=20;}s.content=content;return s;}
 public static int cardY(View view,int index,List<Module> modules){State s=layout(view,modules);int row=index/s.columns;return view.duck$gridTop230()-view.duck$scroll230()+(row>=0&&row<(s.size+s.columns-1)/s.columns?s.rows[row]:0);}
 public static int maxScroll(View view,List<Module> modules){return Math.max(0,layout(view,modules).content-(view.duck$gridBottom230()-view.duck$gridTop230()));}
}
