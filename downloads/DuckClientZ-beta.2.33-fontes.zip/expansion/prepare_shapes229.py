from pathlib import Path
from PIL import Image
from math import sqrt,floor

# Match the existing half-pixel fill edge and 4x4 sampled stroke coverage.
atlas=Image.new('RGBA',(512,2048),(255,255,255,0))
for radius in range(1,33):
    n=radius*2
    yy=(radius-1)*(radius+4)+2
    for y in range(n):
        edge=n-sqrt(max(0,n*n-(n-y-.5)**2))
        left=floor(edge)
        alpha=floor(255*(1-(edge-left))+.5)
        for x in range(n):
            a=255 if x>left else alpha if x==left else 0
            atlas.putpixel((2+x,yy+y),(255,255,255,a))
            for thickness in range(1,5):
                inside=max(0,n-2*thickness)
                count=sum(inside**2 <= (n-x-(sx+.5)/4)**2+(n-y-(sy+.5)/4)**2 <= n*n for sx in range(4) for sy in range(4))
                atlas.putpixel((thickness*68+2+x,yy+y),(255,255,255,(count*255+8)//16))
for x in range(512):
    a=floor(((1-(x+.5)/512)**2)*255+.5)
    atlas.putpixel((x,2000),(255,255,255,a))
p=Path(__file__).parent/'resources/assets/duckswords/textures/gui/shapes229.png'
p.parent.mkdir(parents=True,exist_ok=True)
atlas.save(p)
print('PASS generated immutable 32-radius rounded fill/stroke atlas:',p.stat().st_size,'bytes')
