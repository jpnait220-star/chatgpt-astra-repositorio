# beta.2.33
User requested more HUD/inventory optimization, not only those, then specifically
players/entities. Implemented bounded exact glyph layout cache for HudText gradient
with original native color blend; static Inventory HUD slot atlas (82->1/28->2),
live contents/counts/highlights unchanged; HUD ThreadLocal null-entry reuse with
nested exception restoration; idle particle pool exit and per-draw setting snapshots;
Cleaner exact pure camera angle predicate cache per thread, while mode/world/screen/
Free Look/attached-camera guards remain live. No target selection cache or lower
cosmetic quality added. Existing232 changes preserved.

User requested restart warning and clarified via async: IN UPDATER WINDOW,
not cloud broadcast/chat. Added two notice lines and expanded dialog height.
No messages sent to other users via chat/announcement service. Old client windows
cannot change until updated; existing download/apply/backup/signature unchanged.

Tests: actual old/new gradient144 cases/version inclUnicode;1000 cached repeats
avoid width scans, font/reload/cache bounds. Actual old/new inventory16 pixel/item/
count comparisons perversion, styles/alpha/highlights.360000 native old camera
predicates perversion incl3 threads. Pool capacity/expiry/clear and idle. Updater
window progress0/50/100 and320/640 width;1000 nested failing HUD context restores.
NativeAPI/mixin/CRC, runtimeHUD/menu/mining/target, Cleaner and camera protections,
ring/glint, cosmeticbaker/animations and signed updater process-transition tests.
No GPU/Pojav/Dawn/Windows or actual FPS measurements. Do not promise total fix.

Publish immutable233 artifacts and update signed fixed manifest, verify all12
remote hashes and production /updates using trusted published229 verifier.

Latest steering: remove feature selection gradient/hover square, keep P intro;
1.20.1 feature/config lag and integrated-GPU reports. Added FeatureChrome233
static cards/toggles, DuckModsScreen hoverFade constant0; native original
opening fade and all input handlers compare bytecode-identical to232. Settings
color tracks use native vertical vertex gradients under90deg GUI transform,
split hue groups plus endpoint caps; no texture uploads/custom shaders.120
native old/new selector raster cases perversion:229->31 submissions, exact
alpha/markers/preview and <=1 channel rounding. Modifiable data/hitboxes same.
Actual RGB/HSB conversions reduced from per-column to per-selector snapshots.
New menu layout test uses actual final artifact. Await final packaging/pubchecks.
