from pathlib import Path
from zipfile import ZipFile
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v,e in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';out=B/'gui229-runtime'/v;out.mkdir(parents=True,exist_ok=True)
 mat='matrix' if new else 'matrix.matrix'
 def coord(x,y,axis):
  return f'{mat}.m'+('00' if axis==0 else '01')+f'()*{x}+{mat}.m'+('10' if axis==0 else '11')+f'()*{y}+{mat}.m'+('20' if new and axis==0 else '21' if new else '30' if axis==0 else '31')+'()'
 java=r'''import net.minecraft.*;import com.duckswords.render.*;import com.duckswords.visuals.*;import java.awt.image.BufferedImage;import javax.imageio.ImageIO;
 public class Shapes229Jvm {
 static class Reference extends class_332 {float[] pixels=new float[320*240];int draws;
 void span(float x,float y,float w,float h,int color){float px=COORDX,py=COORDY;float scale=SCALE;int xx=Math.round(px*2),yy=Math.round(py*2),ww=Math.round(w*scale*2),hh=Math.round(h*scale*2);float a=(color>>>24)/255f;for(int row=Math.max(0,yy);row<Math.min(240,yy+hh);row++)for(int col=Math.max(0,xx);col<Math.min(320,xx+ww);col++){int k=row*320+col;pixels[k]=a+pixels[k]*(1-a);}}
 public void method_25294(int x,int y,int right,int bottom,int color){draws++;span(x,y,right-x,bottom-y,color);}}
 static class Atlas extends Reference implements LegacyMarker225.Blit {BufferedImage atlas;Atlas()throws Exception{atlas=ImageIO.read(getClass().getResourceAsStream("/assets/duckswords/textures/gui/shapes229.png"));}
 public void duck$marker225(Object texture,int x1,int x2,int y1,int y2,float u0,float u1,float v0,float v1,int color){draws++;int w=(x2-x1)*2,h=(y2-y1)*2;for(int y=0;y<h;y++)for(int x=0;x<w;x++){int u=(int)((u0+(u1-u0)*(x+.5f)/w)*atlas.getWidth()),v=(int)((v0+(v1-v0)*(y+.5f)/h)*atlas.getHeight());int a=(atlas.getRGB(u,v)>>>24)*(color>>>24)/255;span(x1+x*.5f,y1+y*.5f,.5f,.5f,(color&0xffffff)|a<<24);}}}
 static void draw(class_332 c,int r,int mode,int color){if(mode==0)RoundedPanel.draw(c,9,13,100,80,r,color);else if(mode==1)SmoothOutline225.draw(c,9,13,100,80,r,color);else SmoothOutline225.top(c,9,13,100,r,mode-1,color,color);}
 public static void main(String[] args)throws Exception{int samples=0;for(int r:new int[]{1,2,5,8,11,16,32})for(int mode=0;mode<5;mode++)for(int a:new int[]{0,80,183,255}){Reference old=new Reference();Atlas now=new Atlas();draw(old,r,mode,a<<24|0x29abcd);draw(now,r,mode,a<<24|0x29abcd);for(int i=0;i<old.pixels.length;i++)if(Math.abs(old.pixels[i]-now.pixels[i])>.0041f)throw new AssertionError("coverage changed r="+r+" mode="+mode+" pixel="+i+" "+old.pixels[i]+" vs "+now.pixels[i]);if(now.draws>(mode==0?7:mode==1?8:2))throw new AssertionError("unbounded submissions");samples++;}Reference old=new Reference();Atlas now=new Atlas();RoundedPanel.draw(old,9,13,100,80,8,0xff101010);SmoothOutline225.draw(old,9,13,100,80,8,-1);RoundedPanel.draw(now,9,13,100,80,8,0xff101010);SmoothOutline225.draw(now,9,13,100,80,8,-1);System.out.println("PASS "+samples+" raster comparisons: original corner alpha, tint opacity and transparent interior preserved; panel submissions "+old.draws+" -> "+now.draws+" "+args[0]);}}
'''
 java=java.replace('COORDX',coord('x','y',0)).replace('COORDY',coord('x','y',1)).replace('SCALE',mat+'.m00()')
 p=out/'Shapes229Jvm.java';p.write_text(java)
 root=Path('/workspace/duckclientz-1.21.11' if new else '/workspace/duckclientz')
 cp=os.pathsep.join(map(str,[out,B/'ui226-runtime'/v,B/'runtime220'/v/'classes',e['jar'],root/'tools/joml.jar',root/'repair/stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old')]))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(p)],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'Shapes229Jvm',v],check=True)
