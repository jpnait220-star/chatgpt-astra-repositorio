from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,shutil
B=Path(__file__).parent;OUT=B/'release';OUT.mkdir(exist_ok=True)
P=Path('/workspace/duck-publish218/downloads');version='beta.2.32'
report=json.loads((B/'build-report.json').read_text())
assert set(report)=={'1.20.1','1.21.1','1.21.4','1.21.11'}
logs=['native232-check.log','startup232-check.log','artifact232-check.log','animation232-check.log','health232-check.log','runtime232-check.log','cosmetics232-check.log','render232-check.log','cleaner232-check.log','remote232-check.log','transition232-check.log']
validation='Duck Client beta.2.32 — validacao tecnica\n\nSem teste grafico de Minecraft, Pojav, Dawn ou medicao de FPS.\nTestes de bytecode/API real e JVM com endpoints de desenho substituidos por gravadores.\nOs testes do updater usam os helpers publicados da2.29 e os quatro JARs finais desta entrega.\n\n'
for name in logs:
 text=(B/name).read_text();assert 'PASS' in text and 'Traceback' not in text and 'Exception in thread' not in text,name
 validation+='\n'+name+'\n'+text
validation_path=OUT/'DuckClientZ-beta.2.32-VALIDACAO.txt';validation_path.write_text(validation)
readme=OUT/f'DuckClientZ-{version}-LEIA-ME.txt';shutil.copy2(B/'LEIA-ME232.txt',readme)
update=OUT/'DuckClientZ-update.json';shutil.copy2(OUT/'DuckClientZ-update232-draft.json',update)
def safe(path):
 return not any(part in {'.vercel','node_modules','__pycache__','.git'} or (part.startswith('.env') and part!='.env.example') for part in path.parts)
site=OUT/f'Duck-Connect-{version}-site.zip'
with ZipFile(site,'w',ZIP_DEFLATED) as z:
 for path in sorted((B/'cosmetics-relay').rglob('*')):
  if path.is_file() and safe(path):z.write(path,path.relative_to(B/'cosmetics-relay').as_posix())
 z.write(B/'PUBLICAR-SITE.txt','PUBLICAR-SITE.txt')
source=OUT/f'DuckClientZ-{version}-fontes.zip'
directories=['src','modules-src','modules-new-src','gui-old','gui-new','target-old','target-new','camera-double','camera-float','camera-native','compile-stubs','compile-stubs-new','resources','test-old','test-new','settings-test-src','safety-tests','native-regression-src','cosmetics-relay','native']
with ZipFile(source,'w',ZIP_DEFLATED) as z:
 for directory in directories:
  for path in sorted((B/directory).rglob('*')):
   if path.is_file() and safe(path) and path.suffix not in {'.class','.pyc'}:z.write(path,'expansion/'+path.relative_to(B).as_posix())
 for path in sorted(B.glob('*')):
  if path.is_file() and (path.suffix in {'.java','.py'} or path.name in {'LEIA-ME232.txt','CREDITOS.txt','LICENSE-REFERENCIA-SOUP.txt','README-FONTES.txt','PUBLICAR-SITE.txt','build-report.json','TASK232.md','scythe232.json','medal232.json','skull232.json','bubbles232.json','update-public229.txt'} or path.name.endswith('-manifest.json')):z.write(path,'expansion/'+path.name)
 z.write(validation_path,'VALIDACAO.txt')
 for parent,name in [(Path('/workspace/duckclientz/dist-fixes9'),'DuckClientZ-correcoes-fonte-beta.2.13-fixes.9.zip'),(Path('/workspace/duckclientz-1.21.11/dist'),'DuckClientZ-1.21.11-1.5.28-opt.2-fonte.zip')]:z.write(parent/name,'bases-fontes/'+name)
artifacts={}
for game,entry in report.items():
 path=Path(entry['jar']);assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
 with ZipFile(path) as z:assert json.loads(z.read('fabric.mod.json'))['version']=='1.5.28-'+version and z.testzip() is None
 artifacts[f'{game}/mods/{path.name}']=path.read_bytes()
artifacts.update({'LEIA-ME.txt':readme.read_bytes(),'CREDITOS.txt':(B/'CREDITOS.txt').read_bytes(),'LICENSE-REFERENCIA-SOUP.txt':(B/'LICENSE-REFERENCIA-SOUP.txt').read_bytes(),'validacao/VALIDACAO.txt':validation_path.read_bytes(),'validacao/build-report.json':(B/'build-report.json').read_bytes(),'fontes/'+source.name:source.read_bytes(),'site/'+site.name:site.read_bytes(),'update/DuckClientZ-update.json':update.read_bytes()})
def bundle(path,items):
 with ZipFile(path,'w',ZIP_DEFLATED) as z:
  for name,data in items.items():z.writestr(name,data)
  z.writestr('SHA256SUMS.txt',''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in items.items()))
 with ZipFile(path) as z:assert z.testzip() is None
allzip=OUT/f'DuckClientZ-{version}-4-versoes.zip';bundle(allzip,artifacts)
nativezip=OUT/f'DuckClientZ-1.21.11-{version}.zip';bundle(nativezip,{(name[len('1.21.11/'):] if name.startswith('1.21.11/') else name):data for name,data in artifacts.items() if name.startswith('1.21.11/') or name in {'LEIA-ME.txt','CREDITOS.txt','LICENSE-REFERENCIA-SOUP.txt','validacao/VALIDACAO.txt'}})
checksum=allzip.with_suffix('.zip.sha256');checksum.write_text(hashlib.sha256(allzip.read_bytes()).hexdigest()+'  '+allzip.name+'\n')
files=[Path(e['jar']) for e in report.values()]+[allzip,nativezip,source,site,readme,checksum,update,validation_path]
manifest={}
for path in files:
 dest=P/path.name
 if dest.exists() and path.name!='DuckClientZ-update.json':assert dest.read_bytes()==path.read_bytes(),'Immutable release filename exists with other bytes: '+path.name
 shutil.copy2(path,dest);manifest[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
(B/'release-manifest232.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS staged',len(files),'artifacts; final JAR hashes checked; ZIP CRC checked; signed updater uses final build')
