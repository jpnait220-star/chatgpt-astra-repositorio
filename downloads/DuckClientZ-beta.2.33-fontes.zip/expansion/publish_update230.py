from pathlib import Path
import json,subprocess,hashlib
B=Path(__file__).parent;report=json.loads((B/'build-report.json').read_text());releases={}
for game,e in report.items():
 p=Path(e['jar']);version=json.loads(__import__('zipfile').ZipFile(p).read('fabric.mod.json'))['version'];sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==e['sha256'];releases[game]={'version':version,'url':'https://raw.githubusercontent.com/jpnait220-star/chatgpt-astra-repositorio/asasa/downloads/'+p.name,'sha256':sha,'size':p.stat().st_size}
# A fixed public envelope is replaced at each release; immutable JAR names never change.
(B/'update-payload230.json').write_text(json.dumps({'protocol':1,'releases':releases},separators=(',',':')))
script="""import {readFileSync,writeFileSync} from 'node:fs';import {sign,createPrivateKey,createPublicKey} from 'node:crypto';const key=createPrivateKey(readFileSync('/workspace/duck-release-private/update-ed25519.pem'));const body=readFileSync('update-payload230.json');const publicKey=createPublicKey(key).export({type:'spki',format:'der'}).toString('base64');if(publicKey!==readFileSync('update-public229.txt','utf8').trim())throw Error('Signing key differs from client');writeFileSync('release/DuckClientZ-update230-draft.json',JSON.stringify({payload:body.toString('base64'),signature:sign(null,body,key).toString('base64')})+'\\n');"""
subprocess.run(['node','--input-type=module','-e',script],cwd=B,check=True)
print('PASS signed manifest for',len(releases),'exact game/JAR hashes; private key remains outside source/output')
