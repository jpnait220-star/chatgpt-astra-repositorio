from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io,hashlib,numpy as np
from render_cosmetic_icons223 import render,rotation
B=Path(__file__).parent;key='halloween2024SkullScythe';source='game/cosmetics/back/'+key
with ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip') as z:
 model=json.loads(z.read(source+'.geo.json'));g=model['minecraft:geometry'][0];by={b['name']:b for b in g['bones']};cache={}
 def tf(b):
  if b['name'] not in cache:cache[b['name']]=(tf(by[b['parent']]) if b.get('parent') in by else np.eye(4))@rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]))
  return cache[b['name']]
 candidates=[(b,c) for b in g['bones'] for c in b.get('cubes',[]) if not c.get('rotation')]
 bone,shaft=max(candidates,key=lambda bc:bc[1]['size'][1]/max(.5,bc[1]['size'][0]+bc[1]['size'][2]));center=np.array(shaft['origin'])+np.array(shaft['size'])/2;point=tf(bone)@np.append(center,1)
 points=[]
 for b in g['bones']:
  for cube in b.get('cubes',[]):
   lo=np.array(cube['origin']);hi=lo+np.array(cube['size']);mat=tf(b)@rotation(cube.get('rotation',[0,0,0]),cube.get('pivot',lo));points.extend((mat@np.array([x,y,z,1]))[:3] for x in (lo[0],hi[0]) for y in (lo[1],hi[1]) for z in (lo[2],hi[2]))
 minimum=np.array(points).min(0);delta=np.array([-point[0],18-point[1],3.25-minimum[2]])
 for b in g['bones']:
  if 'pivot' in b:b['pivot']=(np.array(b['pivot'])+delta).tolist()
  for c in b.get('cubes',[]):
   c['origin']=(np.array(c['origin'])+delta).tolist()
   if 'pivot' in c:c['pivot']=(np.array(c['pivot'])+delta).tolist()
 out=B/'resources/assets/duckswords/cosmetics'/key.lower();out.mkdir(parents=True,exist_ok=True);(out/'model.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
 image=Image.open(io.BytesIO(z.read(source+'.webp')));frames=[]
 for i in range(getattr(image,'n_frames',1)):
  image.seek(i);image.load();name='texture.png' if i==0 else f'frame_{i:03d}.png';image.convert('RGBA').save(out/name);frames.append({'file':name,'duration':max(20,min(5000,int(image.info.get('duration',100))))})
 p=B/'resources/assets/duckswords/cosmetics/animated-textures.json';table=json.loads(p.read_text());table[key]=frames;p.write_text(json.dumps(table,separators=(',',':'))+'\n');render(key,'back')
 (B/'skull230.json').write_text(json.dumps({'id':key,'name':'Foice Skull','translation':delta.tolist(),'texture_frames':len(frames),'source':'game.zip/'+source,'status':'original model/UVs and animation retained; alignment pending native animated-envelope check'},indent=2)+'\n')
 print('PASS imported original Skull scythe:',len(frames),'texture frames; animation untouched; exact rear alignment requires loop check')
