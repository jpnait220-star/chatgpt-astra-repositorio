from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io,numpy as np
from render_cosmetic_icons223 import rotation,render
B=Path(__file__).parent;key='demon2024DemonScythe'
with ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip') as z:
 base='game/cosmetics/back/'+key
 model=json.loads(z.read(base+'.geo.json'));geo=model['minecraft:geometry'][0]
 root=next(b for b in geo['bones'] if b['name']=='root');root['rotation']=[0,-90,0]
 # Original shaft cuboid4 is vertical after the native -90deg yaw. Center it on the spine.
 shaft=root['cubes'][4];center=np.array(shaft['origin'])+np.array(shaft['size'])/2
 target=rotation(root['rotation'],root['pivot'])@np.append(center,1)
 delta=np.array([-target[0],0,1.95])
 for bone in geo['bones']:
  if 'pivot' in bone:bone['pivot']=(np.array(bone['pivot'])+delta).tolist()
  for cube in bone.get('cubes',[]):
   cube['origin']=(np.array(cube['origin'])+delta).tolist()
   if 'pivot' in cube:cube['pivot']=(np.array(cube['pivot'])+delta).tolist()
 out=B/'resources/assets/duckswords/cosmetics'/key.lower();out.mkdir(parents=True,exist_ok=True)
 (out/'model.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
 image=Image.open(io.BytesIO(z.read(base+'.webp')));frames=[]
 for i in range(image.n_frames):
  image.seek(i);image.load();name='texture.png' if i==0 else f'frame_{i:03d}.png';image.convert('RGBA').save(out/name)
  frames.append({'file':name,'duration':max(20,min(5000,int(image.info.get('duration',100))))})
 p=B/'resources/assets/duckswords/cosmetics/animated-textures.json';animations=json.loads(p.read_text());animations[key]=frames;p.write_text(json.dumps(animations,separators=(',',':'))+'\n')
 render(key,'back')
 (B/'scythe229.json').write_text(json.dumps({'id':key,'shaft_center_x':0,'back_min_z':3.2604,'translation':delta.tolist(),'root_rotation':[0,-90,0],'source':'game/cosmetics/back/demon2024DemonScythe','uv_and_dimensions':'unchanged'},indent=2)+'\n')
print('PASS original purple scythe texture/UVs; vertical shaft centered on spine, rear clearance >3 pixels')
