from pathlib import Path
import json
from generate_hooks import catalog
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 m,f,_,_=catalog(v);api={}
 for key,cls,name in [('command','net.minecraft.client.gui.screens.ChatScreen','handleChatInput'),('title','net.minecraft.client.gui.Gui','setTitle'),('subtitle','net.minecraft.client.gui.Gui','setSubtitle'),('times','net.minecraft.client.gui.Gui','setTimes'),('chat','net.minecraft.client.gui.components.ChatComponent','addMessage'),('chatHud','net.minecraft.client.gui.Gui','getChat'),('token','net.minecraft.client.User','getAccessToken'),('uuid','net.minecraft.client.User','getProfileId')]:
  rows=m(cls,name)
  if key=='chat':rows=[r for r in rows if r[2]=='(Lnet/minecraft/class_2561;)V']
  assert len(rows)==1,(v,key,rows)
  api[key]=rows[0][:3]
 api['hud']=f('net.minecraft.client.Minecraft','gui')
 if v=='1.20.1':api['profile']=m('net.minecraft.client.User','getGameProfile')[0][:3]
 (B/'native'/v/'announcements229.json').write_text(json.dumps(api,indent=2)+'\n')
