from pathlib import Path
from PIL import Image
B=Path(__file__).parent;atlas=Image.new('RGBA',(512,128),(255,255,255,0))
for row,key in enumerate(['empty','full','intermediate','poison','wither','frozen','absorption']):
 im=Image.open(B/'resources/assets/duckswords/healthbar'/f'{key}.png').convert('RGBA');assert im.size==(80,9)
 atlas.paste(im,(2,row*16+2))
 for gold in [False,True]:
  base=Image.new('RGBA',im.size,(255,255,255,0));tint=base.copy()
  for y in range(9):
   for x in range(80):
    r,g,b,a=im.getpixel((x,y));selected=(r>100 and g>80 and b<g*.65) if gold else (r>80 and r>g*1.4 and r>b*1.4)
    if selected:
     v=max(r,g) if gold else r;tint.putpixel((x,y),(v,v,v,a))
    else:base.putpixel((x,y),(r,g,b,a))
  column=3 if gold else 1;atlas.paste(base,(column*84+2,row*16+2));atlas.paste(tint,((column+1)*84+2,row*16+2))
atlas.save(B/'resources/assets/duckswords/textures/gui/health232.png')
