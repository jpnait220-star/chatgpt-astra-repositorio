from pathlib import Path
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
main=r'''public static void main(String[] args)throws Exception{int n=0;for(int[] size:new int[][]{{250,80,7},{126,18,7},{100,40,5},{22,17,7},{160,54,0}})for(float strength:new float[]{0,.3f,1})for(float alpha:new float[]{0,.12f,.5f,1}){Reference old=new Reference();Atlas now=new Atlas();RoundedFade225.draw(old,9,13,size[0],size[1],size[2],0xff29abcd,strength,alpha);RoundedFade225.draw(now,9,13,size[0],size[1],size[2],0xff29abcd,strength,alpha);float tolerance=Math.min(1,strength*alpha)*8/(size[0]*2)+.008f;for(int k=0;k<old.pixels.length;k++)if(Math.abs(old.pixels[k]-now.pixels[k])>tolerance)throw new AssertionError("fade/raster changed beyond original8-column quantization "+java.util.Arrays.toString(size)+" "+k+" "+old.pixels[k]+" vs "+now.pixels[k]);if(now.draws>29)throw new AssertionError("unbounded gradient submissions "+now.draws);if(alpha==0||strength==0){if(now.draws!=0)throw new AssertionError("transparent fade submits geometry");}n++;}Reference old=new Reference();Atlas now=new Atlas();RoundedFade225.draw(old,9,13,250,80,7,0xff29abcd,1,1);RoundedFade225.draw(now,9,13,250,80,7,0xff29abcd,1,1);System.out.println("PASS "+n+" gradient comparisons: original rounded clipping and opacity falloff retained within old8-column quantization; zero-alpha skips geometry; submissions "+old.draws+" -> "+now.draws+" "+args[0]);}}'''
for v,e in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';out=B/'fade230-runtime'/v;out.mkdir(parents=True,exist_ok=True)
 s=(B/'gui229-runtime'/v/'Shapes229Jvm.java').read_text();s=s[:s.index(' public static void main')]+main
 s=s.replace('Shapes229Jvm','Fade230Jvm').replace('320*240','1024*512').replace('Math.min(240','Math.min(512').replace('Math.min(320','Math.min(1024').replace('row*320','row*1024')
 matrix='matrix' if new else 'matrix.matrix'
 s=s.replace('int w=(x2-x1)*2,h=(y2-y1)*2;', 'float scale='+matrix+'.m00();int w=Math.round((x2-x1)*scale*2),h=Math.round((y2-y1)*scale*2);float dx=(x2-x1)/(float)w,dy=(y2-y1)/(float)h;')
 s=s.replace('span(x1+x*.5f,y1+y*.5f,.5f,.5f,','span(x1+x*dx,y1+y*dy,dx,dy,')
 p=out/'Fade230Jvm.java';p.write_text(s)
 root=Path('/workspace/duckclientz-1.21.11' if new else '/workspace/duckclientz');cp=os.pathsep.join(map(str,[out,B/'ui226-runtime'/v,B/'runtime220'/v/'classes',e['jar'],root/'tools/joml.jar',root/'repair/stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old')]))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(p)],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'Fade230Jvm',v],check=True)
