from pathlib import Path
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
cp=os.pathsep.join(map(str,[B/'classes',B/'tools/mixin-loader-0.19.3.jar',B/'tools/mixinextras-fabric-0.5.4.jar',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(B/'classes'),str(B/'TestAnnotations229.java')],check=True)
subprocess.run(['java','-Xverify:all','-cp',cp,'TestAnnotations229',str(B/'dist/DuckClientZ-1.20.1-1.5.28-beta.2.28.jar'),'broken'],check=True)
for v,e in json.loads((B/'build-report.json').read_text()).items():
    subprocess.run(['java','-Xverify:all','-cp',cp,'TestAnnotations229',e['jar'],'fixed'],check=True)
