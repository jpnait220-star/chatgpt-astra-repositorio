from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import io,json,os,subprocess,ast
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');key='demon2024DemonScythe';folder='assets/duckswords/cosmetics/'+key.lower()+'/'
source=ZipFile('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip');original=json.loads(source.read('game/cosmetics/back/'+key+'.geo.json'));image=Image.open(io.BytesIO(source.read('game/cosmetics/back/'+key+'.webp')))
tree=ast.parse((B/'test_aura227.py').read_text());java=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='java' for t in n.targets));java=java[:java.index(' public static void main')].replace('Aura227Tests','Scythe229Tests')+r''' public static void main(String[] args)throws Exception{Class<?> renderer=Class.forName(args[0]);Method load=renderer.getDeclaredMethod("load",String.class);load.setAccessible(true);Object baked=load.invoke(null,"demon2024DemonScythe");if(baked==null)throw new AssertionError("missing scythe");Field parts=baked.getClass().getDeclaredField("parts");parts.setAccessible(true);Bounds b=new Bounds();for(Object part:((Map<?,?>)parts.get(baked)).values())walk((class_630)part,new Matrix4f(),b);if(b.lowZ<3.24||b.highZ>6||b.high-b.low<31||b.high-b.low>33)throw new AssertionError("back alignment "+b.lowZ+".."+b.highZ+" height "+(b.high-b.low));if(!com.duckswords.cosmetic.CosmeticCatalog222.IDS.contains("demon2024DemonScythe"))throw new AssertionError("not selectable");System.out.printf(java.util.Locale.ROOT,"PASS actual native scythe bake: back depth %.3f..%.3fpx, height %.3fpx; selectable original model %s%n",b.lowZ,b.highZ,b.high-b.low,args[1]);}}'''
for v,e in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(e['jar']) as z:
  model=json.loads(z.read(folder+'model.json'));bones=model['minecraft:geometry'][0]['bones'];old=original['minecraft:geometry'][0]['bones'];assert len(bones)==len(old)
  assert bones[1]['rotation']==[0,-90,0]
  for a,b in zip(bones,old):
   for c,d in zip(a.get('cubes',[]),b.get('cubes',[])):
    assert c['uv']==d['uv'] and c['size']==d['size'] and c.get('rotation')==d.get('rotation')
  frames=json.loads(z.read('assets/duckswords/cosmetics/animated-textures.json'))[key];assert len(frames)==image.n_frames
  for i,row in enumerate(frames):
   image.seek(i);image.load();actual=Image.open(io.BytesIO(z.read(folder+row['file']))).convert('RGBA');assert actual.tobytes()==image.convert('RGBA').tobytes();assert row['duration']==max(20,min(5000,int(image.info.get('duration',100))))
 out=B/'scythe229-runtime'/v;out.mkdir(parents=True,exist_ok=True);p=out/'Scythe229Tests.java';p.write_text(java);new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair')
 cp=os.pathsep.join(map(str,[out,B/'aura227-runtime'/v,B/'cosmetics226-runtime'/v/'classes',e['jar'],r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),T/'gson.jar',r.parent/'tools/joml.jar',T/'slf4j-api-2.0.9.jar',T/'slf4j-simple-2.0.9.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(p)],check=True);subprocess.run(['java','-Xverify:all','-cp',cp,'Scythe229Tests','com.duckswords.cosmetic.'+('ModelCosmeticRenderer' if new else 'ModelCosmeticRenderer1211'),v],check=True)
 print('PASS original purple scythe 13 cuboids/UVs and all7 texture frames/timings preserved',v)
