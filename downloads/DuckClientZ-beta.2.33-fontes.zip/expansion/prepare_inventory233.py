from pathlib import Path
from PIL import Image,ImageDraw
B=Path(__file__).parent;atlas=Image.new('RGBA',(256,256),(255,255,255,0))
for dark in [False,True]:
 im=Image.new('RGBA',(170,62),(255,255,255,0) if dark else (198,198,198,255));draw=ImageDraw.Draw(im)
 for i in range(27):
  x=4+i%9*18;y=4+i//9*18
  if dark:draw.rectangle((x,y,x+17,y+17),fill=(52,59,73,128))
  else:
   draw.rectangle((x,y,x+17,y+17),fill=(55,55,55,255));draw.rectangle((x+1,y+1,x+17,y+17),fill=(255,255,255,255));draw.rectangle((x+1,y+1,x+16,y+16),fill=(139,139,139,255))
 atlas.paste(im,(2,66 if dark else 2))
atlas.save(B/'resources/assets/duckswords/textures/gui/inventory233.png')
