from pathlib import Path
import os,subprocess,json
from zipfile import ZipFile
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');out=B/'updater229-runtime';out.mkdir(exist_ok=True)
p=out/'UpdateParent229.java';p.write_text('public class UpdateParent229 {public static void main(String[] args)throws Exception{System.in.read();}}')
cp=os.pathsep.join(map(str,[out,T/'gson.jar']))
with ZipFile(B/'dist/DuckClientZ-1.20.1-1.5.28-beta.2.29.jar') as z:
 for name in z.namelist():
  if name.startswith('com/duckswords/update/') and not name.endswith('ClientUpdater229.class'):
   data=z.read(name);assert int.from_bytes(data[6:8],'big')<=61
   dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
files=[B/'TestUpdater229.java',p]
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,files)],check=True)
subprocess.run(['java','-Xverify:all','-cp',cp,'TestUpdater229',str(out/'files')],check=True)
