package com.duckswords.render;
import net.minecraft.class_332;
/** Cached corner spans. Straight edges stay single rectangles, regardless of panel height. */
public final class MenuPanels223 {
 public static void outline(class_332 c,int x,int y,int w,int h,int radius,int color){SmoothOutline225.draw(c,x,y,w,h,radius,color);}
 public static void box(class_332 c,int x,int y,int w,int h,int radius,int fill,int border){RoundedPanel.draw(c,x,y,w,h,radius,fill);outline(c,x,y,w,h,radius,border);}
 public static void panel(class_332 c,int x,int y,int w,int h,int fill,int border){box(c,x,y,w,h,Math.min(8,h/2),fill,border);}
 public static void background(class_332 c,int x,int y,int w,int h,int fill,int border){box(c,x,y,w,h+10,11,fill,border);}
 public static void menu(class_332 c,int x,int y,int w,int h,int fill,int border){box(c,x,y,w,h,11,fill,border);}
 public static void gradientAdapter(class_332 c,int x,int y,int w,int h,int first,int second){throw new IllegalStateException("native theme adapter");}
 public static void accentLine(class_332 c,int x,int y,int w,int h,int first,int second){if(w>22){SmoothOutline225.top(c,x,y,w,11,h,first,second);gradientAdapter(c,x+11,y,w-22,h,first,second);}}
 public static void listScroll(class_332 c,int left,int top,int right,int bottom,int color){RoundedPanel.draw(c,left+1,top,right-left,bottom-top,1,color);}
 public static void horizontalFade(class_332 c,int x,int y,int w,int h,int color,float strength,float alpha){RoundedFade225.draw(c,x+1,y+1,w-2,h-2,Math.min(7,(h-2)/2),color,strength,alpha);}

 public static int hoverColor(){throw new IllegalStateException("native theme adapter");}
 public static void hover(class_332 c,int x,int y,int w,int h,float alpha){int color=hoverColor();int opacity=Math.min(255,Math.max(0,(int)(alpha*255)));RoundedFade225.draw(c,x+1,y+1,w-2,h-2,Math.min(7,(h-2)/2),color,1,alpha);}
 public static void glow(class_332 c,int x,int y,int w,int h,int color,float alpha){int opacity=Math.min(70,Math.max(0,(int)(alpha*255)));RoundedPanel.draw(c,x-1,y-1,w+2,h+2,Math.min(9,(h+2)/2),color&0xffffff|opacity<<24);}
}
