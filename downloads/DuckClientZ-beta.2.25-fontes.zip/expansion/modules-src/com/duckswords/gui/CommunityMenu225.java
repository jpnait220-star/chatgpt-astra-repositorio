package com.duckswords.gui;
import com.duckswords.social.Community225;import com.duckswords.render.*;import com.duckswords.theme.HudText;import net.minecraft.*;
public final class CommunityMenu225 {
 public static void draw(class_332 c,int center,int y){Community225.tick();MenuPanels223.box(c,center-14,y,28,26,8,0xff202b3b,0xff53647a);RoundedPanel.draw(c,center-8,y+6,16,10,4,0xffd1dce9);c.method_25294(center-5,y+14,center-2,y+19,0xffd1dce9);int n=Community225.online();String label=n<0?Community225.status():n+(n==1?" pessoa usando o mod":" pessoas usando o mod");int x=center-HudText.width(label)/2;RoundedPanel.draw(c,x-9,y+34,4,4,2,n<0?0xff929baa:0xff51e68b);HudText.draw(c,label,x,y+32,0xffb8c6d8);}
 public static boolean click(class_437 parent,int x,int y,int center,int top){if(x<center-14||x>=center+14||y<top||y>=top+26)return false;class_310.method_1551().method_1507(new CommunityScreen225(parent));return true;}
}
