from pathlib import Path
import json,subprocess,os
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');cp=os.pathsep.join(map(str,[B/'classes',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',T/'asm-commons-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',cp,'-d',str(B/'classes'),str(B/'TestGeometry217.java')],check=True)
for v,e in json.loads((B/'build-report.json').read_text()).items():
 t=Path('/workspace/duckclientz-1.21.11/tools') if v=='1.21.11' else T
 subprocess.run(['java','-Xverify:all','-cp',cp,'TestGeometry217',e['jar'],str(t/'minecraft-client' if v=='1.21.11' else t/f'minecraft-{v}-client'),str(t/'intermediary.tiny' if v=='1.21.11' else t/f'intermediary-{v}.tiny')],check=True)
