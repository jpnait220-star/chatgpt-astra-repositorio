from pathlib import Path
from zipfile import ZipFile
from PIL import Image,ImageDraw
from collections import deque
import io,json
B=Path(__file__).parent;out=B/'resources/assets/duckswords/textures/gui/icons';keys=['targethighlight','sprintkeeper','hitparticles','customkills','targethud','watermark','sessiontimer','customglint','health'];report={};sheet=Image.new('RGBA',(1024,960),(48,50,58,255));draw=ImageDraw.Draw(sheet)
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.17.jar') as z:
 for index,key in enumerate(keys):
  old=Image.open(io.BytesIO(z.read('assets/duckswords/textures/gui/icons/'+key+'.png'))).convert('RGBA');im=old.copy();w,h=im.size
  def gray(p):return p[3]>0 and min(p[:3])>=50 and max(p[:3])-min(p[:3])<=85
  def outside(x,y):p=old.getpixel((x,y));return p[3]<20 or gray(p)
  q=deque();seen=set()
  # Seed every transparent region, including the empty interior of a crosshair.
  for x in range(w):
   for y in range(h):
    if old.getpixel((x,y))[3]<20:seen.add((x,y));q.append((x,y))
  while q:
   x,y=q.popleft()
   for xx,yy in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if 0<=xx<w and 0<=yy<h and (xx,yy) not in seen and outside(xx,yy):seen.add((xx,yy));q.append((xx,yy))
  changed=[]
  for x,y in sorted(seen):
   p=old.getpixel((x,y))
   if not gray(p):continue
   # Preserve the pastel centers of the tiny particle dots; only their fringe is matte.
   if key=="hitparticles" and any((x-cx)**2+(y-cy)**2<=4 for cx,cy in [(43,26),(98,33),(104,65),(79,107),(17,66),(35,100),(29,63),(71,92)]):continue
   if not any(0<=x+dx<w and 0<=y+dy<h and old.getpixel((x+dx,y+dy))[3]<20 for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(2,0),(-2,0),(0,2),(0,-2),(1,1),(-1,1),(1,-1),(-1,-1)]):continue
   near=[]
   for dy in range(-3,4):
    for dx in range(-3,4):
     xx,yy=x+dx,y+dy
     if 0<=xx<w and 0<=yy<h:
      n=old.getpixel((xx,yy))
      if n[3]>=220 and n[0]<50 and n[1]<100 and 35<=n[2]<170:near.append((dx*dx+dy*dy,xx,yy,n))
   if near or key=="targethud":
    c=min(near)[-1] if near else (18,53,87,255);im.putpixel((x,y),(*c[:3],p[3]));
    if im.getpixel((x,y))!=p:changed.append([x,y])
  assert im.getchannel('A').tobytes()==old.getchannel('A').tobytes();im.save(out/(key+'.png'));report[key]={'pixels':changed,'modified':len(changed),'alpha_preserved':True}
  x=index%4*256;y=index//4*320;sheet.alpha_composite(im.resize((256,256),Image.Resampling.NEAREST),(x,y));draw.text((x+5,y+265),key,fill='white')
(B/'icon218-report.json').write_text(json.dumps(report,indent=2)+'\n');sheet.save('/tmp/icons218-after.png');print({k:r['modified'] for k,r in report.items()})
