package com.duckswords.camera;
import com.duckswords.DucksWordsClient;import com.duckswords.modules.RecordingCamera;import net.minecraft.class_310;
public final class FreeLookControl{
 private static float distance=4f;
 public static RecordingCamera camera(){class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1755!=null)return null;RecordingCamera camera=DucksWordsClient.MODULES.get(RecordingCamera.class);return camera!=null&&camera.isEnabled()&&camera.isCameraActive()?camera:null;}
 public static boolean look(Object entity,double dx,double dy){if(entity!=class_310.method_1551().field_1724)return false;RecordingCamera camera=camera();if(camera==null||!CameraOptions.locked(camera))return false;if(Double.isFinite(dx)&&Double.isFinite(dy))camera.rotate(dx,dy);return true;}
 public static float distance(RecordingCamera camera){return distance;}
 public static boolean scroll(double amount){RecordingCamera camera=camera();if(camera==null||!CameraOptions.scrolling(camera)||!Double.isFinite(amount))return false;distance=Math.max(0.5f,Math.min(10f,distance-(float)amount*0.5f));return true;}
}
