from pathlib import Path
from zipfile import ZipFile
from PIL import Image
from collections import deque
import io,json
B=Path(__file__).parent;OUT=B/'resources/assets/duckswords/textures/gui/icons';OUT.mkdir(parents=True,exist_ok=True)
# Inspected, outlined artwork only. Never remove alpha or flood the icon interior.
SELECTED=['combocounter','customglint','fullbright','health','killfeed','scoreboard','sprintkeeper','swing','watermark','clock','clicksounds','cameragravacao']
report={}
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.16.jar') as z:
 names=[n for n in z.namelist() if '/gui/icons/' in n and n.endswith('.png')]
 for name in names:
  key=Path(name).stem;old=Image.open(io.BytesIO(z.read(name))).convert('RGBA');w,h=old.size
  if key not in SELECTED:report[key]={'reviewed':True,'modified':0};continue
  data=list(old.getdata());seen=set();q=deque()
  def light(p):return p[3]>0 and min(p[:3])>=150 and max(p[:3])-min(p[:3])<=48
  def passable(x,y):p=data[y*w+x];return p[3]==0 or light(p)
  for y in range(h):
   for x in [0,w-1]:
    if passable(x,y):seen.add((x,y));q.append((x,y))
  for x in range(w):
   for y in [0,h-1]:
    if passable(x,y):seen.add((x,y));q.append((x,y))
  while q:
   x,y=q.popleft()
   for xx,yy in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
    if 0<=xx<w and 0<=yy<h and (xx,yy) not in seen and passable(xx,yy):seen.add((xx,yy));q.append((xx,yy))
  im=old.copy();changed=[]
  for x,y in seen:
   p=data[y*w+x]
   if not light(p):continue
   nearest=[]
   for dy in range(-2,3):
    for dx in range(-2,3):
     xx,yy=x+dx,y+dy
     if not(0<=xx<w and 0<=yy<h):continue
     n=data[yy*w+xx]
     if n[3]>=128 and max(n[:3])<130:nearest.append((dx*dx+dy*dy,n))
   if not nearest:continue
   nearest.sort(key=lambda n:n[0]);n=nearest[0][1];im.putpixel((x,y),(*n[:3],p[3]));changed.append([x,y])
  assert old.getchannel('A').tobytes()==im.getchannel('A').tobytes()
  if changed:im.save(OUT/(key+'.png'))
  report[key]={'reviewed':True,'modified':len(changed),'pixels':changed,'alpha_preserved':True}
(B/'icon217-report.json').write_text(json.dumps(report,indent=2)+'\n');print('Reviewed',len(report),'icons; exterior white fringe recolored:',{k:v['modified'] for k,v in report.items() if v['modified']})
