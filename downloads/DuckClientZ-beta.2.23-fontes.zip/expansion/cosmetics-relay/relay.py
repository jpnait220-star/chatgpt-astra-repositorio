"""Optional small Duck cosmetics relay. No Minecraft account credentials; UUIDs are self-declared.
For private/testing use. Add account verification and an HTTPS reverse proxy before public hosting.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from threading import Lock
import argparse, json, re, time, uuid
PROFILES = {}
LOCK = Lock()
TTL = 120
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def response(self, code, body):
        data = json.dumps(body, separators=(',', ':')).encode()
        self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(data))); self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path)
        if path.path != '/profiles': return self.response(404, {})
        ids=parse_qs(path.query).get('ids', [''])[0].split(',')
        if len(ids)>32 or len(self.path)>4096:return self.response(400,{})
        try: ids=[str(uuid.UUID(s)) for s in ids if s]
        except ValueError:return self.response(400,{})
        now=time.monotonic()
        with LOCK:
            for key in list(PROFILES):
                if now-PROFILES[key][0]>TTL:del PROFILES[key]
            data={key:PROFILES[key][1] for key in ids if key in PROFILES}
        self.response(200,data)
    def do_POST(self):
        if self.path!='/profile':return self.response(404,{})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=16384:return self.response(413,{})
            data=json.loads(self.rfile.read(size));key=str(uuid.UUID(data['uuid']));ids=data['cosmetics']
            if not isinstance(ids,list) or len(ids)>32 or any(not isinstance(s,str) or not re.fullmatch('[A-Za-z0-9_]{1,64}',s) for s in ids):return self.response(400,{})
        except (ValueError,KeyError,TypeError):return self.response(400,{})
        with LOCK:
            now=time.monotonic()
            for old in list(PROFILES):
                if now-PROFILES[old][0]>TTL:del PROFILES[old]
            if len(PROFILES)>=2048 and key not in PROFILES:return self.response(503,{})
            PROFILES[key]=(now,list(dict.fromkeys(ids)))
        self.response(200,{'ok':True})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bind',default='127.0.0.1');p.add_argument('--port',type=int,default=8765);args=p.parse_args();ThreadingHTTPServer((args.bind,args.port),Handler).serve_forever()
