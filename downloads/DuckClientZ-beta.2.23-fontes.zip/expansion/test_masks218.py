from pathlib import Path
from zipfile import ZipFile
import subprocess,json,os,hashlib,concurrent.futures
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');audio=B/'audio218-runtime';audio.mkdir(exist_ok=True);seen=set();star=None
probe='''import java.lang.reflect.*;import java.io.*;import java.util.*;import com.duckswords.visuals.TargetHudParticles;import com.duckswords.particles.VisualParticles;
public class MaskTests218 {public static void main(String[] args)throws Exception{Method load=TargetHudParticles.class.getDeclaredMethod("load",String.class);load.setAccessible(true);int before=0,after=0;for(int n=0;n<VisualParticles.SHAPES.length;n++){String key=VisualParticles.KEYS[n];int[] expected=new int[144],actual=new int[144];try(var in=new DataInputStream(TargetHudParticles.class.getResourceAsStream("/assets/duckswords/gui-particles/"+key+".bin"))){int count=in.readUnsignedShort();before+=count;for(int i=0;i<count;i++){int x=in.readUnsignedByte(),y=in.readUnsignedByte(),w=in.readUnsignedByte(),a=in.readUnsignedByte();for(int xx=x;xx<x+w;xx++)expected[y*12+xx]=a;}}Object sprite=load.invoke(null,VisualParticles.SHAPES[n]);Method runs=sprite.getClass().getDeclaredMethod("runs");runs.setAccessible(true);for(Object run:(List<?>)runs.invoke(sprite)){int[] v=new int[5];int i=0;for(String name:new String[]{"x","y","w","h","a"}){Method m=run.getClass().getDeclaredMethod(name);m.setAccessible(true);v[i++]=(int)m.invoke(run);}for(int y=v[1];y<v[1]+v[3];y++)for(int x=v[0];x<v[0]+v[2];x++)actual[y*12+x]=v[4];after++;}if(!Arrays.equals(expected,actual))throw new AssertionError("Changed mask "+key);}if(after>=before)throw new AssertionError("No reduction");System.out.println("PASS exact particle mask reconstruction: merged "+before+" runs to "+after+" rectangles; "+args[0]);}}'''
for v,e in json.loads((B/'build-report.json').read_text()).items():
 out=B/'followup218-runtime'/v/'classes';r=Path('/workspace/duckclientz-1.21.11/repair' if v=='1.21.11' else '/workspace/duckclientz/repair');src=out/'MaskTests218.java';src.write_text(probe);cp=os.pathsep.join(map(str,[out,e['jar'],r/'stubclasses',B/('compile-stubclasses-new' if v=='1.21.11' else 'compile-stubclasses-old'),T/'gson.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar',r.parent/'tools/joml.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(src)],check=True);subprocess.run(['java','-Xverify:all','-cp',cp,'MaskTests218',v],check=True)
 with ZipFile(e['jar']) as z:
  current=z.read('assets/duckswords/textures/particle/visual/star.png');assert star is None or star==current;star=current
  for n in z.namelist():
   if n.endswith('.ogg'):
    data=z.read(n);h=hashlib.sha256(data).hexdigest()
    if h not in seen:seen.add(h);(audio/(h+'.ogg')).write_bytes(data)
def decode(p):subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(decode,audio.glob('*.ogg')))
print('PASS same star asset across all four versions; all',len(seen),'unique OGG files decode successfully')
