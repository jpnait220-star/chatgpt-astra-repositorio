package net.minecraft;public class class_742 extends class_1657 {public boolean method_31550(){return false;}}
