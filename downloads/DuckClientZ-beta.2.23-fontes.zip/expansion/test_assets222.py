from pathlib import Path
from zipfile import ZipFile
from collections import Counter
from PIL import Image
import json,hashlib,io,copy
B=Path(__file__).parent;manifest=json.loads((B/'cosmetics222-manifest.json').read_text());archive=Path('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip');assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256'];assert Counter(e['category'] for e in manifest['items'])=={'face':7,'arm':7,'auras':7,'back':7};assert manifest['clown_coplanar_fragments_removed']==1
for version,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{version}-1.5.28-beta.2.21.jar') as old,ZipFile(archive) as original:
  for name in old.namelist():
   if name.startswith('assets/duckswords/profiles/v3/'):assert z.read(name)==old.read(name),name
   if name.startswith('assets/duckswords/') and name.endswith(('.png','.ogg')) and not name.startswith('assets/duckswords/cosmetics/custommask/'):assert z.read(name)==old.read(name),name
  assert hashlib.sha256(z.read('assets/duckswords/profiles/v5/a.dict')).hexdigest()=='6c63f83c5af746b898e7f4b23c2af8179eaa709f9f676d2b240e28653f2d9d5a'
  animation=json.loads(z.read('assets/duckswords/cosmetics/animated-textures.json'))
  for e in manifest['items']:
   key=e['id'];prefix='assets/duckswords/cosmetics/'+key.lower()+'/';source='game/cosmetics/'+e['category']+'/'+key;model=json.loads(original.read(source+'.geo.json'));geom=model['minecraft:geometry'][0];renamed=e['root_renames']
   for bone in geom['bones']:
    bone['name']=renamed.get(bone['name'],bone['name'])
    if 'parent' in bone:bone['parent']=renamed.get(bone['parent'],bone['parent'])
   assert model==json.loads(z.read(prefix+'model.json')),key
   icon=Image.open(io.BytesIO(z.read(prefix+'icon.png'))).convert('RGBA');assert icon.size==(128,128) and icon.getchannel('A').getbbox() and icon.getchannel('A').getextrema()[0]==0
   image=Image.open(io.BytesIO(original.read(source+'.webp')))
   for frame in range(getattr(image,'n_frames',1)):
    image.seek(frame);image.load();name=animation[key][frame]['file'] if key in animation else 'texture.png';texture=Image.open(io.BytesIO(z.read(prefix+name))).convert('RGBA');assert texture.size==image.size and texture.tobytes()==image.convert('RGBA').tobytes(),key
    if key in animation:assert animation[key][frame]['duration']==max(20,min(5000,int(image.info.get('duration',100))))
   if e['animation']:
    anim=json.loads(original.read(source+'.animation.json'))
    for a in anim.get('animations',{}).values():
     if 'bones' in a:a['bones']={renamed.get(k,k):v for k,v in a['bones'].items()}
    assert anim==json.loads(z.read(prefix+'animation.json'))
  preset=json.loads(json.loads(z.read('assets/duckswords/default-profile.json'))['config']);online=preset['Cosmeticos Online']['settings'];assert online['Compartilhar tag Duck'] and online['Tag Duck no nick e TAB'];assert all(not preset['$cosmetics'][e['id']]['equipped'] for e in manifest['items']);meta=json.loads(z.read('fabric.mod.json'));assert meta['name']=='Duck Client' and 'Dawn Client' in meta['description'] and version in meta['description'];assert 'offlinenametagicon' not in meta['depends'];assert 'MixinAutoClickHold222' in json.loads(z.read('duckclientz-expansion.mixins.json'))['client']
 print('PASS 28 original models and lossless atlas frames/durations/animation data; 7 per category; 29 icons; prior icons/audio/a-x untouched; frozen dictionary; sharing-tag default; Duck/Dawn metadata:',version)
