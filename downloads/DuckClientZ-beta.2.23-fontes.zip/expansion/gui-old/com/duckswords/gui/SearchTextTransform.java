package com.duckswords.gui;
import net.minecraft.class_332;import net.minecraft.class_4587;
public final class SearchTextTransform{
 public static void push(class_332 ctx,int x,int y,float scale){class_4587 m=ctx.method_51448();m.method_22903();m.method_46416(x,y+2*scale,0);m.method_22905(scale*1.1f,scale*1.1f,1);m.method_46416(-x,-y,0);}
 public static void pop(class_332 ctx){ctx.method_51448().method_22909();}
 public static double mouse(double value,int anchor,float scale){return anchor+(value-anchor)/(scale*1.1);}
}
