from pathlib import Path
from zipfile import ZipFile
from collections import Counter
from PIL import Image
import json,hashlib,io,copy
B=Path(__file__).parent;manifest=json.loads((B/'cosmetics223-manifest.json').read_text());archive=Path('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip');assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256'];assert len(manifest['items'])==39 and len(manifest['pets_added'])==3 and len(set(e['id'] for e in manifest['items']))==39;assert manifest['clown_lower_jaw_removed']
for version,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{version}-1.5.28-beta.2.22.jar') as old,ZipFile(archive) as original:
  for removed in manifest['removed']:assert not any(n.startswith('assets/duckswords/cosmetics/'+removed.lower()+'/') for n in z.namelist()),removed
  for name in old.namelist():
   if name.startswith('assets/duckswords/profiles/v3/'):assert z.read(name)==old.read(name),name
   if name.startswith('assets/duckswords/') and name.endswith(('.png','.ogg')) and not any(name.startswith('assets/duckswords/cosmetics/'+id+'/') for id in ['custommask','halloween2024ghostpet','halloween2024reaperpet']+[x.lower() for x in manifest['removed']]):assert z.read(name)==old.read(name),name
  assert hashlib.sha256(z.read('assets/duckswords/profiles/v5/a.dict')).hexdigest()=='6c63f83c5af746b898e7f4b23c2af8179eaa709f9f676d2b240e28653f2d9d5a'
  animation=json.loads(z.read('assets/duckswords/cosmetics/animated-textures.json'))
  for e in manifest['items']:
   if e['category']=='pets':
    tex=z.read('assets/duckswords/cosmetics/'+e['id'].lower()+'/texture.png');assert hashlib.sha256(tex).hexdigest()==e['source_texture_sha256'];continue
   key=e['id'];prefix='assets/duckswords/cosmetics/'+key.lower()+'/';source='game/cosmetics/'+e['category']+'/'+key;model=json.loads(original.read(source+'.geo.json'));geom=model['minecraft:geometry'][0];renamed=e['root_renames']
   for bone in geom['bones']:
    bone['name']=renamed.get(bone['name'],bone['name'])
    if 'parent' in bone:bone['parent']=renamed.get(bone['parent'],bone['parent'])
   assert model==json.loads(z.read(prefix+'model.json')),key
   icon=Image.open(io.BytesIO(z.read(prefix+'icon.png'))).convert('RGBA');assert icon.size==(128,128) and icon.getchannel('A').getbbox() and icon.getchannel('A').getextrema()[0]==0
   image=Image.open(io.BytesIO(original.read(source+'.webp')))
   for frame in range(getattr(image,'n_frames',1)):
    image.seek(frame);image.load();name=animation[key][frame]['file'] if key in animation else 'texture.png';texture=Image.open(io.BytesIO(z.read(prefix+name))).convert('RGBA');assert texture.size==image.size and texture.tobytes()==image.convert('RGBA').tobytes(),key
    if key in animation:assert animation[key][frame]['duration']==max(20,min(5000,int(image.info.get('duration',100))))
   if e['animation']:
    anim=json.loads(original.read(source+'.animation.json'))
    for a in anim.get('animations',{}).values():
     if 'bones' in a:a['bones']={renamed.get(k,k):v for k,v in a['bones'].items()}
    assert anim==json.loads(z.read(prefix+'animation.json'))
  for key in ['halloween2024ghostpet','halloween2024reaperpet']:
   prefix='assets/duckswords/cosmetics/'+key+'/';assert z.read(prefix+'texture.png')==old.read(prefix+'texture.png');g=json.loads(z.read(prefix+'model.json'))['minecraft:geometry'][0];assert all(isinstance(c['uv'],dict) for b in g['bones'] for c in b.get('cubes',[]))
  clown=json.loads(z.read('assets/duckswords/cosmetics/custommask/model.json'))['minecraft:geometry'][0];assert all(c['origin'][1]>=23 for b in clown['bones'] for c in b.get('cubes',[]))
  preset=json.loads(json.loads(z.read('assets/duckswords/default-profile.json'))['config']);online=preset['Cosmeticos Online']['settings'];assert online['Compartilhar tag Duck'] and online['Tag Duck no nick e TAB'] and online['Compartilhar meus cosmeticos'];assert all(not preset['$cosmetics'][e['id']]['equipped'] for e in manifest['items']);meta=json.loads(z.read('fabric.mod.json'));assert meta['name']=='Duck Client' and 'Dawn Client' in meta['description'] and version in meta['description'];assert 'offlinenametagicon' not in meta['depends'];assert 'MixinAutoClickHold222' in json.loads(z.read('duckclientz-expansion.mixins.json'))['client']
 print('PASS 39 selectable catalog additions (17 new including 3 pets); removed IDs/assets absent; original lossless frames; fixed pet UV; clown jaw removed; frozen a-z/dictionary; cosmetic and tag sharing defaults; Duck/Dawn metadata:',version)
