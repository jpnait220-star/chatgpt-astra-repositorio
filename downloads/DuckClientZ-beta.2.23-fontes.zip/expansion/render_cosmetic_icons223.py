from pathlib import Path
import json,math
import numpy as np
from PIL import Image
B=Path(__file__).parent;SIZE=128

def rotation(angles,pivot):
 x,y,z=np.radians(angles);rx=np.array([[1,0,0],[0,math.cos(x),-math.sin(x)],[0,math.sin(x),math.cos(x)]]);ry=np.array([[math.cos(y),0,math.sin(y)],[0,1,0],[-math.sin(y),0,math.cos(y)]]);rz=np.array([[math.cos(z),-math.sin(z),0],[math.sin(z),math.cos(z),0],[0,0,1]]);r=rz@ry@rx;m=np.eye(4);m[:3,:3]=r;p=np.array(pivot);m[:3,3]=p-r@p;return m

def render(key,category):
 root=B/'resources/assets/duckswords/cosmetics'/key.lower();geo=json.loads((root/'model.json').read_text())['minecraft:geometry'][0];tw=geo['description']['texture_width'];th=geo['description']['texture_height'];texture=np.array(Image.open(root/'texture.png').convert('RGBA'));bones=geo['bones'];byname={b['name']:b for b in bones};cache={}
 def transform(b,seen=()):
  if id(b) in cache:return cache[id(b)]
  if b['name'] in seen:raise ValueError('bone cycle')
  local=rotation(b.get('rotation',[0,0,0]),b.get('pivot',[0,0,0]));parent=byname.get(b.get('parent'));world=(transform(parent,seen+(b['name'],))@local) if parent is not None else local;cache[id(b)]=world;return world
 faces=[]
 for b in bones:
  for cube in b.get('cubes',[]):
   p=np.array(cube['origin'],dtype=float);s=np.array(cube['size'],dtype=float);inf=cube.get('inflate',0);lo=p-inf;hi=p+s+inf;x,y,z=lo;X,Y,Z=hi
   quads={'north':[(x,Y,z),(X,Y,z),(X,y,z),(x,y,z)],'south':[(X,Y,Z),(x,Y,Z),(x,y,Z),(X,y,Z)],'east':[(X,Y,z),(X,Y,Z),(X,y,Z),(X,y,z)],'west':[(x,Y,Z),(x,Y,z),(x,y,z),(x,y,Z)],'up':[(x,Y,Z),(X,Y,Z),(X,Y,z),(x,Y,z)],'down':[(x,y,z),(X,y,z),(X,y,Z),(x,y,Z)]}
   uv=cube.get('uv',{});
   if isinstance(uv,list):
    u,v=uv;w,h,d=s;uv={'north':{'uv':[u+d,v+d],'uv_size':[w,h]},'south':{'uv':[u+2*d+w,v+d],'uv_size':[w,h]},'east':{'uv':[u+d+w,v+d],'uv_size':[d,h]},'west':{'uv':[u,v+d],'uv_size':[d,h]},'up':{'uv':[u+d,v],'uv_size':[w,d]},'down':{'uv':[u+d+w,v+d],'uv_size':[w,-d]}}
   m=transform(b)@rotation(cube.get('rotation',[0,0,0]),cube.get('pivot',(p+s/2).tolist()))
   normals={'north':[0,0,-1],'south':[0,0,1],'east':[1,0,0],'west':[-1,0,0],'up':[0,1,0],'down':[0,-1,0]}
   for name,face in uv.items():
    if name not in quads or 'uv' not in face:continue
    points=np.array([list(q)+[1] for q in quads[name]])@m.T;u,v=face['uv'];du,dv=face.get('uv_size',[s[0],s[1]]);coords=np.array([[u,v],[u+du,v],[u+du,v+dv],[u,v+dv]])/[tw,th];normal=m[:3,:3]@normals[name];faces.append((points[:,:3],coords,normal))
 front=-1 if category not in ('back','auras') else 1;angle=math.radians(12 if category=='face' else 24);eye=np.array([math.sin(angle),.15,front*math.cos(angle)]);eye/=np.linalg.norm(eye);right=np.cross(eye,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,eye);view=np.array([right,up,eye]);projected=[pts@view.T for pts,uv,n in faces];allpoints=np.concatenate(projected);mn=allpoints[:,:2].min(axis=0);mx=allpoints[:,:2].max(axis=0);scale=(SIZE-16)/max(mx-mn);center=(mx+mn)/2;out=np.zeros((SIZE,SIZE,4),np.uint8);depth=np.full((SIZE,SIZE),-np.inf)
 for (pts,uv,normal),v in zip(faces,projected):
  screen=np.column_stack(((v[:,0]-center[0])*scale+SIZE/2,SIZE/2-(v[:,1]-center[1])*scale,v[:,2]));shade=.68+.32*max(0,normal@(eye*.65+up*.35))
  for tri in [(0,1,2),(0,2,3)]:
   a,b,c=screen[list(tri)];xmin=max(0,int(np.floor(min(a[0],b[0],c[0]))));xmax=min(SIZE-1,int(np.ceil(max(a[0],b[0],c[0]))));ymin=max(0,int(np.floor(min(a[1],b[1],c[1]))));ymax=min(SIZE-1,int(np.ceil(max(a[1],b[1],c[1]))));
   if xmax<xmin or ymax<ymin:continue
   yy,xx=np.mgrid[ymin:ymax+1,xmin:xmax+1];xx=xx+.5;yy=yy+.5;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
   if abs(den)<1e-9:continue
   wa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den;wb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;wc=1-wa-wb;z=wa*a[2]+wb*b[2]+wc*c[2];ta,tb,tc=uv[list(tri)];tx=(wa*ta[0]+wb*tb[0]+wc*tc[0])*texture.shape[1];ty=(wa*ta[1]+wb*tb[1]+wc*tc[1])*texture.shape[0];pixels=texture[np.clip(ty.astype(int),0,texture.shape[0]-1),np.clip(tx.astype(int),0,texture.shape[1]-1)].copy();pixels[:,:,:3]=(pixels[:,:,:3]*shade).astype(np.uint8);d=depth[ymin:ymax+1,xmin:xmax+1];mask=(wa>=-1e-7)&(wb>=-1e-7)&(wc>=-1e-7)&(z>d)&(pixels[:,:,3]>10);d[mask]=z[mask];out[ymin:ymax+1,xmin:xmax+1][mask]=pixels[mask]
 assert (out[:,:,3]>0).sum()>30,key
 Image.fromarray(out).save(root/'icon.png');return Image.fromarray(out)
if __name__=='__main__':
 items=json.loads((B/'cosmetics223-manifest.json').read_text())['items']+[{'id':'customMask','category':'face'}];sheet=Image.new('RGBA',(7*SIZE,6*SIZE),(29,34,44,255))
 for i,row in enumerate(items):sheet.alpha_composite(render(row['id'],row['category']),((i%7)*SIZE,(i//7)*SIZE))
 sheet.save('/workspace/duck223-inspect/cosmetics-sheet.png');print('Rendered transparent model thumbnails:',len(items))
