Duck Client beta.2.22 — concluído em código/build/testes; publicação em andamento.

4 versões: 1.20.1, 1.21.1, 1.21.4, 1.21.11. Sem agentes.
28 novos cosméticos do game.zip, 7 máscaras/punhos/auras/costas sem asas.
Modelos originais, atlas WebP -> frames PNG lossless, durações e animações preservadas.
29 miniaturas renderizadas de modelos; manifesto cosmetics222-manifest.json.
Máscara original completa/128atlas, remove1fragmento coplanar da bochecha direita;
levanta1pixel e recua2. Sombrero sobe1. Money ajuste anterior preservado.
Tag amarela depois do nome [ ᴅ ], nome original preservado; compartilhar tag ON
no construtor e no novo padrão y/z. Migração delta-only uma vez com backup,
preserva demais opções/perfis ativos/customizados. Não confundir anúncio da tag
com Compartilhar meus cosméticos, opção independente mantida como configurada.
Cleaner painel redesenhado, 4modos/aplicar/desativar, block-entity ranges48/32/24;
novos JARs analisados: não importar resets de cooldown/GC/opções globais no FPS.
Mantém exceções F5/FreeLook/detached e escopos/identidade das partículas Duck.
HUD backgrounds condicionais a conteúdo real para Effects/Text/CPS/EnderChest.
AutoClick físico segurar não minera; pulso esquerdo sempre libera botão sintético;
novo hook Minecraft1590 mais start/progress no gerenciador. Pausa GUI mantida.
D5 base91 e dicionário congelado SHA6c63f83c5af746b898e7f4b23c2af8179eaa709f9f676d2b240e28653f2d9d5a;
bases a-x intactas; y/z adicionadas; imports D4/DZ3 retidos, D5 requer2.22+.
HitRange world-space annulus, native quad pipeline na11 corrige F11 deformado;
malha reutilizada, swept target query/tick na11 e limpeza ao trocar mundo.
Glint exact pixel palette/diagonal caches; fase/matriz porframe old3; dispatch
copia template imutável contra reset do backend; native11 cacheownerstrength.
AnimatedCosmetic factory chama renderLayer ORIGINAL completa, inclusive builder
nativo da11. Primeiro smoke detectou chamada builder incorreta: corrigida antes
build final; smoke real29models/UV/anim/cache passa4versões com -Xverify:all.
Metadados Duck Client/Minecraftversion/créditos Dawn/Soup/Cleaner seminventarlicença.

Build final: build222-final.log; hashes build-report.json.
Testes atuais *222-check.log: native4, startup MixinAPPLY4, artifacts4,
cleaner174/version, runtime1794/version, workerHTTP4, burst240/version,
default13/version+8crossimports, assets28lossless4, cosmetics29bake4,
render764378/oldversion e646746/native11, profiles790+3021,
HUD16/oldversion e1022/native11 including querybudget/physicalhook.
Não executado Minecraft/GPU/Pojav/Dawn/anticheat; sem medição/promessa de FPS.
Publicação: 9 novos arquivos beta.2.22 em downloads/asasa; não sobrescrever2.21.

Publicação concluída: cd876029c47f7d46173b2d0c105928b461193bfc em asasa. 9 downloads verificados por HTTP200 e SHA256; ZIP combinado também verificado por entradas e hashes internos. Checkout de publicação limpo.
