from pathlib import Path
import json,os,subprocess,re
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');asm=os.pathsep.join(map(str,[T/'asm-9.7.1.jar',T/'asm-commons-9.7.1.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',asm,'-d',str(B/'classes'),str(B/'CloneGlint222.java')],check=True)
for v,e in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');root=B/'render222-runtime'/v;src=root/'src';out=root/'classes';out.mkdir(parents=True,exist_ok=True)
 listing=subprocess.check_output(['java','-m','jdk.jdeps/com.sun.tools.javap.Main','-p','-c','-cp',e['jar'],'com.duckswords.render.Ring222'],text=True)
 provider=re.search(r'InterfaceMethod net/minecraft/class_4597\.([^:]+):',listing)[1];factory=re.search(r'Method net/minecraft/(class_1921|class_12249)\.([^:]+):\(\)Lnet/minecraft/class_1921;',listing);ctx='net.fabricmc.fabric.api.client.rendering.v1.'+('world.' if new else '')+'WorldRenderContext';matrix='Matrix4fc' if ':(Lorg/joml/Matrix4fc;FFF)' in listing else 'Matrix4f'
 fixtures={
 'net/minecraft/class_243.java':'public class class_243 {public double field_1352,field_1351,field_1350;public class_243(double x,double y,double z){field_1352=x;field_1351=y;field_1350=z;}}',
 'net/minecraft/class_4587.java':'public class class_4587 {public class_4665 method_23760(){return new class_4665();}public static class class_4665 {public org.joml.Matrix4f method_23761(){return new org.joml.Matrix4f();}}}',
 'net/minecraft/class_4588.java':f'public interface class_4588 {{class_4588 method_22918(org.joml.{matrix} m,float x,float y,float z);class_4588 method_39415(int c);default void method_1344(){{}}}}',
 'net/minecraft/class_4597.java':f'public interface class_4597 {{class_4588 {provider}(class_1921 layer);}}',
 'net/minecraft/class_1921.java':'public class class_1921 {public static class_1921 method_49042(){return new class_1921();}}',
 'net/minecraft/class_12249.java':'public class class_12249 {public static class_1921 method_76023(){return new class_1921();}}',
 'net/minecraft/class_4184.java':'public class class_4184 {public class_243 pos;public class_243 method_19326(){return pos;}}',
 'net/minecraft/class_11658.java':'public class class_11658 {public class_12075 field_63082=new class_12075();}',
 'net/minecraft/class_12075.java':'public class class_12075 {public class_243 field_63078;}',
 ctx.replace('.','/')+'.java':'public interface WorldRenderContext {net.minecraft.class_4597 consumers();net.minecraft.class_4587 '+('matrices' if new else 'matrixStack')+'();'+('net.minecraft.class_11658 worldState();' if new else 'net.minecraft.class_4184 camera();')+'}',
 }
 for name,body in fixtures.items():p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+name.rsplit('/',1)[0].replace('/','.')+';'+body)
 (src/'Context222.java').write_text('import net.minecraft.*;public class Context222 implements '+ctx+' {public int width,height;final class_4588 buffer;final class_4184 camera=new class_4184();final class_11658 state=new class_11658();public Context222(class_4588 b){buffer=b;}public class_4597 consumers(){return layer->buffer;}public class_4587 '+('matrices' if new else 'matrixStack')+'(){return new class_4587();}public class_4184 camera(){return camera;}public class_11658 worldState(){return state;}public void cameraPos(class_243 p){camera.pos=p;state.field_63082.field_63078=p;}}')
 cp=os.pathsep.join(map(str,[out,e['jar'],r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),T/'gson.jar',r.parent/'tools/joml.jar']))
 if not new:subprocess.run(['java','-cp',str(B/'classes')+os.pathsep+asm,'CloneGlint222',str(B/f'dist/DuckClientZ-{v}-1.5.28-beta.2.21.jar'),str(out)],check=True)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(B/'Render222Tests.java'),*map(str,src.rglob('*.java'))],check=True)
 subprocess.run(['java','-Xverify:all','-cp',cp,'Render222Tests',v],check=True)
