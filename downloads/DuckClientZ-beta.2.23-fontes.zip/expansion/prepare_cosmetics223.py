"""Import selected original resources; keep IDs stable and remove deprecated choices."""
from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io,sys,hashlib,shutil
from prepare_cosmetics222 import GROUPS
B=Path(__file__).parent
REMOVED={'springShield','springLeatherBackpack','springTurtleShell','summer2024FishingRod','summer2024GasMask','natureGloves'}
ADDED={
 'back':[('gamerGamerTower','PC gamer'),('donutDragonWings','Asas de dragão'),('gamerGameOverSign','Placa Game Over')],
 'face':[('gamerGamerGlasses','Óculos gamer'),('hellLordMask','Máscara de demônio')],
 'boots':[('gamerRGBBoots','Botas RGB gamer')],
 'auras':[('gamerControllerAura','Aura de controles gamer'),('gamerJoystickAura','Aura de joysticks gamer')],
 'hats':[('gamerGamerHeadsetV2','Headset gamer'),('spring2025FrogHat','Chapéu de sapo'),('winter2024IceCrown','Coroa de gelo'),('summer2024PropellerHat','Chapéu de hélice'),('springCowboyHat','Chapéu de cowboy'),('demon2024DemonKnightHelmet','Máscara de cavaleiro demoníaco')]
}
if __name__=='__main__':
 archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip');items=[];animated={};selected={group:[(key,label) for key,label in rows if key not in REMOVED] for group,rows in GROUPS.items()}
 for group,rows in ADDED.items():selected.setdefault(group,[]).extend(rows)
 with ZipFile(archive) as z:
  for group,rows in selected.items():
   for key,label in rows:
    source=f'game/cosmetics/{group}/{key}';model=json.loads(z.read(source+'.geo.json'));geometry=model['minecraft:geometry'][0];renamed={}
    if group in ('face','hats'):
     for bone in geometry['bones']:
      if not bone.get('parent') and 'head' not in bone['name'].lower():renamed[bone['name']]='anchor_head_'+bone['name']
     for bone in geometry['bones']:
      bone['name']=renamed.get(bone['name'],bone['name'])
      if 'parent' in bone:bone['parent']=renamed.get(bone['parent'],bone['parent'])
    root=B/'resources/assets/duckswords/cosmetics'/key.lower();root.mkdir(parents=True,exist_ok=True);(root/'model.json').write_text(json.dumps(model,ensure_ascii=False,separators=(',',':'))+'\n')
    image=Image.open(io.BytesIO(z.read(source+'.webp')));frames=[];seen={};assert getattr(image,'n_frames',1)<=64
    for frame in range(getattr(image,'n_frames',1)):
     image.seek(frame);image.load();rgba=image.convert('RGBA');signature=hashlib.sha256(rgba.tobytes()).hexdigest();filename=seen.get(signature)
     if filename is None:filename='texture.png' if not seen else 'texture_'+str(len(seen))+'.png';seen[signature]=filename;rgba.save(root/filename)
     frames.append({'file':filename,'duration':max(20,min(5000,int(image.info.get('duration',100))))})
    if len(frames)>1:animated[key]=frames
    anim=source+'.animation.json'
    if anim in z.namelist():
     data=json.loads(z.read(anim))
     for animation in data.get('animations',{}).values():
      if 'bones' in animation:animation['bones']={renamed.get(k,k):v for k,v in animation['bones'].items()}
     (root/'animation.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    items.append({'id':key,'name':label,'category':group,'cubes':sum(len(b.get('cubes',[])) for b in geometry['bones']),'bones':len(geometry['bones']),'animation':anim in z.namelist(),'source_sha256':hashlib.sha256(z.read(source+'.geo.json')).hexdigest(),'root_renames':renamed})
 # Preserve the original atlas and remove only the unwanted lower jaw piece.
 p=B/'resources/assets/duckswords/cosmetics/custommask/model.json';model=json.loads(p.read_text());g=model['minecraft:geometry'][0];removed_jaw=[b for b in g['bones'] if any(c['origin'][1]<23 and c['size'][1]>3 for c in b.get('cubes',[]))];assert len(removed_jaw) in (0,1)
 g['bones']=[b for b in g['bones'] if b not in removed_jaw];p.write_text(json.dumps(model,separators=(',',':'))+'\n')
 for key in REMOVED:
  root=B/'resources/assets/duckswords/cosmetics'/key.lower()
  if root.exists():shutil.rmtree(root)
 (B/'resources/assets/duckswords/cosmetics/animated-textures.json').write_text(json.dumps(animated,separators=(',',':'))+'\n')
 report={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'removed':sorted(REMOVED),'added':[key for rows in ADDED.values() for key,label in rows],'items':items,'clown_lower_jaw_removed':True}
 (B/'cosmetics223-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 labels={item['id']:item['name'] for item in items};entries=',\n'.join('Map.entry('+json.dumps(k)+','+json.dumps(v,ensure_ascii=False)+')' for k,v in labels.items());ids=','.join(json.dumps(k) for k in labels);removed=','.join(json.dumps(k) for k in sorted(REMOVED))
 (B/'modules-src/com/duckswords/cosmetic/CosmeticCatalog222.java').write_text('''package com.duckswords.cosmetic;
import java.util.*;
/** Current selectable catalog. Deprecated IDs remain importable only as inert profile data. */
public final class CosmeticCatalog222 {
 private static final Map<String,String> LABELS=Map.ofEntries('''+entries+''');
 public static final List<String> IDS=List.of('''+ids+''');
 private static final Set<String> REMOVED=Set.of('''+removed+''');
 public static List<String> extend(List<String> original){Set<String> all=new LinkedHashSet<>(original);all.removeAll(REMOVED);all.addAll(IDS);return List.copyOf(all);}
 public static String label(String id){return LABELS.get(id);}
 public static String description(String id){return LABELS.containsKey(id)?"Modelo original do pacote enviado; texturas e animações preservadas":null;}
}
''')
 print('Prepared',len(items),'current catalog additions;',len(report['added']),'new entries;',len(REMOVED),'removed; clown lower jaw removed')
