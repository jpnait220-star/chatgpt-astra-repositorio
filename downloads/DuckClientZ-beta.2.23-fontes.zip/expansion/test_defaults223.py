from pathlib import Path
import json,subprocess,os
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');versions=json.loads((B/'build-report.json').read_text());paths={}
for v,e in versions.items():
 new=v=='1.21.11';r=Path('/workspace/duckclientz-1.21.11/repair' if new else '/workspace/duckclientz/repair');out=B/'defaults223-runtime'/v;out.mkdir(parents=True,exist_ok=True);existing=B/'corrections215-runtime'/v/'classes';cp=os.pathsep.join(map(str,[out,existing,r/'stubclasses',B/('compile-stubclasses-new' if new else 'compile-stubclasses-old'),e['jar'],T/'gson.jar',r.parent/'tools/joml.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar',T/'slf4j-api-2.0.9.jar',T/'slf4j-simple-2.0.9.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(B/'Default223Tests.java'),str(B/'ProfileCross220Tests.java')],check=True);subprocess.run(['java','-Xverify:all','-cp',cp,'Default223Tests',v],check=True);paths[v]=cp
for producer,base in [('1.20.1','0'),('1.21.11','1')]:
 code=B/'defaults223-runtime'/('cross-'+base+'.txt');subprocess.run(['java','-Xverify:all','-cp',paths[producer],'ProfileCross220Tests','produce',str(B/'resources/assets/duckswords/profiles/v3'/(base+'.json')),str(code),producer],check=True)
 for v in versions:subprocess.run(['java','-Xverify:all','-cp',paths[v],'ProfileCross220Tests','consume','-',str(code),v],check=True)
