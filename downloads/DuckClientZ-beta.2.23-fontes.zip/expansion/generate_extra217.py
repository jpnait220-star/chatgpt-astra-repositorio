from pathlib import Path
from generate_hooks import catalog
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 m,f,c,t=catalog(v);rows=[]
 for key,cls,name in [('wither','net.minecraft.world.effect.MobEffects','WITHER'),('poison','net.minecraft.world.effect.MobEffects','POISON')]:rows.append([key,*f(cls,name)])
 for key,cls,name in [('hasEffect','net.minecraft.world.entity.LivingEntity','hasEffect'),('frozen','net.minecraft.world.entity.Entity','isFullyFrozen'),('absorption','net.minecraft.world.entity.LivingEntity','getAbsorptionAmount')]:
  found=m(cls,name);assert len(found)==1,(v,key,found);rows.append([key,*found[0][:3]])
 (B/'native'/v/'extra217.tsv').write_text('\n'.join('\t'.join(r) for r in rows)+'\n')
