from pathlib import Path
from zipfile import ZipFile
import json
B=Path(__file__).parent
name='assets/duckswords/cosmetics/custommask/model.json'
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.19.jar') as z:original=json.loads(z.read(name))
root=json.loads((B/'resources'/name).read_text());changed=0
for old,new in zip(original['minecraft:geometry'][0]['bones'],root['minecraft:geometry'][0]['bones']):
 for a,b in zip(old.get('cubes',[]),new.get('cubes',[])):
  if not isinstance(a.get('uv'),list):continue
  # These boxes were geometrically scaled to 50%; their atlas dimensions remain 100%.
  u,v=a['uv'];w,h,d=[x*2 for x in a['size']]
  layout={'north':([u+d,v+d],[w,h]),'south':([u+2*d+w,v+d],[w,h]),'east':([u+d+w,v+d],[d,h]),'west':([u,v+d],[d,h]),'up':([u+d,v],[w,d]),'down':([u+d+w,v+d],[w,-d])}
  b['uv']={key:{'uv':p,'uv_size':s} for key,(p,s) in layout.items()};changed+=1
(B/'resources'/name).write_text(json.dumps(root,ensure_ascii=False,separators=(',',':'))+'\n');print('Corrected half-scale box UVs, original explicit nose UV and geometry preserved:',changed)
