from pathlib import Path
import importlib.util,threading,urllib.request,urllib.error,json,time
p=Path(__file__).parent/'cosmetics-relay/relay.py';s=importlib.util.spec_from_file_location('relay',p);r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
server=r.ThreadingHTTPServer(('127.0.0.1',0),r.Handler);threading.Thread(target=server.serve_forever,daemon=True).start();base='http://127.0.0.1:'+str(server.server_port);uid='00000000-0000-0000-0000-000000000001'
def req(path,data=None):
 try:
  raw=None if data is None else json.dumps(data).encode()
  with urllib.request.urlopen(urllib.request.Request(base+path,data=raw,headers={'Content-Type':'application/json'}),timeout=3) as q:return q.status,json.load(q)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
try:
 assert req('/profiles?ids='+uid)==(200,{})
 assert req('/profile',{'uuid':uid,'cosmetics':['duckMask','duckMask']})==(200,{'ok':True})
 assert req('/profiles?ids='+uid)==(200,{uid:['duckMask']})
 assert req('/profile',{'uuid':uid,'cosmetics':['../bad']})[0]==400
 assert req('/profile',{'uuid':uid,'cosmetics':['x']*33})[0]==400
 assert req('/profiles?ids=invalid')[0]==400
 assert req('/profiles?ids='+','.join([uid]*33))[0]==400
 assert req('/unknown')[0]==404
 r.PROFILES[uid]=(time.monotonic()-121,['duckMask']);assert req('/profiles?ids='+uid)==(200,{})
 print('PASS: relay upload/query, deduplication, malformed IDs/path/limits, TTL expiry; localhost only')
finally:server.shutdown();server.server_close()
