from pathlib import Path
import subprocess,os,json
B=Path(__file__).parent;entry=json.loads((B/'build-report.json').read_text())['1.21.11'];root=B/'firework-session-runtime';src=root/'src';out=root/'classes';out.mkdir(parents=True,exist_ok=True)
fixtures={
'net/minecraft/class_1297.java':'public class class_1297 {public int field_6012;public boolean alive=true;public boolean method_5805(){return alive;}}',
'net/minecraft/class_1309.java':'public class class_1309 extends class_1297 {}',
'net/minecraft/class_1657.java':'public class class_1657 extends class_1309 {}',
'net/minecraft/class_746.java':'public class class_746 extends class_1657 {public final class_1661 inventory=new class_1661();public class_1661 method_31548(){return inventory;}public class_1799 method_6047(){return inventory.method_5438(inventory.selected);}}',
'net/minecraft/class_1661.java':'public class class_1661 {public int selected;public final class_1799[] slots=new class_1799[9];public class_1661(){for(int i=0;i<9;i++)slots[i]=new class_1799(null);}public int method_67532(){return selected;}public void method_61496(int i){selected=i;}public class_1799 method_5438(int i){return slots[i];}}',
'net/minecraft/class_1792.java':'public class class_1792 {}',
'net/minecraft/class_1799.java':'public class class_1799 {public final class_1792 item;public int sharpness;public class_1799(class_1792 item){this.item=item;}public boolean method_31574(class_1792 other){return item==other;}}',
'net/minecraft/class_1802.java':'public class class_1802 {public static final class_1792 field_8639=new class_1792();}',
'net/minecraft/class_437.java':'public class class_437 {}',
'net/minecraft/class_310.java':'public class class_310 {private static final class_310 INSTANCE=new class_310();public class_746 field_1724;public class_638 field_1687;public class_636 field_1761;public class_437 field_1755;public static class_310 method_1551(){return INSTANCE;}}',
'net/minecraft/class_636.java':'public class class_636 {public static int calls;public int lastSlot;public class_1269 method_2919(class_1657 player,class_1268 hand){calls++;lastSlot=((class_746)player).inventory.selected;return new class_1269();}}',
'net/minecraft/class_1269.java':'public class class_1269 {public static class class_9860 extends class_1269 {public class_9861 comp_2909(){return class_9861.SERVER;}}public enum class_9861 {field_52427,SERVER;}}',
'net/minecraft/class_1268.java':'public enum class_1268 {field_5808,field_5810}',
'net/minecraft/class_1937.java':'public class class_1937 {public class_5455 method_30349(){return key->requested->new class_6880.class_6883();}}',
'net/minecraft/class_638.java':'public class class_638 extends class_1937 {}',
'net/minecraft/class_5455.java':'public interface class_5455 {class_2378 method_30530(class_5321 key);}',
'net/minecraft/class_2378.java':'public interface class_2378 {class_6880.class_6883 method_46747(class_5321 key);}',
'net/minecraft/class_5321.java':'public class class_5321 {}',
'net/minecraft/class_7924.java':'public class class_7924 {public static final class_5321 field_41265=new class_5321();}',
'net/minecraft/class_1893.java':'public class class_1893 {public static final class_5321 field_9118=new class_5321();}',
'net/minecraft/class_6880.java':'public interface class_6880 {public static final class class_6883 implements class_6880 {}}',
'net/minecraft/class_1890.java':'public class class_1890 {public static int method_8225(class_6880 enchantment,class_1799 stack){return stack.sharpness;}}',
'com/duckswords/setting/KeybindSetting.java':'public class KeybindSetting extends Setting<String> {public static boolean pressed;public KeybindSetting(String name,String description,int key,int mods){super(name,description);}public boolean isPressed(boolean extras){return pressed;}public String getValue(){return "0:0";}public void reset(){}}'
}
for file,body in fixtures.items():
 p=src/file;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+str(Path(file).parent).replace('/','.')+';'+body)
(src/'FireworkSessionTests.java').write_text('''import com.duckswords.modules.FireworkKey;import com.duckswords.setting.KeybindSetting;import net.minecraft.*;
public class FireworkSessionTests {static int checks;static void check(boolean b){if(!b)throw new AssertionError("firework lifecycle "+checks);checks++;}static class_746 player(int slot,int rocket,int tick){class_746 p=new class_746();p.inventory.selected=slot;p.inventory.slots[rocket]=new class_1799(class_1802.field_8639);p.field_6012=tick;return p;}static void key(FireworkKey feature,class_746 p,boolean down,int age){try{var map=com.duckswords.input.FireworkTiming.class.getDeclaredField("STATES");map.setAccessible(true);Object state=((java.util.Map<?,?>)map.get(null)).get(feature);if(state!=null){for(String n:new String[]{"attempt","restore"}){var f=state.getClass().getDeclaredField(n);f.setAccessible(true);f.setLong(state,n.equals("restore")?1:System.nanoTime()-1_000_000_000L);}com.duckswords.input.FireworkTiming.frame();}}catch(ReflectiveOperationException e){throw new AssertionError(e);}p.field_6012=age;KeybindSetting.pressed=down;feature.onTick();}
 public static void main(String[] args)throws Exception {class_310 mc=class_310.method_1551();mc.field_1687=new class_638();mc.field_1761=new class_636();mc.field_1724=player(2,5,100000);class_746 first=mc.field_1724;FireworkKey feature=new FireworkKey();feature.setEnabled(true);key(feature,first,true,100000);check(class_636.calls==1&&first.inventory.selected==5);key(feature,first,false,100001);check(first.inventory.selected==2);key(feature,first,true,100005);check(class_636.calls==2);first.alive=false;key(feature,first,true,100006);check(class_636.calls==2&&first.inventory.selected==2);
 class_746 respawn=player(7,1,0);mc.field_1724=respawn;key(feature,respawn,true,0);check(class_636.calls==3&&respawn.inventory.selected==1);key(feature,respawn,false,1);check(respawn.inventory.selected==7);key(feature,respawn,true,2);check(class_636.calls==3);key(feature,respawn,false,3);key(feature,respawn,true,5);check(class_636.calls==4);key(feature,respawn,true,8);check(class_636.calls==4); // original native press-edge behavior preserved
 class_746 third=player(4,8,0);mc.field_1724=third;key(feature,third,false,0);check(third.inventory.selected==4);key(feature,third,true,1);check(class_636.calls==5);third.inventory.selected=6;key(feature,third,false,2);check(third.inventory.selected==6);key(feature,third,true,700000);check(class_636.calls==6);key(feature,third,false,700001);key(feature,third,true,0);check(class_636.calls==7); // same player tick rollback
 mc.field_1687=new class_638();key(feature,third,true,1);check(class_636.calls==8);mc.field_1761=new class_636();key(feature,third,true,2);check(class_636.calls==9);feature.setEnabled(false);check(third.inventory.selected==6);for(String field:new String[]{"duck$lastPlayer","duck$lastWorld","duck$lastManager","duck$temporaryPlayer"}){var f=FireworkKey.class.getDeclaredField(field);f.setAccessible(true);check(f.get(feature)==null);}feature.setEnabled(true);key(feature,third,true,0);check(class_636.calls==10);
 key(feature,third,false,1);feature.sharpness.setValue(true);key(feature,third,true,4);check(class_636.calls==10);key(feature,third,false,5);third.inventory.slots[third.inventory.selected].sharpness=5;key(feature,third,true,8);check(class_636.calls==11);mc.field_1724=null;feature.onTick();check(class_636.calls==11);System.out.println("PASS: "+checks+" actual native FireworkKey lifecycle checks: death/respawn, young age, delay5; elapsed time simulated; real-time pacing tested separately, press edge, player/world/manager changes, slot ownership/manual changes, tick rollback, disable/re-enable, cache release and Sharpness");}}
''')
cp=os.pathsep.join(map(str,[out,'/workspace/duckclientz-1.21.11/repair/stubclasses',B/'compile-stubclasses-new',entry['jar'],'/workspace/duckclientz-1.21.11/tools/joml.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,src.rglob('*.java'))],check=True)
subprocess.run(['java','-Xverify:all','-cp',cp,'FireworkSessionTests'],check=True)
