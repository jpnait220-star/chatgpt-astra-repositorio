from pathlib import Path
from zipfile import ZipFile
import json,math,hashlib
from PIL import Image
B=Path(__file__).parent;BASE=B/'resources/assets/duckswords/cosmetics'
def boxuv(u,v,size):
 w,h,d=size
 return {key:{'uv':a,'uv_size':b} for key,a,b in [('north',[u+d,v+d],[w,h]),('south',[u+2*d+w,v+d],[w,h]),('east',[u+d+w,v+d],[d,h]),('west',[u,v+d],[d,h]),('up',[u+d,v],[w,d]),('down',[u+d+w,v+d],[w,-d])]}
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n')
# Existing mini pets: round box-UV dimensions to atlas pixels, independently of geometry.
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.22.jar') as old:
 for key in ['halloween2024ghostpet','halloween2024reaperpet']:
  prefix='assets/duckswords/cosmetics/'+key+'/';model=json.loads(old.read(prefix+'model.json'));count=0
  for bone in model['minecraft:geometry'][0]['bones']:
   for cube in bone.get('cubes',[]):
    if isinstance(cube.get('uv'),list):u,v=cube['uv'];cube['uv']=boxuv(u,v,[math.floor(n+.5) for n in cube['size']]);count+=1
  if key=='halloween2024ghostpet':model['minecraft:geometry'][0]['bones'][0]['cubes'][0]['uv']=boxuv(0,0,[12,16,10])
  else:
   head=next(b for b in model['minecraft:geometry'][0]['bones'] if b['name']=='head');head['cubes'][0]['uv']['north']={'uv':[8,8],'uv_size':[16,16]};head['cubes'][1]['uv']['north']={'uv':[12,12],'uv_size':[8,8]}
  root=BASE/key;save(root/'model.json',model)
  for name in ['texture.png','animation.json']:(root/name).write_bytes(old.read(prefix+name))
  print('Explicit atlas faces, unchanged geometry:',key,count)
class Pet:
 def __init__(self,key,label,texture,scale,origin):self.key=key;self.label=label;self.texture=texture;self.scale=scale;self.origin=origin;self.pivots={'anchor_body':origin};self.bones=[{'name':'anchor_body','pivot':[0,24,0]}]
 def position(self,p):return [-11+(p[0]-self.origin[0])*self.scale,28-(p[1]-self.origin[1])*self.scale,(p[2]-self.origin[2])*self.scale]
 def part(self,name,parent='anchor_body',pivot=(0,0,0),cubes=(),rotation=(0,0,0)):
  globalpivot=[a+b for a,b in zip(self.pivots[parent],pivot)] if parent!='anchor_body' else list(pivot);self.pivots[name]=globalpivot;bone={'name':name,'parent':parent,'pivot':self.position(globalpivot)}
  if any(rotation):bone['rotation']=[-rotation[0],rotation[1],-rotation[2]]
  boxes=[]
  for uv,local,size in cubes:
   p=[a+b for a,b in zip(globalpivot,local)];c={'origin':self.position([p[0],p[1]+size[1],p[2]]),'size':[n*self.scale for n in size],'uv':boxuv(*uv,size)};boxes.append(c)
  if boxes:bone['cubes']=boxes
  self.bones.append(bone);return name
 def write(self,jar,extra):
  texture=jar.read('assets/minecraft/'+self.texture);root=BASE/self.key.lower();root.mkdir(parents=True,exist_ok=True);(root/'texture.png').write_bytes(texture);im=Image.open(root/'texture.png');model={'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.'+self.key,'texture_width':im.width,'texture_height':im.height,'visible_bounds_width':3,'visible_bounds_height':3.5,'visible_bounds_offset':[0,1.25,0]},'bones':self.bones}]};save(root/'model.json',model)
  tracks={'anchor_body':{'position':{'0.0':[0,0,0],'1.0':[0,.65,0],'2.0':[0,0,0]}}};tracks.update(extra);save(root/'animation.json',{'format_version':'1.8.0','animations':{'animation.'+self.key+'.idle':{'loop':True,'animation_length':2,'bones':tracks}}})
  return {'id':self.key,'name':self.label,'category':'pets','cubes':sum(len(b.get('cubes',[])) for b in self.bones),'bones':len(self.bones),'animation':True,'source':'Minecraft 1.20.1 vanilla model dimensions/UV and texture','source_texture':self.texture,'source_texture_sha256':hashlib.sha256(texture).hexdigest(),'root_renames':{}}
bee=Pet('duckBeePet','Pet abelha','textures/entity/bee/bee.png',.48,(0,19,0));bee.part('bee',pivot=(0,19,0),cubes=[((0,0),(-3.5,-4,-5),(7,7,10)),((26,7),(0,-1,5),(0,1,2))]);bee.part('antenna_left','bee',(0,-2,-5),[((2,0),(1.5,-2,-3),(1,2,3))]);bee.part('antenna_right','bee',(0,-2,-5),[((2,3),(-2.5,-2,-3),(1,2,3))]);bee.part('wing_right','bee',(-1.5,-4,-3),[((0,18),(-9,0,0),(9,0,6))],(0,-15,0));bee.part('wing_left','bee',(1.5,-4,-3),[((0,18),(0,0,0),(9,0,6))],(0,15,0))
for i,z in enumerate([-2,0,2]):bee.part('legs'+str(i),'bee',(1.5,3,z),[((26,1+i*2),(-5,0,0),(7,2,0))],(35,0,0))
fox=Pet('duckFoxPet','Pet raposa','textures/entity/fox/fox.png',.38,(0,17,0));fox.part('fox_head',pivot=(-1,16.5,-3),cubes=[((1,5),(-3,-2,-5),(8,6,6)),((8,1),(-3,-4,-4),(2,2,1)),((15,1),(3,-4,-4),(2,2,1)),((6,18),(-1,2.01,-8),(4,2,3))]);fox.part('fox_body',pivot=(0,16,-6),cubes=[((24,15),(-3,3.999,-3.5),(6,11,6))],rotation=(90,0,0));fox.part('fox_tail','fox_body',(-4,15,-1),[((30,0),(2,0,-1),(4,9,5))],(-3,0,0))
for i,p in enumerate([(-5,17.5,7),(-1,17.5,7),(-5,17.5,0),(-1,17.5,0)]):fox.part('paw'+str(i),pivot=p,cubes=[(((13 if i%2==0 else 4),24),(2,.5,-1),(2,6,2))])
axo=Pet('duckAxolotlPet','Pet axolote','textures/entity/axolotl/axolotl_cyan.png',.38,(0,20,0));axo.part('axo_body',pivot=(0,20,5),cubes=[((0,11),(-4,-2,-9),(8,4,10)),((2,17),(0,-3,-8),(0,5,9))]);axo.part('axo_head','axo_body',(0,0,-9),[((0,1),(-4,-3,-5),(8,5,5))]);axo.part('top_gills','axo_head',(0,-3,-1),[((3,37),(-4,-3,0),(8,3,0))]);axo.part('left_gills','axo_head',(-4,0,-1),[((0,40),(-3,-5,0),(3,7,0))]);axo.part('right_gills','axo_head',(4,0,-1),[((11,40),(0,-5,0),(3,7,0))]);axo.part('axo_tail','axo_body',(0,0,1),[((2,19),(0,-3,0),(0,5,12))])
for i,p in enumerate([(-3.5,1,-1),(3.5,1,-1),(-3.5,1,-8),(3.5,1,-8)]):axo.part('axo_paw'+str(i),'axo_body',p,[((2,13),(-2 if i%2==0 else -1,0,0),(3,5,0))],(0,0,70 if i%2==0 else -70))
def sway(axis,amount):return {'rotation':{'0.0':[0,0,0],'0.5':[amount if a==axis else 0 for a in range(3)],'1.5':[-amount if a==axis else 0 for a in range(3)],'2.0':[0,0,0]}}
with ZipFile('/workspace/duckclientz/tools/minecraft-1.20.1-client') as game:
 rows=[bee.write(game,{'wing_left':sway(2,35),'wing_right':sway(2,-35)}),fox.write(game,{'fox_tail':sway(1,15)}),axo.write(game,{'axo_tail':sway(1,18),'left_gills':sway(2,8),'right_gills':sway(2,-8)})]
m=json.loads((B/'cosmetics223-manifest.json').read_text());m['items']=[e for e in m['items'] if e['id'] not in {r['id'] for r in rows}]+rows;m['pets_added']=[r['id'] for r in rows];m['pets_uv_fixed']=['halloween2024GhostPet','halloween2024ReaperPet'];save(B/'cosmetics223-manifest.json',m)
p=B/'modules-src/com/duckswords/cosmetic/CosmeticCatalog222.java';s=p.read_text();last='Map.entry("duckBeePet","Pet abelha"),Map.entry("duckFoxPet","Pet raposa"),Map.entry("duckAxolotlPet","Pet axolote")';s=s.replace('Map.entry("demon2024DemonKnightHelmet","Máscara de cavaleiro demoníaco"));','Map.entry("demon2024DemonKnightHelmet","Máscara de cavaleiro demoníaco"),'+last+');');s=s.replace('"demon2024DemonKnightHelmet");','"demon2024DemonKnightHelmet","duckBeePet","duckFoxPet","duckAxolotlPet");');s=s.replace('return LABELS.containsKey(id)?','return id.equals("duckBeePet")||id.equals("duckFoxPet")||id.equals("duckAxolotlPet")?"Miniatura com texturas originais do Minecraft":LABELS.containsKey(id)?');p.write_text(s)
print('Prepared 3 small animated vanilla companions:',[r['id'] for r in rows])
