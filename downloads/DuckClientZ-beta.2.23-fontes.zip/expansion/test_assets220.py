from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import io,json,copy
B=Path(__file__).parent
masks=json.loads((B/'icon220-report.json').read_text())
def no_uv(node):
 if isinstance(node,dict):return {k:no_uv(v) for k,v in node.items() if k not in ('uv','uv_size')}
 if isinstance(node,list):return [no_uv(v) for v in node]
 return node
for version,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{version}-1.5.28-beta.2.19.jar') as old:
  prefix='assets/duckswords/textures/gui/icons/'
  for name in old.namelist():
   if not name.startswith(prefix) or not name.endswith('.png'):continue
   key=Path(name).stem
   if key not in masks:assert old.read(name)==z.read(name),name;continue
   a=Image.open(io.BytesIO(old.read(name))).convert('RGBA');b=Image.open(io.BytesIO(z.read(name))).convert('RGBA')
   assert a.size==b.size and a.getchannel('A').tobytes()==b.getchannel('A').tobytes()
   changed={(x,y) for y in range(a.height) for x in range(a.width) if a.getpixel((x,y))!=b.getpixel((x,y))}
   assert changed=={tuple(p) for p in masks[key]['pixels']}
   assert all(x>=a.width//2 for x,y in changed)
  for name in old.namelist():
   if name.startswith('assets/duckswords/profiles/v3/') and name.endswith('.json'):assert old.read(name)==z.read(name),name
  for key in ('custommask','winter2024bunnyhat'):
   name=f'assets/duckswords/cosmetics/{key}/model.json';a=json.loads(old.read(name));b=json.loads(z.read(name));assert no_uv(a)==no_uv(b)
   ga=a['minecraft:geometry'][0];gb=b['minecraft:geometry'][0];desc=gb['description'];w=desc['texture_width'];h=desc['texture_height']
   for ba,bb in zip(ga['bones'],gb['bones']):
    for ca,cb in zip(ba.get('cubes',[]),bb.get('cubes',[])):
     if isinstance(ca.get('uv'),dict):assert ca['uv']==cb['uv'];continue
     if 'uv' not in cb:continue
     assert isinstance(cb['uv'],dict)
     for f in cb['uv'].values():
      u,v=f['uv'];du,dv=f['uv_size'];assert 0<=min(u,u+du)<=max(u,u+du)<=w and 0<=min(v,v+dv)<=max(v,v+dv)<=h,(key,f,w,h)
 print('PASS icon changes confined to recorded right-edge pixels, alpha/other icons preserved; frozen profile schemas unchanged; cosmetic geometry/explicit UV preserved, generated UV in atlas:',version)
