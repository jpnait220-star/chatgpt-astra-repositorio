from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import io,struct
B=Path(__file__).parent;source=Path('/workspace/attachments/2b982f68-c0f3-4509-aff4-f0966764a2a2/simple-health-bar-1.1.3+1.21.11.jar');out=B/'resources/assets/duckswords/healthbar';out.mkdir(exist_ok=True)
with ZipFile(source) as z:
 for name in z.namelist():
  if '/healthbars/' not in name or not name.endswith('.png'):continue
  data=z.read(name);key=Path(name).stem;(out/(key+'.png')).write_bytes(data);im=Image.open(io.BytesIO(data)).convert('RGBA');runs=[]
  if im.size!=(80,9):continue
  for y in range(9):
   x=0
   while x<80:
    p=im.getpixel((x,y));start=x;x+=1
    while x<80 and im.getpixel((x,y))==p:x+=1
    r,g,b,a=p
    if a:runs.append((start,y,x-start,a<<24|r<<16|g<<8|b))
  (out/(key+'.bin')).write_bytes(struct.pack('>H',len(runs))+b''.join(struct.pack('>BBBI',*run) for run in runs))
print('Simple Health Bar CC0 sprites prepared, with editable color at render time')
