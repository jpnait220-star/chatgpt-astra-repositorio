from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import io,json,subprocess,concurrent.futures,hashlib
B=Path(__file__).parent;root=B/'audio216-runtime';root.mkdir(exist_ok=True);first=None;checks=0
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z:
  names=set(z.namelist());doc=json.loads(z.read('assets/duckswords/sounds.json'))
  for mode in ['vanilla_strong','vanilla_crit','vanilla_sweep','vanilla_mace','vanilla_bell','totem_blocks','totem_glass','totem_confirm','totem_bong','totem_drop']:assert mode in doc;checks+=1
  for key,val in doc.items():
   for a in val['sounds']:
    path=a if isinstance(a,str) else a['name'];namespace,stem=path.split(':');p=f'assets/{namespace}/sounds/{stem}.ogg';assert p in names,p;checks+=1
    if first is None:(root/(stem.replace('/','_')+'.ogg')).write_bytes(z.read(p))
  with ZipFile(B/'dist'/f'DuckClientZ-{v}-1.5.28-beta.2.15.jar') as old:
   for key in ['autoclicker','nohurtcam']:
    p='assets/duckswords/textures/gui/icons/'+key+'.png';a=Image.open(io.BytesIO(old.read(p))).convert('RGBA');b=Image.open(io.BytesIO(z.read(p))).convert('RGBA');assert a.size==b.size
    if key=='nohurtcam':assert a.getchannel('A').tobytes()==b.getchannel('A').tobytes(),'Camera outline must remain intact'
    for y in range(a.height):
     for x in range(a.width):
      allowed=(47<=x<=61 and 96<=y<=109) if key=='autoclicker' else (112<=x<122 and (32<=y<47 or 91<=y<108))
      if not allowed:assert a.getpixel((x,y))==b.getpixel((x,y)),(key,x,y)
    checks+=a.width*a.height
  assert not any('texturemaker/' in n.lower() or 'texturemaker.class' in n.lower() or n.endswith('/texturemaker.png') for n in names)
 first=True
# Decode the complete audio, not just its container header. Record any invalid/silent audio.
def audio(p):
 probe=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,channels:format=duration','-of','json',str(p)],capture_output=True,text=True,check=True);d=json.loads(probe.stdout);assert all(s['codec_name']=='vorbis' for s in d['streams']),p
 decoded=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','f32le','-ac','1','-'],capture_output=True,check=True).stdout
 import array,math
 samples=array.array('f');samples.frombytes(decoded);assert samples and max(abs(x) for x in samples)>.00001,('silent',p)
 return {'file':p.name,'seconds':float(d['format']['duration']),'peak':max(abs(x) for x in samples)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:report=list(pool.map(audio,root.glob('*.ogg')))
(B/'audio216-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',checks,'asset checks; icon pixels unchanged outside inspected spots; camera alpha preserved; no Texture Maker; decoded',len(report),'non-silent Vorbis audio files')
