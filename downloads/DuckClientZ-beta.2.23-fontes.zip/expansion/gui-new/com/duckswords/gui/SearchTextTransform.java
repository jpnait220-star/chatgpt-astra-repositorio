package com.duckswords.gui;
import net.minecraft.class_332;import org.joml.Matrix3x2fStack;
public final class SearchTextTransform{
 public static void push(class_332 ctx,int x,int y,float scale){Matrix3x2fStack m=ctx.method_51448();m.pushMatrix();m.translate(x,y+2*scale);m.scale(scale*1.1f,scale*1.1f);m.translate(-x,-y);}
 public static void pop(class_332 ctx){ctx.method_51448().popMatrix();}
 public static double mouse(double value,int anchor,float scale){return anchor+(value-anchor)/(scale*1.1);}
}
