from pathlib import Path
import json,subprocess,os,urllib.parse,urllib.request
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');out=B/'online218-runtime';out.mkdir(exist_ok=True)
with urllib.request.urlopen('https://duck-connect.vercel.app/health',timeout=15) as r:assert r.status==200 and json.load(r)['status']=='online'
print('PASS public HTTPS/health, verified TLS; JVM execution proxy only when required by this environment',flush=True)
p=urllib.parse.urlparse(os.environ.get('HTTPS_PROXY',''));proxy=['-Dhttps.proxyHost='+p.hostname,'-Dhttps.proxyPort='+str(p.port or 80)] if p.hostname else []
for v,e in json.loads((B/'build-report.json').read_text()).items():
 r=Path('/workspace/duckclientz-1.21.11/repair' if v=='1.21.11' else '/workspace/duckclientz/repair');cp=os.pathsep.join(map(str,[out,B/'revision218-runtime'/v/'classes',e['jar'],r/'stubclasses',T/'gson.jar',T/'mixin.jar',T/'fabric-loader-0.16.10.jar',r.parent/'tools/joml.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(B/'OnlineRelayTests218.java')],check=True)
 subprocess.run(['java',*proxy,'-Xverify:all','-cp',cp,'OnlineRelayTests218',v],check=True)
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w,h in [(1366,900),(390,844)]:
  page=browser.new_page(viewport={'width':w,'height':h},ignore_https_errors=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));r=page.goto('https://duck-connect.vercel.app/',wait_until='networkidle');assert r.status==200
  page.wait_for_function("document.querySelector('#badge').textContent==='ONLINE'");assert page.locator('#copy').is_enabled();assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');assert not errors
  print('PASS public site browser',w,'online/button/responsive/no JS errors (Chromium trust workaround; TLS verified separately)');page.close()
 browser.close()
