from pathlib import Path
import subprocess,os,json
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v,entry in json.loads((B/'build-report.json').read_text()).items():
 new=v=='1.21.11';root=Path('/workspace/duckclientz-1.21.11' if new else '/workspace/duckclientz');tools=root/'tools'
 cp=os.pathsep.join(str(p) for p in [B/'classes',root/'repair/toolclasses',T/'asm-9.7.1.jar',T/'asm-tree-9.7.1.jar',T/'asm-analysis-9.7.1.jar',T/'asm-commons-9.7.1.jar'])
 subprocess.run(['java','-cp',cp,'CheckAddedApi','Verify12111' if new else 'VerifyArtifacts',str(tools/'intermediary.tiny' if new else T/f'intermediary-{v}.tiny'),str(tools/'minecraft-client' if new else T/f'minecraft-{v}-client'),entry['jar'],str(B/'tools'/f'fabric-particles-{v}.jar'),str(T/'fabric-loader-0.16.10.jar'),str(B/'tools'/f'fabric-api-base-{v}.jar'),str(B/'tools'/f'fabric-rendering-v1-{v}.jar'),str(B/'tools'/f'authlib-{v}.jar')],check=True)
