from pathlib import Path
from zipfile import ZipFile
from PIL import Image
from collections import deque
import io,json
B=Path(__file__).parent;report={};sheet=Image.new('RGBA',(768,384),(55,55,65,255))
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.19.jar') as z:
 for index,key in enumerate(['fullbright','scoreboard']):
  old=Image.open(io.BytesIO(z.read(f'assets/duckswords/textures/gui/icons/{key}.png'))).convert('RGBA');im=old.copy();w,h=im.size
  def matte(p):return p[3]>0 and min(p[:3])>=50 and max(p[:3])-min(p[:3])<=65
  queue=deque((x,y) for x in range(w) for y in range(h) if old.getpixel((x,y))[3]<20);seen=set(queue)
  while queue:
   x,y=queue.popleft()
   for xx,yy in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if 0<=xx<w and 0<=yy<h and (xx,yy) not in seen and (old.getpixel((xx,yy))[3]<20 or matte(old.getpixel((xx,yy)))):seen.add((xx,yy));queue.append((xx,yy))
  changed=[]
  for x,y in sorted(seen):
   p=old.getpixel((x,y))
   if x<w//2 or not matte(p):continue
   dark=[]
   for dy in range(-3,4):
    for dx in range(-3,4):
     xx,yy=x+dx,y+dy
     if 0<=xx<w and 0<=yy<h:
      q=old.getpixel((xx,yy))
      if q[3]>=200 and q[0]<50 and q[1]<100 and 25<=q[2]<150:dark.append((dx*dx+dy*dy,xx,yy,q))
   if dark:
    q=min(dark)[3];im.putpixel((x,y),(*q[:3],p[3]));changed.append([x,y])
  assert im.getchannel('A').tobytes()==old.getchannel('A').tobytes();path=B/f'resources/assets/duckswords/textures/gui/icons/{key}.png';path.parent.mkdir(parents=True,exist_ok=True);im.save(path);report[key]={'pixels':changed,'alpha_preserved':True};sheet.alpha_composite(im.resize((384,384)),(index*384,0))
(B/'icon220-report.json').write_text(json.dumps(report,indent=2)+'\n');sheet.save('/workspace/duck220-inspect/icons-after.png');print({k:len(v['pixels']) for k,v in report.items()})
