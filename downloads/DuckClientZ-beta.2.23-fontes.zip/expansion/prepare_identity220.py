from pathlib import Path
import json,urllib.request,hashlib
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 root=Path('/workspace/duckclientz-1.21.11/tools') if v=='1.21.11' else Path('/workspace/duckclientz/tools');meta=root/('minecraft.json' if v=='1.21.11' else f'minecraft-{v}.json');doc=json.loads(meta.read_text());lib=next(l for l in doc['libraries'] if l['name'].startswith('com.mojang:authlib:'));artifact=lib['downloads']['artifact'];out=B/'tools'/f'authlib-{v}.jar'
 if not out.exists():out.write_bytes(urllib.request.urlopen(artifact['url'],timeout=30).read())
 assert hashlib.sha1(out.read_bytes()).hexdigest()==artifact['sha1'];print('PASS official authlib verified:',v,lib['name'])
