from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io,sys,hashlib
B=Path(__file__).parent
GROUPS={
 'face': [('cyberpunkLEDMask','Máscara LED'),('cyberpunkOniMask','Máscara Oni'),('fall2025OwlMask','Máscara de coruja'),('halloween2024FrankensteinMask','Máscara Frankenstein'),('summer2024GasMask','Máscara de gás'),('cloudMask','Máscara de nuvem'),('spaceMask','Máscara espacial')],
 'arm': [('angelGloves','Punhos angelicais'),('cyberNinjaGloves','Punhos cyber ninja'),('dragonFestivalGloves','Punhos do dragão'),('knightGloves','Punhos de cavaleiro'),('natureGloves','Punhos da natureza'),('voidGloves','Punhos do vazio'),('gamerRGBFists','Punhos RGB')],
 'auras': [('spaceAura','Aura espacial'),('jan2025BlackHoleAura','Aura de buraco negro'),('jan2025SolarSystemAura','Aura do sistema solar'),('cloudAura','Aura de nuvens'),('flameFragsFireRing','Aura de fogo'),('spring2025RainbowAura','Aura de arco-íris'),('hellLordAura','Aura infernal')],
 'back': [('springKatana','Katana nas costas'),('springShield','Escudo nas costas'),('springLeatherBackpack','Mochila de couro'),('springTurtleShell','Casco de tartaruga'),('summer2024Surfboard','Prancha de surfe'),('demon2024DemonScythe','Foice demoníaca'),('summer2024FishingRod','Vara de pesca')]
}
if __name__=='__main__':
 archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/3e2ccb6f-5b1b-4fbf-af00-e370eba86fe0/game.zip')
 report=[];animated={}
 with ZipFile(archive) as z:
  for group,rows in GROUPS.items():
   for key,label in rows:
    source=f'game/cosmetics/{group}/{key}';model=json.loads(z.read(source+'.geo.json'));geometry=model['minecraft:geometry'][0];renamed={}
    if group=='face':
     for bone in geometry['bones']:
      if not bone.get('parent') and 'head' not in bone['name'].lower():renamed[bone['name']]='anchor_head_'+bone['name']
     for bone in geometry['bones']:
      bone['name']=renamed.get(bone['name'],bone['name'])
      if 'parent' in bone:bone['parent']=renamed.get(bone['parent'],bone['parent'])
    root=B/'resources/assets/duckswords/cosmetics'/key.lower();root.mkdir(parents=True,exist_ok=True)
    (root/'model.json').write_text(json.dumps(model,ensure_ascii=False,separators=(',',':'))+'\n')
    image=Image.open(io.BytesIO(z.read(source+'.webp')));frames=[];seen={};assert getattr(image,'n_frames',1)<=64
    for frame in range(getattr(image,'n_frames',1)):
     image.seek(frame);image.load();rgba=image.convert('RGBA');signature=hashlib.sha256(rgba.tobytes()).hexdigest();filename=seen.get(signature)
     if filename is None:
      filename='texture.png' if not seen else 'texture_'+str(len(seen))+'.png';seen[signature]=filename;rgba.save(root/filename)
     frames.append({'file':filename,'duration':max(20,min(5000,int(image.info.get('duration',100))))})
    if len(frames)>1:animated[key]=frames
    anim=source+'.animation.json'
    if anim in z.namelist():
     data=json.loads(z.read(anim))
     for animation in data.get('animations',{}).values():
      if 'bones' in animation:animation['bones']={renamed.get(k,k):v for k,v in animation['bones'].items()}
     (root/'animation.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    report.append({'id':key,'name':label,'category':group,'cubes':sum(len(b.get('cubes',[])) for b in geometry['bones']),'bones':len(geometry['bones']),'animation':anim in z.namelist(),'source_sha256':hashlib.sha256(z.read(source+'.geo.json')).hexdigest(),'root_renames':renamed})
  # Replace the legacy simplified clown mesh with the supplied complete, centered reference.
  source='game/cosmetics/face/summer2024ClownMask';model=json.loads(z.read(source+'.geo.json'));geometry=model['minecraft:geometry'][0];geometry['description']['identifier']='geometry.customMask'
  removed=0
  for bone in geometry['bones']:
   cubes=bone.get('cubes',[]);keep=[]
   for i,cube in enumerate(cubes):
    # Exact coplanar top fragment lies inside the right cheek. Removing it prevents z-fighting.
    if any(i!=j and all(cube['origin'][a]>=other['origin'][a] and cube['origin'][a]+cube['size'][a]<=other['origin'][a]+other['size'][a]+1e-6 for a in range(3)) and cube.get('rotation')==other.get('rotation') for j,other in enumerate(cubes)):
     removed+=1;continue
    keep.append(cube)
   if 'cubes' in bone:bone['cubes']=keep
  root=B/'resources/assets/duckswords/cosmetics/custommask';(root/'model.json').write_text(json.dumps(model,separators=(',',':'))+'\n');Image.open(io.BytesIO(z.read(source+'.webp'))).convert('RGBA').save(root/'texture.png')
  assert removed==1,removed
 (B/'resources/assets/duckswords/cosmetics/animated-textures.json').write_text(json.dumps(animated,separators=(',',':'))+'\n')
 (B/'cosmetics222-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'items':report,'clown_coplanar_fragments_removed':removed},ensure_ascii=False,indent=2)+'\n')
 print('Prepared',len(report),'new cosmetics (7/category); canonical clown mesh/atlas and removed one overlapping cheek face')
