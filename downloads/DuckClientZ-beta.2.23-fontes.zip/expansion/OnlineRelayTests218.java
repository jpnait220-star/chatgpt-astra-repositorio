import com.duckswords.social.CosmeticSharing;
public class OnlineRelayTests218 {
 public static void main(String[] args)throws Exception{
  String url="https://duck-connect.vercel.app",uuid=java.util.UUID.randomUUID().toString();
  if(!CosmeticSharing.request(url+"/profile","{\"uuid\":\""+uuid+"\",\"cosmetics\":[\"duckMask\",\"chinaHat\"]}").equals("{\"ok\":true}"))throw new AssertionError();
  try{var values=CosmeticSharing.parse(CosmeticSharing.request(url+"/profiles?ids="+uuid,null));if(!values.get(uuid).equals(java.util.List.of("duckMask","chinaHat")))throw new AssertionError();}
  finally{CosmeticSharing.request(url+"/profile","{\"uuid\":\""+uuid+"\",\"cosmetics\":[]}");}
  System.out.println("PASS real four-version client HTTP/parse against public Redis relay with original1.5s timeouts, synthetic UUID cleared "+args[0]);
 }
}
