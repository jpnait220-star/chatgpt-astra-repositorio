package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import org.joml.Matrix4f;
/** World-view projection only. Hand and GUI projections stay vanilla. */
public final class VisualRatio extends Module {
 public final ModeSetting preset=add(new ModeSetting("Proporcao","Estira a visao do mundo sem alterar itens nas maos","4:3","4:3","5:4","16:9","16:10","21:9","Personalizado"));
 public final NumberSetting custom=add(new NumberSetting("Proporcao personalizada","Largura dividida pela altura",1.3333,.5,4,.01));
 private static VisualRatio current;private static int worldDepth,handDepth;
 public VisualRatio(){super("Visual Ratio","Estira somente a tela do mundo; preserva o ViewModel e o HUD",Category.VISUALS);current=this;}
 public static void worldBegin(){worldDepth++;}public static void worldEnd(){worldDepth=Math.max(0,worldDepth-1);}public static void handBegin(){handDepth++;}public static void handEnd(){handDepth=Math.max(0,handDepth-1);}
 public double ratio(){return switch(preset.getValue()){case "4:3"->4./3;case "5:4"->5./4;case "16:9"->16./9;case "16:10"->16./10;case "21:9"->21./9;default->custom.getValue();};}
 public static Matrix4f projection(Matrix4f original){VisualRatio m=current;if(m==null||!m.isEnabled()||worldDepth<=0||handDepth>0||original==null)return original;double ratio=m.ratio();if(!Double.isFinite(ratio)||ratio<.5||ratio>4)return original;return new Matrix4f(original).m00((float)(original.m11()/ratio));}
 @Override public void onDisable(){worldDepth=handDepth=0;}
}
