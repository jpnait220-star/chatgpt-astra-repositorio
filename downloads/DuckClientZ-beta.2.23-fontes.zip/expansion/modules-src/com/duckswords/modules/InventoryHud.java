package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;import com.duckswords.client.ClientData;import com.duckswords.gui.DressingProps;import net.minecraft.*;import java.util.*;
public final class InventoryHud extends Module {
 private static InventoryHud current;
 public final NumberSetting x=add(new NumberSetting("X","Posicao horizontal",10,0,4000,1)),y=add(new NumberSetting("Y","Posicao vertical",130,0,4000,1));
 public final ModeSetting style=add(new ModeSetting("Estilo","Vanilla com slots de pedra; Dark com painel escuro","Vanilla","Vanilla","Dark"));
 public final ColorSetting background=add(new ColorSetting("Fundo Dark","Cor e opacidade do painel",0xd91a202a));
 public final BooleanSetting highlights=add(new BooleanSetting("Destacar itens","Pinta atras dos itens configurados no HUD e inventario",true));
 public final BooleanSetting normal=add(new BooleanSetting("Destacar no inventario","Aplica as mesmas cores nos slots de inventarios abertos",true));
 private final StringSetting[] items=new StringSetting[12];private final ColorSetting[] colors=new ColorSetting[12];private final Map<String,ColorSetting> rules=new HashMap<>();private final String[] previous=new String[12];
 public InventoryHud(){super("Inventory HUD","Seu inventario de 27 slots, sem hotbar, com cores por item",Category.HUD);current=this;for(int i=0;i<12;i++){items[i]=add(new StringSetting("Item "+(i+1),"ID do item, exemplo minecraft:totem_of_undying; vazio desativa a regra",i==0?"minecraft:totem_of_undying":"",128));colors[i]=add(new ColorSetting("Cor do item "+(i+1),"Pintura atras deste item; opacidade configuravel",i==0?0x90ffce39:0x8059a4ee));}}
 public boolean visibleRule(String name){for(int i=0;i<12;i++){if(name.equals(items[i].getName()))return i==0||!items[i].getValue().isBlank()||!items[i-1].getValue().isBlank();if(name.equals(colors[i].getName()))return !items[i].getValue().isBlank();}return true;}
 public int hudWidth(){return 170;}public int hudHeight(){return 62;}
 @Override public void onTick(){boolean changed=false;for(int i=0;i<12;i++)if(!Objects.equals(previous[i],items[i].getValue())){previous[i]=items[i].getValue();changed=true;}if(changed){rules.clear();for(int i=0;i<12;i++){String key=ClientData.normalize(previous[i]);if(!key.isEmpty())rules.put(key,colors[i]);}}}
 private int tint(class_1799 stack){if(!highlights.getValue()||stack==null||ClientData.count(stack)==0)return 0;ColorSetting c=rules.get(ClientData.key(stack));return c==null?0:c.getDisplayValue();}
 public static void slot(class_332 ctx,class_1799 stack,int x,int y){InventoryHud m=current;if(m==null||!m.isEnabled()||!m.normal.getValue())return;int color=m.tint(stack);if((color>>>24)!=0)ctx.method_25294(x,y,x+16,y+16,color);}
 @Override public void onEnable(){onTick();}
 @Override public void onHudRender(class_332 ctx,float delta){if(mc.field_1724==null)return;int left=x.getInt(),top=y.getInt();boolean dark=style.is("Dark");ctx.method_25294(left,top,left+170,top+62,dark?background.getDisplayValue():0xffc6c6c6);for(int i=0;i<27;i++){int xx=left+4+i%9*18,yy=top+4+i/9*18;if(dark)ctx.method_25294(xx,yy,xx+18,yy+18,0x80343b49);else{ctx.method_25294(xx,yy,xx+18,yy+18,0xff373737);ctx.method_25294(xx+1,yy+1,xx+18,yy+18,0xffffffff);ctx.method_25294(xx+1,yy+1,xx+17,yy+17,0xff8b8b8b);}class_1799 stack=ClientData.inventory(i+9);int color=tint(stack);if((color>>>24)!=0)ctx.method_25294(xx+1,yy+1,xx+17,yy+17,color);if(stack!=null&&ClientData.count(stack)>0){DressingProps.item(ctx,stack,xx+1,yy+1);ClientData.decorate(ctx,stack,xx+1,yy+1);}}}
}
