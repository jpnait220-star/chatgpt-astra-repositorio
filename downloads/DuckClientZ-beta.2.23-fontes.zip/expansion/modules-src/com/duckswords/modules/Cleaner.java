package com.duckswords.modules;
import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.setting.*;
/** Action card. Settings persist with the version's normal profile; enabled is never used. */
public final class Cleaner extends Module {
 public final ModeSetting level=add(new ModeSetting("Intensidade","Limites de desenho; nao muda simulacao, HUD ou particulas do Duck","Medium","Low","Medium","High","Ultra High"));
 public final BooleanSetting applied=add(new BooleanSetting("Otimizacao aplicada","Controlado pelos botoes do painel Cleaner",false));
 public Cleaner(){super("Cleaner","Abra para otimizar jogadores, entidades e efeitos do jogo preservando os efeitos do Duck",Category.CLIENT);}
 @Override public void toggle(){com.duckswords.cleaner.CleanerRuntime.open(this);}
 @Override public void setEnabled(boolean value){} // action, not a toggle
}
