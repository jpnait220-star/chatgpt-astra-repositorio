package com.duckswords.perf;
import java.util.*;import net.minecraft.*;
/** One spatial query per game tick, covering the player's whole interpolation path. */
public final class HitProbe222 {
 private static Object world,player;private static int tick;private static double px,py,pz,ox,oy,oz;private static List<class_1297> candidates=List.of();
 public static void clear(){world=player=null;candidates=List.of();tick=Integer.MIN_VALUE;}public static void frame(){if(world!=null&&net.minecraft.class_310.method_1551().field_1687!=world)clear();}
 public static boolean any(class_638 w,class_1297 p,double x,double y,double z){if(w==null||p==null)return false;double xx=p.method_23317(),yy=p.method_23318(),zz=p.method_23321(),prevX=previous(p,0),prevY=previous(p,1),prevZ=previous(p,2);if(world!=w||player!=p||tick!=p.field_6012||px!=xx||py!=yy||pz!=zz||ox!=prevX||oy!=prevY||oz!=prevZ){world=w;player=p;tick=p.field_6012;px=xx;py=yy;pz=zz;ox=prevX;oy=prevY;oz=prevZ;double motion=Math.max(Math.abs(xx-prevX),Math.max(Math.abs(yy-prevY),Math.abs(zz-prevZ)));candidates=TargetQuery220.query(p,3.03001+motion);}for(class_1297 e:candidates){if(e==p||!(e instanceof class_1309)||!e.method_5805())continue;double dx=e.method_23317()-x,dz=e.method_23321()-z;if(dx*dx+dz*dz<=9&&Math.abs(e.method_23318()-y)<=3)return true;}return false;}
 public static double previous(class_1297 player,int axis){throw new IllegalStateException("native previous position adapter");}
}
