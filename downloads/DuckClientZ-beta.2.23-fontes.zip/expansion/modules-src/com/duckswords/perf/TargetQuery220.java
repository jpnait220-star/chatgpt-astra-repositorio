package com.duckswords.perf;
import net.minecraft.*;import java.util.*;import java.util.function.Predicate;
/** One chunk-indexed candidate query per client tick; camera selection stays live each call. */
public final class TargetQuery220 {
 public static final Predicate<class_1297> LIVING=e->e instanceof class_1309;
 private static Object world,player;private static int tick;private static double radius,x,y,z;private static List<class_1297> candidates=List.of();
 public static List<class_1297> candidates(double requested){class_310 mc=class_310.method_1551();if(mc.field_1687==null||mc.field_1724==null){world=player=null;candidates=List.of();return candidates;}class_1297 p=mc.field_1724;double size=Math.max(32,requested);if(world!=mc.field_1687||player!=p||tick!=p.field_6012||radius<size||x!=p.method_23317()||y!=p.method_23318()||z!=p.method_23321()){world=mc.field_1687;player=p;tick=p.field_6012;radius=size;x=p.method_23317();y=p.method_23318();z=p.method_23321();candidates=query(p,size);}return candidates;}
 public static Iterable<class_1297> highlighted(){return candidates(32);}
 public static List<class_1297> query(class_1297 p,double radius){throw new IllegalStateException("native indexed entity query adapter");}
 public static Object crosshair(){throw new IllegalStateException("native crosshair adapter");}
 public static double eyeY(class_1297 entity){throw new IllegalStateException("native eye height adapter");}
 public static class_243 look(class_1297 entity){throw new IllegalStateException("native look adapter");}
 private static double distance(class_1297 a,class_1297 b){double dx=a.method_23317()-b.method_23317(),dy=a.method_23318()-b.method_23318(),dz=a.method_23321()-b.method_23321();return dx*dx+dy*dy+dz*dz;}
 public static class_1309 target(double range){class_310 mc=class_310.method_1551();class_1297 p=mc.field_1724;if(p==null||mc.field_1687==null||!Double.isFinite(range)||range<0)return null;double limit=range*range;if(crosshair() instanceof class_1309 e&&e!=p&&distance(e,p)<=limit)return e;class_243 look=look(p);double len=Math.sqrt(look.field_1352*look.field_1352+look.field_1351*look.field_1351+look.field_1350*look.field_1350);if(len<1e-9)return null;double lx=look.field_1352/len,ly=look.field_1351/len,lz=look.field_1350/len,py=eyeY(p),best=Math.cos(Math.toRadians(30));class_1309 target=null;
  for(class_1297 e:candidates(range)){if(!(e instanceof class_1309 living)||e==p||!e.method_5805()||distance(e,p)>limit)continue;double dx=e.method_23317()-p.method_23317(),dy=eyeY(e)-py,dz=e.method_23321()-p.method_23321(),d=dx*dx+dy*dy+dz*dz;if(d<1e-14)continue;double dot=(lx*dx+ly*dy+lz*dz)/Math.sqrt(d);if(dot>best){best=dot;target=living;}}return target;
 }
}
