package com.duckswords.cleaner;
/** Render-thread scope around Duck emission calls. No stack inspection per particle. */
public final class ClientParticleScope {
 private static final ThreadLocal<int[]> DEPTH=ThreadLocal.withInitial(()->new int[1]);
 public static void enter(){DEPTH.get()[0]++;}public static void exit(){int[] d=DEPTH.get();if(d[0]>0)d[0]--;}
 public static boolean active(){return DEPTH.get()[0]!=0;}
}
