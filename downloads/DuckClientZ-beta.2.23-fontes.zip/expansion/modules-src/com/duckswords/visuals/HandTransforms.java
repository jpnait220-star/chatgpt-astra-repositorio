package com.duckswords.visuals;
import com.duckswords.DucksWordsClient;import com.duckswords.modules.ViewModel;import com.duckswords.setting.NumberSetting;import org.joml.Quaternionf;import net.minecraft.*;import java.util.*;
/** Each hand owns a matrix scope and independent pose/size settings. */
public final class HandTransforms {
 private static final class Frame {class_4587 matrix;ViewModel model;class_1268 hand;boolean active;}
 private static final class Context {Frame[] frames={new Frame(),new Frame(),new Frame(),new Frame()};int depth;Frame push(){if(depth==frames.length){int old=frames.length;frames=Arrays.copyOf(frames,old*2);for(int i=old;i<frames.length;i++)frames[i]=new Frame();}return frames[depth++];}Frame peek(){return depth==0?null:frames[depth-1];}}
 private static final ThreadLocal<Context> STACK=ThreadLocal.withInitial(Context::new);
 private static final IdentityHashMap<ViewModel,NumberSetting> OFF_SIZE=new IdentityHashMap<>();
 public static void attach(ViewModel m){NumberSetting size=new NumberSetting("Tamanho mao secundaria","Tamanho exclusivo do item da mao secundaria",1,.1,3,.05);m.getSettings().add(size);OFF_SIZE.put(m,size);}
 public static void begin(class_742 player,class_1268 hand,class_1799 item,class_4587 matrix){ViewModel model=DucksWordsClient.MODULES.get(ViewModel.class);boolean active=model!=null&&model.isEnabled()&&!player.method_31550()&&model.shouldApply(player,hand,item);Frame frame=STACK.get().push();frame.matrix=matrix;frame.model=model;frame.hand=hand;frame.active=active;if(active){matrix.method_22903();model.apply(matrix,hand);}}
 public static void end(class_4587 matrix){Context context=STACK.get();Frame frame=context.peek();if(frame==null||frame.matrix!=matrix)return;context.depth--;if(frame.active)matrix.method_22909();frame.matrix=null;frame.model=null;frame.hand=null;frame.active=false;}
 public static void itemScale(class_4587 matrix,class_1268 hand){Frame f=STACK.get().peek();if(f!=null&&f.active&&f.matrix==matrix&&f.hand==hand)f.model.applyItemScale(matrix,hand);}
 public static void pose(ViewModel m,class_4587 matrix,class_1268 hand){if(ModernDuck.pose(m,matrix,hand))return;boolean off=hand==class_1268.field_5810;matrix.method_46416((off?m.offhandPosX:m.posX).getFloat(),(off?m.offhandPosY:m.posY).getFloat(),(off?m.offhandPosZ:m.posZ).getFloat());rotate(matrix,(off?m.offhandRotX:m.rotX).getFloat(),(off?m.offhandRotY:m.rotY).getFloat(),(off?m.offhandRotZ:m.rotZ).getFloat());}
 private static void rotate(class_4587 matrix,float x,float y,float z){if(x!=0)matrix.method_22907(new Quaternionf().rotationX((float)Math.toRadians(x)));if(y!=0)matrix.method_22907(new Quaternionf().rotationY((float)Math.toRadians(y)));if(z!=0)matrix.method_22907(new Quaternionf().rotationZ((float)Math.toRadians(z)));}

 public static void scale(ViewModel m,class_4587 matrix,class_1268 hand){if(ModernDuck.scale(m,matrix,hand))return;boolean off=hand==class_1268.field_5810;NumberSetting offSize=OFF_SIZE.get(m);float size=off?(offSize==null?1:offSize.getFloat()):m.itemSize.getFloat();matrix.method_22905((off?m.offhandX:m.scaleX).getFloat()*size,(off?m.offhandY:m.scaleY).getFloat()*size,(off?m.offhandZ:m.scaleZ).getFloat()*size);}
}
