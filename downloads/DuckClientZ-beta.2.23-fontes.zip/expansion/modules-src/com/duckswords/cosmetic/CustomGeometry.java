package com.duckswords.cosmetic;
/** Mark only client-created models. Vanilla/Sodium models keep their normal fast path. */
public final class CustomGeometry {public interface Marker {void duck$customGeometry();}public static void mark(Object model){if(model instanceof Marker m)m.duck$customGeometry();}}
