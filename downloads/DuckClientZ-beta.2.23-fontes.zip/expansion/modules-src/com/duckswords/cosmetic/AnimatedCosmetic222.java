package com.duckswords.cosmetic;
import com.google.gson.*;import java.util.*;import java.io.*;import java.nio.charset.StandardCharsets;
/** Small pre-decoded texture frames. No per-frame file reads, uploads or model rebuilding. */
public final class AnimatedCosmetic222 {
 private static final long START=System.nanoTime();private static final Map<String,Frames> ANIMATIONS=load();
 private static final class Frames {final String[] files;final long[] ends;final Object[] layers;final long length;Frames(String id,JsonArray values){int n=values.size();files=new String[n];ends=new long[n];layers=new Object[n];long total=0;for(int i=0;i<n;i++){JsonObject frame=values.get(i).getAsJsonObject();files[i]="cosmetics/"+id.toLowerCase(Locale.ROOT)+"/"+frame.get("file").getAsString();ends[i]=total+=frame.get("duration").getAsLong();}length=total;}}
 private static Map<String,Frames> load(){try(InputStream stream=AnimatedCosmetic222.class.getResourceAsStream("/assets/duckswords/cosmetics/animated-textures.json")){if(stream==null)return Map.of();JsonObject root=JsonParser.parseString(new String(stream.readAllBytes(),StandardCharsets.UTF_8)).getAsJsonObject();Map<String,Frames> result=new HashMap<>();for(var e:root.entrySet())result.put(e.getKey(),new Frames(e.getKey(),e.getValue().getAsJsonArray()));return Map.copyOf(result);}catch(IOException|RuntimeException error){throw new IllegalStateException("Invalid cosmetic frame manifest",error);}}
 public static Object layer(Object original,String id){return at(original,id,(System.nanoTime()-START)/1_000_000);}
 public static Object at(Object original,String id,long milliseconds){Frames frames=ANIMATIONS.get(id);if(frames==null)return original;long time=Math.floorMod(milliseconds,frames.length);int i=0;while(i<frames.ends.length-1&&time>=frames.ends[i])i++;Object layer=frames.layers[i];if(layer==null){layer=frames.files[i].endsWith("/texture.png")?original:make(frames.files[i]);frames.layers[i]=layer;}return layer;}
 public static Object make(String path){throw new IllegalStateException("native texture layer adapter");}
}
