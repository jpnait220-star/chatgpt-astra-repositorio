package com.duckswords.render;
import com.duckswords.gui.GuiTransforms;import net.minecraft.class_332;import java.util.*;
/** Subpixel antialiased ring. Coverage/runs are rebuilt only when geometry changes. */
public final class SmoothRing {
 private record Run(int x,int y,int width,int alpha){}private double radius=-1,thickness;private List<Run> runs=List.of();
 private void prepare(double r,double t){if(r==radius&&t==thickness)return;radius=r;thickness=t;List<Run> result=new ArrayList<>();int n=(int)Math.ceil((r+t+1)*4);for(int y=-n;y<=n;y++){int start=-n,last=-1;for(int x=-n;x<=n+1;x++){double d=Math.hypot(x+.5,y+.5);int a=x>n?0:(int)Math.round(255*Math.max(0,Math.min(1,t*2+.5-Math.abs(d-r*4))));if(a!=last){if(last>0)result.add(new Run(start,y,x-start,last));start=x;last=a;}}}runs=List.copyOf(result);}
 public void draw(class_332 c,float x,float y,double radius,double thickness,int color,float size){prepare(radius,thickness);GuiTransforms.push(c,x,y,size/4);try{int a=color>>>24;for(Run run:runs){int alpha=run.alpha*a/255;if(alpha>0)c.method_25294(run.x,run.y,run.x+run.width,run.y+1,(color&0xffffff)|alpha<<24);}}finally{GuiTransforms.pop(c);}}
 public static int blend(int a,int b,double t){t=Math.max(0,Math.min(1,t));int out=0;for(int shift:new int[]{0,8,16,24})out|=(int)Math.round((a>>>shift&255)*(1-t)+(b>>>shift&255)*t)<<shift;return out;}
}
