package com.duckswords.render;
import com.duckswords.theme.HudText;import net.minecraft.class_332;
public final class FixedHudFont {
 public static void draw(class_332 context,String value,int x,int y,int color){throw new IllegalStateException("native font adapter");}
 public static int width(String value){throw new IllegalStateException("native font adapter");}
 public static void selective(class_332 c,String value,int x,int y,int color){if(!value.isEmpty()&&(Character.isDigit(value.charAt(0))||value.charAt(0)=='+')&&(value.contains("/")||value.contains("❤")))draw(c,value.replace("❤",""),x,y,color);else HudText.draw(c,value,x,y,color);}
}
