package com.duckswords.render;import net.minecraft.class_2338;
/** Visual-only continuation past the cobweb containing the camera; never changes interaction targets. */
public final class WebOutlineTarget {
 public static class_2338 position(class_2338 supplied){throw new IllegalStateException("native ray adapter");}
 public static double[] direction(float yaw,float pitch){double y=Math.toRadians(yaw),p=Math.toRadians(pitch),c=Math.cos(p);return new double[]{-Math.sin(y)*c,-Math.sin(p),Math.cos(y)*c};}
 public static double exit(double x,double y,double z,double dx,double dy,double dz){double[] pos={x,y,z},dir={dx,dy,dz};double end=Double.POSITIVE_INFINITY;for(int i=0;i<3;i++){if(Math.abs(dir[i])<1e-9)continue;double bound=Math.floor(pos[i])+(dir[i]>0?1:0);end=Math.min(end,(bound-pos[i])/dir[i]);}return end;}
}
