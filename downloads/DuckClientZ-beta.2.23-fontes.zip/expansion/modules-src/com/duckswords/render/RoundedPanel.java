package com.duckswords.render;
import com.duckswords.gui.GuiTransforms;import net.minecraft.class_332;import java.util.concurrent.ConcurrentHashMap;
/** Cached subpixel corner coverage; no images, uploads or per-frame geometry allocation. */
public final class RoundedPanel {
 private static final int Q=2;private record Shape(int[] inset,int[] alpha){}private static final ConcurrentHashMap<Integer,Shape> CACHE=new ConcurrentHashMap<>();
 private static Shape shape(int r){int n=r*Q;int[] inset=new int[n],alpha=new int[n];for(int row=0;row<n;row++){double dy=n-row-.5,edge=n-Math.sqrt(Math.max(0,n*n-dy*dy));int floor=(int)edge;inset[row]=floor;alpha[row]=(int)Math.round(255*(1-(edge-floor)));}return new Shape(inset,alpha);}
 public static void draw(class_332 c,int x,int y,int width,int height,int radius,int color){if(width<=0||height<=0||(color>>>24)==0)return;int r=Math.max(0,Math.min(radius,Math.min(width,height)/2));if(r==0){c.method_25294(x,y,x+width,y+height,color);return;}Shape s=CACHE.computeIfAbsent(r,RoundedPanel::shape);int w=width*Q,h=height*Q,n=r*Q;GuiTransforms.push(c,x,y,1f/Q);try{c.method_25294(0,n,w,h-n,color);for(int row=0;row<n;row++){int left=s.inset[row],a=(color>>>24)*s.alpha[row]/255,edge=color&0xffffff|a<<24;for(int side=0;side<2;side++){int yy=side==0?row:h-row-1;c.method_25294(left+1,yy,w-left-1,yy+1,color);if(a>0){c.method_25294(left,yy,left+1,yy+1,edge);c.method_25294(w-left-1,yy,w-left,yy+1,edge);}}}}finally{GuiTransforms.pop(c);}}
}
