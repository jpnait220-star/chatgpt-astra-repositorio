package com.duckswords.render;
import net.minecraft.class_332;import com.duckswords.gui.GuiTransforms;import java.util.concurrent.ConcurrentHashMap;
/** Cached corner spans. Straight edges stay single rectangles, regardless of panel height. */
public final class MenuPanels223 {
 private record Rim(int[] outer,int[] inner){}private static final ConcurrentHashMap<Integer,Rim> RIMS=new ConcurrentHashMap<>();
 private static Rim rim(int radius){int n=radius*2;int[] outer=new int[n],inner=new int[n];for(int row=0;row<n;row++){double dy=n-row-.5;outer[row]=(int)Math.ceil(n-Math.sqrt(Math.max(0,n*n-dy*dy)));inner[row]=dy>=n-2?-1:(int)Math.ceil(n-Math.sqrt(Math.max(0,(n-2)*(n-2)-dy*dy)));}return new Rim(outer,inner);}
 public static void outline(class_332 c,int x,int y,int w,int h,int radius,int color){if(w<3||h<3||(color>>>24)==0)return;int r=Math.min(radius,Math.min(w,h)/2);if(r<1)return;Rim rim=RIMS.computeIfAbsent(r,MenuPanels223::rim);int n=r*2,ww=w*2,hh=h*2;GuiTransforms.push(c,x,y,.5f);try{c.method_25294(0,n,2,hh-n,color);c.method_25294(ww-2,n,ww,hh-n,color);for(int row=0;row<n;row++){int from=rim.outer[row],to=rim.inner[row];for(int side=0;side<2;side++){int yy=side==0?row:hh-row-1;if(to<0)c.method_25294(from,yy,ww-from,yy+1,color);else if(to>from){c.method_25294(from,yy,to,yy+1,color);c.method_25294(ww-to,yy,ww-from,yy+1,color);}}}}finally{GuiTransforms.pop(c);}}
 public static void box(class_332 c,int x,int y,int w,int h,int radius,int fill,int border){RoundedPanel.draw(c,x,y,w,h,radius,fill);outline(c,x,y,w,h,radius,border);}
 public static void panel(class_332 c,int x,int y,int w,int h,int fill,int border){box(c,x,y,w,h,Math.min(5,h/2),fill,border);}
 public static void background(class_332 c,int x,int y,int w,int h,int fill,int border){box(c,x,y,w,h+10,8,fill,border);}
 public static int hoverColor(){throw new IllegalStateException("native theme adapter");}
 public static void hover(class_332 c,int x,int y,int w,int h,float alpha){int color=hoverColor();int opacity=Math.min(255,Math.max(0,(int)(alpha*255)));RoundedPanel.draw(c,x+1,y+1,w-2,h-2,4,color&0xffffff|opacity<<24);}
 public static void glow(class_332 c,int x,int y,int w,int h,int color,float alpha){int opacity=Math.min(70,Math.max(0,(int)(alpha*255)));RoundedPanel.draw(c,x-1,y-1,w+2,h+2,6,color&0xffffff|opacity<<24);}
}
