package com.duckswords.render;
import org.joml.Matrix4f;import com.duckswords.module.Module;import com.duckswords.setting.NumberSetting;
/** All glint passes in one frame share phase/matrices. Returned matrices are never mutated later. */
public final class GlintFrame222 {
 public interface Clock {double advance(long now,double speed);}private static long frame;private static Module nativeOwner;private static NumberSetting nativeStrength;
 private static final class State {Object owner,clock;long frame=Long.MIN_VALUE;long speed;double phase;int count;final float[] scales=new float[8],sizes=new float[8];final Matrix4f[] matrices=new Matrix4f[8];}private static final ThreadLocal<State> CACHE=ThreadLocal.withInitial(State::new);
 private static final ThreadLocal<Matrix4f> DISPATCH=ThreadLocal.withInitial(Matrix4f::new);public static Matrix4f dispatch(Matrix4f template){return DISPATCH.get().set(template);}
 public static void nextFrame(){frame++;}public static void invalidate(Object owner){State s=CACHE.get();if(s.owner==owner)s.frame=Long.MIN_VALUE;}
 public static Matrix4f matrix(Object owner,Object clock,double speed,float scale,float size){State s=CACHE.get();long bits=Double.doubleToLongBits(speed);if(s.owner!=owner||s.clock!=clock||s.frame!=frame||s.speed!=bits){s.owner=owner;s.clock=clock;s.frame=frame;s.speed=bits;s.count=0;s.phase=((Clock)clock).advance(System.nanoTime(),speed);}for(int i=0;i<s.count;i++)if(s.scales[i]==scale&&s.sizes[i]==size)return s.matrices[i];double phase=s.phase;float x=(float)(phase*4000%110000/110000),y=(float)(phase*4000%30000/30000);Matrix4f matrix=new Matrix4f().translation(-x,y,0).rotateZ(0.17453292f).scale(scale*.5f/size);if(s.count<8){int i=s.count++;s.scales[i]=scale;s.sizes[i]=size;s.matrices[i]=matrix;}return matrix;}
 public static void bind(Module module,NumberSetting strength){nativeOwner=module;nativeStrength=strength;}public static void unbind(Module module){if(nativeOwner==module){nativeOwner=null;nativeStrength=null;}}
 public static double strength(double vanilla){Module owner=nativeOwner;NumberSetting strength=nativeStrength;return owner!=null&&owner.isEnabled()&&strength!=null?vanilla*strength.getValue():vanilla;}
}
