package com.duckswords.render;
/** Dedicated cached line material only for Duck overlays while the camera is inside cobweb. */
public final class WebLineLayers {
 private static long frame,checked=-1;private static boolean inside;private static Object world;
 public static void frame(){frame++;}
 public static Object layer(Object normal){Object current=net.minecraft.class_310.method_1551().field_1687;if(checked!=frame||world!=current){inside=insideWeb();checked=frame;world=current;}return inside?special():normal;}
 public static boolean insideWeb(){throw new IllegalStateException("native cobweb adapter");}
 public static Object special(){throw new IllegalStateException("native line material adapter");}
}
