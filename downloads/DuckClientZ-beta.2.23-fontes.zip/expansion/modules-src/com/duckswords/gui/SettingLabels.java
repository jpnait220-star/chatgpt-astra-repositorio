package com.duckswords.gui;
import com.duckswords.setting.Setting;
/** Display labels only: profile keys remain unchanged. */
public final class SettingLabels {public static String name(Setting<?> setting){String value=setting.getName();if(value.equals("Tamanho do item"))return "Tamanho mao principal";if(value.matches("(Posicao|Rotacao|Escala) [XYZ]"))return value+" principal";if(value.equals("Travar câmera")||value.equals("Travar camera"))return "Travar cabeca";if(value.equals("Estilo ModernDuck"))return "Estilo";if(value.startsWith("ModernDuck ")){value=value.substring(11);if(!value.isEmpty())value=Character.toUpperCase(value.charAt(0))+value.substring(1);}return value;}}
