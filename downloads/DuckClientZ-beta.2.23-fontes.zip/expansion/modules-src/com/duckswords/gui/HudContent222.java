package com.duckswords.gui;
/** Data predicates only; a hidden HUD never allocates or draws its background. */
public final class HudContent222 {
 public static boolean text(Object value){return value instanceof String s&&!s.isBlank();}
 public static boolean cps(Object value,boolean right){if(!(value instanceof String s))return false;if(!right)s=s.replace(" | {right} R","").replace("{right}","");return !s.isBlank();}
 public static boolean effects(){throw new IllegalStateException("native effect collection adapter");}
}
