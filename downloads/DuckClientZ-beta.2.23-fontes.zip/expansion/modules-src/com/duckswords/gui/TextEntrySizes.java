package com.duckswords.gui;import com.duckswords.modules.TextHud;import com.google.gson.*;import net.minecraft.class_332;import java.util.*;
public final class TextEntrySizes {
 public interface Scale {float duck$entryScale();void duck$entryScale(float value);}
 public static float scale(TextHud.Entry e){return (Object)e instanceof Scale s?s.duck$entryScale():1;}
 public static void set(TextHud.Entry e,float value){if((Object)e instanceof Scale s)s.duck$entryScale(Math.round(Math.max(.25f,Math.min(3,value))*20)/20f);}
 public static void begin(class_332 c,TextHud.Entry e){float s=scale(e);if(s!=1)GuiTransforms.anchor(c,e.x(),e.y(),s);}public static void end(class_332 c,TextHud.Entry e){if(scale(e)!=1)GuiTransforms.pop(c);}
 public static JsonArray write(JsonArray data){List<TextHud.Entry> entries=TextHud.entries();for(int i=0;i<Math.min(entries.size(),data.size());i++){float s=scale(entries.get(i));if(s!=1)data.get(i).getAsJsonObject().addProperty("scale",s);}return data;}
 public static void validate(JsonArray data){for(JsonElement row:data)if(row.isJsonObject()&&row.getAsJsonObject().has("scale")){JsonElement value=row.getAsJsonObject().get("scale");if(!value.isJsonPrimitive()||!value.getAsJsonPrimitive().isNumber())throw new IllegalArgumentException("Escala de texto invalida");float s=value.getAsFloat();if(!Float.isFinite(s)||s<.25||s>3)throw new IllegalArgumentException("Escala de texto invalida");}}
 public static void read(JsonArray data){List<TextHud.Entry> entries=TextHud.entries();for(int i=0;i<Math.min(entries.size(),data.size());i++){JsonObject value=data.get(i).getAsJsonObject();set(entries.get(i),value.has("scale")?value.get("scale").getAsFloat():1);}}
 public static void reset(){for(TextHud.Entry e:TextHud.entries())set(e,1);}
}
