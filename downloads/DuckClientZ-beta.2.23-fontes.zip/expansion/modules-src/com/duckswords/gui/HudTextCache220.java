package com.duckswords.gui;
import net.minecraft.class_2561;import java.util.*;
/** Main-thread bounded text/metrics cache. Changing the selected font invalidates both together. */
public final class HudTextCache220 {
 private static final class Entry {class_2561 styled;int width=-1;}
 private static String selected="";private static volatile boolean invalidated;private static final LinkedHashMap<String,Entry> CACHE=new LinkedHashMap<>(128,.75f,true){protected boolean removeEldestEntry(Map.Entry<String,Entry> e){return size()>512;}};
 private static Entry entry(String text){String font=font();if(invalidated||!selected.equals(font)){CACHE.clear();selected=font;invalidated=false;}return CACHE.computeIfAbsent(text,k->new Entry());}
 public static class_2561 styled(String text){if(text.length()>1024)return rawStyle(text);Entry e=entry(text);if(e.styled==null)e.styled=rawStyle(text);return e.styled;}
 public static int width(String text){if(text.length()>1024)return rawWidth(text);Entry e=entry(text);if(e.width<0)e.width=rawWidth(text);return e.width;}
 public static void clear(){invalidated=true;}public static void reload(Object future){if(future instanceof java.util.concurrent.CompletableFuture<?> f)f.whenComplete((value,error)->clear());else clear();}
 public static String font(){throw new IllegalStateException("native font selector");}public static class_2561 rawStyle(String value){throw new IllegalStateException("native style adapter");}public static int rawWidth(String value){throw new IllegalStateException("native width adapter");}
}
