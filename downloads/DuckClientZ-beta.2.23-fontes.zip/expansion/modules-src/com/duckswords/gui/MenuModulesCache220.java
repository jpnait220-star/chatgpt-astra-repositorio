package com.duckswords.gui;
import com.duckswords.module.Module;import com.duckswords.DucksWordsClient;import java.util.*;
public final class MenuModulesCache220 {
 public interface View {List<Module> duck$uncachedModules220();}
 private record Key(Object manager,String tab,String query,int count,long favorites){}private record Entry(Key key,List<Module> list){}private static final WeakHashMap<View,Entry> CACHE=new WeakHashMap<>();
 public static List<Module> get(View view,String tab,String query){List<Module> modules=DucksWordsClient.MODULES.getModules();long signature=1;if(tab.equals("FAVORITOS"))for(Module m:modules)signature=signature*31+(m.favorite?1:0);Key key=new Key(DucksWordsClient.MODULES,tab,query,modules.size(),signature);Entry old=CACHE.get(view);if(old!=null&&old.key.equals(key))return old.list;List<Module> list=List.copyOf(view.duck$uncachedModules220());CACHE.put(view,new Entry(key,list));return list;}
}
