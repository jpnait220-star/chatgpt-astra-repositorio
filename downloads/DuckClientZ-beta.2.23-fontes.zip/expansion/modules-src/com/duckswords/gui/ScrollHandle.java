package com.duckswords.gui;
import net.minecraft.class_332;import com.duckswords.render.RoundedPanel;import java.util.*;
public final class ScrollHandle {
 public interface View {int duckScrollX();int duckScrollY();int duckScrollHeight();int duckScrollMax();int duckScrollValue();void duckScrollSet(int value);default int duckScrollWidth(){return 5;}default int duckScrollPixelsMax(){return duckScrollMax();}}
 private static final Set<View> DRAG=Collections.newSetFromMap(new WeakHashMap<>());
 private static int thumb(View v){int h=v.duckScrollHeight();return Math.min(h,Math.max(12,h*h/Math.max(1,h+Math.max(0,v.duckScrollPixelsMax()))));}
 public static void draw(View v,class_332 c){int max=v.duckScrollMax(),h=v.duckScrollHeight();if(max<=0||h<=0)return;int x=v.duckScrollX(),y=v.duckScrollY(),w=Math.max(1,v.duckScrollWidth()),t=thumb(v),at=y+(h-t)*Math.max(0,Math.min(max,v.duckScrollValue()))/max;RoundedPanel.draw(c,x,y,w,h,w/2,0x80303945);RoundedPanel.draw(c,x,at,w,t,w/2,0xffa2adbf);}
 private static void move(View v,double y){int t=thumb(v),h=v.duckScrollHeight();double p=(y-v.duckScrollY()-t/2.)/Math.max(1,h-t);v.duckScrollSet((int)Math.round(Math.max(0,Math.min(1,p))*v.duckScrollMax()));}
 public static boolean click(View v,double x,double y,int button){if(button!=0||v.duckScrollMax()<=0||x<v.duckScrollX()-2||x>v.duckScrollX()+v.duckScrollWidth()+2||y<v.duckScrollY()||y>v.duckScrollY()+v.duckScrollHeight())return false;DRAG.add(v);move(v,y);return true;}
 public static boolean drag(View v,double y){if(!DRAG.contains(v))return false;move(v,y);return true;}
 public static boolean release(View v){return DRAG.remove(v);}
}
