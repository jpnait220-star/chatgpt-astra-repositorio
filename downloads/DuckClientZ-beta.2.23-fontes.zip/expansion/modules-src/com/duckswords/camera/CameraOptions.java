package com.duckswords.camera;
import com.duckswords.module.Module;import com.duckswords.setting.*;import com.duckswords.client.ClientData;import java.util.*;
public final class CameraOptions {
 private record Options(BooleanSetting lock,BooleanSetting scroll){}private static final IdentityHashMap<Module,Options> ALL=new IdentityHashMap<>();
 public static void attach(Module m){BooleanSetting lock=null;for(Setting<?> s:m.getSettings())if(s instanceof BooleanSetting b&&s.getName().startsWith("Travar"))lock=b;if(lock==null){lock=new BooleanSetting("Travar cabeca","Ligado gira somente a camera; desligado a cabeca acompanha",true);m.getSettings().add(lock);}BooleanSetting scroll=new BooleanSetting("Zoom com rolagem","Permite aproximar e afastar a camera com a roda do mouse",true);m.getSettings().add(scroll);ALL.put(m,new Options(lock,scroll));}
 public static boolean locked(Module m){Options o=ALL.get(m);return o==null||o.lock.getValue();}public static boolean scrolling(Module m){Options o=ALL.get(m);return o==null||o.scroll.getValue();}
 public static float yaw(Module m,float fallback){return locked(m)||net.minecraft.class_310.method_1551().field_1724==null?fallback:ClientData.playerYaw();}public static float pitch(Module m,float fallback){return locked(m)||net.minecraft.class_310.method_1551().field_1724==null?fallback:ClientData.playerPitch();}

 private static final class Session {Object player,world;boolean active,blocked;int perspective;}
 private static final IdentityHashMap<Module,Session> SESSIONS=new IdentityHashMap<>();
 public static void reset(Module m){SESSIONS.remove(m);}
 public static boolean cancel(com.duckswords.modules.RecordingCamera m){net.minecraft.class_310 mc=net.minecraft.class_310.method_1551();Session state=SESSIONS.computeIfAbsent(m,k->new Session());boolean held=m.bind.isPressed();if(state.player!=mc.field_1724||state.world!=mc.field_1687){state.player=mc.field_1724;state.world=mc.field_1687;state.active=false;state.blocked=held;}int current=ClientData.perspectiveId();boolean changed=state.active&&m.isCameraActive()&&current!=state.perspective;if(mc.field_1755!=null||changed){state.blocked=true;m.onDisable();if(changed)ClientData.perspectiveId(current);state.active=false;return true;}if(state.blocked){if(!held)state.blocked=false;return true;}return false;}
 public static void finished(com.duckswords.modules.RecordingCamera m){Session state=SESSIONS.computeIfAbsent(m,k->new Session());state.active=m.isCameraActive();state.perspective=ClientData.perspectiveId();}
public static void frame(){var m=com.duckswords.DucksWordsClient.MODULES.get(com.duckswords.modules.RecordingCamera.class);if(m!=null&&m.isEnabled()&&m.isCameraActive()){cancel(m);finished(m);}}
}
