package com.duckswords.input;
import com.duckswords.modules.FireworkKey;import java.util.*;
/** Real-time pacing prevents catch-up ticks from emitting bursts. No movement or custom use packets. */
public final class FireworkTiming {
 public interface Restore {void duck$restoreFirework();}
 private static final class State {long attempt,restore;boolean used,pending;}
 private static final IdentityHashMap<FireworkKey,State> STATES=new IdentityHashMap<>();private static FireworkKey pending;
 private static State state(FireworkKey m){return STATES.computeIfAbsent(m,k->new State());}
 public static boolean allowUse(FireworkKey m){State s=state(m);long now=System.nanoTime(),delay=(long)Math.max(5,m.delay.getInt())*50_000_000L;return !s.pending&&(!s.used||now-s.attempt>=delay);}
 public static void used(FireworkKey m){State s=state(m);s.used=true;s.attempt=System.nanoTime();}
 public static void switched(FireworkKey m){State s=state(m);s.pending=true;s.restore=System.nanoTime()+55_000_000L;pending=m;}
 public static boolean ready(FireworkKey m){State s=STATES.get(m);return s==null||!s.pending||System.nanoTime()>=s.restore;}
 public static void cancel(FireworkKey m){STATES.remove(m);if(pending==m)pending=null;}
 public static void frame(){FireworkKey m=pending;if(m==null)return;State s=STATES.get(m);if(s==null){pending=null;return;}if(System.nanoTime()<s.restore)return;s.pending=false;pending=null;((Restore)(Object)m).duck$restoreFirework();}
}
