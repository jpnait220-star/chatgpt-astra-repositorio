package com.duckswords.input;
import com.duckswords.setting.KeybindSetting;import com.duckswords.modules.AutoClicker;import java.util.*;
public final class KeyboardOnlyBinds {
 private static final Set<KeybindSetting> KEYS=Collections.newSetFromMap(new IdentityHashMap<>());
 public static void register(AutoClicker owner){KEYS.add(owner.bind);normalize(owner.bind);}
 public static boolean reject(KeybindSetting bind,int key){return KEYS.contains(bind)&&key<=-100;}
 public static void normalize(KeybindSetting bind){if(reject(bind,bind.getKey()))bind.clear();}
}
