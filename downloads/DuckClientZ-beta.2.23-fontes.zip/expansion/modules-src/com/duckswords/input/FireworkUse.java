package com.duckswords.input;
/** Native adapter mirrors vanilla successful-use swing/equip feedback, without a second item use. */
public final class FireworkUse {public static void finish(Object result){throw new IllegalStateException("native action result adapter");}}
