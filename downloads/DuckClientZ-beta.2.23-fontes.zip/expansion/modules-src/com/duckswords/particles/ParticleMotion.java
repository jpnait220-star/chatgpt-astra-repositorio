package com.duckswords.particles;import net.minecraft.*;
/** Native adapter: preserve the requested burst velocity after vanilla construction. */
public final class ParticleMotion {public static void restore(Object particle,double x,double y,double z){throw new IllegalStateException("native particle velocity adapter");}public static void spawn(class_638 world,class_2394 type,double x,double y,double z,double vx,double vy,double vz){throw new IllegalStateException("native adapter");}}
