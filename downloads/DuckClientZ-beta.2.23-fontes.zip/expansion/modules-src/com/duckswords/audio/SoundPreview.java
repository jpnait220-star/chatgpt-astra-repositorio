package com.duckswords.audio;
import com.duckswords.DucksWordsClient;import com.duckswords.module.Module;import com.duckswords.setting.*;
/** Called from interactive mode cycling only, never profile loading or rendering. */
public final class SoundPreview {
 private static long next;
 public static void cycle(ModeSetting setting,int direction){setting.cycle(direction);String value=setting.getValue();if(ModernSounds.id(value)==null)return;for(Module module:DucksWordsClient.MODULES.getModules())if(module.getSettings().contains(setting)){String name=module.getName();if(!name.equals("HitSound")&&!name.equals("ClickSounds")&&!name.equals("Totem Editor")&&!setting.getName().toLowerCase(java.util.Locale.ROOT).contains("som"))return;long now=System.nanoTime();if(now<next)return;next=now+100_000_000L;float volume=.65f,pitch=1;for(Setting<?> s:module.getSettings())if(s instanceof NumberSetting number){if(s.getName().toLowerCase(java.util.Locale.ROOT).contains("volume"))volume=number.getFloat();if(s.getName().equalsIgnoreCase("Pitch"))pitch=number.getFloat();}ModernSounds.play(value,volume,pitch);return;}}
 public static String label(ModeSetting setting){if(setting.getName().equals("Servico oficial"))return com.duckswords.social.CosmeticSharing.status();String value=setting.getValue();return value.startsWith("ModernDuck ")?value.substring(11):value;}
}
