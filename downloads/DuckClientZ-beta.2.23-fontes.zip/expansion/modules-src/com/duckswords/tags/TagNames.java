package com.duckswords.tags;
import com.duckswords.social.CosmeticSharing;import com.duckswords.client.ClientData;import java.util.*;
/** Cosmetic presence only: not an account/authentication badge. Does not touch scoreboard/team data. */
public final class TagNames {
 private record Cached(String uuid,Object value){}private static final IdentityHashMap<Object,Cached> CACHE=new IdentityHashMap<>();
 public static Object name(Object original,Object entity){if(entity==null)return original;return decorate(original,ClientData.entityUUID(ClientData.entityId(entity)));}
 public static Object decorate(Object original,String uuid){if(original==null||!CosmeticSharing.tagged(uuid))return original;Cached entry=CACHE.get(original);if(entry!=null&&Objects.equals(uuid,entry.uuid))return entry.value;if(CACHE.size()>=256)CACHE.clear();Object text=prefix(original);CACHE.put(original,new Cached(uuid,text));return text;}
 public static Object prefix(Object original){throw new IllegalStateException("native text adapter");}
 public static Iterable<?> entries(){throw new IllegalStateException("native tab entries adapter");}
 public static String uuid(Object entry){throw new IllegalStateException("native profile adapter");}
}
