from pathlib import Path
from zipfile import ZipFile
import json
B=Path(__file__).parent
for v,e in json.loads((B/'build-report.json').read_text()).items():
 expected={'fabric.mod.json','com/duckswords/mixin/MixinWebLines218.class'}
 expected.add('com/duckswords/mixin/MixinWebPipeline218.class' if v=='1.21.11' else 'com/duckswords/util/MinecraftCompat.class')
 with ZipFile(e['jar']) as current,ZipFile(B/'dist'/f'DuckClientZ-{v}-1.5.28-beta.2.18.jar') as old:
  assert set(current.namelist())==set(old.namelist())
  changed={n for n in old.namelist() if old.read(n)!=current.read(n)};assert changed==expected,(v,changed^expected)
  meta=json.loads(current.read('fabric.mod.json'));oldmeta=json.loads(old.read('fabric.mod.json'));assert meta.pop('version')=='1.5.28-beta.2.19';oldmeta.pop('version');assert meta==oldmeta
 print('PASS exact release scope:',v,'only metadata, web bridges and NativeImage fix where applicable; profiles/assets/features otherwise byte-identical')
