from pathlib import Path
from zipfile import ZipFile
import json,math
B=Path(__file__).parent
with ZipFile(B/'dist/DuckClientZ-1.21.4-1.5.28-beta.2.19.jar') as z:
 for key in ['custommask','winter2024bunnyhat']:
  name=f'assets/duckswords/cosmetics/{key}/model.json';root=json.loads(z.read(name));changes=0
  for bone in root['minecraft:geometry'][0]['bones']:
   for cube in bone.get('cubes',[]):
    if not isinstance(cube.get('uv'),list):continue
    # Bedrock box-UV pixel dimensions are integral even when model geometry is scaled.
    u,v=cube['uv'];w,h,d=[math.floor(n+.5) for n in cube['size']]
    layout={'north':([u+d,v+d],[w,h]),'south':([u+2*d+w,v+d],[w,h]),'east':([u+d+w,v+d],[d,h]),'west':([u,v+d],[d,h]),'up':([u+d,v],[w,d]),'down':([u+d+w,v+d],[w,-d])}
    cube['uv']={face:{'uv':uv,'uv_size':size} for face,(uv,size) in layout.items()};changes+=1
  path=B/'resources'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(root,ensure_ascii=False,separators=(',',':'))+'\n');print('Prepared explicit UV faces, unchanged geometry:',key,changes)
