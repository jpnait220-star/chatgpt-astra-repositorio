from pathlib import Path
from generate_hooks import catalog
B=Path(__file__).parent
for v in ['1.20.1','1.21.1','1.21.4','1.21.11']:
 m,f,c,t=catalog(v);rows=[]
 for key,name in [('world','renderLevel'),('hand','renderItemInHand'),('projection','getProjectionMatrix')]:
  found=m('net.minecraft.client.renderer.GameRenderer',name);assert len(found)==1;(rows.append([key,*found[0][:3]]))
 for key,name in [('cameraPos','position' if v=='1.21.11' else 'getPosition'),('cameraYaw','yRot' if v=='1.21.11' else 'getYRot'),('cameraPitch','xRot' if v=='1.21.11' else 'getXRot')]:rows.append([key,*(m('net.minecraft.client.Camera',name) or m('net.minecraft.world.waypoints.TrackedWaypoint$Camera',name))[0][:3]])
 rows.append(['font',*next(x[:3] for x in m('net.minecraft.client.gui.GuiGraphics','drawString') if x[2].startswith('(Lnet/minecraft/class_327;Ljava/lang/String;IIIZ)'))])
 (B/'native'/v/'followup218.tsv').write_text('\n'.join('\t'.join(r) for r in rows)+'\n')
