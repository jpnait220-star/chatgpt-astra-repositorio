from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import json,io
B=Path(__file__).parent
def no_uv(v):
 if isinstance(v,dict):return {k:no_uv(x) for k,x in v.items() if k!='uv'}
 if isinstance(v,list):return [no_uv(x) for x in v]
 return v
for version,entry in json.loads((B/'build-report.json').read_text()).items():
 with ZipFile(entry['jar']) as z,ZipFile(B/f'dist/DuckClientZ-{version}-1.5.28-beta.2.20.jar') as old:
  name='assets/duckswords/cosmetics/custommask/model.json';a=json.loads(old.read(name));b=json.loads(z.read(name));assert no_uv(a)==no_uv(b)
  ac=a['minecraft:geometry'][0]['bones'][0]['cubes'];bc=b['minecraft:geometry'][0]['bones'][0]['cubes'];assert ac[4:]==bc[4:]
  texture=Image.open(io.BytesIO(z.read('assets/duckswords/cosmetics/custommask/texture.png'))).convert('RGBA')
  for cube in bc:
   for face in cube['uv'].values():
    u,v=face['uv'];w,h=face['uv_size'];assert min(u,u+w)>=0 and max(u,u+w)<=64 and min(v,v+h)>=0 and max(v,v+h)<=64
  def count(cube,predicate):
   face=cube['uv']['north'];u,v=map(int,face['uv']);w,h=map(int,face['uv_size']);return sum(predicate(texture.getpixel((x,y))) for x in range(u,u+w) for y in range(v,v+h))
  red=lambda p:p[3]>0 and p[0]>p[1]*1.3 and p[0]>p[2]*1.3
  black=lambda p:p[3]>0 and max(p[:3])<70
  assert count(bc[1],red)>count(ac[1],red)
  assert count(bc[2],black)>count(ac[2],black)
  for name in old.namelist():
   if name.startswith('assets/duckswords/') and name.endswith(('.png','.ogg')):assert z.read(name)==old.read(name),name
   if name.startswith('assets/duckswords/profiles/v3/'):assert z.read(name)==old.read(name),name
  meta=json.loads(z.read('fabric.mod.json'));assert 'offlinenametagicon' not in meta['depends'];assert meta['version']=='1.5.28-beta.2.21';assert 'assets/duckswords/LICENSE-Cleaner.txt' in z.namelist()
  mixes=json.loads(z.read('duckclientz-expansion.mixins.json'))['client'];assert all(n in mixes for n in ('MixinAutoClickMining218','MixinDuckName221','MixinDuckTab221'))
 print('PASS mask geometry/nose UV preserved; main UV now samples red mouth/black eyes; atlas bounds; existing textures/audio/profile bases unchanged; built-in tags need no companion:',version)
