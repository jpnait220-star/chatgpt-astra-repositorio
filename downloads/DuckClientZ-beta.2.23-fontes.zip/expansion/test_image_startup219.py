from pathlib import Path
from zipfile import ZipFile
import json,subprocess,os
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools')
for v,e in json.loads((B/'build-report.json').read_text()).items():
 if v=='1.21.11':continue
 root=B/'image219-runtime'/v;out=root/'classes';src=root/'src';out.mkdir(parents=True,exist_ok=True);src.mkdir(exist_ok=True)
 fixtures={'net/minecraft/class_1011.java':'''package net.minecraft;public class class_1011 {public String api;public int x,y,color,calls;public void method_4305(int x,int y,int color){this.x=x;this.y=y;this.color=color;calls++;api="ABGR";}public void method_61941(int x,int y,int color){method_4305(x,y,color);api="ARGB";}}''','com/duckswords/compat/RuntimeNames.java':'''package com.duckswords.compat;public class RuntimeNames {public static String methodName(java.lang.reflect.Method method){return method.getName();}}'''}
 for n,text in fixtures.items():p=src/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 (src/'ImageStartupTests219.java').write_text('''import com.duckswords.util.MinecraftCompat;import net.minecraft.class_1011;public class ImageStartupTests219 {public static void main(String[] a)throws Exception {Class.forName("com.duckswords.util.MinecraftCompat");class_1011 image=new class_1011();int[] colors={0,0xff123456,0x7f10e020,0x01010203,0xffffffff,0xffff0000,0xff0000ff};for(int color:colors){MinecraftCompat.setPixel(image,3,7,color);int expected=a[0].equals("1.21.4")?color:(color&0xff00ff00)|((color&0xff0000)>>>16)|((color&0xff)<<16);if(image.color!=expected||image.x!=3||image.y!=7||!image.api.equals(a[0].equals("1.21.4")?"ARGB":"ABGR"))throw new AssertionError("Color channel/order mismatch");}if(image.calls!=colors.length)throw new AssertionError();System.out.println("PASS actual MinecraftCompat static initialization and native pixel setter with intermediary names only; alpha/channel preservation "+a[0]);}}''')
 cp=os.pathsep.join(map(str,[out,e['jar'],Path('/workspace/duckclientz/repair/stubclasses'),B/'compile-stubclasses-old',T/'gson.jar',T/'joml.jar',T/'fabric-loader-0.16.10.jar',T/'mixin.jar']))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,src.rglob('*.java'))],check=True)
 if v=='1.21.4':
  baseline=cp.replace(e['jar'],str(B/'dist'/f'DuckClientZ-{v}-1.5.28-beta.2.18.jar'));result=subprocess.run(['java','-Xverify:all','-cp',baseline,'ImageStartupTests219',v],capture_output=True,text=True);assert result.returncode!=0 and 'No compatible native image pixel setter was found' in result.stderr;print('PASS reproduced legacy NativeImage reflection crash when only intermediary method names are present')
 subprocess.run(['java','-Xverify:all','-cp',cp,'ImageStartupTests219',v],check=True)
