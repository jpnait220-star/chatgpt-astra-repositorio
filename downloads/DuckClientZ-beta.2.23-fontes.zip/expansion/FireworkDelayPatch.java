import java.nio.file.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Minimum is enforced by the setting and again at the use site. */
public class FireworkDelayPatch implements Opcodes {
 public static void main(String[] args)throws Exception{
  String owner="com/duckswords/modules/FireworkKey";Path out=Path.of(args[1]).resolve(owner+".class");ClassNode c=new ClassNode();try(ZipFile z=new ZipFile(args[0])){new ClassReader(z.getInputStream(z.getEntry(owner+".class"))).accept(c,0);}int constants=0,guards=0;
  for(MethodNode method:c.methods){boolean delay=false;for(AbstractInsnNode n:method.instructions.toArray()){
   if(method.name.equals("<init>")){if(n instanceof LdcInsnNode l&&"Delay (ticks)".equals(l.cst))delay=true;if(delay&&n instanceof LdcInsnNode l&&l.cst instanceof Double d&&d==3d){l.cst=5d;constants++;}if(delay&&n instanceof MethodInsnNode m&&m.name.equals("<init>")&&m.owner.endsWith("/NumberSetting"))delay=false;}
   if(method.name.equals("fire")&&n instanceof MethodInsnNode call&&call.owner.endsWith("/NumberSetting")&&call.name.equals("getInt")&&call.getPrevious() instanceof FieldInsnNode f&&f.name.equals("delay")){InsnList clamp=new InsnList();clamp.add(new InsnNode(ICONST_5));clamp.add(new MethodInsnNode(INVOKESTATIC,"java/lang/Math","max","(II)I",false));method.instructions.insert(n,clamp);guards++;}
  }}if(constants!=2||guards!=1)throw new IllegalStateException("Unexpected firework delay hooks: "+constants+" / "+guards);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());
 }
}
