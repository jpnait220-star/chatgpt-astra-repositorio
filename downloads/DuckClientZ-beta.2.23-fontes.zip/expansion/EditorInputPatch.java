import java.nio.file.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class EditorInputPatch implements Opcodes {
 public static void main(String[] a)throws Exception{if(!a[2].equals("1.21.11"))return;String owner="com/duckswords/gui/CrosshairCanvasScreen";ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(a[3]).resolve(owner+".class"))).accept(c,0);
  String[][] cases={{"method_25402","(Lnet/minecraft/class_11909;Z)Z","click"},{"method_25403","(Lnet/minecraft/class_11909;DD)Z","drag"},{"method_25406","(Lnet/minecraft/class_11909;)Z","release"},{"method_25404","(Lnet/minecraft/class_11908;)Z","key"},{"method_25400","(Lnet/minecraft/class_11905;)Z","character"}};
  for(String[] row:cases){MethodNode m=new MethodNode(ACC_PUBLIC,row[0],row[1],null,null);InsnList i=m.instructions;i.add(new VarInsnNode(ALOAD,0));String desc;
   if(row[2].equals("click")||row[2].equals("drag")){for(String field:new String[]{"comp_4798","comp_4799"}){i.add(new VarInsnNode(ALOAD,1));i.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/class_11909",field,"()D",false));}i.add(new VarInsnNode(ALOAD,1));i.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/class_11909","method_74245","()I",false));desc="(DDI)Z";}
   else if(row[2].equals("release"))desc="()Z";
   else{boolean key=row[2].equals("key");i.add(new VarInsnNode(ALOAD,1));i.add(new MethodInsnNode(INVOKEVIRTUAL,key?"net/minecraft/class_11908":"net/minecraft/class_11905",key?"comp_4795":"comp_4793","()I",false));if(key)i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/gui/EditorKeys","modifiers","()I",false));desc=key?"(II)Z":"(I)Z";}
   i.add(new MethodInsnNode(INVOKEVIRTUAL,owner,row[2],desc,false));i.add(new InsnNode(IRETURN));c.methods.add(m);
  }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of(a[1]).resolve(owner+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
}
