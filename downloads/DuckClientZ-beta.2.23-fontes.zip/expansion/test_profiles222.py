from pathlib import Path
import json,os,subprocess
B=Path(__file__).parent;T=Path('/workspace/duckclientz/tools');entry=json.loads((B/'build-report.json').read_text())['1.20.1'];out=B/'profiles222-runtime';out.mkdir(exist_ok=True);cp=os.pathsep.join(map(str,[out,entry['jar'],T/'gson.jar']))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),str(B/'ProfileCodeTests.java'),str(B/'Profile222Tests.java')],check=True)
for name in ['ProfileCodeTests','Profile222Tests']:subprocess.run(['java','-Xverify:all','-cp',cp,name,str(B/'resources/assets/duckswords/profiles/v3')],check=True)
