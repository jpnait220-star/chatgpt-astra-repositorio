import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.analysis.*;
public class Verify12111 {
 static Map<String,String> classes=new HashMap<>(),reverse=new HashMap<>(),methods=new HashMap<>(),fields=new HashMap<>();
 static Map<String,ClassNode> cache=new HashMap<>();
 static Map<String,List<String>> rawParents=new HashMap<>();
 static ZipFile minecraft,mod;
 static String mappedMethod(String owner,String name,String desc)throws java.io.IOException {
  String mapped=methods.get(owner+" "+name+desc);if(mapped!=null)return mapped;
  if(name.startsWith("<")||minecraft==null)return null;
  List<String> parents=rawParents.get(owner);
  if(parents==null) {
   parents=new ArrayList<>();ZipEntry entry=minecraft.getEntry(owner+".class");
   if(entry!=null) {
    ClassReader r=new ClassReader(minecraft.getInputStream(entry));
    if(r.getSuperName()!=null)parents.add(r.getSuperName());parents.addAll(Arrays.asList(r.getInterfaces()));
   }
   rawParents.put(owner,parents);
  }
  for(String parent:parents){mapped=mappedMethod(parent,name,desc);if(mapped!=null)return mapped;}
  return null;
 }
 static Remapper remap=new Remapper() {
  @Override public String map(String n){return classes.getOrDefault(n,n);}
  @Override public String mapMethodName(String o,String n,String d){try{String mapped=mappedMethod(o,n,d);return mapped==null?n:mapped;}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}
  @Override public String mapFieldName(String o,String n,String d){return fields.getOrDefault(o+" "+n+d,n);}
 };
 static ClassNode read(String name)throws Exception {
  if(cache.containsKey(name))return cache.get(name);
  if(name.startsWith("java/")) {
   try(java.io.InputStream stream=ClassLoader.getSystemResourceAsStream(name+".class")) {
    if(stream==null)return null;ClassNode c=new ClassNode();new ClassReader(stream).accept(c,ClassReader.SKIP_CODE);cache.put(name,c);return c;
   }
  }
  boolean game=name.startsWith("net/minecraft/");
  String path=(game?reverse.get(name):name)+".class";
  ZipEntry entry=game?minecraft.getEntry(path):mod.getEntry(path);
  if(entry==null&&name.startsWith("com/mojang/"))entry=minecraft.getEntry(path);
  if(entry==null)return null;
  ClassNode c=new ClassNode();
  ClassReader r=new ClassReader((game||name.startsWith("com/mojang/"))?minecraft.getInputStream(entry):mod.getInputStream(entry));
  r.accept(game?new ClassRemapper(c,remap):c,0);cache.put(name,c);return c;
 }
 static boolean member(String owner,String name,String desc,boolean method)throws Exception {
  ClassNode c=read(owner);if(c==null)return false;
  if(method) {for(MethodNode m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;}
  else {for(FieldNode f:c.fields)if(f.name.equals(name)&&f.desc.equals(desc))return true;}
  if(c.superName!=null&&!name.equals("<init>")&&member(c.superName,name,desc,method))return true;
  for(String i:c.interfaces)if(member(i,name,desc,method))return true;
  return false;
 }
 static void require(boolean b,String text){if(!b)throw new IllegalStateException(text);}
 static boolean reachesCapture(String owner,String name,String desc,Set<String> seen)throws Exception {
  if(owner.equals("net/minecraft/class_922")&&name.equals("method_62355"))return true;
  if(!seen.add(owner+" "+name+desc))return false;
  ClassNode c=read(owner);if(c==null)return false;
  boolean declares=false;
  for(MethodNode m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc)) {
   declares=true;
   for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.getOpcode()==Opcodes.INVOKESPECIAL&&call.desc.equals(desc)&&reachesCapture(call.owner,call.name,call.desc,seen))return true;
  }
  return !declares&&c.superName!=null&&reachesCapture(c.superName,name,desc,seen);
 }
 public static void main(String[] a)throws Exception {
  String owner="";
  for(String line:Files.readAllLines(Paths.get(a[0]))) {
   String[] p=line.split("\t");
   if(p[0].equals("c")){owner=p[1];classes.put(p[1],p[2]);reverse.put(p[2],p[1]);}
   else if(p.length==5&&(p[1].equals("m")||p[1].equals("f")))
    (p[1].equals("m")?methods:fields).put(owner+" "+p[3]+p[2],p[4]);
  }
  minecraft=new ZipFile(a[1]);mod=new ZipFile(a[2]);
  String held="net/minecraft/class_759",render="method_3228",desc="(Lnet/minecraft/class_742;FFLnet/minecraft/class_1268;FLnet/minecraft/class_1799;FLnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V";
  require(member(held,render,desc,true),"Native first-person render signature missing");
  int swingCalls=0,equipCalls=0;
  for(MethodNode m:read(held).methods)if(m.name.equals(render)&&m.desc.equals(desc))for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call) {
   if(call.name.equals("method_65816"))swingCalls++;if(call.name.equals("method_3224"))equipCalls++;
  }
  require(swingCalls>=3&&equipCalls>=5,"Original Swing redirect ordinals do not exist in native 1.21.11");
  require(member("com/duckswords/modules/Swing","cooldownDrop","Lcom/duckswords/setting/BooleanSetting;",false),"Cooldown option absent");
  require(member("com/duckswords/modules/TextHud","duck$renderEntryRaw","(Lnet/minecraft/class_332;Lcom/duckswords/modules/TextHud$Entry;I)V",true),"Raw entry renderer absent");
  int bodies=0,links=0;
  for(String file:Files.readAllLines(Paths.get(a[3]))) {
   if(!file.endsWith(".class"))continue;ClassNode c=read(file.substring(0,file.length()-6));require(c!=null,"Changed class missing");
   require(c.version<=65,"Unsupported bytecode version");
   for(MethodNode m:c.methods) {
    if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0){new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);bodies++;}
    for(AbstractInsnNode n:m.instructions) {
     if(n instanceof MethodInsnNode call&&(call.owner.startsWith("net/minecraft/")||call.owner.startsWith("com/duckswords/"))) {
      require(member(call.owner,call.name,call.desc,true),"Missing native/mod method "+call.owner+"."+call.name+call.desc);links++;
      if(call.getOpcode()==Opcodes.INVOKEINTERFACE)require((read(call.owner).access&Opcodes.ACC_INTERFACE)!=0,"Wrong native invocation kind");
     }
     if(n instanceof FieldInsnNode field&&(field.owner.startsWith("net/minecraft/")||field.owner.startsWith("com/duckswords/"))) {
      require(member(field.owner,field.name,field.desc,false),"Missing native/mod field "+field.owner+"."+field.name+field.desc);links++;
     }
    }
   }
  }
  System.out.println("PASS: "+bodies+" method bodies, "+links+" native/mod member references; original Swing target/ordinals exist in real MC 1.21.11.");
 }
}
