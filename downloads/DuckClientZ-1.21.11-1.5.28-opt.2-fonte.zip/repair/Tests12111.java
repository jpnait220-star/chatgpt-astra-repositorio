import com.duckswords.modules.*;
import com.duckswords.setting.*;
import com.duckswords.swing.SwingCooldown;
import com.duckswords.perf.*;
import com.duckswords.DucksWordsClient;
import com.duckswords.mixin.*;
import net.minecraft.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import java.lang.reflect.*;
import java.util.*;
public class Tests12111 {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static void near(float a,float b,String s){check(Math.abs(a-b)<1e-6,s+": "+a+" vs "+b);}
 public static class Hooks extends MixinHeldItemRenderer implements MixinHeldItemRendererAccessor {
  int vanillaEquip;float progress;class_1306 arm;
  public void duckswords$invokeEquipOffset(class_4587 m,class_1306 a,float p){vanillaEquip++;progress=p;arm=a;}
  public void duckswords$invokeSwingArm(float p,class_4587 m,int x,class_1306 a){}
 }
 record Vertex(float x,float y,float z,int color,float nx,float ny,float nz,float width){}
 static class Sink implements class_4588 {
  float x,y,z,nx,ny,nz;int color;final List<Vertex> points=new ArrayList<>();
  public class_4588 method_22918(Matrix4fc m,float x,float y,float z){this.x=x;this.y=y;this.z=z;return this;}
  public class_4588 method_39415(int c){color=c;return this;}
  public class_4588 method_22914(float x,float y,float z){nx=x;ny=y;nz=z;return this;}
  public class_4588 method_75298(float w){points.add(new Vertex(x,y,z,color,nx,ny,nz,w));return this;}
 }
 static class Context implements WorldRenderContext {
  final Sink sink=new Sink();final class_4587 matrix=new class_4587();final class_11658 state=new class_11658();
  public class_4597 consumers(){return layer->sink;}public class_4587 matrices(){return matrix;}public class_11658 worldState(){return state;}
 }
 public static void main(String[] args)throws Exception {
  class_310 mc=class_310.method_1551();mc.field_1724=new class_746();mc.field_1687=new class_638();
  Swing swing=new Swing();DucksWordsClient.MODULES.modules.put(Swing.class,swing);
  check(!swing.cooldownDrop.getValue(),"cooldown drop defaults off, preserving previous animation");check(swing.getSettings().contains(swing.cooldownDrop),"option registered for GUI and profile serialization");
  Hooks hooks=new Hooks();Method equip=MixinHeldItemRenderer.class.getDeclaredMethod("duckswords$skipSwingEquipOffset",class_759.class,class_4587.class,class_1306.class,float.class);equip.setAccessible(true);
  swing.setEnabled(true);class_4587 matrix=new class_4587();equip.invoke(hooks,null,matrix,class_1306.field_6183,1f);near(matrix.y,0,"custom Swing without cooldown stays unchanged");check(hooks.vanillaEquip==0,"custom path avoids duplicate vanilla translation");
  swing.cooldownDrop.setValue(true);
  for(class_1306 arm:class_1306.values())for(float progress:new float[]{-1,0,.25f,.5f,1,2,Float.NaN}) {
   matrix=new class_4587();equip.invoke(hooks,null,matrix,arm,progress);
   float expected=Float.isFinite(progress)?-.24f*Math.max(0,Math.min(1,progress)):0;near(matrix.y,expected,"visual drop bounded for both arms");near(matrix.x,0,"drop does not alter horizontal pose");near(matrix.z,0,"drop does not alter depth/scale");
  }
  swing.setEnabled(false);equip.invoke(hooks,null,new class_4587(),class_1306.field_6182,.35f);check(hooks.vanillaEquip==1&&hooks.arm==class_1306.field_6182&&hooks.progress==.35f,"disabled Swing retains exact vanilla fallback arguments");swing.setEnabled(true);
  TotemFeature totem=new TotemFeature();DucksWordsClient.MODULES.modules.put(TotemFeature.class,totem);totem.disableEquipAnimation.setValue(true);mc.field_1724.main.item=class_1802.field_8288;
  matrix=new class_4587();equip.invoke(hooks,null,matrix,mc.field_1724.arm,1f);near(matrix.y,0,"totem disable-equip option takes precedence");mc.field_1724.main.item=null;
  matrix=new class_4587();equip.invoke(hooks,null,matrix,mc.field_1724.arm,1f);near(matrix.y,-.24f,"ordinary items retain enabled cooldown drop");
  swing.cooldownDrop.reset();check(!swing.cooldownDrop.getValue(),"reset restores non-dropping default");
  // The five original swing animations must remain bit-for-bit equivalent as transforms.
  Object baseline=Class.forName("BaselineSwing").getConstructor().newInstance();ModeSetting oldMode=(ModeSetting)baseline.getClass().getField("mode").get(baseline);NumberSetting oldForce=(NumberSetting)baseline.getClass().getField("strength").get(baseline);
  Method oldApply=baseline.getClass().getMethod("apply",class_4587.class,class_1306.class,float.class);
  for(String mode:Swing.MODES)for(double force:new double[]{20,45,75})for(class_1306 arm:class_1306.values())for(float progress:new float[]{0,.125f,.5f,.875f,1}) {
   swing.mode.setValue(mode);oldMode.setValue(mode);swing.strength.setValue(force);oldForce.setValue(force);class_4587 before=new class_4587(),after=new class_4587();oldApply.invoke(baseline,before,arm,progress);swing.apply(after,arm,progress);check(before.matrix.equals(after.matrix),"original mode/force/arm swing transform unchanged");
  }
  Method oldCircle=Class.forName("OriginalCircle").getMethod("drawCircle",WorldRenderContext.class,double.class,double.class,double.class,double.class,int.class,int.class,float.class);
  Method newCircle=Class.forName("OptimizedCircle").getMethod("drawCircle",WorldRenderContext.class,double.class,double.class,double.class,double.class,int.class,int.class,float.class);
  for(int resolution:new int[]{2,3,4,16,64,128,256}) {
   Context before=new Context(),after=new Context();before.state.field_63082.field_63078=after.state.field_63082.field_63078=new class_243(11.7,-3.2,4.9);
   oldCircle.invoke(null,before,10.5,65.03,-2.7,3d,0x9944aa33,resolution,4f);newCircle.invoke(null,after,10.5,65.03,-2.7,3d,0x9944aa33,resolution,4f);
   check(before.sink.points.equals(after.sink.points),"cached circle preserves every vertex/color/normal/width at resolution "+resolution);
   check(after.sink.points.size()==(resolution<3?0:resolution*2),"same segment count, no quality reduction");
  }
  check(UnitCircle.get(128)==UnitCircle.get(128),"circle geometry reused between frames");
  // Spatial broad phase must preserve the previous hit-range predicate exactly.
  Random random=new Random(7331);
  for(int sample=0;sample<60;sample++) {
   mc.field_1687.entities.clear();boolean expected=false;
   for(int j=0;j<100;j++) {
    class_1297 entity=j%4==0?new class_1297():new class_1309();entity.x=random.nextDouble()*40-20;entity.y=random.nextDouble()*20-10;entity.z=random.nextDouble()*40-20;entity.alive=j%5!=0;mc.field_1687.entities.add(entity);
    expected|=entity instanceof class_1309&&entity.alive&&entity.x*entity.x+entity.z*entity.z<=9&&Math.abs(entity.y)<=3;
   }
   check(NearbyTargets.any(mc.field_1687,mc.field_1724,0,0,0)==expected,"spatial query preserves original selection predicate");
  }
  mc.field_1687.entities.clear();class_1309 boundary=new class_1309();boundary.x=3;boundary.y=3;mc.field_1687.entities.add(boundary);check(NearbyTargets.any(mc.field_1687,mc.field_1724,0,0,0),"inclusive horizontal/vertical boundary retained");
  HitRange range=new HitRange();mc.field_1724.field_6014=10;mc.field_1724.x=12;mc.field_1724.field_6036=mc.field_1724.y=65;mc.field_1724.field_5969=mc.field_1724.z=-7;
  boundary.x=13.9;boundary.y=65;boundary.z=-7;range.onWorldRender(new WorldRenderContext(){});check(com.duckswords.util.RenderUtil.lastColor==-13244309&&com.duckswords.util.RenderUtil.segments==128,"actual Hit Range keeps color, line quality and interpolation");
  boundary.x=16;range.onWorldRender(new WorldRenderContext(){});check(com.duckswords.util.RenderUtil.lastColor==range.color.getDisplayValue(),"target color updates next frame without a scan throttle");
  ColorSetting color=new ColorSetting("color","hsb",0xff336699);float[] hsb=java.awt.Color.RGBtoHSB(0x33,0x66,0x99,null);
  near(color.hue(),hsb[0],"cached hue exact");near(color.saturation(),hsb[1],"cached saturation exact");near(color.brightness(),hsb[2],"cached brightness exact");color.setValue(0xffee1177);hsb=java.awt.Color.RGBtoHSB(0xee,0x11,0x77,null);near(color.hue(),hsb[0],"color change invalidates HSB");color.reset();near(color.hue(),java.awt.Color.RGBtoHSB(0x33,0x66,0x99,null)[0],"reset invalidates HSB");
  String text=HudFormatCache.format("%02d:%02d",new Object[]{1,2});check(text.equals("01:02")&&text==HudFormatCache.format("%02d:%02d",new Object[]{1,2}),"unchanged HUD values reuse formatted result");
  com.duckswords.theme.Interface ui=new com.duckswords.theme.Interface();check(ui.hudFont.getValue().equals("Minecraft"),"Minecraft font remains the default as requested");
  System.out.println("PASS: "+checks+" 1.21.11 optimization/cooldown regressions (actual hooks, all five original swings, exact circle geometry, spatial predicate, color reset and font default).");
 }
}
