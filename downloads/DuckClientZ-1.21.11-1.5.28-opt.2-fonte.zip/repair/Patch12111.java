import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class Patch12111 implements Opcodes {
 static ZipFile jar;static Path out;
 static ClassNode read(String n)throws Exception {ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getEntry(n+".class"))).accept(c,ClassReader.EXPAND_FRAMES);return c;}
 static void write(ClassNode c)throws Exception {ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=out.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 static MethodNode method(ClassNode c,String n){return c.methods.stream().filter(m->m.name.equals(n)).findFirst().orElseThrow();}
 static void load(InsnList i,int opcode,int var){i.add(new VarInsnNode(opcode,var));}
 static void call(InsnList i,int opcode,String o,String n,String d,boolean itf){i.add(new MethodInsnNode(opcode,o,n,d,itf));}
 static int local(MethodNode m,String name){return m.localVariables.stream().filter(v->v.name.equals(name)).findFirst().orElseThrow().index;}
 public static void main(String[] a)throws Exception {
  out=Paths.get(a[1]);try(ZipFile z=new ZipFile(a[0])){jar=z;
   ClassNode c=read("com/duckswords/modules/Swing");
   c.fields.add(new FieldNode(ACC_PUBLIC|ACC_FINAL,"cooldownDrop","Lcom/duckswords/setting/BooleanSetting;",null,null));
   MethodNode init=method(c,"<init>");int added=0;
   for(AbstractInsnNode n:init.instructions.toArray())if(n.getOpcode()==RETURN) {
    InsnList i=new InsnList();load(i,ALOAD,0);load(i,ALOAD,0);
    i.add(new TypeInsnNode(NEW,"com/duckswords/setting/BooleanSetting"));i.add(new InsnNode(DUP));
    i.add(new LdcInsnNode("Descer com cooldown"));i.add(new LdcInsnNode("Permite a descida visual da arma ao equipar ou durante o cooldown"));i.add(new InsnNode(ICONST_0));
    call(i,INVOKESPECIAL,"com/duckswords/setting/BooleanSetting","<init>","(Ljava/lang/String;Ljava/lang/String;Z)V",false);
    call(i,INVOKEVIRTUAL,c.name,"add","(Lcom/duckswords/setting/Setting;)Lcom/duckswords/setting/Setting;",false);
    i.add(new TypeInsnNode(CHECKCAST,"com/duckswords/setting/BooleanSetting"));i.add(new FieldInsnNode(PUTFIELD,c.name,"cooldownDrop","Lcom/duckswords/setting/BooleanSetting;"));init.instructions.insertBefore(n,i);added++;
   }
   if(added!=1)throw new IllegalStateException("Swing constructor changed");write(c);
   c=read("com/duckswords/mixin/MixinHeldItemRenderer");MethodNode m=method(c,"duckswords$skipSwingEquipOffset");
   m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;InsnList i=m.instructions;
   call(i,INVOKESTATIC,"com/duckswords/modules/Swing","get","()Lcom/duckswords/modules/Swing;",false);load(i,ASTORE,5);
   LabelNode vanilla=new LabelNode();load(i,ALOAD,5);i.add(new JumpInsnNode(IFNULL,vanilla));load(i,ALOAD,5);load(i,ALOAD,3);
   call(i,INVOKEVIRTUAL,"com/duckswords/modules/Swing","shouldAnimate","(Lnet/minecraft/class_1306;)Z",false);i.add(new JumpInsnNode(IFEQ,vanilla));
   load(i,ALOAD,2);load(i,ALOAD,3);load(i,FLOAD,4);load(i,ALOAD,5);i.add(new FieldInsnNode(GETFIELD,"com/duckswords/modules/Swing","cooldownDrop","Lcom/duckswords/setting/BooleanSetting;"));
   call(i,INVOKESTATIC,"com/duckswords/swing/SwingCooldown","apply","(Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;FLcom/duckswords/setting/BooleanSetting;)V",false);i.add(new InsnNode(RETURN));
   i.add(vanilla);i.add(new FrameNode(F_NEW,6,new Object[]{c.name,"net/minecraft/class_759","net/minecraft/class_4587","net/minecraft/class_1306",FLOAT,"com/duckswords/modules/Swing"},0,new Object[]{}));
   load(i,ALOAD,0);i.add(new TypeInsnNode(CHECKCAST,"com/duckswords/mixin/MixinHeldItemRendererAccessor"));load(i,ALOAD,2);load(i,ALOAD,3);load(i,FLOAD,4);
   call(i,INVOKEINTERFACE,"com/duckswords/mixin/MixinHeldItemRendererAccessor","duckswords$invokeEquipOffset","(Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;F)V",true);i.add(new InsnNode(RETURN));m.maxLocals=6;write(c);
   c=read("com/duckswords/util/RenderUtil");m=c.methods.stream().filter(x->x.name.equals("drawCircle")&&x.desc.endsWith("IIF)V")).findFirst().orElseThrow();
   int segments=local(m,"segments"),index=local(m,"index"),start=local(m,"start"),end=local(m,"end"),array=m.maxLocals;int trig=0;
   i=new InsnList();load(i,ILOAD,segments);call(i,INVOKESTATIC,"com/duckswords/perf/UnitCircle","get","(I)[D",false);load(i,ASTORE,array);m.instructions.insert(i);
   for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof MethodInsnNode mc&&mc.owner.equals("java/lang/Math")&&(mc.name.equals("cos")||mc.name.equals("sin"))) {
    AbstractInsnNode previous=n.getPrevious();while(previous.getOpcode()<0)previous=previous.getPrevious();
    if(!(previous instanceof VarInsnNode v)||v.getOpcode()!=DLOAD||(v.var!=start&&v.var!=end))throw new IllegalStateException("Circle expression changed");
    i=new InsnList();load(i,ALOAD,array);load(i,ILOAD,index);
    if(v.var==end){i.add(new InsnNode(ICONST_1));i.add(new InsnNode(IADD));}
    i.add(new InsnNode(ICONST_1));i.add(new InsnNode(ISHL));
    if(mc.name.equals("sin")){i.add(new InsnNode(ICONST_1));i.add(new InsnNode(IADD));}
    i.add(new InsnNode(DALOAD));m.instructions.insertBefore(previous,i);m.instructions.remove(previous);m.instructions.remove(n);trig++;
   }
   if(trig!=4)throw new IllegalStateException("Expected 4 circle trigonometry calls, got "+trig);
   for(AbstractInsnNode n:m.instructions)if(n instanceof FrameNode frame) {
    int slots=0;for(Object t:frame.local)slots+=t.equals(DOUBLE)||t.equals(LONG)?2:1;
    while(slots++<array)frame.local.add(TOP);frame.local.add("[D");
   }
   m.maxLocals=array+1;write(c);
   int format=0;
   for(ZipEntry e:Collections.list(z.entries()))if(e.getName().startsWith("com/duckswords/modules/")&&e.getName().endsWith(".class")) {
    c=read(e.getName().substring(0,e.getName().length()-6));int edits=0;
    for(MethodNode mm:c.methods)for(AbstractInsnNode n:mm.instructions)if(n instanceof MethodInsnNode mc&&mc.owner.equals("java/lang/String")&&mc.name.equals("format")&&mc.desc.equals("(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;")){mc.owner="com/duckswords/perf/HudFormatCache";edits++;}
    if(edits>0){write(c);format+=edits;}
   }
   if(format<5)throw new IllegalStateException("HUD formatter hooks missing");
   c=read("com/duckswords/theme/Interface");int step=0,font=0;
   for(AbstractInsnNode n:method(c,"<init>").instructions)if(n instanceof LdcInsnNode ldc&&ldc.cst instanceof String s) {
    if(s.equals("Fonte do HUD"))step=1;
    else if(step==1)step=2;
    else if(step==2){ldc.cst="Minecraft";step=0;font++;}
   }
   if(font!=1)throw new IllegalStateException("Font default not found");write(c);
   System.out.println("1.21.11: registered cooldown option/hook, cached circle, "+format+" formatter sites; Minecraft font default");
  }
 }
}
