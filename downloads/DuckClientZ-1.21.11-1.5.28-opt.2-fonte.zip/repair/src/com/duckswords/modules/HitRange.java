/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 */
package com.duckswords.modules;

import com.duckswords.module.Category;
import com.duckswords.module.Module;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.NumberSetting;
import com.duckswords.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;

public class HitRange
extends Module {
    public final ColorSetting color = this.add(new ColorSetting("Cor", "Cor do circulo de alcance", -1437212673));
    public final NumberSetting thickness = this.add(new NumberSetting("Espessura", "Ajusta a espessura visual da linha sem alterar o alcance fixo", 4.0, 1.0, 30.0, 0.5));

    public HitRange() {
        super("Hitrange", "Mostra um circulo fixo de 3 blocos ao redor do jogador", Category.VISUALS);
    }

    @Override
    public void onWorldRender(WorldRenderContext context) {
        if (HitRange.mc.field_1724 != null) {
            float tickDelta = mc.method_61966().method_60637(false);
            double x = HitRange.mc.field_1724.field_6014 + (HitRange.mc.field_1724.method_23317() - HitRange.mc.field_1724.field_6014) * (double)tickDelta;
            double y = HitRange.mc.field_1724.field_6036 + (HitRange.mc.field_1724.method_23318() - HitRange.mc.field_1724.field_6036) * (double)tickDelta + 0.03;
            double z = HitRange.mc.field_1724.field_5969 + (HitRange.mc.field_1724.method_23321() - HitRange.mc.field_1724.field_5969) * (double)tickDelta;
            boolean hasLivingTargetInRange = com.duckswords.perf.NearbyTargets.any(mc.field_1687,mc.field_1724,x,y,z);
            int lineColor = hasLivingTargetInRange ? -13244309 : this.color.getDisplayValue();
            float lineWidth = this.thickness.getFloat();
            RenderUtil.drawCircle(context, x, y, z, 3.0, lineColor, 128, lineWidth);
        }
    }
}

