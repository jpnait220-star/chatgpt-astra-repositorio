package com.duckswords.hud;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;
public final class HudMatrix {
 public static boolean push(class_332 ctx,int x,int y,float scale,int rawX,int rawY) {
  if(x==rawX&&y==rawY&&scale==1)return false;
  Matrix3x2fStack m=ctx.method_51448();m.pushMatrix();
  try{m.translate(x,y);m.scale(scale,scale);m.translate(-rawX,-rawY);}catch(RuntimeException|Error e){m.popMatrix();throw e;}
  return true;
 }
 public static void pop(class_332 ctx){ctx.method_51448().popMatrix();}
}