package com.duckswords.perf;
import java.util.*;
public final class UnitCircle {
    private static final double[] EMPTY=new double[0];
    private static final Map<Integer,double[]> CACHE=new LinkedHashMap<Integer,double[]>(8,.75f,true) {
        protected boolean removeEldestEntry(Map.Entry<Integer,double[]> e){return size()>8;}
    };
    public static synchronized double[] get(int segments) {
        if(segments<3)return EMPTY;
        double[] values=CACHE.get(segments);
        if(values==null) {
            values=new double[Math.multiplyExact(segments+1,2)];
            for(int i=0;i<=segments;i++){double angle=Math.PI*2*i/segments;values[i*2]=Math.cos(angle);values[i*2+1]=Math.sin(angle);}
            if(segments<=4096)CACHE.put(segments,values);
        }
        return values;
    }
}
