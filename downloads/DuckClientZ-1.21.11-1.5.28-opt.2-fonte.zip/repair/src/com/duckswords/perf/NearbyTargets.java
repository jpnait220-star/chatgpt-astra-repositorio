package com.duckswords.perf;
import net.minecraft.*;
import java.util.function.Predicate;
public final class NearbyTargets {
    private static final Predicate<class_1297> LIVING=e->e instanceof class_1309&&e.method_5805();
    public static boolean any(class_638 world,class_1297 player,double x,double y,double z) {
        if(world==null)return false;
        for(class_1297 e:world.method_8333(player,new class_238(x-3.00001,y-3.00001,z-3.00001,x+3.00001,y+3.00001,z+3.00001),LIVING)) {
            double dx=e.method_23317()-x,dz=e.method_23321()-z;
            if(dx*dx+dz*dz<=9&&Math.abs(e.method_23318()-y)<=3)return true;
        }
        return false;
    }
}
