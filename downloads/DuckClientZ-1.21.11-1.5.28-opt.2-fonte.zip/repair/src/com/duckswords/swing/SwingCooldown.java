package com.duckswords.swing;
import com.duckswords.modules.TotemFeature;
import com.duckswords.setting.BooleanSetting;
import net.minecraft.*;
public final class SwingCooldown {
    /** Only the visual drop; attack speed and server cooldown are unchanged. */
    public static void apply(class_4587 matrices,class_1306 arm,float progress,BooleanSetting enabled) {
        if(enabled==null||!enabled.getValue()||!Float.isFinite(progress))return;
        class_746 player=class_310.method_1551().field_1724;
        TotemFeature totem=TotemFeature.get();
        if(player!=null&&totem!=null&&totem.isEnabled()&&totem.disableEquipAnimation.getValue()) {
            class_1799 item=arm==player.method_6068()?player.method_6047():player.method_6079();
            if(item.method_31574(class_1802.field_8288))return;
        }
        matrices.method_46416(0,-.24f*Math.max(0,Math.min(1,progress)),0);
    }
}
