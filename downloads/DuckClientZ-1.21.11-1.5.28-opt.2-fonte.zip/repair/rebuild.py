from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,urllib.request,hashlib,os,json,shutil
B=Path(__file__).resolve().parent;R=B.parent;T=R/'tools';T.mkdir(exist_ok=True)
def fetch(name,url):
 p=T/name
 with urllib.request.urlopen(url+'.sha1',timeout=60) as response:expected=response.read().decode().strip().split()[0]
 if not p.exists() or hashlib.sha1(p.read_bytes()).hexdigest()!=expected:
  with urllib.request.urlopen(url,timeout=60) as response:data=response.read()
  assert hashlib.sha1(data).hexdigest()==expected,name;p.write_bytes(data)
for artifact in ['asm','asm-tree','asm-analysis','asm-commons']:
 fetch(artifact+'.jar',f'https://repo.maven.apache.org/maven2/org/ow2/asm/{artifact}/9.7.1/{artifact}-9.7.1.jar')
fetch('joml.jar','https://repo.maven.apache.org/maven2/org/joml/joml/1.10.8/joml-1.10.8.jar')
original=R/'DuckClientZ-1.21.11-1.5.27.jar'
def cp(*values):return os.pathsep.join(str(v) for v in values)
def run(*args):subprocess.run([str(a) for a in args],cwd=R,check=True)
def compile(out,classpath,files):run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-cp',classpath,'-d',out,*files)
compile(B/'stubclasses',cp(T/'joml.jar',original),(B/'stubs').rglob('*.java'))
compile(B/'classes',cp(B/'stubclasses',T/'joml.jar',original),(B/'src').rglob('*.java'))
asm=cp(T/'asm.jar',T/'asm-tree.jar')
compile(B/'toolclasses',asm,[B/'Patch12111.java',B/'HudPatch.java',B/'GeneralPerfPatch.java'])
if (B/'patched').exists():shutil.rmtree(B/'patched')
run('java','-cp',cp(B/'toolclasses',asm),'Patch12111',original,B/'patched')
run('java','-cp',cp(B/'toolclasses',asm),'HudPatch',original,B/'patched')
run('java','-cp',cp(B/'toolclasses',asm),'GeneralPerfPatch',original,B/'patched')
with ZipFile(original) as z:contents={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
assert not any(n.startswith('META-INF/') and n.endswith(('.SF','.RSA','.DSA')) for n in contents)
changed={}
for directory in ['classes','patched']:
 for p in (B/directory).rglob('*.class'):
  name=p.relative_to(B/directory).as_posix();assert name.startswith('com/duckswords/');changed[name]=p.read_bytes()
meta=json.loads(contents['fabric.mod.json']);meta['version']='1.5.28-opt.2'
meta.setdefault('custom',{})['duckclientz_changes']='scoped-native-1.21.11; cooldown-toggle; spatial-hit-range; cached-circle-hsb-hud-format; canonical-hud-resize'
changed['fabric.mod.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode()
name='assets/duckswords/default-profile.json';profile=json.loads(contents[name]);cfg=json.loads(profile['config'])
cfg['Swing']['settings']['Descer com cooldown']=False
cfg['Interface']['settings']['Fonte do HUD']='Minecraft'
profile['config']=json.dumps(cfg,ensure_ascii=False,indent=2);changed[name]=(json.dumps(profile,ensure_ascii=False,indent=2)+'\n').encode()
out=R/'dist';out.mkdir(exist_ok=True);jar=out/'DuckClientZ-1.21.11-1.5.28-opt.2-experimental.jar'
with ZipFile(jar,'w',ZIP_DEFLATED) as z:
 for name,data in sorted((contents|changed).items()):z.writestr(name,data)
with ZipFile(jar) as z:assert z.testzip() is None
report={'input_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'changed':sorted(changed),'jar':jar.name}
(R/'build-report.json').write_text(json.dumps(report,indent=2)+'\n');print(jar.name,jar.stat().st_size)
