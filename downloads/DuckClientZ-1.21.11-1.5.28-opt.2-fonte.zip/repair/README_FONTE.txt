FONTE DA REVISÃO INCREMENTAL 1.21.11

Coloque o JAR original DuckClientZ-1.21.11-1.5.27.jar ao lado de repair/.
Requer JDK 21 e Python 3. Execute: python repair/rebuild.py
As ferramentas ASM/JOML são baixadas de Maven Central com checksum verificado.
O resultado fica em dist/.

O código em src/ é a alteração nova. stubs/ contém APENAS tipos substitutos
para compilação e testes; nenhum deles entra no JAR final. Patch12111.java
adiciona a opção/hook do cooldown e aplica otimizações pontuais; HudPatch.java
insere os hooks compartilhados de resize, editor e renderização do HUD.
A 1.21.11 usa Matrix3x2fStack: seu backend HudMatrix é separado das versões antigas.

validate.py executa os testes isolados e Verify12111 compara referências com o
client oficial. Para isso, prepare tools/ com o client/mappings usando
python tools/fetch_official.py e com gson 2.10.1, Fabric Loader 0.19.3 e
Sponge Mixin 0.15.4+mixin.0.8.7 de Maven Central/Fabric (checksums publicados).
Esses arquivos externos não estão no pacote. Não é um teste completo no jogo.

Tests12111.java compara os cinco modos de Swing com o original, executa os
hooks novos e compara vértices/cor/normal/espessura dos círculos completos.
HudLayoutTests.java cobre ciclos de F11, persistência, importação de perfil,
arrastar, canvas legado, TextHUD e restauração de transformações em erros.
ExtractProbes.java extrai somente corpos do JAR do usuário para esses testes.

DESEMPENHO GERAL — fixes.9 / opt.2
As quatro versões recebem índice de módulos com invalidação ao alterar a lista,
cache limitado de textos internos (sem guardar larguras dependentes de resourcepack)
e gradientes horizontais em um único quad, preservando a matriz após o desenho.

Nova feature: Client > Performance. Desligada por padrão. Ao ativar, limita apenas
partículas extras do client: orçamento padrão 128 por tick e distância 32 blocos.
Os controles reduzem a densidade visual de efeitos intensos; podem ser ajustados.
Não altera partículas vanilla, chunks, opções de Sodium nem regras do servidor.
As otimizações internas de HUD e consultas funcionam mesmo com Performance desligado.

1.21.4: Fullbright passa também a elevar a iluminação ambiente do lightmap nativo.
Gamma 1 preserva o ambiente original; Gamma 10 ou superior aplica o máximo.
Ao desligar, o cálculo nativo volta a ser usado. Não cria shaders ou texturas extras.

Testes isolados de lógica, HUD, geometria e APIs reais passaram. Não houve execução
do jogo, benchmark de FPS, teste de GPU ou confirmação visual no PC/Pojav. Não é
uma garantia de eliminar todas as travadas. Relatórios detalhados estão incluídos.

GeneralPerfPatch.java integra IndexedModules, HudTextCache, HorizontalGradient e Performance/ParticleBudget.
