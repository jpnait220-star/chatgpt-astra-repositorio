import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.commons.*;
public class ExtractProbes {
 public static void main(String[] a)throws Exception {
  String original=a[2],target=a[3];try(ZipFile z=new ZipFile(a[0])) {
   ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(original+".class"))).accept(c,0);
   if(original.endsWith("RenderUtil")){c.fields.clear();c.methods.removeIf(m->!m.name.equals("drawCircle")&&!m.name.equals("cameraPos"));}
   ClassWriter w=new ClassWriter(0);c.accept(new ClassRemapper(w,new SimpleRemapper(original,target)));Path p=Paths.get(a[1]).resolve(target+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
  }
 }
}
