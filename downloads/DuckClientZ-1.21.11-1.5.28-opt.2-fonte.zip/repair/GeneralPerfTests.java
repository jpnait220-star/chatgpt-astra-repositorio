import com.duckswords.perf.*;import com.duckswords.modules.Performance;import com.duckswords.module.Module;import com.duckswords.module.Category;import com.duckswords.DucksWordsClient;import net.minecraft.*;import java.util.*;
public class GeneralPerfTests {
 static int n;static void check(boolean b){if(!b)throw new AssertionError("check "+n);n++;}
 static class A extends Module{A(){super("A","a",Category.CLIENT);}}
 static class B extends A{}
 public static void main(String[] args){
 IndexedModules list=new IndexedModules();A a=new A();B b=new B();list.add(a);list.add(b);for(int i=0;i<1000;i++)check(list.byType(A.class)==a);
 list.subList(0,1).set(0,b);check(list.byType(A.class)==b);list.set(0,a);check(list.byType(A.class)==a);list.iterator().next();list.remove(0);check(list.byType(A.class)==b);list.clear();check(list.byType(A.class)==null);
 class_332 ctx=new class_332();HorizontalGradient.draw(ctx,12,20,212,35,0xff000000,0xffffffff);check(ctx.gradients==1);check(Math.abs(ctx.capturedX-12)<.001&&Math.abs(ctx.capturedY-35)<.001);ctx.capture(0,0);check(ctx.capturedX==0&&ctx.capturedY==0);ctx.failGradient=true;try{HorizontalGradient.draw(ctx,12,20,212,35,0xff000000,0xffffffff);throw new AssertionError();}catch(IllegalStateException ok){}ctx.capture(0,0);check(ctx.capturedX==0&&ctx.capturedY==0);
 Performance p=new Performance();DucksWordsClient.MODULES.modules.put(Performance.class,p);class_310 mc=class_310.method_1551();mc.field_1724=new class_746();mc.field_1687=new class_638();p.setEnabled(true);p.particleBudget.setValue(16.0);for(int i=0;i<16;i++)check(ParticleBudget.allow(0,0,0));check(!ParticleBudget.allow(0,0,0));mc.field_1724.field_6012++;check(!ParticleBudget.allow(100,0,0));check(ParticleBudget.allow(0,0,0));p.setEnabled(false);for(int i=0;i<50;i++)check(ParticleBudget.allow(100,0,0));
 System.out.println("PASS: "+n+" general performance tests: module index/mutations, gradient alignment/cleanup, particle budget/tick/distance/disable.");
 }
}
