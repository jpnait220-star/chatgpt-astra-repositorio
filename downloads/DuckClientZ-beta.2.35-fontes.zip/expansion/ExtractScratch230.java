import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Run both real copied cube bodies against the same real native Cube/Quad/Vertex data. */
public class ExtractScratch230 implements Opcodes {
 public static void main(String[] a)throws Exception{
  Path target=Path.of(a[2],"net/minecraft/class_630$class_628.class");ClassNode cube=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(a[3],"net/minecraft/class_630$class_628.class"))).accept(cube,0);
  for(int j=0;j<2;j++)try(ZipFile z=new ZipFile(a[j])){ClassNode mix=new ClassNode();new ClassReader(z.getInputStream(z.getEntry("com/duckswords/mixin/MixinCosmeticCube217.class"))).accept(mix,0);MethodNode original=mix.methods.stream().filter(m->m.name.equals("duck$vanilla217$method_32089")).findFirst().orElseThrow();MethodNode copy=new MethodNode(ACC_PUBLIC,j==0?"baseline230":"optimized230",original.desc,null,null);original.accept(copy);copy.visibleAnnotations=null;copy.invisibleAnnotations=null;
   int allocations=0;for(AbstractInsnNode n:copy.instructions){if(n instanceof FieldInsnNode f&&f.owner.equals(mix.name))f.owner=cube.name;if(n instanceof MethodInsnNode call&&call.owner.equals(mix.name))call.owner=cube.name;if(n instanceof TypeInsnNode t&&t.getOpcode()==NEW&&t.desc.startsWith("org/joml/Vector"))allocations++;}
   if(j==1&&allocations!=0)throw new AssertionError("per-cube vector allocation remains");if(j==0&&allocations==0)throw new AssertionError("baseline not exercised");cube.methods.add(copy);if(j==1)for(MethodNode extra:mix.methods)if(extra.name.startsWith("duck$direct234$")||extra.name.startsWith("duck$bulk234$")){MethodNode endpoint=new MethodNode(ACC_PUBLIC,extra.name,extra.desc,null,null);extra.accept(endpoint);endpoint.visibleAnnotations=null;endpoint.invisibleAnnotations=null;for(AbstractInsnNode x:endpoint.instructions){if(x instanceof FieldInsnNode f&&f.owner.equals(mix.name))f.owner=cube.name;if(x instanceof MethodInsnNode call&&call.owner.equals(mix.name))call.owner=cube.name;}cube.methods.add(endpoint);}
  }
  ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS){protected String getCommonSuperClass(String x,String y){return "java/lang/Object";}};cube.accept(writer);Files.createDirectories(target.getParent());Files.write(target,writer.toByteArray());
 }
}
