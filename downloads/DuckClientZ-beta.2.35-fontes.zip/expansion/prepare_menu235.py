from PIL import Image
from io import BytesIO
from pathlib import PurePosixPath

def png(im):
 out=BytesIO();im.save(out,format='PNG');return out.getvalue()
def prepare(data):
 # Shelf packing with transparent/extruded two-pixel gutters; no resampling.
 items=[]
 for name,raw in data.items():
  if name.startswith('assets/duckswords/textures/gui/icons/') and name.endswith('.png') and not any(s in name for s in ['texturemaker','jaulacooldown']):
   im=Image.open(BytesIO(raw)).convert('RGBA');items.append((name,im))
 atlas=Image.new('RGBA',(1024,2048));shelves=[];rows=[];used=0
 for name,im in sorted(items,key=lambda t:(-t[1].height,-t[1].width,t[0])):
  w,h=im.size
  shelf=next((s for s in shelves if s[2]>=h+4 and s[0]+w+4<=1024),None)
  if shelf is None:shelf=[0,used,h+4];shelves.append(shelf);used+=h+4
  x,y=shelf[0]+2,shelf[1]+2;shelf[0]+=w+4;assert used<=2048
  # Extrude colors through gutters to avoid sampling the neighboring sprite.
  atlas.paste(im,(x,y));atlas.paste(im.crop((0,0,1,h)).resize((2,h)),(x-2,y));atlas.paste(im.crop((w-1,0,w,h)).resize((2,h)),(x+w,y))
  atlas.paste(atlas.crop((x-2,y,x+w+2,y+1)).resize((w+4,2)),(x-2,y-2));atlas.paste(atlas.crop((x-2,y+h-1,x+w+2,y+h)).resize((w+4,2)),(x-2,y+h))
  rows.append(name.removeprefix('assets/duckswords/')+'='+','.join(map(str,(x,y,w,h))))
 masks=Image.new('RGBA',(128,1024),(255,255,255,0));shapes=Image.open(BytesIO(data['assets/duckswords/textures/gui/shapes229.png'])).convert('RGBA');r=8;n=16;source=(r-1)*(r+4)+2
 for h,row in [(80,2),(17,166),(16,204),(26,240),(18,296)]:
  ww=36;hh=h*2
  for kind in [0,1]:
   for y in range(hh):
    for x in range(ww):
     xx=min(x,ww-1-x);yy=min(y,hh-1-y)
     if xx<n and yy<n:a=shapes.getpixel((kind*68+2+xx,source+yy))[3]
     else:a=255 if kind==0 or xx<2 or yy<2 else 0
     masks.putpixel((2+kind*40+x,row+y),(255,255,255,a))
 return {'assets/duckswords/textures/gui/icons235.png':png(atlas),'assets/duckswords/textures/gui/icons235.properties':('\n'.join(sorted(rows))+'\n').encode(),'assets/duckswords/textures/gui/panels235.png':png(masks)}
