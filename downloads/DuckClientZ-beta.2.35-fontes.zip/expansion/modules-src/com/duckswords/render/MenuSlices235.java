package com.duckswords.render;
import com.duckswords.visuals.LegacyMarker225;import net.minecraft.class_332;
/** Exact static fill/stroke masks, three horizontal slices per layer. */
public final class MenuSlices235 {
 private static Object texture;public static Object identifier(){throw new IllegalStateException("native menu masks Identifier");}
 private static void layer(class_332 c,LegacyMarker225.Blit blit,int x,int y,int w,int h,int r,int row,int kind,int color){if((color>>>24)==0)return;float u=(2+kind*40)/128f,v=row/1024f,b=(row+h*2)/1024f;blit.duck$marker225(texture,x,x+r,y,y+h,u,u+r*2/128f,v,b,color);if(w>2*r)blit.duck$marker225(texture,x+r,x+w-r,y,y+h,u+r*2/128f,u+(r*2+4)/128f,v,b,color);blit.duck$marker225(texture,x+w-r,x+w,y,y+h,u+(r*2+4)/128f,u+(r*4+4)/128f,v,b,color);}
 public static boolean draw(class_332 c,int x,int y,int w,int h,int fill,int border){int row=switch(h){case 80->2;case 17->166;case 16->204;case 26->240;case 18->296;default->-1;};if(row<0||w<16||!(c instanceof LegacyMarker225.Blit blit))return false;if(texture==null)texture=identifier();GuiFace.begin(c);try{layer(c,blit,x,y,w,h,8,row,0,fill);layer(c,blit,x,y,w,h,8,row,1,border);}finally{GuiFace.end(c);}return true;}
}
