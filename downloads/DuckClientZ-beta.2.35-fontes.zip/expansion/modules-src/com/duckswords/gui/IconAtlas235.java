package com.duckswords.gui;
import com.duckswords.render.GuiFace;import net.minecraft.class_2960;import net.minecraft.class_332;import java.util.*;import java.io.*;
/** Original pixels in one texture. Respect resource packs replacing individual icons. */
public final class IconAtlas235 {
 private record Sprite(int x,int y,int w,int h){}
 private static final class_2960 ATLAS=identifier("textures/gui/icons235.png");
 private static final Map<class_2960,Sprite> SPRITES=load();private static final Map<class_2960,Boolean> COMPAT=new HashMap<>();private static Object pack;private static boolean checked;private static volatile boolean dirty;
 private static Map<class_2960,Sprite> load(){try(InputStream in=IconAtlas235.class.getResourceAsStream("/assets/duckswords/textures/gui/icons235.properties")){if(in==null)return Map.of();Properties p=new Properties();p.load(in);Map<class_2960,Sprite> sprites=new HashMap<>();for(String path:p.stringPropertyNames()){String[] n=p.getProperty(path).split(",");sprites.put(identifier(path),new Sprite(Integer.parseInt(n[0]),Integer.parseInt(n[1]),Integer.parseInt(n[2]),Integer.parseInt(n[3])));}return Map.copyOf(sprites);}catch(IOException|RuntimeException invalid){return Map.of();}}
 public static class_2960 identifier(String path){throw new IllegalStateException("native icon atlas Identifier");}
 public static Object source(Object texture){throw new IllegalStateException("native resource pack identity");}
 public static void clear(){dirty=true;}
 public static boolean draw(class_332 c,class_2960 id,int x,int y,int w,int h){if(!(c instanceof GuiFace.Blit blit))return false;Sprite sprite=SPRITES.get(id);if(sprite==null)return false;if(dirty){COMPAT.clear();checked=false;pack=null;dirty=false;}if(!checked){pack=source(ATLAS);checked=true;}Boolean compatible=COMPAT.get(id);if(compatible==null){compatible=pack!=null&&pack==source(id);COMPAT.put(id,compatible);}if(!compatible)return false;if(w<=0||h<=0)return true;GuiFace.begin(c);try{blit.duck$face220(ATLAS,x,x+w,y,y+h,sprite.x/1024f,(sprite.x+sprite.w)/1024f,sprite.y/2048f,(sprite.y+sprite.h)/2048f);}finally{GuiFace.end(c);}return true;}
}
