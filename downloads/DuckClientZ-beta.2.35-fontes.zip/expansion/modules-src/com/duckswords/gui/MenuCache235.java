package com.duckswords.gui;
import com.duckswords.module.Module;import com.duckswords.setting.Setting;import com.duckswords.theme.HudText;import net.minecraft.class_2960;import java.util.*;
/** Render-thread caches, bounded independently of search/profile input. */
public final class MenuCache235 {
 private record Trim(String text,int width){}
 private static <K,V> Map<K,V> bounded(int max){return new LinkedHashMap<K,V>(64,.75f,true){protected boolean removeEldestEntry(Map.Entry<K,V> e){return size()>max;}};}
 private static final Map<String,class_2960> ICONS=bounded(256);private static final Map<String,String> UPPER=bounded(256);private static final Map<Trim,String> TRIM=bounded(512);private static final Map<Module,List<Setting<?>>> SETTINGS=new IdentityHashMap<>();private static Locale locale=Locale.getDefault();private static String font="";private static volatile boolean dirty;
 public static class_2960 rawIcon(String name){throw new IllegalStateException("native icon name lookup");}
 private static final class_2960[] FAVORITES=new class_2960[2];
 public static class_2960 rawFavorite(boolean selected){throw new IllegalStateException("native favorite lookup");}
 public static class_2960 favorite(boolean selected){int i=selected?1:0;if(FAVORITES[i]==null)FAVORITES[i]=rawFavorite(selected);return FAVORITES[i];}
 public static void clear(){dirty=true;IconAtlas235.clear();}
 private static void refresh(){Locale now=Locale.getDefault();if(!now.equals(locale)){ICONS.clear();UPPER.clear();locale=now;}String selected=HudTextCache220.font();if(dirty||!selected.equals(font)){TRIM.clear();font=selected;dirty=false;}}
 public static class_2960 icon(String name){refresh();class_2960 id=ICONS.get(name);if(id==null){id=rawIcon(name);ICONS.put(name,id);}return id;}
 public static String upper(String text){refresh();return UPPER.computeIfAbsent(text,k->k.toUpperCase());}
 public static String trim(String text,int width){refresh();if(text.length()>1024)return rawTrim(text,width);Trim key=new Trim(text,width);String result=TRIM.get(key);if(result==null){result=rawTrim(text,width);TRIM.put(key,result);}return result;}
 private static String rawTrim(String text,int width){if(HudText.width(text)<=width)return text;StringBuilder result=new StringBuilder();for(int i=0;i<text.length();i++){if(HudText.width(result.toString()+text.charAt(i)+"...")>width)break;result.append(text.charAt(i));}return result+"...";}
 public static void begin(){SETTINGS.clear();}
 public static List<Setting<?>> settings(Module module){List<Setting<?>> settings=SETTINGS.get(module);if(settings==null){settings=List.copyOf(VisibleSettings.of(module));if(SETTINGS.size()<512)SETTINGS.put(module,settings);}return settings;}
}
