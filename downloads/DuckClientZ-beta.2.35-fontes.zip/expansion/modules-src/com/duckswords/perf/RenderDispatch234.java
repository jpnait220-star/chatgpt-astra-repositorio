package com.duckswords.perf;
import com.duckswords.module.Module;import net.minecraft.class_332;import java.lang.reflect.Method;import java.util.List;
/** Skip only inherited, empty render events. Live enabled state and ordering stay unchanged. */
public final class RenderDispatch234 {
 private record Flags(boolean hud,boolean world){}
 private static final ClassValue<Flags> FLAGS=new ClassValue<>(){protected Flags computeValue(Class<?> type){try{boolean hud=type.getMethod("onHudRender",class_332.class,float.class).getDeclaringClass()!=Module.class;boolean world=false;for(Method method:type.getMethods())if(method.getName().equals("onWorldRender")&&method.getParameterCount()==1&&method.getDeclaringClass()!=Module.class)world=true;return new Flags(hud,world);}catch(LinkageError|RuntimeException|ReflectiveOperationException unsupported){return new Flags(true,true);}}};
 public static void prepare(List<Module> modules){for(Module module:modules)FLAGS.get(module.getClass());}
 public static boolean hud(Module m){return m.isEnabled()&&(m.getCategory()==com.duckswords.module.Category.HUD||FLAGS.get(m.getClass()).hud);}
 public static boolean world(Module m){return m.isEnabled()&&FLAGS.get(m.getClass()).world;}
}
