import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class EffectIconsPatch implements Opcodes {
 public static void main(String[] a)throws Exception {
  Path out=Paths.get(a[1]);String version=a[2],helper="com/duckswords/hud/EffectIcons";
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(V17,ACC_PUBLIC|ACC_FINAL,helper,null,"java/lang/Object",null);
  MethodVisitor m=w.visitMethod(ACC_PUBLIC|ACC_STATIC,"draw","(Lnet/minecraft/class_332;Lnet/minecraft/class_1293;II)V",null,null);m.visitCode();
  m.visitVarInsn(ALOAD,0);
  boolean modern=version.equals("1.21.4");
  if(modern) {
   Handle bootstrap=new Handle(H_INVOKESTATIC,"java/lang/invoke/LambdaMetafactory","metafactory","(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite;",false);
   m.visitInvokeDynamicInsn("apply","()Ljava/util/function/Function;",bootstrap,Type.getMethodType("(Ljava/lang/Object;)Ljava/lang/Object;"),new Handle(H_INVOKESTATIC,"net/minecraft/class_1921","method_62277","(Lnet/minecraft/class_2960;)Lnet/minecraft/class_1921;",false),Type.getMethodType("(Lnet/minecraft/class_2960;)Lnet/minecraft/class_1921;"));
  } else {
   m.visitVarInsn(ILOAD,2);m.visitVarInsn(ILOAD,3);m.visitInsn(ICONST_0);m.visitIntInsn(BIPUSH,18);m.visitIntInsn(BIPUSH,18);
  }
  m.visitMethodInsn(INVOKESTATIC,"net/minecraft/class_310","method_1551","()Lnet/minecraft/class_310;",false);
  m.visitMethodInsn(INVOKEVIRTUAL,"net/minecraft/class_310","method_18505","()Lnet/minecraft/class_4074;",false);
  m.visitVarInsn(ALOAD,1);
  String effectType=version.equals("1.20.1")?"net/minecraft/class_1291":"net/minecraft/class_6880";
  m.visitMethodInsn(INVOKEVIRTUAL,"net/minecraft/class_1293","method_5579","()L"+effectType+";",false);
  m.visitMethodInsn(INVOKEVIRTUAL,"net/minecraft/class_4074","method_18663","(L"+effectType+";)Lnet/minecraft/class_1058;",false);
  if(modern) {
   m.visitVarInsn(ILOAD,2);m.visitVarInsn(ILOAD,3);m.visitIntInsn(BIPUSH,18);m.visitIntInsn(BIPUSH,18);
   m.visitMethodInsn(INVOKEVIRTUAL,"net/minecraft/class_332","method_52709","(Ljava/util/function/Function;Lnet/minecraft/class_1058;IIII)V",false);
  } else m.visitMethodInsn(INVOKEVIRTUAL,"net/minecraft/class_332","method_25298","(IIIIILnet/minecraft/class_1058;)V",false);
  m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();
  Path target=out.resolve(helper+".class");Files.createDirectories(target.getParent());Files.write(target,w.toByteArray());
  String name="com/duckswords/modules/PotionHud";Path file=out.resolve(name+".class");ClassNode c=new ClassNode();
  byte[] bytes;
  if(Files.exists(file))bytes=Files.readAllBytes(file);else try(ZipFile jar=new ZipFile(a[0])){bytes=jar.getInputStream(jar.getEntry(name+".class")).readAllBytes();}
  new ClassReader(bytes).accept(c,0);MethodNode render=c.methods.stream().filter(mm->mm.name.equals("onHudRender")).findFirst().orElseThrow();
  int x=render.localVariables.stream().filter(v->v.name.equals("x")).findFirst().orElseThrow().index;
  int y=render.localVariables.stream().filter(v->v.name.equals("rowY")).findFirst().orElseThrow().index;
  int effect=render.localVariables.stream().filter(v->v.name.equals("effect")).findFirst().orElseThrow().index;
  int edits=0;
  for(AbstractInsnNode n:render.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(name)&&call.name.equals("label")) {
   AbstractInsnNode before=n.getPrevious();while(before.getOpcode()<0)before=before.getPrevious();before=before.getPrevious();while(before.getOpcode()<0)before=before.getPrevious();
   if(!(before instanceof VarInsnNode v)||v.getOpcode()!=ALOAD||v.var!=0)throw new IllegalStateException("Potion label expression changed");
   InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,1));i.add(new VarInsnNode(ALOAD,effect));i.add(new VarInsnNode(ILOAD,x));i.add(new IntInsnNode(BIPUSH,6));i.add(new InsnNode(IADD));i.add(new VarInsnNode(ILOAD,y));i.add(new MethodInsnNode(INVOKESTATIC,helper,"draw","(Lnet/minecraft/class_332;Lnet/minecraft/class_1293;II)V",false));render.instructions.insertBefore(before,i);edits++;
  }
  if(edits!=1)throw new IllegalStateException("Expected exactly one per-row icon hook, got "+edits);
  w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(file,w.toByteArray());System.out.println(version+": native 18x18 effect icon per Potion HUD row");
 }
}
