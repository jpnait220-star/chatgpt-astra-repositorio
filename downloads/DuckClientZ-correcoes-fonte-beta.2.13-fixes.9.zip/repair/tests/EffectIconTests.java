import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.lang.reflect.*;
import java.util.function.Function;
import org.objectweb.asm.*;
public class EffectIconTests implements Opcodes {
 static final String MC="net/minecraft/";
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static ClassWriter base(String name) {
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(V17,ACC_PUBLIC,name,null,"java/lang/Object",null);
  MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","()V",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKESPECIAL,"java/lang/Object","<init>","()V",false);m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();return w;
 }
 static void field(ClassWriter w,String name,String desc){w.visitField(ACC_PUBLIC,name,desc,null,null).visitEnd();}
 static void getter(ClassWriter w,String owner,String method,String field,String desc) {
  MethodVisitor m=w.visitMethod(ACC_PUBLIC,method,"()"+desc,null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,owner,field,desc);m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();
 }
 static byte[] client() {
  String name=MC+"class_310";ClassWriter w=base(name);w.visitField(ACC_PUBLIC|ACC_STATIC,"instance","L"+name+";",null,null).visitEnd();field(w,"manager","L"+MC+"class_4074;");
  MethodVisitor m=w.visitMethod(ACC_PUBLIC|ACC_STATIC,"method_1551","()L"+name+";",null,null);m.visitCode();m.visitFieldInsn(GETSTATIC,name,"instance","L"+name+";");m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();getter(w,name,"method_18505","manager","L"+MC+"class_4074;");return w.toByteArray();
 }
 static byte[] manager(boolean legacy) {
  String name=MC+"class_4074";ClassWriter w=base(name);field(w,"sprite","L"+MC+"class_1058;");field(w,"lastEffect","Ljava/lang/Object;");
  MethodVisitor m=w.visitMethod(ACC_PUBLIC,"method_18663","(L"+MC+(legacy?"class_1291":"class_6880")+";)L"+MC+"class_1058;",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);m.visitFieldInsn(PUTFIELD,name,"lastEffect","Ljava/lang/Object;");m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,name,"sprite","L"+MC+"class_1058;");m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();return w.toByteArray();
 }
 static byte[] layer() {
  String name=MC+"class_1921";ClassWriter w=base(name);w.visitField(ACC_PUBLIC|ACC_STATIC,"value","L"+name+";",null,null).visitEnd();
  MethodVisitor m=w.visitMethod(ACC_PUBLIC|ACC_STATIC,"method_62277","(L"+MC+"class_2960;)L"+name+";",null,null);m.visitCode();m.visitFieldInsn(GETSTATIC,name,"value","L"+name+";");m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();return w.toByteArray();
 }
 static byte[] context(boolean modern) {
  String name=MC+"class_332";ClassWriter w=base(name);field(w,"sprite","L"+MC+"class_1058;");field(w,"function","Ljava/lang/Object;");
  for(String f:new String[]{"x","y","width","height","calls"})field(w,f,"I");
  String desc=modern?"(Ljava/util/function/Function;L"+MC+"class_1058;IIII)V":"(IIIIIL"+MC+"class_1058;)V";
  MethodVisitor m=w.visitMethod(ACC_PUBLIC,modern?"method_52709":"method_25298",desc,null,null);m.visitCode();
  if(modern){m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);m.visitFieldInsn(PUTFIELD,name,"function","Ljava/lang/Object;");}
  m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,modern?2:6);m.visitFieldInsn(PUTFIELD,name,"sprite","L"+MC+"class_1058;");
  String[] fields={"x","y","width","height"};int[] slots=modern?new int[]{3,4,5,6}:new int[]{1,2,4,5};
  for(int i=0;i<4;i++){m.visitVarInsn(ALOAD,0);m.visitVarInsn(ILOAD,slots[i]);m.visitFieldInsn(PUTFIELD,name,fields[i],"I");}
  m.visitVarInsn(ALOAD,0);m.visitInsn(DUP);m.visitFieldInsn(GETFIELD,name,"calls","I");m.visitInsn(ICONST_1);m.visitInsn(IADD);m.visitFieldInsn(PUTFIELD,name,"calls","I");m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();return w.toByteArray();
 }
 static Class<?> type(ClassLoader l,String n)throws Exception{return l.loadClass((MC+n).replace('/','.'));}
 public static void main(String[] a)throws Exception {
  boolean legacy=a[1].equals("1.20.1"),modern=a[1].equals("1.21.4");Map<String,byte[]> defs=new HashMap<>();
  defs.put(MC+"class_1291",PotionCrashTests.effectClass());defs.put(MC+"class_1293",PotionCrashTests.valueClass(MC+"class_1293",false,true,legacy));
  if(!legacy){defs.put(MC+"class_6880",PotionCrashTests.entryClass());defs.put(MC+"class_6880$class_6883",PotionCrashTests.valueClass(MC+"class_6880$class_6883",true,false,false));}
  defs.put(MC+"class_310",client());defs.put(MC+"class_4074",manager(legacy));defs.put(MC+"class_332",context(modern));defs.put(MC+"class_1058",base(MC+"class_1058").toByteArray());defs.put(MC+"class_2960",base(MC+"class_2960").toByteArray());defs.put(MC+"class_1921",layer());
  String helper="com/duckswords/hud/EffectIcons";try(ZipFile z=new ZipFile(a[0])){defs.put(helper,z.getInputStream(z.getEntry(helper+".class")).readAllBytes());}
  ClassLoader loader=new PotionCrashTests.Isolated(defs);Class<?> context=type(loader,"class_332"),client=type(loader,"class_310"),manager=type(loader,"class_4074"),instance=type(loader,"class_1293");
  Object ctx=context.getConstructor().newInstance(),cl=client.getConstructor().newInstance(),sprites=manager.getConstructor().newInstance(),sprite=type(loader,"class_1058").getConstructor().newInstance();
  manager.getField("sprite").set(sprites,sprite);client.getField("manager").set(cl,sprites);client.getField("instance").set(null,cl);
  Method draw=loader.loadClass(helper.replace('/','.')).getMethod("draw",context,instance,int.class,int.class);
  Object effect=type(loader,"class_1291").getConstructor().newInstance();Object entry=legacy?effect:type(loader,"class_6880$class_6883").getConstructor(Object.class).newInstance(effect);Object status=instance.getConstructor(Object.class).newInstance(entry);
  draw.invoke(null,ctx,status,23,47);
  check(manager.getField("lastEffect").get(sprites)==entry,"native atlas receives exact effect type/registry entry");check(context.getField("sprite").get(ctx)==sprite,"effect icon comes from native sprite atlas");check(context.getField("x").getInt(ctx)==23&&context.getField("y").getInt(ctx)==47,"row coordinates unchanged");check(context.getField("width").getInt(ctx)==18&&context.getField("height").getInt(ctx)==18,"icon size 18x18");
  draw.invoke(null,ctx,status,23,69);check(context.getField("calls").getInt(ctx)==2&&context.getField("y").getInt(ctx)==69,"each effect row draws its icon");
  if(modern){Object value=type(loader,"class_1921").getConstructor().newInstance();type(loader,"class_1921").getField("value").set(null,value);Function<Object,Object> function=(Function<Object,Object>)context.getField("function").get(ctx);check(function.apply(type(loader,"class_2960").getConstructor().newInstance())==value,"modern GUI render-layer adapter resolves correctly");}
  System.out.println("PASS: "+checks+" native effect-icon adapter assertions; exact generated helper with version-shaped atlas/context stubs.");
 }
}
