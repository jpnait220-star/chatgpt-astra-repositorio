import com.duckswords.perf.WorldGeometry;
import com.duckswords.modules.TargetHighlight;
import com.duckswords.util.RenderUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.util.*;

public final class WorldRenderTests {
 static int checks;
 static void check(boolean ok,String what){if(!ok)throw new AssertionError(what);checks++;}
 static class Sink implements class_4588 {
  final List<Vector3f> points=new ArrayList<>(),normals=new ArrayList<>();final List<Integer> colors=new ArrayList<>();
  public class_4588 method_22918(Matrix4f m,float x,float y,float z){points.add(m.transformPosition(new Vector3f(x,y,z)));return this;}
  public class_4588 method_39415(int c){colors.add(c);return this;}
  public class_4588 method_22914(float x,float y,float z){normals.add(new Vector3f(x,y,z));return this;}
  public void method_1344(){}
  void clear(){points.clear();normals.clear();colors.clear();}
 }
 static class Context implements WorldRenderContext {
  final class_4587 matrix=new class_4587();final class_4184 eye=new class_4184();final class_4604 frustum=new class_4604();final Sink sink=new Sink();int buffers;
  public class_4597 consumers(){return new class_4597(){public class_4588 getBuffer(class_1921 l){buffers++;return sink;}};}
  public class_4587 matrixStack(){return matrix;}public class_4184 camera(){return eye;}public class_4604 frustum(){return frustum;}
  public float tickDelta(){return .375f;}
  Context(){eye.pos=new class_243(0,0,0);}
  void clear(){buffers=0;sink.clear();}
 }
 @SuppressWarnings("unchecked") static List<class_1309> targets(TargetHighlight h)throws Exception {
  var f=TargetHighlight.class.getDeclaredField("targets");f.setAccessible(true);return (List<class_1309>)f.get(h);
 }
 public static void main(String[] args)throws Exception {
  Context c=new Context();check(WorldGeometry.tickDelta(c)==.375f,"uses frame delta, not an independent client clock");
  for(double origin:new double[]{0,1000000,-1000000,29999000,-29999000})for(float angle:new float[]{0,.1f,1.57f,3.14f}) {
   c.clear();c.eye.pos=new class_243(origin+.125,100.125,origin-.375);c.matrix.matrix.identity().rotateY(angle).rotateX(.3f);
   Matrix4f before=new Matrix4f(c.matrix.matrix);
   class_238 b=new class_238(origin+.1,100.2,origin+.3,origin+.7,102,origin+.9);
   WorldGeometry.drawFilledBox(c,b,1,.5f,0,.5f);
   check(c.sink.points.size()==24&&c.buffers==1,"filled box batches six faces with one buffer");
   check(c.matrix.matrix.equals(before)&&c.matrix.depth==0,"filled box preserves caller pose");
   Vector3f expected=before.transformPosition(new Vector3f((float)(b.field_1323-c.eye.pos.field_1352),(float)(b.field_1322-c.eye.pos.field_1351),(float)(b.field_1321-c.eye.pos.field_1350)));
   check(c.sink.points.get(0).equals(expected,1e-6f),"sub-block precision independent of world coordinate and camera angle");
   check(Math.abs(c.sink.points.get(0).distance(c.sink.points.get(1))-.6f)<1e-5f,"width remains .6 at world border");
   c.clear();WorldGeometry.drawBox(c,b,1,0,0,1);
   check(c.sink.points.size()==24&&c.sink.normals.size()==24&&c.buffers==1,"outline has exactly twelve edges, no voxel shape construction");
   for(int i=0;i<24;i+=2) {
    Vector3f direction=new Vector3f(c.sink.points.get(i+1)).sub(c.sink.points.get(i)).normalize();
    check(c.sink.normals.get(i).equals(direction,1e-5f)&&c.sink.normals.get(i+1).equals(direction,1e-5f),"line shader receives actual transformed edge direction");
   }
  }
  c.clear();c.eye.pos=new class_243(0,0,0);c.matrix.matrix.identity();RenderSystem.lineCalls=0;
  WorldGeometry.drawCircle(c,1,2,3,3,0xff112233,64,2);
  check(c.buffers==1&&RenderSystem.lineCalls==1&&c.sink.points.size()==128,"circle acquires buffer/line width once, not once per segment");
  for(int i=0;i<64;i++){Vector3f p=c.sink.points.get(i*2);check(Math.abs(Math.hypot(p.x-1,p.z-3)-3)<1e-6&&p.y==2,"circle radius and orientation preserved");}
  c.clear();WorldGeometry.drawSphere(c,1,2,3,2,0xff112233,16,2);check(c.buffers==1&&c.sink.points.size()==96,"sphere batches its three great circles");
  c.clear();WorldGeometry.drawLine(c,1,2,3,1,2,3,0xff112233,2);check(c.sink.points.isEmpty(),"zero-length lines skipped before invalid normals reach GPU");
  c.clear();WorldGeometry.drawBox(c,new class_238(0,0,0,1,1,1),1,1,1,0);WorldGeometry.drawFilledBox(c,new class_238(0,0,0,1,1,1),1,1,1,0);
  WorldGeometry.drawCircle(c,0,0,0,3,0,64,2);check(c.buffers==0,"fully transparent effects skip GPU work");
  class_310 mc=class_310.method_1551();mc.field_1724=new class_746();mc.field_1687=new class_638();TargetHighlight h=new TargetHighlight();
  Random random=new Random(5678);ArrayList<class_1309> oracle=new ArrayList<>();
  for(int i=0;i<500;i++) {class_1309 e=i%4==0?new class_1309():new class_1657();e.x=random.nextDouble()*30-15;e.y=random.nextDouble()*4-2;e.z=random.nextDouble()*30-15;e.alive=i%13!=0;mc.field_1687.entities.add(e);}
  for(boolean only:new boolean[]{true,false})for(int limit:new int[]{1,5,20})for(double range:new double[]{1,6,20}) {
   h.onlyPlayers.setValue(only);h.maxPlayers.setValue((double)limit);h.range.setValue(range);oracle.clear();
   for(class_1297 e:mc.field_1687.entities)if(e instanceof class_1309 l&&e.method_5805()&&(!only||e instanceof class_1657)&&mc.field_1724.method_5739(e)<=range)oracle.add(l);
   oracle.sort(Comparator.comparingDouble(mc.field_1724::method_5739));if(oracle.size()>limit)oracle.subList(limit,oracle.size()).clear();
   // Reset removes old fade targets, matching a fresh detection scenario.
   h.onDisable();h.onTick();check(targets(h).equals(oracle),"bounded top-k matches full-world sorted oracle "+only+"/"+limit+"/"+range);
  }
  mc.field_1687.entities.clear();class_1657 e=new class_1657();e.x=3;mc.field_1687.entities.add(e);h.onTick();check(targets(h).size()==1,"active target");
  int lines=RenderUtil.lines,fills=RenderUtil.fills;h.mode.setValue("Both");h.onWorldRender(c);check(RenderUtil.lines==lines+1&&RenderUtil.fills==fills+1,"both rendering modes retained");
  c.frustum.visible=false;h.onWorldRender(c);check(RenderUtil.lines==lines+1&&RenderUtil.fills==fills+1,"offscreen target skips geometry");c.frustum.visible=true;
  mc.field_1687.entities.clear();h.duration.setValue(20.0);for(int i=0;i<19;i++)h.onTick();check(!targets(h).isEmpty(),"lost target retained during fade");h.onTick();check(targets(h).isEmpty(),"fade expires on original tick schedule");
  mc.field_1687.entities.add(e);h.onTick();mc.field_1687=new class_638();h.onWorldRender(c);check(RenderUtil.lines==lines+1,"old world target not drawn during world switch");h.onTick();check(targets(h).isEmpty(),"world switch clears cached targets");
  mc.field_1687=null;mc.field_1724=null;h.onTick();h.onWorldRender(c);check(targets(h).isEmpty(),"disconnect safe");
  System.out.println("PASS: "+checks+" world-render assertions: camera/rotation/world-border precision, actual edge normals, batches, bounded target oracle, fade/frustum/world switches.");
 }
}
