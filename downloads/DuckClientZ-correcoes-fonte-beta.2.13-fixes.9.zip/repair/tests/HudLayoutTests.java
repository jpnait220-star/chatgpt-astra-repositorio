import com.duckswords.DucksWordsClient;
import com.duckswords.module.Module;
import com.duckswords.module.ModuleManager;
import com.duckswords.module.Category;
import com.duckswords.setting.NumberSetting;
import com.duckswords.modules.TextHud;
import com.duckswords.hud.*;
import com.duckswords.theme.Draw;
import net.minecraft.class_332;
import com.google.gson.*;
public class HudLayoutTests {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static void near(float a,float b,String s){check(Math.abs(a-b)<.001,s+": "+a+" vs "+b);}
 static class Widget extends Module {
  final NumberSetting x=add(new NumberSetting("X","x",580,0,10000,1)),y=add(new NumberSetting("Y","y",320,0,10000,1));
  int w=60,h=12,widthReads,heightReads;boolean fail;float originX,originY,endX,endY;
  Widget(){super("test hud","layout test",Category.HUD);}
  public int hudWidth(){widthReads++;return w;}public int hudHeight(){heightReads++;return h;}
  public void onHudRender(class_332 ctx,float delta){ctx.capture(x.getInt(),y.getInt());originX=ctx.capturedX;originY=ctx.capturedY;if(fail)throw new IllegalStateException("test draw failure");ctx.capture(x.getInt()+w,y.getInt()+h);endX=ctx.capturedX;endY=ctx.capturedY;}
 }
 static Widget install(int refW,int refH) {
  DucksWordsClient.MODULES=new ModuleManager();Widget widget=new Widget();widget.setEnabled(true);DucksWordsClient.MODULES.modules.put(Widget.class,widget);DucksWordsClient.MODULES.setHudViewport(refW,refH);return widget;
 }
 static String snapshot(Widget w) {
  JsonObject j=new JsonObject();j.addProperty("x",w.x.getValue());j.addProperty("y",w.y.getValue());j.addProperty("scale",w.hudScaleSetting().getValue());j.addProperty("width",DucksWordsClient.MODULES.hudViewportWidth());j.addProperty("height",DucksWordsClient.MODULES.hudViewportHeight());return j.toString();
 }
 static void load(Widget w,String json) {
  JsonObject j=JsonParser.parseString(json).getAsJsonObject();w.x.setValue(j.get("x").getAsDouble());w.y.setValue(j.get("y").getAsDouble());w.hudScaleSetting().setValue(j.get("scale").getAsDouble());DucksWordsClient.MODULES.setHudViewport(j.get("width").getAsInt(),j.get("height").getAsInt());
 }
 static void draw(Widget w,class_332 ctx,int width,int height){ctx.width=width;ctx.height=height;HudRender.begin(ctx);w.renderHud(ctx,0);}
 public static void main(String[] args) {
  Draw.compensation=1;Widget w=install(640,360);class_332 ctx=new class_332();
  draw(w,ctx,640,360);near(w.originX,580,"reference-canvas x unchanged");near(w.originY,320,"reference-canvas y unchanged");
  check(w.widthReads==1&&w.heightReads==1,"layout measures each HUD only once per frame");
  String original=snapshot(w);
  for(int i=0;i<50;i++) {
   draw(w,ctx,320,180);check(w.originX>=0&&w.originY>=0&&w.endX<=320.01&&w.endY<=180.01,"HUD remains visible in smaller window");
   near(w.originX,260,"right edge retained");check(snapshot(w).equals(original),"resize never rewrites saved coordinates or reference");
   draw(w,ctx,640,360);near(w.originX,580,"F11 restore returns original x");near(w.originY,320,"F11 restore returns original y");
  }
  draw(w,ctx,320,180);String savedWhileSmall=snapshot(w);float smallX=w.originX,smallY=w.originY;
  w=install(1,1);load(w,savedWhileSmall);draw(w,ctx,320,180);near(w.originX,smallX,"relaunch in window preserves projected x");near(w.originY,smallY,"relaunch in window preserves projected y");check(savedWhileSmall.equals(snapshot(w)),"save/load roundtrip preserves canonical values exactly");
  String profileA=snapshot(w);w.x.setValue(180);w.y.setValue(110);DucksWordsClient.MODULES.setHudViewport(800,450);String profileB=snapshot(w);
  draw(w,ctx,320,180);float bx=w.originX,by=w.originY;
  for(int i=0;i<10;i++){load(w,profileA);draw(w,ctx,320,180);near(w.originX,smallX,"profile A x stable");load(w,profileB);draw(w,ctx,320,180);near(w.originX,bx,"profile B x stable");near(w.originY,by,"profile B y stable");}
  load(w,profileA);draw(w,ctx,320,180);HudLayout.move(w.x,100,0,320-HudLayout.width(w));HudLayout.move(w.y,80,0,180-HudLayout.height(w));draw(w,ctx,320,180);
  check(Math.abs(w.originX-100)<=1&&Math.abs(w.originY-80)<=1,"editor inverse mapping places widget under mouse");check(w.x.getInt()!=100,"editor saves reference coordinate, not temporary window pixel");
  String moved=snapshot(w);w=install(1,1);load(w,moved);draw(w,ctx,320,180);check(Math.abs(w.originX-100)<=1&&Math.abs(w.originY-80)<=1,"edited position survives restart");
  TextHud.Entry entry=new TextHud.Entry(580,340);HudRender.entry(ctx,entry,-1);check(ctx.capturedX>=0&&ctx.capturedX<=320&&ctx.capturedY>=0&&ctx.capturedY<=180,"custom text/item entry mapped on-screen");check(entry.x()==580&&entry.y()==340,"custom entry saved coordinates remain canonical");
  HudLayout.moveEntry(entry,70,50);HudRender.entry(ctx,entry,-1);check(Math.abs(ctx.capturedX-70)<=1&&Math.abs(ctx.capturedY-50)<=1,"custom entry drag uses inverse mapping");
  ctx.reset();ctx.parent(7,11,1.25f);ctx.capture(0,0);float parentX=ctx.capturedX,parentY=ctx.capturedY;
  w.fail=true;try{w.renderHud(ctx,0);throw new AssertionError("expected render error");}catch(IllegalStateException expected){}ctx.capture(0,0);near(ctx.capturedX,parentX,"exception restores parent x transform");near(ctx.capturedY,parentY,"exception restores parent y transform");w.fail=false;
  entry.fail=true;try{HudRender.entry(ctx,entry,-1);throw new AssertionError("expected entry error");}catch(IllegalStateException expected){}ctx.capture(0,0);near(ctx.capturedX,parentX,"entry exception restores parent transform");entry.fail=false;
  ctx.reset();w.w=1000;w.h=600;draw(w,ctx,320,180);check(w.originX>=0&&w.originY>=0&&w.endX<=320.01&&w.endY<=180.01,"oversized HUD temporarily fits small window");check(w.hudScaleSetting().getValue()==1,"temporary fit never changes selected scale");w.w=60;w.h=12;
  int ref=DucksWordsClient.MODULES.hudViewportWidth();HudLayout.begin(0,0);check(DucksWordsClient.MODULES.hudViewportWidth()==ref,"minimize cannot corrupt reference viewport");
  w=install(-1,-1);draw(w,ctx,640,360);check(DucksWordsClient.MODULES.hudViewportWidth()==640&&DucksWordsClient.MODULES.hudViewportHeight()==360,"legacy profile without viewport captures one reference");draw(w,ctx,320,180);check(DucksWordsClient.MODULES.hudViewportWidth()==640,"reference is not rebound on each resize");
  Draw.compensation=2f/3f;ctx.reset();ctx.parent(0,0,Draw.compensation);draw(w,ctx,320,180);check(w.originX>=0&&w.endX<=320.01&&w.endY<=180.01,"GUI-scale compensation uses the same logical canvas");Draw.compensation=1;
  w=install(640,360);w.y.setValue(395);draw(w,ctx,640,360);int repaired=DucksWordsClient.MODULES.hudViewportHeight();check(repaired==407&&w.y.getInt()==395,"stale legacy viewport expands without changing position");
  String normalized=snapshot(w);draw(w,ctx,320,180);check(snapshot(w).equals(normalized),"legacy repair is not repeated on resize");
  w=install(640,360);w.y.setValue(395);draw(w,ctx,320,180);check(DucksWordsClient.MODULES.hudViewportHeight()==repaired,"legacy repair independent of window used to load profile");
  w=install(-1,-1);draw(w,ctx,320,180);check(DucksWordsClient.MODULES.hudViewportWidth()==640&&DucksWordsClient.MODULES.hudViewportHeight()==360,"profile without viewport has same reference when first loaded windowed");
  Draw.compensation=1;
  System.out.println("PASS: "+checks+" HUD resize/editor/persistence assertions (F11 cycles, save while windowed, restart, profile switching, custom entries, oversize fit and exception cleanup).");
 }
}
