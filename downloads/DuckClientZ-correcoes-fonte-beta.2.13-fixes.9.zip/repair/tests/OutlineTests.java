import com.duckswords.modules.BlockOverlay;
import com.duckswords.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.*;
public class OutlineTests {
 public static void main(String[] a) {
  BlockOverlay module=new BlockOverlay();
  var listener=WorldRenderEvents.BLOCK_OUTLINE.listeners.get(0);
  WorldRenderContext ctx=new WorldRenderContext(){public class_4184 camera(){return new class_4184();}public class_4597 consumers(){return new class_4597(){};}public class_4587 matrixStack(){return new class_4587();}};
  WorldRenderContext.BlockOutlineContext hit=()->new class_2338(123,70,-55);
  if(!listener.onBlockOutline(ctx,hit))throw new AssertionError("vanilla outline should remain while module disabled");
  module.setEnabled(true);module.onWorldRender(ctx);
  if(RenderUtil.lines!=0)throw new AssertionError("old LAST render must be inactive");
  if(listener.onBlockOutline(ctx,hit))throw new AssertionError("custom outline should replace vanilla");
  if(RenderUtil.lines!=1||!RenderUtil.last.position().equals(hit.blockPos()))throw new AssertionError("outline must use vanilla's block target");
  module.mode.setValue("Filled");listener.onBlockOutline(ctx,hit);
  if(RenderUtil.fills!=1||RenderUtil.lines!=1)throw new AssertionError("filled mode");
  module.mode.setValue("Both");listener.onBlockOutline(ctx,hit);
  if(RenderUtil.fills!=2||RenderUtil.lines!=2)throw new AssertionError("both mode");
  if(!listener.onBlockOutline(new WorldRenderContext(){},hit))throw new AssertionError("no consumer must retain vanilla outline");
  System.out.println("PASS: 7 block-outline regressions (native event/target, no late camera raycast).");
 }
}
