import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Shared hooks; the matrix backend is compiled separately for each GUI API. */
public class HudPatch implements Opcodes {
 static Path out;static ZipFile jar;
 static ClassNode read(String name)throws Exception {
  ClassNode c=new ClassNode();Path existing=out.resolve(name+".class");
  byte[] bytes=Files.exists(existing)?Files.readAllBytes(existing):jar.getInputStream(jar.getEntry(name+".class")).readAllBytes();
  new ClassReader(bytes).accept(c,0);return c;
 }
 static void write(ClassNode c)throws Exception {
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=out.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
 static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
 static void clear(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 static void call(InsnList i,String name,String desc){i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/hud/HudRender",name,desc,false));}
 static void begin(ClassNode c,String name)throws Exception {
  MethodNode m=method(c,name);InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,1));call(i,"begin","(Lnet/minecraft/class_332;)V");m.instructions.insert(i);
 }
 static InsnList clearDrag(String owner) {
  InsnList i=new InsnList();
  for(String field:new String[]{"dragging","draggingEntry"}) {
   i.add(new VarInsnNode(ALOAD,0));i.add(new InsnNode(ACONST_NULL));
   i.add(new FieldInsnNode(PUTFIELD,owner,field,field.equals("dragging")?"Lcom/duckswords/module/Module;":"Lcom/duckswords/modules/TextHud$Entry;"));
  }
  return i;
 }
 public static void main(String[] a)throws Exception {
  out=Paths.get(a[1]);Files.createDirectories(out);
  try(ZipFile input=new ZipFile(a[0])) {jar=input;
   ClassNode c=read("com/duckswords/module/Module");MethodNode m=method(c,"renderHud");clear(m);
   InsnList i=m.instructions;i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new VarInsnNode(FLOAD,2));call(i,"render","(Lcom/duckswords/module/Module;Lnet/minecraft/class_332;F)V");i.add(new InsnNode(RETURN));write(c);
   c=read("com/duckswords/module/ModuleManager");begin(c,"onHudRender");
   i=new InsnList();i.add(new MethodInsnNode(INVOKESTATIC,"com/duckswords/hud/HudLayout","referenceChanged","()V",false));method(c,"setHudViewport").instructions.insert(i);write(c);
   c=read("com/duckswords/gui/HudEditorScreen");begin(c,"method_25394");int edits=0;
   for(MethodNode editor:c.methods)for(AbstractInsnNode n:editor.instructions)if(n instanceof MethodInsnNode mc) {
    String descriptor=null,name=null;
    if(mc.owner.equals("com/duckswords/setting/NumberSetting")) {
     if(mc.name.equals("getInt")){name="coordinate";descriptor="(Lcom/duckswords/setting/NumberSetting;)I";}
     if(mc.name.equals("setValueWithin")){name="move";descriptor="(Lcom/duckswords/setting/NumberSetting;DDD)V";}
    }
    if(mc.owner.equals("com/duckswords/module/Module")&&(mc.name.equals("hudWidthScaled")||mc.name.equals("hudHeightScaled"))) {name=mc.name.equals("hudWidthScaled")?"width":"height";descriptor="(Lcom/duckswords/module/Module;)I";}
    if(mc.owner.equals("com/duckswords/modules/TextHud$Entry")) {
     if(mc.name.equals("x")||mc.name.equals("y")){name=mc.name.equals("x")?"entryX":"entryY";descriptor="(Lcom/duckswords/modules/TextHud$Entry;)I";}
     if(mc.name.equals("moveTo")){name="moveEntry";descriptor="(Lcom/duckswords/modules/TextHud$Entry;II)V";}
    }
    if(mc.owner.equals("com/duckswords/modules/TextHud")&&(mc.name.equals("entryWidth")||mc.name.equals("entryHeight"))){name=mc.name;descriptor=mc.desc;}
    if(descriptor!=null){mc.setOpcode(INVOKESTATIC);mc.owner="com/duckswords/hud/HudLayout";mc.name=name;mc.desc=descriptor;mc.itf=false;edits++;}
   }
   if(edits<20)throw new IllegalStateException("Editor hooks missing: "+edits);
   MethodNode init=c.methods.stream().filter(mm->mm.name.equals("method_25426")&&mm.desc.equals("()V")).findFirst().orElse(null);
   if(init==null) {
    init=new MethodNode(ACC_PROTECTED,"method_25426","()V",null,null);init.instructions.add(clearDrag(c.name));
    init.instructions.add(new VarInsnNode(ALOAD,0));init.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"method_25426","()V",false));init.instructions.add(new InsnNode(RETURN));c.methods.add(init);
   } else init.instructions.insert(clearDrag(c.name));
   method(c,"method_25419").instructions.insert(clearDrag(c.name));write(c);
   c=read("com/duckswords/modules/TextHud");m=method(c,"renderEntry");m.name="duck$renderEntryRaw";
   MethodNode wrapper=new MethodNode(ACC_PUBLIC|ACC_STATIC,"renderEntry",m.desc,null,null);
   i=wrapper.instructions;i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new VarInsnNode(ILOAD,2));call(i,"entry","(Lnet/minecraft/class_332;Lcom/duckswords/modules/TextHud$Entry;I)V");i.add(new InsnNode(RETURN));c.methods.add(wrapper);write(c);
   System.out.println("HUD: canonical coordinates preserved; "+edits+" editor mappings; module and custom-entry render scopes");
  }
 }
}
