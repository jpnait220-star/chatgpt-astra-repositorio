package com.duckswords.modules;
import com.duckswords.module.Module;
import com.duckswords.module.Category;
import com.duckswords.setting.BooleanSetting;
import com.duckswords.setting.NumberSetting;
public final class Performance extends Module {
 public final BooleanSetting limitParticles=add(new BooleanSetting("Limitar particulas extras","Limita apenas particulas criadas pelo client; pode reduzir a densidade dos efeitos",true));
 public final NumberSetting particleBudget=add(new NumberSetting("Particulas por tick","Maximo de particulas extras por tick; menor reduz o custo e a densidade",128,16,1024,16));
 public final BooleanSetting limitDistance=add(new BooleanSetting("Limitar distancia das particulas","Evita criar particulas extras distantes do jogador",true));
 public final NumberSetting particleDistance=add(new NumberSetting("Distancia das particulas","Alcance das particulas extras em blocos",32,8,128,4));
 public Performance(){super("Performance","Controles de custo dos efeitos extras do client, compativeis com Sodium",Category.CLIENT);}
 @Override public void onDisable(){com.duckswords.perf.ParticleBudget.reset();}
}
