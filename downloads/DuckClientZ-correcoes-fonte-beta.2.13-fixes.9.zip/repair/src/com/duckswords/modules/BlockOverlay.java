package com.duckswords.modules;
import com.duckswords.module.Module;
import com.duckswords.module.Category;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.ModeSetting;
import com.duckswords.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_238;
public class BlockOverlay extends Module {
    public final ColorSetting color=add(new ColorSetting("Cor","Cor do outline",-855660032));
    public final ModeSetting mode=add(new ModeSetting("Modo","Estilo do overlay","Box","Box","Filled","Both"));
    public BlockOverlay() {
        super("BlockOverlay","Outline no bloco mirado, alinhado ao mundo",Category.VISUALS);
        WorldRenderEvents.BLOCK_OUTLINE.register(this::renderOutline);
    }
    private boolean renderOutline(WorldRenderContext ctx,WorldRenderContext.BlockOutlineContext hit) {
        if(!isEnabled()||ctx.camera()==null||ctx.consumers()==null||ctx.matrixStack()==null)return true;
        class_238 box=new class_238(hit.blockPos()).method_1014(.002);
        if(mode.is("Box")||mode.is("Both"))RenderUtil.drawBox(ctx,box,color.r(),color.g(),color.b(),color.a());
        if(mode.is("Filled")||mode.is("Both"))RenderUtil.drawFilledBox(ctx,box,color.r(),color.g(),color.b(),color.a()*.2f);
        return false;
    }
    // The old LAST callback has no live consumer buffer and used a second camera raycast.
    @Override public void onWorldRender(WorldRenderContext ctx) {}
}
