/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 */
package com.duckswords.modules;

import com.duckswords.module.Category;
import com.duckswords.module.Module;
import com.duckswords.setting.BooleanSetting;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.ModeSetting;
import com.duckswords.setting.NumberSetting;
import com.duckswords.util.MinecraftCompat;
import com.duckswords.util.RenderUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class TargetHighlight
extends Module {
    public final NumberSetting duration = this.add(new NumberSetting("Duracao", "Tempo em ticks que o highlight fica visivel depois de perder o alvo", 20.0, 1.0, 200.0, 1.0));
    public final ColorSetting color = this.add(new ColorSetting("Cor", "Cor do highlight", -1291786753));
    public final ModeSetting mode = this.add(new ModeSetting("Modo", "Estilo do highlight", "Box", "Box", "Filled", "Both"));
    public final NumberSetting range = this.add(new NumberSetting("Alcance", "Distancia maxima para detectar o alvo", 6.0, 1.0, 20.0, 0.5));
    public final BooleanSetting onlyPlayers = this.add(new BooleanSetting("So Players", "Ignora mobs", true));
    public final BooleanSetting fade = this.add(new BooleanSetting("Fade", "Some suavemente ao expirar", true));
    public final NumberSetting maxPlayers = this.add(new NumberSetting("Limite de players", "Numero maximo de jogadores proximos destacados", 5.0, 1.0, 20.0, 1.0));
    public final BooleanSetting healthColors = this.add(new BooleanSetting("Cores por vida", "Usa cores diferentes conforme a vida restante do alvo", true));
    public final ColorSetting highHealthColor = this.add(new ColorSetting("Cor vida alta", "Cor quando o alvo tem pelo menos 66% de vida", -16711936));
    public final ColorSetting mediumHealthColor = this.add(new ColorSetting("Cor meia vida", "Cor quando o alvo tem entre 33% e 66% de vida", -256));
    public final ColorSetting lowHealthColor = this.add(new ColorSetting("Cor pouca vida", "Cor quando o alvo tem menos de 33% de vida", -65536));
    private List<class_1309> targets = List.of();
    private int ticksLeft;
    private Object lastWorld;
    private final float[] distances=new float[20];
    private final java.util.function.Predicate<class_1297> candidateFilter=e->e instanceof class_1309&&e.method_5805()&&(!onlyPlayers.getValue()||e instanceof class_1657);

    public TargetHighlight() {
        super("TargetHighlight", "Destaca os jogadores proximos com a hitbox", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.targets = List.of();
        this.ticksLeft = 0;this.lastWorld=null;
    }

    @Override
    public void onTick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            this.targets = List.of();
            this.ticksLeft = 0;this.lastWorld=null;
            return;
        }
        if (lastWorld != client.field_1687) {targets=List.of();ticksLeft=0;lastWorld=client.field_1687;}
        final int limit=Math.max(1,Math.min(20,maxPlayers.getInt()));
        double radius=range.getValue(), x=client.field_1724.method_23317(), y=client.field_1724.method_23318(), z=client.field_1724.method_23321();
        List<class_1297> candidates=client.field_1687.method_8333(client.field_1724,
                new class_238(x-radius-.00001,y-radius-.00001,z-radius-.00001,x+radius+.00001,y+radius+.00001,z+radius+.00001), candidateFilter);
        ArrayList<class_1309> nearby=new ArrayList<>(limit);
        for(class_1297 entity:candidates) {
            // Same native float distance and stable nearest-first order as the original.
            float distance=client.field_1724.method_5739(entity);
            if(distance>radius)continue;
            int slot=nearby.size();
            while(slot>0&&distance<distances[slot-1])slot--;
            if(slot>=limit)continue;
            if(nearby.size()==limit)nearby.remove(limit-1);
            for(int i=nearby.size();i>slot;i--)distances[i]=distances[i-1];
            distances[slot]=distance;nearby.add(slot,(class_1309)entity);
        }
        if (nearby.isEmpty()) {
            if (this.ticksLeft > 0) {
                --this.ticksLeft;
                if (this.ticksLeft == 0) {
                    this.targets = List.of();
                }
            }
        } else {
            this.targets = nearby;
            this.ticksLeft = this.duration.getInt();
        }
    }

    @Override
    public void onWorldRender(WorldRenderContext ctx) {
        if (mc.field_1687!=null && lastWorld==mc.field_1687 && !this.targets.isEmpty() && this.ticksLeft > 0) {
            float tickDelta = com.duckswords.perf.WorldGeometry.tickDelta(ctx);
            float fadeFactor = this.fade.getValue() != false ? Math.min(1.0f, (float)this.ticksLeft / Math.max(1.0f, this.duration.getFloat())) : 1.0f;
            for (class_1309 target : this.targets) {
                if (!target.method_5805()) continue;
                ColorSetting selectedColor = this.color;
                if (this.healthColors.getValue().booleanValue()) {
                    float healthRatio;
                    float f = healthRatio = target.method_6063() <= 0.0f ? 0.0f : Math.max(0.0f, Math.min(1.0f, target.method_6032() / target.method_6063()));
                    selectedColor = healthRatio >= 0.66f ? this.highHealthColor : (healthRatio >= 0.33f ? this.mediumHealthColor : this.lowHealthColor);
                }
                float alpha = selectedColor.a() * fadeFactor;
                class_238 box = RenderUtil.entityBox((class_1297)target, tickDelta, 0.0);
                if(alpha<=0 || (ctx.frustum()!=null&&!ctx.frustum().method_23093(box)))continue;
                if (this.mode.is("Box") || this.mode.is("Both")) {
                    RenderUtil.drawBox(ctx, box, selectedColor.r(), selectedColor.g(), selectedColor.b(), alpha);
                }
                if (!this.mode.is("Filled") && !this.mode.is("Both")) continue;
                RenderUtil.drawFilledBox(ctx, box, selectedColor.r(), selectedColor.g(), selectedColor.b(), alpha * 0.25f);
            }
        }
    }
}

