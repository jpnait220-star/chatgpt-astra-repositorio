package com.duckswords.modules;
import com.duckswords.module.Category;
import com.duckswords.module.Module;
import com.duckswords.repair.HitRangeRing;
import com.duckswords.setting.ColorSetting;
import com.duckswords.setting.NumberSetting;
import com.duckswords.util.MinecraftCompat;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.*;
import java.util.function.Predicate;
public class HitRange extends Module {
    public final ColorSetting color=add(new ColorSetting("Cor","Cor do circulo de alcance",-1437212673));
    public final NumberSetting range=add(new NumberSetting("Tamanho","Raio do circulo de alcance em blocos",3,3,3,.5));
    public final NumberSetting thickness=add(new NumberSetting("Espessura","Ajusta a espessura visual da linha",30,1,60,.5));
    private static final Predicate<class_1297> LIVING=e->e instanceof class_1309&&e.method_5805();
    private boolean nearby;
    private Object lastWorld;
    private int untilScan;
    public HitRange(){super("Hitrange","Mostra um circulo de alcance configuravel ao redor do jogador",Category.VISUALS);}
    @Override public void onTick() {
        if(mc.field_1724==null||mc.field_1687==null){nearby=false;lastWorld=null;untilScan=0;return;}
        if(lastWorld!=mc.field_1687){lastWorld=mc.field_1687;untilScan=0;nearby=false;}
        if(untilScan-->0)return;
        untilScan=1; // 10 queries/second, independent of frame rate.
        double x=mc.field_1724.method_23317(),y=mc.field_1724.method_23318()+.03,z=mc.field_1724.method_23321();
        nearby=false;
        for(class_1297 e:mc.field_1687.method_8333(mc.field_1724,new class_238(x-3.00001,y-3.00001,z-3.00001,x+3.00001,y+3.00001,z+3.00001),LIVING)) {
            double dx=e.method_23317()-x,dz=e.method_23321()-z;
            if(dx*dx+dz*dz<=9&&Math.abs(e.method_23318()-y)<=3){nearby=true;break;}
        }
    }
    @Override public void onDisable(){nearby=false;lastWorld=null;untilScan=0;}
    @Override public void onWorldRender(WorldRenderContext context) {
        if(mc.field_1724==null||mc.field_1687==null)return;
        class_243 p=mc.field_1724.method_30950(com.duckswords.perf.WorldGeometry.tickDelta(context));
        HitRangeRing.drawCircle(context,p.field_1352,p.field_1351+.03,p.field_1350,3,nearby&&lastWorld==mc.field_1687?-13244309:color.getDisplayValue(),64,thickness.getFloat());
    }
}
