package com.duckswords.hud;
import com.duckswords.module.Module;
import com.duckswords.modules.TextHud;
import com.duckswords.setting.NumberSetting;
import com.duckswords.theme.Draw;
import net.minecraft.class_332;
public final class HudRender {
    public static void begin(class_332 context) {
        float compensation=Draw.guiScaleCompensation();
        if(!Float.isFinite(compensation)||compensation<=0)compensation=1;
        HudLayout.begin(Math.round(context.method_51421()/compensation),Math.round(context.method_51443()/compensation));
    }
    public static void render(Module module,class_332 context,float delta) {
        NumberSetting x=module.hudX(),y=module.hudY();
        if(x==null||y==null){module.onHudRender(context,delta);return;}
        int px=HudLayout.coordinate(x),py=HudLayout.coordinate(y);float scale=HudLayout.scale(module);
        boolean pushed=HudMatrix.push(context,px,py,scale,x.getInt(),y.getInt());
        try{module.onHudRender(context,delta);}finally{if(pushed)HudMatrix.pop(context);}
    }
    public static void entry(class_332 context,TextHud.Entry entry,int color) {
        boolean pushed=HudMatrix.push(context,HudLayout.entryX(entry),HudLayout.entryY(entry),HudLayout.entryScale(entry),entry.x(),entry.y());
        try{TextHud.duck$renderEntryRaw(context,entry,color);}finally{if(pushed)HudMatrix.pop(context);}
    }
}
