package com.duckswords.hud;
import net.minecraft.class_332;
import net.minecraft.class_4587;
/** MatrixStack backend for 1.20.1, 1.21.1 and 1.21.4. */
public final class HudMatrix {
    public static boolean push(class_332 context,int x,int y,float scale,int rawX,int rawY) {
        if(x==rawX&&y==rawY&&scale==1)return false;
        class_4587 m=context.method_51448();m.method_22903();
        try{m.method_46416(x,y,0);m.method_22905(scale,scale,1);m.method_46416(-rawX,-rawY,0);}
        catch(RuntimeException|Error e){m.method_22909();throw e;}
        return true;
    }
    public static void pop(class_332 context){context.method_51448().method_22909();}
}
