package com.duckswords.hud;
import com.duckswords.DucksWordsClient;
import com.duckswords.module.Module;
import com.duckswords.module.ModuleManager;
import com.duckswords.modules.TextHud;
import com.duckswords.setting.NumberSetting;
import java.util.IdentityHashMap;
import java.util.WeakHashMap;
/** Canonical coordinates belong to a profile, never to a temporary window size. */
public final class HudLayout {
    private record Binding(Module module,boolean horizontal) {}
    private static final IdentityHashMap<NumberSetting,Binding> BINDINGS=new IdentityHashMap<>();
    private static final IdentityHashMap<Module,Metrics> MODULE_METRICS=new IdentityHashMap<>();
    private static final WeakHashMap<TextHud.Entry,Metrics> ENTRY_METRICS=new WeakHashMap<>();
    private static long frame;
    private static final class Metrics {
        long frame=-1;int baseWidth,baseHeight,displayWidth,displayHeight;float selected,scale;
    }
    private static ModuleManager owner;
    private static int count=-1,width,height;
    private static boolean resolved;
    public static void referenceChanged(){resolved=false;}
    public static void begin(int w,int h) {
        if(w<=0||h<=0)return;
        width=w;height=h;frame++;
        ModuleManager manager=DucksWordsClient.MODULES;
        if(manager!=owner||manager.getModules().size()!=count) {
            owner=manager;count=manager.getModules().size();BINDINGS.clear();MODULE_METRICS.clear();ENTRY_METRICS.clear();resolved=false;
            for(Module m:manager.getHudElements()) {
                BINDINGS.put(m.hudX(),new Binding(m,true));BINDINGS.put(m.hudY(),new Binding(m,false));
            }
        }
        if(!resolved) {
            // All four embedded presets use 640x360. A legacy import must not
            // acquire a different coordinate system depending on the current window.
            int rw=manager.hudViewportWidth()>0?manager.hudViewportWidth():640;
            int rh=manager.hudViewportHeight()>0?manager.hudViewportHeight():360;
            int boundX=rw,boundY=rh;boolean invalidX=false,invalidY=false;
            for(Module m:manager.getHudElements())if(m.isEnabled()) {
                int x=m.hudX().getInt(),y=m.hudY().getInt();
                invalidX|=x>=rw;invalidY|=y>=rh;
                boundX=Math.max(boundX,x+referenceObject(m,true));boundY=Math.max(boundY,y+referenceObject(m,false));
            }
            for(TextHud.Entry entry:TextHud.entries()) {
                invalidX|=entry.x()>=rw;invalidY|=entry.y()>=rh;
                boundX=Math.max(boundX,entry.x()+metrics(entry).baseWidth);boundY=Math.max(boundY,entry.y()+metrics(entry).baseHeight);
            }
            if(invalidX)rw=boundX;if(invalidY)rh=boundY;
            // Repair stale legacy metadata deterministically, never scale the stored positions.
            if(manager.hudViewportWidth()!=rw||manager.hudViewportHeight()!=rh)manager.setHudViewport(rw,rh);
            resolved=true;
        }
    }
    private static int reference(boolean x) {
        int n=x?DucksWordsClient.MODULES.hudViewportWidth():DucksWordsClient.MODULES.hudViewportHeight();
        return n>0?n:Math.max(1,x?width:height);
    }
    private static int current(boolean x){return Math.max(1,x?width:height);}
    private static int dimension(int n){return Math.max(1,n);}
    private static void refresh(Metrics value,int baseWidth,int baseHeight,float selected) {
        if(!Float.isFinite(selected)||selected<=0)selected=1;
        value.baseWidth=dimension(baseWidth);value.baseHeight=dimension(baseHeight);value.selected=selected;
        value.scale=width<=0||height<=0?selected:Math.min(selected,Math.min(width/(float)value.baseWidth,height/(float)value.baseHeight));
        value.displayWidth=Math.max(1,Math.round(value.baseWidth*value.scale));value.displayHeight=Math.max(1,Math.round(value.baseHeight*value.scale));value.frame=frame;
    }
    private static Metrics metrics(Module module) {
        Metrics value=MODULE_METRICS.get(module);
        if(value==null){value=new Metrics();MODULE_METRICS.put(module,value);}
        if(value.frame!=frame)refresh(value,module.hudWidth(),module.hudHeight(),module.hudScale());
        return value;
    }
    private static Metrics metrics(TextHud.Entry entry) {
        Metrics value=ENTRY_METRICS.get(entry);
        if(value==null){value=new Metrics();ENTRY_METRICS.put(entry,value);}
        if(value.frame!=frame)refresh(value,TextHud.entryWidth(entry),TextHud.entryHeight(entry),1);
        return value;
    }
    public static float scale(Module m){return metrics(m).scale;}
    public static int width(Module m){return metrics(m).displayWidth;}
    public static int height(Module m){return metrics(m).displayHeight;}
    public static int project(double raw,int reference,int current,int referenceObject,int displayedObject) {
        if(reference<=0||current<=0)return (int)Math.round(raw);
        double remainingReference=Math.max(1,reference-referenceObject);
        double fraction=Math.max(0,Math.min(1,raw/remainingReference));
        return (int)Math.round(fraction*Math.max(0,current-displayedObject));
    }
    public static double unproject(double displayed,double old,int reference,int current,int referenceObject,int displayedObject) {
        int remaining=Math.max(0,current-displayedObject);
        if(remaining==0)return old; // A tiny window must not erase the intended position.
        double fraction=Math.max(0,Math.min(1,displayed/remaining));
        return fraction*Math.max(0,reference-referenceObject);
    }
    private static int referenceObject(Module m,boolean x) {
        Metrics value=metrics(m);
        return Math.max(1,Math.round((x?value.baseWidth:value.baseHeight)*value.selected));
    }
    public static int coordinate(NumberSetting setting) {
        Binding b=BINDINGS.get(setting);if(b==null)return setting.getInt();
        boolean x=b.horizontal;Module m=b.module;
        return project(setting.getInt(),reference(x),current(x),referenceObject(m,x),x?width(m):height(m));
    }
    public static void move(NumberSetting setting,double displayed,double minimum,double maximum) {
        Binding b=BINDINGS.get(setting);
        if(b==null){setting.setValueWithin(displayed,minimum,maximum);return;}
        boolean x=b.horizontal;Module m=b.module;
        double raw=unproject(displayed,setting.getValue(),reference(x),current(x),referenceObject(m,x),x?width(m):height(m));
        setting.setValueWithin(raw,setting.getMin(),Math.min(setting.getMax(),Math.max(setting.getValue(),Math.max(0,reference(x)-referenceObject(m,x)))));
    }
    public static float entryScale(TextHud.Entry e) {
        return metrics(e).scale;
    }
    public static int entryWidth(TextHud.Entry e){return metrics(e).displayWidth;}
    public static int entryHeight(TextHud.Entry e){return metrics(e).displayHeight;}
    public static int entryX(TextHud.Entry e){return project(e.x(),reference(true),current(true),metrics(e).baseWidth,entryWidth(e));}
    public static int entryY(TextHud.Entry e){return project(e.y(),reference(false),current(false),metrics(e).baseHeight,entryHeight(e));}
    public static void moveEntry(TextHud.Entry e,int x,int y) {
        int rawX=(int)Math.round(unproject(x,e.x(),reference(true),current(true),metrics(e).baseWidth,entryWidth(e)));
        int rawY=(int)Math.round(unproject(y,e.y(),reference(false),current(false),metrics(e).baseHeight,entryHeight(e)));
        e.moveTo(Math.max(-1000,Math.min(10000,rawX)),Math.max(-1000,Math.min(10000,rawY)));
    }
}
