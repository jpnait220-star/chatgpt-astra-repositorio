package com.duckswords.mixin;
import com.duckswords.perf.FullbrightAmbient;
import net.minecraft.class_765;
import net.minecraft.class_2874;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Mixin(class_765.class)
public abstract class MixinFullbrightAmbient {
 @Redirect(method="method_3313(F)V",at=@At(value="INVOKE",target="Lnet/minecraft/class_2874;comp_656()F"),require=1,remap=false)
 private float duck$ambient(class_2874 dimension){return FullbrightAmbient.apply(dimension.comp_656());}
}
