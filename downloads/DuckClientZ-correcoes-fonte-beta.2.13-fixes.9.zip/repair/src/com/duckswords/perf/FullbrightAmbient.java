package com.duckswords.perf;
import com.duckswords.DucksWordsClient;
import com.duckswords.modules.Fullbright;
public final class FullbrightAmbient {
 public static float apply(float vanilla){
  Fullbright f=DucksWordsClient.MODULES.get(Fullbright.class);
  return f==null||!f.isEnabled()?vanilla:adjust(vanilla,f.gamma.getFloat());
 }
 public static float adjust(float vanilla,float gamma){
  if(!Float.isFinite(gamma)||gamma<=1)return vanilla;
  float strength=Math.min(1,(gamma-1)/9f);
  return Math.max(vanilla,vanilla+(1-vanilla)*strength);
 }
}
