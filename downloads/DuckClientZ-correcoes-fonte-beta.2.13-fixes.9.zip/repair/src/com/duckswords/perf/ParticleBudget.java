package com.duckswords.perf;
import com.duckswords.DucksWordsClient;
import com.duckswords.modules.Performance;
import net.minecraft.*;
/** Only mod-owned spawn call sites are routed here. No vanilla/global particle hooks. */
public final class ParticleBudget {
 private static Object world,player;private static int tick=Integer.MIN_VALUE,used;
 public static void reset(){world=null;player=null;tick=Integer.MIN_VALUE;used=0;}
 public static boolean allow(double x,double y,double z){
  Performance options=DucksWordsClient.MODULES.get(Performance.class);
  if(options==null||!options.isEnabled())return true;
  class_310 mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1687==null){reset();return true;}
  if(world!=mc.field_1687||player!=mc.field_1724||tick!=mc.field_1724.field_6012){world=mc.field_1687;player=mc.field_1724;tick=mc.field_1724.field_6012;used=0;}
  if(options.limitDistance.getValue()){
   double dx=x-mc.field_1724.method_23317(),dy=y-mc.field_1724.method_23318(),dz=z-mc.field_1724.method_23321(),range=options.particleDistance.getValue();
   if(dx*dx+dy*dy+dz*dz>range*range)return false;
  }
  if(options.limitParticles.getValue()){
   if(used>=options.particleBudget.getInt())return false;
   used++;
  }
  return true;
 }
 public static void spawn(class_638 w,class_2394 effect,double x,double y,double z,double vx,double vy,double vz){if(allow(x,y,z))w.method_8406(effect,x,y,z,vx,vy,vz);}
}
