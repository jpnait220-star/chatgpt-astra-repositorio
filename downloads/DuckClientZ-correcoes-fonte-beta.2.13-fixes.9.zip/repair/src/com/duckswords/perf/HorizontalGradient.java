package com.duckswords.perf;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.joml.Quaternionf;
/** A single interpolated quad instead of one fill per column. */
public final class HorizontalGradient {
 private static final Quaternionf ROTATION=new Quaternionf().rotationZ(-(float)Math.PI/2);
 public static void draw(class_332 ctx,int x1,int y1,int x2,int y2,int from,int to){
  int w=Math.max(1,x2-x1);if(y1==y2)return;
  if(from==to||w==1){ctx.method_25294(x1,y1,x1+w,y2,from);return;}
  class_4587 m=ctx.method_51448();m.method_22903();
  try{m.method_46416(x1,y1,0);m.method_22907(ROTATION);ctx.method_25296(y1-y2,0,0,w,from,to);}
  finally{m.method_22909();}
 }
}
