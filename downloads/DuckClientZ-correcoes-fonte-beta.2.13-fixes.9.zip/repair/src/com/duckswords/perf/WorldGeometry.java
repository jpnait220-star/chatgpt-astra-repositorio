package com.duckswords.perf;

import com.duckswords.util.MinecraftCompat;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.*;
import org.joml.Matrix4f;

/** Camera-relative doubles before conversion to GPU floats. No matrix mutation; the existing line-width setting is retained. */
public final class WorldGeometry {
    private WorldGeometry() {}
    // Replaced with the version-specific Fabric context accessor during the build.
    public static float tickDelta(WorldRenderContext ctx) { return 0; }
    private static boolean ready(WorldRenderContext c) {
        return c != null && c.camera()!=null && c.consumers()!=null && c.matrixStack()!=null;
    }
    private static int argb(float r,float g,float b,float a) {
        return channel(a)<<24|channel(r)<<16|channel(g)<<8|channel(b);
    }
    private static int channel(float v) {return (int)(Math.max(0,Math.min(1,v))*255);}
    public static void drawBox(WorldRenderContext c,class_238 b,float r,float g,float blue,float a) {
        if(!ready(c)||a<=0)return;
        class_243 eye=c.camera().method_19326();
        float x1=(float)(b.field_1323-eye.field_1352), y1=(float)(b.field_1322-eye.field_1351), z1=(float)(b.field_1321-eye.field_1350);
        float x2=(float)(b.field_1320-eye.field_1352), y2=(float)(b.field_1325-eye.field_1351), z2=(float)(b.field_1324-eye.field_1350);
        com.mojang.blaze3d.systems.RenderSystem.lineWidth(1f);
        class_4588 v=c.consumers().getBuffer(class_1921.method_23594());
        Matrix4f m=c.matrixStack().method_23760().method_23761(); int col=argb(r,g,blue,a);
        line(v,m,x1,y1,z1,x2,y1,z1,col); line(v,m,x1,y1,z1,x1,y2,z1,col); line(v,m,x1,y1,z1,x1,y1,z2,col);
        line(v,m,x2,y1,z1,x2,y2,z1,col); line(v,m,x2,y1,z1,x2,y1,z2,col);
        line(v,m,x1,y2,z1,x2,y2,z1,col); line(v,m,x1,y2,z1,x1,y2,z2,col);
        line(v,m,x1,y1,z2,x2,y1,z2,col); line(v,m,x1,y1,z2,x1,y2,z2,col);
        line(v,m,x2,y2,z1,x2,y2,z2,col); line(v,m,x2,y1,z2,x2,y2,z2,col); line(v,m,x1,y2,z2,x2,y2,z2,col);
    }
    public static void drawFilledBox(WorldRenderContext c,class_238 b,float r,float g,float blue,float a) {
        if(!ready(c)||a<=0)return;
        class_243 eye=c.camera().method_19326();
        float x1=(float)(b.field_1323-eye.field_1352), y1=(float)(b.field_1322-eye.field_1351), z1=(float)(b.field_1321-eye.field_1350);
        float x2=(float)(b.field_1320-eye.field_1352), y2=(float)(b.field_1325-eye.field_1351), z2=(float)(b.field_1324-eye.field_1350);
        class_4588 v=c.consumers().getBuffer(MinecraftCompat.debugQuadLayer());
        Matrix4f m=c.matrixStack().method_23760().method_23761(); int col=argb(r,g,blue,a);
        quad(v,m,x1,y1,z1,x2,y1,z1,x2,y1,z2,x1,y1,z2,col);
        quad(v,m,x1,y2,z1,x1,y2,z2,x2,y2,z2,x2,y2,z1,col);
        quad(v,m,x1,y1,z1,x1,y2,z1,x2,y2,z1,x2,y1,z1,col);
        quad(v,m,x1,y1,z2,x2,y1,z2,x2,y2,z2,x1,y2,z2,col);
        quad(v,m,x1,y1,z1,x1,y1,z2,x1,y2,z2,x1,y2,z1,col);
        quad(v,m,x2,y1,z1,x2,y2,z1,x2,y2,z2,x2,y1,z2,col);
    }
    public static void drawLine(WorldRenderContext c,double x1,double y1,double z1,double x2,double y2,double z2,int color,float width) {
        if(!ready(c)||width<=0||!Float.isFinite(width)||(color>>>24)==0)return;
        com.mojang.blaze3d.systems.RenderSystem.lineWidth(width);
        class_243 p=c.camera().method_19326();
        line(c.consumers().getBuffer(class_1921.method_23594()),c.matrixStack().method_23760().method_23761(),
            (float)(x1-p.field_1352),(float)(y1-p.field_1351),(float)(z1-p.field_1350),
            (float)(x2-p.field_1352),(float)(y2-p.field_1351),(float)(z2-p.field_1350),color);
    }
    public static void drawCircle(WorldRenderContext c,double x,double y,double z,double radius,int color,int segments,float width) {
        circle(c,x,y,z,radius,color,segments,width,false);
    }
    public static void drawSphere(WorldRenderContext c,double x,double y,double z,double radius,int color,int segments,float width) {
        circle(c,x,y,z,radius,color,segments,width,true);
    }
    private static void circle(WorldRenderContext c,double x,double y,double z,double radius,int color,int segments,float width,boolean sphere) {
        if(!ready(c)||segments<3||radius<=0||width<=0||!Float.isFinite(width)||(color>>>24)==0)return;
        com.mojang.blaze3d.systems.RenderSystem.lineWidth(width);
        class_243 p=c.camera().method_19326();
        double cx=x-p.field_1352,cy=y-p.field_1351,cz=z-p.field_1350;
        class_4588 v=c.consumers().getBuffer(class_1921.method_23594());Matrix4f m=c.matrixStack().method_23760().method_23761();
        double[] unit=CirclePoints.get(segments);
        for(int i=0;i<segments;i++) {
            double ax=unit[2*i]*radius,ay=unit[2*i+1]*radius,bx=unit[2*i+2]*radius,by=unit[2*i+3]*radius;
            line(v,m,(float)(cx+ax),(float)cy,(float)(cz+ay),(float)(cx+bx),(float)cy,(float)(cz+by),color);
            if(sphere) {
                line(v,m,(float)(cx+ax),(float)(cy+ay),(float)cz,(float)(cx+bx),(float)(cy+by),(float)cz,color);
                line(v,m,(float)cx,(float)(cy+ax),(float)(cz+ay),(float)cx,(float)(cy+bx),(float)(cz+by),color);
            }
        }
    }
    private static void line(class_4588 v,Matrix4f m,float x1,float y1,float z1,float x2,float y2,float z2,int c) {
        float dx=x2-x1,dy=y2-y1,dz=z2-z1;
        float nx=m.m00()*dx+m.m10()*dy+m.m20()*dz,ny=m.m01()*dx+m.m11()*dy+m.m21()*dz,nz=m.m02()*dx+m.m12()*dy+m.m22()*dz;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);if(len<=1e-8f||!Float.isFinite(len))return;
        nx/=len;ny/=len;nz/=len;
        MinecraftCompat.vertexColorNormal(v,m,x1,y1,z1,c,nx,ny,nz);MinecraftCompat.vertexColorNormal(v,m,x2,y2,z2,c,nx,ny,nz);
    }
    private static void quad(class_4588 v,Matrix4f m,float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz,int color) {
        MinecraftCompat.vertexColor(v,m,ax,ay,az,color);MinecraftCompat.vertexColor(v,m,bx,by,bz,color);
        MinecraftCompat.vertexColor(v,m,cx,cy,cz,color);MinecraftCompat.vertexColor(v,m,dx,dy,dz,color);
    }
}
