package com.duckswords.perf;
import com.duckswords.module.Module;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
/** List-compatible lookup index. All mutations, including sublists/iterators, invalidate it. */
public final class IndexedModules extends AbstractList<Module> implements RandomAccess {
 private final ArrayList<Module> values=new ArrayList<>();
 private final Map<Class<?>,Module> index=new ConcurrentHashMap<>();
 public Module get(int i){return values.get(i);}
 public int size(){return values.size();}
 public Module set(int i,Module v){Module old=values.set(i,v);index.clear();return old;}
 public void add(int i,Module v){values.add(i,v);modCount++;index.clear();}
 public Module remove(int i){Module old=values.remove(i);modCount++;index.clear();return old;}
 protected void removeRange(int from,int to){values.subList(from,to).clear();modCount++;index.clear();}
 public Module byType(Class<?> type){
  Module found=index.get(type);if(found!=null)return found;
  for(Module m:values)if(type.isInstance(m)){if(index.size()<256)index.put(type,m);return m;}
  return null;
 }
}
