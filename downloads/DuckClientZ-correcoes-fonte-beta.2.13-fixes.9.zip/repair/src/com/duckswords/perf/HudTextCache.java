package com.duckswords.perf;
import com.duckswords.theme.HudText;
import com.duckswords.theme.Interface;
import net.minecraft.class_2561;
import java.util.*;
/** Internal drawing cache only. Public styled() still returns independent mutable text. */
public final class HudTextCache {
 private static String font;
 private static final Map<String,class_2561> TEXT=new LinkedHashMap<>(256,.75f,true){protected boolean removeEldestEntry(Map.Entry<String,class_2561> e){return size()>256;}};
 public static class_2561 styled(String value){
  Interface settings=Interface.get();String current=settings==null?"Minecraft":settings.hudFont.getValue();
  if(!Objects.equals(font,current)){TEXT.clear();font=current;}
  if(value==null||value.length()>256)return HudText.styled(value);
  class_2561 result=TEXT.get(value);if(result==null){result=HudText.styled(value);TEXT.put(value,result);}return result;
 }
}
