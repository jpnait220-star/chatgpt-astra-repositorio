package net.minecraft; public class class_238 {
 public final double x1,y1,z1,x2,y2,z2,field_1323,field_1322,field_1321,field_1320,field_1325,field_1324;private class_2338 position;
 public class_238(class_2338 p){this(p.x(),p.y(),p.z(),p.x()+1,p.y()+1,p.z()+1);position=p;}
 public class_238(double a,double b,double c,double d,double e,double f){x1=field_1323=a;y1=field_1322=b;z1=field_1321=c;x2=field_1320=d;y2=field_1325=e;z2=field_1324=f;}
 public class_2338 position(){return position;}
 public class_238 method_1014(double g){class_238 v=new class_238(x1-g,y1-g,z1-g,x2+g,y2+g,z2+g);v.position=position;return v;}
}