import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.analysis.*;
public class VerifyArtifacts {
 static Map<String,String> classes=new HashMap<>(),reverse=new HashMap<>(),methods=new HashMap<>(),fields=new HashMap<>();
 static Map<String,ClassNode> cache=new HashMap<>();
 static Map<String,List<String>> rawParents=new HashMap<>();
 static ZipFile minecraft,mod,fabric;
 static String mappedMethod(String owner,String name,String desc)throws java.io.IOException {
  String mapped=methods.get(owner+" "+name+desc);if(mapped!=null)return mapped;
  if(name.startsWith("<")||minecraft==null)return null;
  List<String> parents=rawParents.get(owner);
  if(parents==null) {
   parents=new ArrayList<>();ZipEntry entry=minecraft.getEntry(owner+".class");
   if(entry!=null) {
    ClassReader r=new ClassReader(minecraft.getInputStream(entry));
    if(r.getSuperName()!=null)parents.add(r.getSuperName());parents.addAll(Arrays.asList(r.getInterfaces()));
   }
   rawParents.put(owner,parents);
  }
  for(String parent:parents){mapped=mappedMethod(parent,name,desc);if(mapped!=null)return mapped;}
  return null;
 }
 static Remapper remap=new Remapper() {
  @Override public String map(String n){return classes.getOrDefault(n,n);}
  @Override public String mapMethodName(String o,String n,String d){try{String mapped=mappedMethod(o,n,d);return mapped==null?n:mapped;}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}}
  @Override public String mapFieldName(String o,String n,String d){return fields.getOrDefault(o+" "+n+d,n);}
 };
 static ClassNode read(String name)throws Exception {
  if(cache.containsKey(name))return cache.get(name);
  if(name.startsWith("net/fabricmc/")&&fabric!=null) {
   ZipEntry e=fabric.getEntry(name+".class");if(e==null)return null;
   ClassNode c=new ClassNode();new ClassReader(fabric.getInputStream(e)).accept(c,0);cache.put(name,c);return c;
  }
  if(name.startsWith("java/")) {
   try(java.io.InputStream stream=ClassLoader.getSystemResourceAsStream(name+".class")) {
    if(stream==null)return null;ClassNode c=new ClassNode();new ClassReader(stream).accept(c,ClassReader.SKIP_CODE);cache.put(name,c);return c;
   }
  }
  boolean game=name.startsWith("net/minecraft/");
  String path=(game?reverse.get(name):name)+".class";
  ZipEntry entry=game?minecraft.getEntry(path):mod.getEntry(path);
  if(entry==null&&name.startsWith("com/mojang/"))entry=minecraft.getEntry(path);
  if(entry==null)return null;
  ClassNode c=new ClassNode();
  ClassReader r=new ClassReader((game||name.startsWith("com/mojang/"))?minecraft.getInputStream(entry):mod.getInputStream(entry));
  r.accept(game?new ClassRemapper(c,remap):c,0);cache.put(name,c);return c;
 }
 static boolean member(String owner,String name,String desc,boolean method)throws Exception {
  ClassNode c=read(owner);if(c==null)return false;
  if(method) {for(MethodNode m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;}
  else {for(FieldNode f:c.fields)if(f.name.equals(name)&&f.desc.equals(desc))return true;}
  if(c.superName!=null&&!name.equals("<init>")&&member(c.superName,name,desc,method))return true;
  for(String i:c.interfaces)if(member(i,name,desc,method))return true;
  return false;
 }
 static void require(boolean b,String text){if(!b)throw new IllegalStateException(text);}
 static boolean reachesCapture(String owner,String name,String desc,Set<String> seen)throws Exception {
  if(owner.equals("net/minecraft/class_922")&&name.equals("method_62355"))return true;
  if(!seen.add(owner+" "+name+desc))return false;
  ClassNode c=read(owner);if(c==null)return false;
  boolean declares=false;
  for(MethodNode m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc)) {
   declares=true;
   for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call&&call.getOpcode()==Opcodes.INVOKESPECIAL&&call.desc.equals(desc)&&reachesCapture(call.owner,call.name,call.desc,seen))return true;
  }
  return !declares&&c.superName!=null&&reachesCapture(c.superName,name,desc,seen);
 }
 public static void main(String[] a)throws Exception {
  String owner="";
  for(String line:Files.readAllLines(Paths.get(a[0]))) {
   String[] p=line.split("\t");
   if(p[0].equals("c")){owner=p[1];classes.put(p[1],p[2]);reverse.put(p[2],p[1]);}
   else if(p.length==5&&(p[1].equals("m")||p[1].equals("f")))
    (p[1].equals("m")?methods:fields).put(owner+" "+p[3]+p[2],p[4]);
  }
  minecraft=new ZipFile(a[1]);mod=new ZipFile(a[2]);
  Path tools=Paths.get(a[0]).getParent();
  fabric=new ZipFile(tools.resolve(a[3].equals("1.21.1")?"fabric-rendering-v1.jar":"fabric-rendering-v1-"+a[3]+".jar").toFile());
  ClassNode entry=read("com/duckswords/DucksWordsClient");int events=0,eventLambdas=0;
  for(MethodNode method:entry.methods)if(method.name.equals("onInitializeClient"))for(AbstractInsnNode n:method.instructions) {
   if(n instanceof FieldInsnNode f&&f.owner.equals("net/fabricmc/fabric/api/client/rendering/v1/WorldRenderEvents")) {
    require(!f.name.equals("LAST"),"Buffered world effects still registered after buffers are flushed");
    if(f.name.equals("AFTER_ENTITIES")){require(member(f.owner,f.name,f.desc,false),"Missing Fabric buffered event");events++;}
   }
   if(n instanceof InvokeDynamicInsnNode i&&i.desc.contains("WorldRenderEvents$AfterEntities")) {
    require(i.name.equals("afterEntities"),"Incorrect event SAM");
    require(member("net/fabricmc/fabric/api/client/rendering/v1/WorldRenderEvents$AfterEntities",i.name,"(Lnet/fabricmc/fabric/api/client/rendering/v1/WorldRenderContext;)V",true),"Fabric event descriptor mismatch");
    Handle h=(Handle)i.bsmArgs[1];require(member(h.getOwner(),h.getName(),h.getDesc(),true),"Missing world event body");eventLambdas++;
   }
  }
  require(events==1&&eventLambdas==1,"World effects must be scheduled exactly once per frame");
  ClassNode target=read("com/duckswords/modules/TargetHighlight");
  for(MethodNode m:target.methods)for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call)
   require(!call.name.equals("method_18112")&&!call.name.equals("sort"),"Full-world scan/sort remains in TargetHighlight");
  ClassNode phase=read("net/minecraft/class_4668");
  require(phase!=null,"RenderPhase absent");
  MethodNode texture=phase.methods.stream().filter(m->m.name.equals("method_23517")&&m.desc.equals("(F)V")).findFirst().orElseThrow();
  require((texture.access&Opcodes.ACC_STATIC)!=0,"Glint target is not static");
  boolean setsMatrix=false;
  for(AbstractInsnNode n:texture.instructions)if(n instanceof MethodInsnNode m&&m.owner.equals("com/mojang/blaze3d/systems/RenderSystem")&&m.name.equals("setTextureMatrix"))setsMatrix=true;
  require(setsMatrix,"Glint hook no longer uses a texture matrix");
  if(a[3].equals("1.20.1")) {
   ClassNode light=read("net/minecraft/class_765");
   require(member(light.name,"field_4135","Z",false),"Lightmap dirty flag absent");
   MethodNode update=light.methods.stream().filter(m->m.name.equals("method_3313")&&m.desc.equals("(F)V")).findFirst().orElseThrow();
   int pixelCalls=0;
   for(AbstractInsnNode n:update.instructions)if(n instanceof MethodInsnNode m&&m.owner.equals("net/minecraft/class_1011")&&m.name.equals("method_4305")&&m.desc.equals("(III)V"))pixelCalls++;
   require(pixelCalls==1,"Expected exactly one lightmap pixel setter instruction, found "+pixelCalls);
   require(member(light.name,"method_3314","()V",true),"Lightmap tick absent");
  }
  ClassNode hud=read("net/minecraft/class_329");
  String callerName=a[3].equals("1.20.1")?"method_1753":"method_55803";
  int scoreboardCalls=0;
  for(MethodNode m:hud.methods)if(m.name.equals(callerName))for(AbstractInsnNode n:m.instructions)
    if(n instanceof MethodInsnNode call&&call.owner.equals(hud.name)&&call.name.equals("method_1757")&&call.desc.equals("(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V"))scoreboardCalls++;
  require(scoreboardCalls==1,"Expected one specific scoreboard call in HUD, found "+scoreboardCalls);
  ClassNode scoped=read("com/duckswords/mixin/MixinScopedScoreboard");
  String callerDesc=a[3].equals("1.20.1")?"(Lnet/minecraft/class_332;F)V":"(Lnet/minecraft/class_332;Lnet/minecraft/class_9779;)V";
  int redirects=0;
  for(MethodNode m:scoped.methods)if(m.visibleAnnotations!=null)for(AnnotationNode annotation:m.visibleAnnotations)
   if(annotation.desc.equals("Lorg/spongepowered/asm/mixin/injection/Redirect;"))
    for(int i=0;i<annotation.values.size();i+=2)if(annotation.values.get(i).equals("method")) {
     require(annotation.values.get(i+1).equals(List.of(callerName+callerDesc)),"Scoreboard annotation not tailored to "+a[3]);redirects++;
    }
  require(redirects==1,"Missing scoped scoreboard redirect");
  require(member(hud.name,"method_1757","(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V",true),"Scoreboard shadow target missing");
  ClassNode oldScoreboard=read("com/duckswords/mixin/MixinScoreboardPosition");
  require(oldScoreboard.methods.stream().noneMatch(m->m.name.contains("pushScoreboardOffset")||m.name.contains("popScoreboardOffset")),"Legacy unscoped scoreboard transforms remain");
  String wingHook="com/duckswords/mixin/"+(a[3].equals("1.21.4")?"MixinElytraEntityModel1214":"RepairElytraModel");
  ClassNode wing=read(wingHook);boolean delegates=false;
  for(MethodNode m:wing.methods)for(AbstractInsnNode n:m.instructions)if(n instanceof MethodInsnNode call) {
   require(!call.owner.equals("java/lang/Math")||!call.name.equals("sin"),"Idle-driven wing oscillation remains");
   delegates|=call.owner.equals("com/duckswords/render/ElytraPhysics");
  }
  require(delegates,"Elytra motion hook not delegated");
  require(member("net/minecraft/class_563","method_17079",a[3].equals("1.21.4")?"(Lnet/minecraft/class_10034;)V":"(Lnet/minecraft/class_1309;FFFFF)V",true),"Native Elytra model target missing");
  if(a[3].equals("1.21.4")) {
   String desc="(Lnet/minecraft/class_1309;Lnet/minecraft/class_10042;F)V";
   require(member("net/minecraft/class_922","method_62355",desc,true),"Elytra capture target missing");
   require(read("com/duckswords/mixin/MixinElytraMotionCapture")!=null&&read("com/duckswords/mixin/MixinElytraMotionState")!=null,"Motion state mixins absent");
   for(String renderer:List.of("net/minecraft/class_1007","net/minecraft/class_909")) {
    boolean callsBase=false;
    for(MethodNode m:read(renderer).methods)for(AbstractInsnNode n:m.instructions)
     if(n instanceof MethodInsnNode call&&call.getOpcode()==Opcodes.INVOKESPECIAL&&call.desc.equals(desc)&&reachesCapture(call.owner,call.name,call.desc,new HashSet<>()))callsBase=true;
    require(callsBase,"Renderer does not reach shared motion capture: "+renderer);
   }
  }
  if(a[3].equals("1.21.4")) {
   int ambient=0;
   for(MethodNode m:read("net/minecraft/class_765").methods)if(m.name.equals("method_3313"))for(AbstractInsnNode n:m.instructions)
    if(n instanceof MethodInsnNode call&&call.owner.equals("net/minecraft/class_2874")&&call.name.equals("comp_656")&&call.desc.equals("()F"))ambient++;
   require(ambient==1,"Fullbright ambient redirect must match exactly one native lightmap invocation");
   require(read("com/duckswords/mixin/MixinFullbrightAmbient")!=null,"Missing required Fullbright ambient mixin");
  }
  ClassNode font=read("com/duckswords/theme/HudText");
  for(MethodNode m:font.methods)if(m.name.equals("duck$styledDesktop"))for(AbstractInsnNode n:m.instructions)
    require(!(n instanceof MethodInsnNode call&&call.owner.equals("java/util/stream/IntStream")),"Per-label font stream allocation remains");
  Set<String> changed=new HashSet<>(Files.readAllLines(Paths.get(a[4])));
  int analyzed=0,links=0;
  for(String file:changed) {
   if(!file.endsWith(".class"))continue;
   String name=file.substring(0,file.length()-6);ClassNode c=read(name);require(c!=null,"Missing changed class "+name);
   require(!a[3].equals("1.20.1")||c.version<=61,"Java 21 bytecode in 1.20.1 "+name);
   for(MethodNode m:c.methods) {
    if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0) {new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);analyzed++;}
    // Validate references in newly compiled code against the REAL corresponding MC jar,
    // not the compilation stubs. Legacy bytecode is left untouched outside exact edits.
    if(!name.startsWith("com/duckswords/hud/")&&!name.startsWith("com/duckswords/glint/")&&!name.startsWith("com/duckswords/render/")&&!name.equals("com/duckswords/modules/CustomGlint")&&!name.equals("com/duckswords/modules/BlockOverlay")&&!name.startsWith("com/duckswords/profiles/DefaultProfileMigration")&&!name.equals("com/duckswords/theme/Interface")&&!name.startsWith("com/duckswords/perf/")&&!name.equals("com/duckswords/repair/HitRangeRing")&&!name.equals("com/duckswords/modules/HitRange")&&!name.equals("com/duckswords/modules/TargetHighlight")&&!name.equals("com/duckswords/compat/FullbrightPixels")&&!(name.equals("com/duckswords/util/MinecraftCompat")&&Set.of("vertexColor","vertexColorNormal","rotate","getTickDelta","getCurrentFps","debugQuadLayer","statusEffect").contains(m.name)))continue;
    for(AbstractInsnNode n:m.instructions) {
     if(name.equals("com/duckswords/util/MinecraftCompat")&&n instanceof MethodInsnNode call)
      require(!call.owner.startsWith("java/lang/reflect/")&&!call.owner.startsWith("java/util/stream/")&&!call.owner.equals("java/lang/Class"),"Reflective discovery remained in optimized render path "+m.name);
     if(n instanceof MethodInsnNode call&&(call.owner.startsWith("net/minecraft/")||call.owner.startsWith("net/fabricmc/fabric/api/client/rendering/")||call.owner.startsWith("com/mojang/")||call.owner.startsWith("com/duckswords/"))) {
      require(member(call.owner,call.name,call.desc,true),"Missing method "+call.owner+"."+call.name+call.desc);links++;
      ClassNode api=read(call.owner);
      if(call.getOpcode()==Opcodes.INVOKEINTERFACE)require(api!=null&&(api.access&Opcodes.ACC_INTERFACE)!=0,"invokeinterface on non-interface "+call.owner);
     }
     if(n instanceof FieldInsnNode f&&(f.owner.startsWith("net/minecraft/")||f.owner.startsWith("com/duckswords/"))) {
      require(member(f.owner,f.name,f.desc,false),"Missing field "+f.owner+"."+f.name+f.desc);links++;
     }
    }
   }
  }
  System.out.println(a[3]+": "+analyzed+" method bodies verified, "+links+" member references checked against real MC/mod classes; injection targets present.");
 }
}
