import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
/** Keep buffered world effects in Fabric's supported buffered pass, once per frame. */
public final class WorldRenderPatch implements Opcodes {
 static ClassNode read(ZipFile z,Path out,String name)throws Exception {
  ClassNode c=new ClassNode();Path p=out.resolve(name+".class");
  new ClassReader(Files.exists(p)?Files.readAllBytes(p):z.getInputStream(z.getEntry(name+".class")).readAllBytes()).accept(c,0);return c;
 }
 static void write(ClassNode c,Path out)throws Exception {
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=out.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
 public static void main(String[] a)throws Exception {
  Path out=Path.of(a[1]);String helper="com/duckswords/perf/WorldGeometry";
  try(ZipFile z=new ZipFile(a[0])) {
   ClassNode c=read(z,out,"com/duckswords/DucksWordsClient");int fields=0,lambdas=0;
   for(MethodNode m:c.methods)if(m.name.equals("onInitializeClient"))for(AbstractInsnNode n:m.instructions) {
    if(n instanceof FieldInsnNode f&&f.owner.equals("net/fabricmc/fabric/api/client/rendering/v1/WorldRenderEvents")&&f.name.equals("LAST")){f.name="AFTER_ENTITIES";fields++;}
    if(n instanceof InvokeDynamicInsnNode i&&i.desc.endsWith("WorldRenderEvents$Last;")) {
     if(!i.name.equals("onLast"))throw new IllegalStateException("Unexpected world event lambda");
     i.name="afterEntities";i.desc=i.desc.replace("WorldRenderEvents$Last;","WorldRenderEvents$AfterEntities;");lambdas++;
    }
   }
   if(fields!=1||lambdas!=1)throw new IllegalStateException("Expected one world event: "+fields+"/"+lambdas);write(c,out);
   c=read(z,out,"com/duckswords/util/RenderUtil");int redirects=0;
   for(MethodNode m:c.methods)if(Set.of("drawBox","drawFilledBox","drawLine","drawSphere","drawCircle").contains(m.name)) {
    if(m.name.equals("drawCircle")&&!m.desc.endsWith("IIF)V"))continue; // overload retains default width
    m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;
    int local=0;for(Type t:Type.getArgumentTypes(m.desc)){m.instructions.add(new VarInsnNode(t.getOpcode(ILOAD),local));local+=t.getSize();}
    m.instructions.add(new MethodInsnNode(INVOKESTATIC,helper,m.name,m.desc,false));m.instructions.add(new InsnNode(RETURN));redirects++;
   }
   if(redirects!=5)throw new IllegalStateException("Expected five geometry redirects, got "+redirects);write(c,out);
   c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(a[3]).resolve(helper+".class"))).accept(c,0);
   MethodNode m=c.methods.stream().filter(x->x.name.equals("tickDelta")).findFirst().orElseThrow();
   m.instructions.clear();m.instructions.add(new VarInsnNode(ALOAD,0));
   String ctx="net/fabricmc/fabric/api/client/rendering/v1/WorldRenderContext";
   if(a[2].equals("1.20.1"))m.instructions.add(new MethodInsnNode(INVOKEINTERFACE,ctx,"tickDelta","()F",true));
   else {
    m.instructions.add(new MethodInsnNode(INVOKEINTERFACE,ctx,"tickCounter","()Lnet/minecraft/class_9779;",true));m.instructions.add(new InsnNode(ICONST_0));
    m.instructions.add(new MethodInsnNode(INVOKEINTERFACE,"net/minecraft/class_9779","method_60637","(Z)F",true));
   }
   m.instructions.add(new InsnNode(FRETURN));write(c,out);
   System.out.println(a[2]+": world effects AFTER_ENTITIES once/frame; five batched geometry paths; native frame delta");
  }
 }
}
