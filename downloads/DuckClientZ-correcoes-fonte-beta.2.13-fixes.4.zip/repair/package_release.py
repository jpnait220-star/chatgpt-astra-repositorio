"""Package the tested incremental repair, sources and embedded recovery profiles."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json,hashlib,shutil,struct
ROOT=Path(__file__).resolve().parent.parent
B=ROOT/'repair';OUT=ROOT/'dist-fixes4'
VERSION='beta.2.13-fixes.4'
report=json.loads((ROOT/'build-report.json').read_text())
for version,entry in report.items():
    jar=Path(entry['jar'])
    assert hashlib.sha256(jar.read_bytes()).hexdigest()==entry['output_sha256']
    with ZipFile(jar) as z:
        assert z.testzip() is None
        assert not any(n.startswith(('net/minecraft/','net/fabricmc/')) for n in z.namelist())
        if version=='1.20.1':
            for n in z.namelist():
                if n.endswith('.class'):assert struct.unpack('>H',z.read(n)[6:8])[0]<=61,n
        folder=OUT/'Perfis_Padrao'/version;folder.mkdir(parents=True,exist_ok=True)
        (folder/'default.json').write_bytes(z.read('assets/duckswords/default-profile.json'))
        (folder/'active-profile.txt').write_text('default',encoding='utf-8')
    entry['jar']=jar.name
(OUT/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ['LEIA-ME_CORRECOES.txt','VALIDACAO_TECNICA.txt']:
    shutil.copy2(ROOT/name,OUT/name)
source=OUT/f'DuckClientZ-correcoes-fonte-{VERSION}.zip'
with ZipFile(source,'w',ZIP_DEFLATED) as z:
    for path in sorted(B.rglob('*')):
        rel=path.relative_to(B)
        if path.is_file() and path.suffix in ('.java','.py','.txt','.json') and (
            len(rel.parts)==1 or rel.parts[0] in ('src','stubs','teststubs','tests','resources')):
            z.write(path,'repair/'+rel.as_posix())
hashes=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='SHA256SUMS.txt':hashes.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(OUT).as_posix())
(OUT/'SHA256SUMS.txt').write_text('\n'.join(hashes)+'\n')
bundle=ROOT.parent/f'DuckClientZ-{VERSION}-correcoes-3-versoes.zip'
with ZipFile(bundle,'w',ZIP_DEFLATED) as z:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(OUT).as_posix())
with ZipFile(bundle) as z:assert z.testzip() is None
bundle.with_suffix('.zip.sha256').write_text(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
print(bundle.name,bundle.stat().st_size)
for version,entry in report.items():print(version,entry['output_sha256'])
