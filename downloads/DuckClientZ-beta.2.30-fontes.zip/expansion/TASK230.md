# beta.2.30 — final release preparation

All four final JARs built consistently. User prioritized delivery due to
remaining usage, then removed missing cosmetics from scope. Medal robot,
Herobrine, SantaHatV2 and three extra wings stay out; no substituted models
or further uploads needed. This was disclosed. 1.19.2 is a separate later port.

Implemented: linear per-frame menu layout, atlas fade, per-thread reusable Duck
cube vectors (local AND remote cosmetics), entity-identity remote list cache
invalidated by immutable server snapshots, one atlas quad per TargetHUD
particle, indexed visual particle types. Model geometry, UVs, animations,
particle count, physics and range are retained. Original Red/Medal/Skull
scythes and Bubble Aura prepared; optional middle CPS counter added.

Final checks passed: native API, real MixinExtras startup application, CRC,
menu/fade,19200 exact vertex comparisons per MC version with nested callbacks
and4 threads,200 old/new particle comparisons per version,10000 remote draws
with one profile-map read and lifecycle/reset/bounds checks, particle behavior,
source texture/animation preservation, CPS and actual Sodium0.5.13/Duck mixin
composition on1.20.1. Published229 updater tested with signed230 manifest and
actual final JARs: transfer, validation, wait for fixture process exit, backup,
replace one JAR, preserve profile, no same-version loop. No Minecraft GPU,
Pojav/Windows or FPS measurement. Do not claim a measured FPS gain.

Publish package_release230.py / release-manifest230.json. Existing229 files
immutable; only fixed DuckClientZ-update.json changes. Same Ed25519 key kept
outside source/build/public repo. Vercel /updates already rewrites to fixed
GitHub manifest; no deployment needed. Verify remote files and production
signed manifest after push.
