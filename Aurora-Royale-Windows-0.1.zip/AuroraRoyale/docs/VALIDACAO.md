# Validação — Aurora Royale 0.1 alpha

Engine: Godot 4.6.3, Linux x86_64. Renderização real OpenGL 4.5/Mesa llvmpipe, em servidor X virtual; áudio no dispositivo Dummy (sem audição física). Windows nativo e RX 580 não estão disponíveis neste ambiente. Testes headless não são um benchmark de GPU nem garantia de FPS.

O teste integrado valida 50 bots + um jogador, 150 suprimentos, rotas no mapa, câmera e animação, colocação/consumo/colisão/dano do gelo, recusa de sobreposição, construção de parede e gasto de materiais, tiros em adversários, saque/desbloqueio/troca/recarga de armas, zona, eliminações, dois jetpacks, queda de dano a distância, janelas com abertura, proteção e durabilidade de equipamentos, sons distintos, consumo/elevação do jetpack, conclusão do salto de janela, rampa/piso e deslocamento de bot sobre o terreno.

Capturas: cena real da partida e menu, após substituição do ruído por imagens fotográficas e limpeza do HUD. O pacote PCK é exportado pela engine e verificado com runtime independente da pasta de fontes. O executável de Windows é o runtime oficial Godot de mesma versão; não se afirma execução nativa em Windows.

Resultado final: **35 verificações aprovadas**, tanto no projeto quanto no PCK exportado, aberto por runtime independente a partir de uma pasta sem project.godot. Nenhum SCRIPT ERROR/FAIL nas execuções finais. Importação/exportação concluídas. A verificação por software não equivale a teste nativo em Windows ou audição em equipamento físico.
