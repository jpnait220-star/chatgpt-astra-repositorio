# Aurora Royale — Alpha 0.1

Jogo original de tiro em terceira pessoa feito em Godot 4.6.3. Partida solo offline, 50 bots e um jogador, na Ilha Vésper. Inspiração de mecânicas battle royale; sem personagens, marcas, arquivos ou serviços de Free Fire/Fortnite. É um protótipo jogável: arte, animações e comportamento dos bots ainda não têm o acabamento de um jogo comercial.

## Jogar no Windows

Extraia o ZIP Windows inteiro. Abra **AuroraRoyale.exe** e clique em **Jogar agora**. Mantenha AuroraRoyale.pck na mesma pasta do executável. Não é necessário instalar a Godot para jogar. Windows 10/11 de 64 bits e placa/driver com OpenGL 3.3. Não precisa de conta, servidor ou conexão de rede.

O pacote usa o executável oficial Godot 4.6.3 para Windows como runtime, acompanhado do PCK exportado. Isso aumenta o download comparado a um template de exportação enxuto. A execução e o pacote foram verificados com a mesma versão da engine no Linux; não foi executado Windows nativo nem medido desempenho em uma RX 580. Comece em Equilibrado; use Leve se precisar.

## Abrir e editar na Godot

Extraia o ZIP de fontes, importe `project.godot` no Godot **4.6.3** e pressione F6/F5. O primeiro import prepara os modelos, materiais e fontes. Para exportação padrão de Windows, instale os templates correspondentes na Godot e use o preset Windows Desktop. A pasta .godot é gerada automaticamente e não precisa vir no ZIP.

## Controles

| Ação | Tecla |
|---|---|
| Mover / olhar | W A S D / mouse |
| Correr / andar devagar | Shift / Ctrl |
| Pular / atravessar janela próxima | Espaço, olhando para a janela |
| Atirar / mirar | Mouse esquerdo / direito |
| Recarregar | R |
| Trocar arma | 1, 2, 3; armas 2 e 3 precisam ser coletadas |
| Parede de gelo | G |
| Construção | B liga/desliga; Z parede, X rampa, C piso |
| Construir / girar | Clique esquerdo / R no modo de construção |
| Usar kit | H; 2,8 s, interrompido ao receber dano |
| Coletar | Aproximar ou E |
| Jetpack raro | J liga/desliga; segurar Espaço para voar |
| Pausar / ajuda / tela cheia | Esc / F1 / F11 |

## Partida

- 50 bots físicos: circulam usando rotas, disputam equipamentos e combatem entre si e contra você. Paredes e gelo bloqueiam a visão e os tiros. Recalcular rotas leva um curto intervalo.
- 150 suprimentos iniciais: armas, munição, gelo, materiais, kits, coletes e capacetes. **Exatamente dois jetpacks** por partida, longe do ponto inicial. Um bot também pode encontrar um; ao ser eliminado, ele o deixa cair.
- Gelo: 600 de resistência, oito cargas iniciais, duração de 55 segundos. Madeira: parede com 250 de resistência, rampa e piso com 300. Custa 30 materiais por construção; máximo de 90 construções simultâneas. Há prévia de posição e verificação de espaço.
- Janelas são aberturas na geometria, com salto de passagem de 0,6 s. Fique perto, olhe para o outro lado e aperte Espaço. Destinos ocupados são recusados.
- Jetpack: 100 de combustível, consumo de 13 por segundo enquanto impulsiona, sem recarga passiva. Ao acabar, você cai normalmente. Desative com J para usar o salto comum/janelas.
- Coletes e capacetes têm níveis 1–3 e durabilidade. Coletes absorvem parte do dano no corpo; capacetes absorvem parte do dano na cabeça. Equipamento quebrado não protege. A zona ignora essas proteções.
- A zona começa a contrair depois de 75 segundos, em fases, até o confronto final. Vence o último sobrevivente. Ao morrer, o menu mostra as eliminações e permite recomeçar.

### Dano das armas

Dano base antes de colete/capacete, por acerto. A cabeça multiplica por 1,75. Os números que aparecem no combate refletem a vida perdida após proteção; impactos de uma mesma rajada de escopeta são somados.

| Arma | Perto | Queda de dano | Carregador |
|---|---|---|---|
| AUR-4, tecla 1 | 25 por projétil até 30 m | redução progressiva até 45% a 140 m | 30 |
| Vector, tecla 2 | 23 por projétil até 12 m, disparo rápido | até 28% a 65 m | 32 |
| Ruptura, tecla 3 | 8 projéteis × 19 até 8 m, se todos acertarem | até 7% a 45 m; perde muita força longe | 2 |

A escopeta é perigosa de perto; a submetralhadora favorece combate curto; o fuzil conserva melhor o dano a distância. Distância e dispersão também afetam quantos projéteis acertam.

## Imagem, som e desempenho

Texturas fotográficas CC0 para chão e concreto, personagem animado e texturizado, água com movimento, sombras e três níveis gráficos. O HUD foi revisado para retirar coordenadas, sequência numérica da bússola e contadores de depuração.

Sons distintos de armas, recarga, passos do jogador/bots, salto, aterrissagem, janela, cura, coleta, gelo, construção, destruição, impacto e motor do jetpack. Passos/saltos/aterrissagens usam amostras do TPS demo; demais efeitos são sínteses originais. Sons 3D diminuem à distância; limite de 28 sons pontuais simultâneos, variação de passos/tiros e limitador de pico no áudio. O ambiente de teste não tem saída física de áudio; reprodução/audição final precisa ser conferida no seu PC.

O cenário estático é agrupado em blocos para reduzir chamadas de desenho. Modelos distantes param animações e são ocultados fora do alcance visual. Não há promessa de FPS: depende da placa, processador, driver e resolução.

## Verificação

`godot --headless --path . -- --smoke` executa verificações integradas de partida, tiros, recursos, construções, equipamentos, zona, jetpack e janela. O modo de teste é separado da partida normal. As capturas são da engine em execução, com OpenGL por software. Veja `docs/VALIDACAO.md`.

## Créditos

- Personagem `player.glb`, seus materiais/texturas e amostras `step`, `jump`, `land`: **Juan Linietsky e Fernando Miguel Calabró**, Godot TPS demo, 2018, **CC-BY 3.0**. https://github.com/godotengine/tps-demo . Adaptações: seleção de cinco animações, materiais, escala e integração no jogo. Licença original em `assets/PERSONAGEM-LICENSE.md`.
- Grama/chão e concreto: **Poly Haven**, CC0. https://polyhaven.com/a/aerial_grass_rock e https://polyhaven.com/a/concrete_wall_006 . Downloads 1K usados de https://dl.polyhaven.org/ . Licença: https://polyhaven.com/license . As imagens são incorporadas ao projeto; não há dependência de API em execução.
- Rajdhani SemiBold: Indian Type Foundry, SIL OFL 1.1. `assets/FONT-HEADING-LICENSE.txt`.
- DejaVu Sans: DejaVu/Bitstream, licença em `assets/FONT-BODY-LICENSE.txt`.
- Godot Engine 4.6.3: Godot Engine contributors, MIT; `docs/GODOT-LICENSE.txt` e `docs/GODOT-COPYRIGHT.txt`.
- Código e cenário gerado do Aurora Royale: MIT, conforme `LICENSE.txt`. Esse licenciamento não substitui as licenças dos assets listados acima.
