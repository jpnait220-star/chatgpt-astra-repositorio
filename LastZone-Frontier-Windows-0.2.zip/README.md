# LastZone Frontier — alpha 0.2

Adaptação em Godot do seu **LastZone-v6.html**, com os sistemas de partida solo e a base visual do Aurora. Ainda é um protótipo: modelos, cenário e comportamento não têm acabamento de um jogo comercial. O modo Duo ficou de fora por enquanto.

## Jogar

Extraia o ZIP Windows inteiro e abra **LastZoneFrontier.exe**. Mantenha `LastZoneFrontier.pck` ao lado dele. Windows 10/11 de 64 bits, driver com OpenGL 3.3. Não precisa instalar Godot, criar conta ou conectar a um servidor.

O executável é o runtime oficial Godot 4.6.3 para Windows com o pacote exportado. O pacote foi executado e verificado no Linux com a mesma engine. **Windows nativo, RX 580 e audição dos sons em alto-falantes não foram testados neste ambiente.** Comece em Equilibrado; há modo Leve sem sombras.

## O que entrou nesta versão

- Ilha de 800 m: posições e dimensões das **51 casas, 18 estradas, 390 árvores**, relevo e áreas extraídos do HTML. Casas têm portas, janelas abertas, piso superior e rampas internas. O mapa e minimapa usam esse mesmo cenário.
- **50 bots e um jogador**, navegação por obstáculos, combate, procura de equipamentos, cobertura e disputa da zona. São 51 participantes; o HTML original usava 32.
- Sete armas: Pistola, UMP, AK-47, AWM, MP40, M1014 e SCAR. Carregadores, cadência, recarga, zoom e tabelas finais de dano/distância do HTML. Até três armas carregadas. A câmera **não sobe ao atirar**.
- Movimento do HTML: andar 5,2 m/s, correr 8,5, agachar 2,6; aceleração, salto, deslize, câmera de ombro, aproximação da câmera em obstáculos, visão frontal/primeira pessoa e olhar livre. Queda inicial e paraquedas na partida normal.
- Novo humano de proporções naturais, cabelo, roupas com textura, botas, acessórios e animações de corrida, agachamento, salto, tiro, recarga, cura, arremesso, direção e morte. Arma presa à mão; cofre permite escolher cores e acessórios e guarda o visual.
- Gelo arredondado, curvo, fosco, com colisão na malha e rachaduras conforme sofre dano. Mantém 600 de resistência e 55 segundos de duração. Construção extra opcional com parede, rampa e piso.
- Dez veículos por partida: carros e motos dirigíveis, aceleração, direção, freio, colisão e saída que verifica espaço livre.
- Inventário, mapa completo, teclas e botões do mouse configuráveis. Armas largadas preservam carregador e reserva. Eliminações deixam armas, medicamentos e recursos.
- Kitzinho +25 em 2 s; kitão +100 em 4 s. Dano interrompe cura. Coletes/capacetes de níveis 1–3 e durabilidade. Granadas físicas com fusível, dano por distância e bloqueio por paredes.
- Exatamente dois jetpacks iniciais, raros no mapa; impulso no ar, consumo 28/s, recarga no chão 15/s. Bots também podem coletá-los.
- Zona em seis etapas, esperas/contrações e tamanhos finais do HTML; a primeira espera 35 s e contrai até 270 m em 35 s. Último sobrevivente vence.
- Sons posicionais de passos, salto, janela, tiro, recarga, impacto, cura, gelo, coleta, granada, veículo e jetpack; música ambiente pode ser desligada no menu.

## Controles padrão

| Ação | Controle |
|---|---|
| Andar / olhar / correr | WASD / mouse / Shift |
| Pular, abrir paraquedas, impulsionar jetpack | Espaço |
| Agachar alternando / segurando | Ctrl / C |
| Deslizar / atravessar janela | Q / V (Espaço também reconhece janela próxima) |
| Atirar / mirar / recarregar | Esquerdo / direito / R |
| Três espaços de armas | 1 / 2 / 3 |
| Gelo / granada | T / G |
| Entrar ou sair do veículo / frear | B / Espaço |
| Kitzinho / kitão | H / J |
| Ativar jetpack encontrado | K; segure Espaço no ar |
| Coletar / ligar coleta automática | E / L |
| Inventário / mapa | Tab / M |
| Alternar câmera / olhar livre | F5 / Alt |
| Construção extra | N; Z parede, X rampa, C piso; esquerdo coloca, R gira |
| Pausa / ajuda / tela cheia | Esc / F1 / F11 |

O menu **Configurações · Teclas** permite trocar teclas e botões do mouse. Preferências ficam em `user://settings.cfg` no diretório de dados da Godot para Last Zone Frontier.

## Editar

Importe `project.godot` na **Godot 4.6.3**, espere o primeiro import e pressione F6/F5. O ZIP de fontes contém os recursos usados e seus créditos; `.godot` é gerada automaticamente. Para exportação padrão, instale os templates correspondentes e use o preset Windows Desktop.

`godot --headless --path . -- --smoke` executa os testes integrados, incluindo movimentação real, ossos animados, arma na mão, tiro sem elevar câmera, veículos, gelo e interfaces. Esse modo usa início no chão para os testes; a partida normal começa no ar. Veja `docs/VALIDACAO.md`. A pasta `tools` é auxiliar e não é incluída no jogo exportado.

## Créditos e licenças

- Regras e disposição do mapa: HTML enviado pelo usuário, **LastZone-v6.html**. Dados extraídos em `assets/lastzone_rules.json`, com SHA-256 do original. Código de adaptação e modelos procedurais novos sob MIT, `LICENSE.txt`; isso não altera direitos de materiais preexistentes.
- Humano, cabelo e animações: **Quaternius**, Universal Base Characters Standard e Universal Animation Library Standard 1/2, **CC0**. https://quaternius.com . Espelho da base combinada: https://github.com/NafisRayan/Animate-Rigged-Humanoid-No-Blender . Adaptações: seleção de animações, roupas com pesos, materiais, acessórios e integração. Licenças em `assets/characters/QUATERNIUS-LICENSE-*.txt`.
- Grama, concreto, malha de algodão e jeans: **Poly Haven, CC0**. https://polyhaven.com/a/aerial_grass_rock , https://polyhaven.com/a/concrete_wall_006 , https://polyhaven.com/a/cotton_jersey , https://polyhaven.com/a/denim_fabric . Recursos locais; sem API durante o jogo. https://polyhaven.com/license .
- Minivan/rodas: Godot Truck Town demo, **Godot Engine contributors, MIT**. https://github.com/godotengine/godot-demo-projects/tree/master/3d/truck_town . Licença em `assets/vehicles/GODOT-DEMO-LICENSE.md`. Som de motor é síntese própria; sons ambientes de terceiros desse demo não foram usados.
- Passos/salto/aterrissagem: **Juan Linietsky e Fernando Miguel Calabró**, Godot TPS demo (2018), **CC-BY 3.0**. https://github.com/godotengine/tps-demo . Licença em `assets/PERSONAGEM-LICENSE.md`; o personagem antigo desse demo foi removido, preservando somente esses sons. Demais efeitos sintetizados para o jogo; música adaptada da progressão de acordes do HTML.
- Fontes: Rajdhani SemiBold (Indian Type Foundry, SIL OFL) e DejaVu Sans (DejaVu/Bitstream). Licenças em `assets/FONT-*-LICENSE.txt`.
- Godot Engine 4.6.3: Godot Engine contributors, MIT; `docs/GODOT-LICENSE.txt` e `docs/GODOT-COPYRIGHT.txt`.
