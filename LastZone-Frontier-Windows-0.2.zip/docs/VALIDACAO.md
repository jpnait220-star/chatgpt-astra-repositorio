# Validação — LastZone Frontier alpha 0.2

Godot 4.6.3, Linux x86_64. Renderização real OpenGL 4.5/Mesa llvmpipe em tela X virtual. Áudio Dummy, sem audição física. Este ambiente não tem Windows nativo nem RX 580; testes headless não são medição de desempenho da GPU.

## Testes integrados

**55 verificações** cobrem 50 bots e um jogador, os dados de casas/estradas/armas do HTML, vida inicial 200, medicamentos e jetpacks, veículos, janelas, navegação e correspondência da altura física do terreno. Incluem orientação das faces visíveis do chão, piso superior físico e roupa com geometria, pesos e textura.

As animações são verificadas pela mudança efetiva dos ossos na corrida e pela posição da cabeça ao agachar, além da resolução de todos os clipes e do vínculo da arma com o osso da mão. O teste de disparo confirma consumo de bala e ausência de mudança no ângulo vertical da mira.

Também são exercitados inventário com três armas, recarga que conserva munição, danos por distância, tiros em adversário e gelo, rachaduras, recusa de gelo sobreposto, velocidades reais, cápsula agachada, deslize, cura/interrupção, impulso/recarga de jetpack, entrada/aceleração/movimento/saída de carro, passagem de janela, lançamento de granada, etapas da zona, eliminações com saque e conservação de munição da arma largada.

Os testes abrem inventário, mapa, cofre e remapeamento de controles. Confirmam que a prévia do cofre está dentro da árvore de cena, e que visual e botão do mouse remapeado persistem em arquivo de configuração. Um bot volta a simular e é observado se deslocando sobre o terreno.

Comando: `godot --headless --path . -- --smoke`. O início no chão é um recurso desse teste; a partida normal começa no ar. Use um diretório de dados separado para o teste, pois ele grava configurações de demonstração temporárias.

## Revisão visual e pacote

Capturas da engine em execução mostram partida, menu, cofre, gelo novo/danificado e veículos. A revisão encontrou e corrigiu faces invertidas no chão, estradas sem espessura, roupa recortada e botas fora da posição. As capturas são do próprio jogo, sem composição de uma tela de gameplay fictícia.

O pacote exportado é verificado usando uma cópia independente do runtime Linux e PCK, em uma pasta sem `project.godot`. O ZIP Windows contém o runtime oficial correspondente e o mesmo PCK. Isso verifica o conteúdo do pacote; **não equivale a executá-lo no Windows**. ZIPs têm CRC e SHA-256 verificados antes da publicação.

Em descarte de prévias/modelos e no encerramento, a Godot 4.6.3 pode registrar mensagens nativas `Parameter "material" is null` durante a remoção de dependências gráficas. Os testes funcionais passam e não registram `SCRIPT ERROR`; essas mensagens de limpeza da engine permanecem uma limitação conhecida desta alpha. Não são evidência de teste de imagem ou desempenho em hardware real.
