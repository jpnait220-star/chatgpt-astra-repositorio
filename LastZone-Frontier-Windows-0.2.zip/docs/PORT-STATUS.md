# LastZone HTML → Godot

Fonte fornecida pelo usuário: LastZone-v6.html. Regras finais extraídas do JavaScript executado, incluindo correções posteriores no arquivo. assets/lastzone_rules.json registra dados e hash SHA-256 do HTML original.

Requisitos confirmados: portar mapa, inventário, armas, menus/cofre e veículos; manter do Aurora texturas/gráficos, bots, mira, movimento, pulo, sons e funcionamento do gelo. Remover recoil que move a câmera. Substituir ambos os avatares rejeitados por humano animado. Gelo com aparência arredondada/fosca e rachaduras.

Defeito de animação confirmado: Godot removeu sufixo -cycle, importando Idlecombat/running_gun/walking_gun/jump_3_midair. O controlador antigo procurava nomes com sufixo, logo não iniciava nenhum clipe.

Projeto anterior permanece em /workspace/aurora-royale; trabalho novo em /workspace/lastzone-godot. Downloads 0.1 já publicados não serão substituídos.

Correção do usuário: a movimentação deve ser a do HTML, não a do Aurora (inclui câmera/velocidades/pulo). Manter mira sem elevação por recoil.

Decisão final: SEM DUO por enquanto; portar a partida SOLO completa, com veículos. Pedido de Duo foi cancelado explicitamente.
